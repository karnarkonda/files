from interface.repo_connector_interface import DbRepoConnectorInterface


@DbRepoConnectorInterface.register
class SQLServerConnector:
    pass
