""" Module for exposing & defining suppported data connectors. """
from enum import Enum
from .interface.repo_connector_interface import DbRepoConnectorInterface
from .snowflake_connector import SnowFlakeConnector
from .sql_server_connector import SQLServerConnector
from .azure_sql_connector import AzureSQLConnector


class ConnectorType(Enum):
    """
    An enumerated class that defines all supported data connectors
    """

    SNOWFLAKE = 'snowflake'
    AZURESQLSERVER = 'azuresqlserver'
    SQLSERVER = 'sqlserver'


# Map Connector fields
connectors_by_type = {
    ConnectorType.SNOWFLAKE: SnowFlakeConnector,
    ConnectorType.AZURESQLSERVER: AzureSQLConnector,
    ConnectorType.SQLSERVER: SQLServerConnector,
}


def get_connector(connector_type: ConnectorType) -> DbRepoConnectorInterface:
    """
    A method for fetching data connector object.
    Args:
    :param connector_type: ConnectorType enum
    """
    return connectors_by_type.get(connector_type, None)
