""" Module that abstracts interfaces for diverse data sources """

import abc
import sys
from ..exceptions import ConnectorDefinitionException


class DbRepoConnectorInterface(metaclass=abc.ABCMeta):
    """
    A virtual base class & interface for relational database
    data-repository connectors.
    """

    @classmethod
    def __subclasshook__(cls, subclass):
        return (
            hasattr(subclass, 'get_connection')
            and callable(subclass.get_connection)
            and hasattr(subclass, 'execute')
            and callable(subclass.execute)
            and hasattr(subclass, 'close')
            and callable(subclass.close)
            and NotImplemented
        )

    @abc.abstractmethod
    def get_connection(self, **kwargs):
        """
        A method that establishes a connection session with the target
        datastore.
        Args:
        :param **kwargs: Optional dictionary
        """
        info = sys.exc_info()[2]
        raise ConnectorDefinitionException(NotImplementedError, info)

    @abc.abstractmethod
    def execute(self, **kwargs):
        """
        A method that executes a query against the target datastore.
        Args:
        :param **kwargs: Optional dictionary
        """
        info = sys.exc_info()[2]
        raise ConnectorDefinitionException(NotImplementedError, info)

    @abc.abstractmethod
    def close(self, **kwargs):
        """
        A method that closes a session/connection to the target datastore.
        Args:
        :param **kwargs: Optional dictionary
        """
        info = sys.exc_info()[2]
        raise ConnectorDefinitionException(NotImplementedError, info)


class FileRepoConnectorInterface(metaclass=abc.ABCMeta):
    """
    A virtual base class & interface for flat file
    data-repository connectors.
    """
