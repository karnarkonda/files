""" Module for exposing & defining datarepo specific exceptions. """

from types import TracebackType
from typing import Union


class ConnectorDefinitionException(Exception):
    """
    Custom exception to handle connector definition errors
    Args:
    :param error: Exception Object
    :param exc_info: TracebackType with details about the error
    """

    def __init__(self, error, exc_info: Union[TracebackType, None] = None):
        filename = exc_info.tb_frame.f_code.co_filename if exc_info else ''
        line = exc_info.tb_lineno if exc_info else ''
        message = f'Unhandled exception "{error}" while processing\
              "{filename}" on line "{line}"'
        super().__init__(message)
