""" Module that encapsulates access to Snowflake database. """

from .interface.repo_connector_interface import DbRepoConnectorInterface


@DbRepoConnectorInterface.register
class SnowFlakeConnector:
    """
    A class that implements an interface into a Snowflake datastore.
    """
