"""Azuresql connector testsuite."""
