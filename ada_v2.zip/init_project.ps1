Write-Host ">>>> Initializing TFE project dependencies & tooling <<<<<<<" -ForegroundColor Green

$root_dir = Get-Location
$venv_dir = $root_dir.ToString() + "\.venv"
$activate_path = $venv_dir + "\Scripts\Activate.ps1"

# Setup Python virtual env for project
if (Test-Path -Path  $venv_dir) {
    Write-Host ">>> Found existing python virtual env: " $venv_dir -ForegroundColor Yellow
    & $activate_path
    python -m pip install --upgrade pip
    pip install -r .\requirements.txt

} else {
     Write-Host ">>> Creating python virtual Environment" -ForegroundColor Yellow
     python -m venv .venv
     & $activate_path
     python -m pip install --upgrade pip
     pip install -r .\requirements.txt
}

# Enable chocolatey to install Make tool
Write-Host ">>> Installing Chocolatey PM" -ForegroundColor Yellow
Set-ExecutionPolicy Bypass -Scope Process -Force; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
choco install make
make --version
Write-Host " >>> Initialization Completed <<<<" -ForegroundColor Gree
