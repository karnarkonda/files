# ADA Project - Analytics Donuts for Analysts (Upgrade)

### **Project Description**

**ADA project** (upgrade) is a structural improvement on the first version of the project as inherited from **IDS-analytics** AZDO project. 

The improvement focuses on 
- Defining proper and simple abstractions for commonly used concepts.
- Improved core library mantainability & extendability.
- Setup core library and implementations in a manner that adheres to standard and best practices.
- Enable automated unit, functional and integration tests of all components.
- Packaging core statistical capability as deployeable azure functions.
- Performance & scalability.

The **Ada** project consists of:
- [Ada](/ada) - Core statistics & data acquisition library - (Legacy version/version 1)
- [Ada (Upgrade)](/ada_v2) - Core statistics & data acquisition library - (Upgrade/version 2)


### *TODO: Project installation instructions*