

# Run check of ready portfloio batches.

# Process each batch key found.