#KRD constants for benchmarks
delta_statistic_id = 248
krd_statistic_ids = [211,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247]
pv_statistic_id = 255
benchmark_total_nav = 10000000000
index_total_nav = 10000000000

# Exposure standard mapping
unitary_benchmark_mapping = [
                               [1011, "IssuerMV_FxFMV_EquityMV"]
                             , [1012, "IssuerMV_FxFMV_EquityMV"]
                             , [1013, "IssuerMV_FxFMV_EquityMV"]
                             , [1014, "IssuerMV_FxFMV_EquityMV"]
                             , [1015, "IssuerMV_FxFMV_EquityMV"]
                             , [1016, "IssuerMV_FxFMV_EquityMV"]
                             , [1034, "IssuerMV_FxFMV_EquityMV"]
                             , [1071, "IssuerMV_FxFMV_EquityMV"]
                             , [1073, "IssuerMV_FxFMV_EquityMV"]
                             , [1170, "IssuerMV_FxFMV_EquityMV"]
            
                             , [1008, "IssuerMV_AI_FxFMV"]
                             , [1020, "IssuerMV_AI_FxFMV"]
                             , [1021, "IssuerMV_AI_FxFMV"]
                             , [1070, "IssuerMV_AI_FxFMV"]
                             , [1072, "IssuerMV_AI_FxFMV"]
                             , [1091, "IssuerMV_AI_FxFMV"]
                             , [1122, "IssuerMV_AI_FxFMV"]
                             
                             , [1076, "FxFMV_CommodityMV"]
            
                            ]

# Exposure standard mapping
normal_mapping = [
      [1048, "FxCcyDDelta"]
    , [1066, "FxCcyDDelta"]
    , [1068, "FxCcyDDelta"]
    , [1099, "FxCcyDDelta"]
    , [1001, "FxFMV"]
    , [1002, "FxFMV"]
    , [1045, "FxFMV"]
    , [1049, "FxFMV"]
    , [1050, "FxFMV"]
    , [1051, "FxFMV"]
    , [1052, "FxFMV"]
    , [1053, "FxFMV"]
    , [1054, "FxFMV"]
    , [1056, "FxFMV"]
    , [1058, "FxFMV"]
    , [1059, "FxFMV"]
    , [1062, "FxFMV"]
    , [1067, "FxFMV"]
    , [1069, "FxFMV"]
    , [1072, "IssuerNAV_FxMV"]
    , [1091, "IssuerNAV_FxMV"]
    , [1095, "FxFMV"]
    , [1101, "FxFMV"]
    , [1102, "FxFMV"]
    , [1103, "FxFMV"]
    , [1104, "FxFMV"]
    , [1107, "FxFMV"]
    , [1109, "FxFMV"]
    , [1111, "FxFMV"]
    , [1112, "FxFMV"]
    , [1113, "FxFMV"]
    , [1114, "FxFMV"]
    , [1115, "FxFMV"]
    , [1116, "FxFMV"]
    , [1119, "FxFMV"]
    , [1120, "FxFMV"]
    , [1126, "FxFMV"]
    , [1130, "FxFMV"]
    , [1131, "FxFMV"]
    , [1155, "FxFMV"]
    , [1156, "FxFMV"]
    , [1157, "FxFMV"]
    , [1158, "FxFMV"]
    , [1159, "FxFMV"]
    , [1160, "FxFMV"]
    , [1165, "FxFMV"]
    , [1025, "FxFMV"]
    , [0, "IssuerNAV_FxMV"]
    , [1030, "FxFMV_CommodityCmdtyDDelta"]
    , [1094, "FxFMV_CommodityCmdtyDDelta"]
    , [1031, "FxFMV_CommodityNot"]
    , [1110, "FxFMV_CommodityNot"]
    , [1034, "IssNotDe_FxFMV_EqtNotD"]
    , [1035, "IssNotDe_FxFMV_EqtNotD"]
    , [1036, "IssNotDe_FxFMV_EqtNotD"]
    , [1037, "IssNotDe_FxFMV_EqtNotD"]
    , [1038, "IssNotDe_FxFMV_EqtNotD"]
    , [1039, "IssNotDe_FxFMV_EqtNotD"]
    , [1040, "IssNotDe_FxFMV_EqtNotD"]
    , [1041, "IssNotDe_FxFMV_EqtNotD"]
    , [1042, "IssNotDe_FxFMV_EqtNotD"]
    , [1093, "IssNotDe_FxFMV_EqtNotD"]
    , [1123, "IssNotDe_FxFMV_EqtNotD"]
    , [1011, "IssuerMV_FxFMV_EquityMV"]
    , [1012, "IssuerMV_FxFMV_EquityMV"]
    , [1013, "IssuerMV_FxFMV_EquityMV"]
    , [1014, "IssuerMV_FxFMV_EquityMV"]
    , [1015, "IssuerMV_FxFMV_EquityMV"]
    , [1016, "IssuerMV_FxFMV_EquityMV"]
    , [1071, "IssuerMV_FxFMV_EquityMV"]
    # , [ 1098, 'IssuerMV_FxFMV_EquityMV']
    , [1125, "IssuerMV_FxFMV_EquityMV"]
    , [1143, "IssuerMV_FxFMV_EquityMV"]
    , [1144, "IssuerMV_FxFMV_EquityMV"]
    , [1145, "IssuerMV_FxFMV_EquityMV"]
    , [1146, "IssuerMV_FxFMV_EquityMV"]
    , [1147, "IssuerMV_FxFMV_EquityMV"]
    , [1148, "IssuerMV_FxFMV_EquityMV"]
    , [1149, "IssuerMV_FxFMV_EquityMV"]
    , [1170, "IssuerMV_FxFMV_EquityMV"]
    , [1003, "IssuerMV_AI_FxFMV"]
    , [1004, "IssuerMV_AI_FxFMV"]
    , [1005, "IssuerMV_AI_FxFMV"]
    , [1006, "IssuerMV_AI_FxFMV"]
    , [1007, "IssuerMV_AI_FxFMV"]
    , [1008, "IssuerMV_AI_FxFMV"]
    , [1009, "IssuerMV_AI_FxFMV"]
    , [1010, "IssuerMV_AI_FxFMV"]
    , [1065, "IssuerMV_AI_FxFMV"]
    , [1100, "IssuerMV_AI_FxFMV"]
    , [1117, "IssuerMV_AI_FxFMV"]
    , [1118, "IssuerMV_AI_FxFMV"]
    , [1128, "IssuerMV_AI_FxFMV"]
    , [1132, "IssuerMV_AI_FxFMV"]
    , [1133, "IssuerMV_AI_FxFMV"]
    , [1017, "IssuerMV_AI_FxFMV"]
    , [1018, "IssuerMV_AI_FxFMV"]
    , [1019, "IssuerMV_AI_FxFMV"]
    , [1020, "IssuerMV_AI_FxFMV"]
    , [1021, "IssuerMV_AI_FxFMV"]
    , [1070, "IssuerMV_AI_FxFMV"]
    , [1122, "IssuerMV_AI_FxFMV"]
    , [1127, "IssuerMV_AI_FxFMV"]
    , [1134, "IssuerMV_AI_FxFMV"]
    , [1135, "IssuerMV_AI_FxFMV"]
    , [1136, "IssuerMV_AI_FxFMV"]
    , [1137, "IssuerMV_AI_FxFMV"]
    , [1138, "IssuerMV_AI_FxFMV"]
    , [1139, "IssuerMV_AI_FxFMV"]
    , [1140, "IssuerMV_AI_FxFMV"]
    , [1141, "IssuerMV_AI_FxFMV"]
    , [1142, "IssuerMV_AI_FxFMV"]
    , [1150, "IssuerMV_AI_FxFMV"]
    , [1151, "IssuerMV_AI_FxFMV"]
    , [1166, "IssuerMV_AI_FxFMV"]
    , [1167, "IssuerMV_AI_FxFMV"]
    , [1168, "IssuerMV_AI_FxFMV"]
    , [1057, "IssuerNot_FxFMV_Swap"]
    , [1097, "IssuerNot_FxFMV_Swap"]
    , [1162, "IssuerNot_FxFMV_Swap"]
    , [1032, "IssuerNot_FxFMV_Swap"]
    , [1108, "IssuerNot_FxFMV_Swap"]
    , [1033, "IssuerNot_FxFMV_CDO"]
    , [1060, "IssuerNot_FxFMV_Fwd"]
    , [1061, "IssuerNot_FxFMV_Fwd"]
    , [1063, "IssuerNot_FxFMV_Fut"]
    , [1043, "IssuerNot_FxFMV_EquityNot_2Legs"]
    , [1044, "IssuerNot_FxFMV_EquityNot_2Legs"]
    , [1154, "IssuerNot_FxFMV_EquityNot_2Legs"]
    , [1046, "IssuerNot_FxFMV_EquityNot_1_Fut"]
    , [1124, "IssuerNot_FxFMV_EquityNot_1_Fut"]
    , [1105, "IssuerNot_FxFMV_EquityNot_1_Fwd"]
    , [1106, "IssuerNot_FxFMV_EquityNot_1_Fwd"]
    , [1047, "IssuerNotDelta_FxFMV_Bond"]
    , [1055, "IssuerNotDelta_FxFMV_Fut"]
    , [1096, "IssuerNotDelta_FxFMV_Fut"]
    , [1152, "IssuerNotDelta_FxFMV_CDS"]
    , [1098, "IssuerMV_AI_FxFMV"]
    , [1161, "IssuerMV_AI_FxFMV"]
    , [1172, "IssuerMV_AI_FxFMV"]
]

# Exposure standard mapping
exotic_mapping = [
      ["Foreign Exchange Single Barrier Option", "FxCcyDDelta"]
    , ["Foreign Exchange Option", "FxCcyDDelta"]
    , ["Foreign Exchange Digital Barrier Option", "FxCcyDDelta"]
    , ["FX Barrier Digital Option", "FxCcyDDelta"]
    , ["FX Digital Option", "FxCcyDDelta"]
    , ["Break-Even Inflation Swap", "FxPV"]
    , ["Cap", "FxPV"]
    , ["Cash", "FxPV"]
    , ["Cash Flow Stream", "FxPV"]
    , ["Equity Variance Swap", "FxPV"]
    , ["Foreign Exchange Forward", "FxPV"]
    , ["Foreign Exchange Futures", "FxPV"]
    , ["Forward Rate Agreement", "FxPV"]
    , ["FX Forward", "FxPV"]
    , ["FX Variance Swap", "FxPV"]
    , ["Interest Rate Future", "FxPV"]
    , ["Money Market", "FxPV"]
    , ["Option on Interest Rate Future", "FxPV"]
    , ["swap", "FxPV"]
    , ["Constant Maturity Swap Spread Option", "FxPV"]
    , ["Inflation Indexed Cap/Floor", "FxPV"]
    , ["Inflation Swap", "FxPV"]
    , ["Overnight Indexed Swap", "FxPV"]
    , ["Rate Swap", "FxPV"]
    , ["Swaption", "FxPV"]
    , ["Dual Asset Option", "FxPV"]
    , ["Dual Binary Option", "FxPV"]
    , ["Floor", "FxPV"]
    , ["Commodity Basis Swap", "FxPV_CommoCmdtyDDelta"]
    , ["Commodity Future", "FxPV_CommoCmdtyDDelta"]
    , ["Commodity", "FxPV_CommoCmdtyDDelta"]
    , ["Option on Commodity Future", "FxPV_CommoCmdtyDDelta"]
    , ["equity", "IssEqtyDelta_FxPV_EqEqtDe"]
    , ["Equity Option", "IssEqtyDelta_FxPV_EqEqtDe"]
    , ["Option on Equity Future", "IssEqtyDelta_FxPV_EqEqtDe"]
    , ["contractForDifference", "IssEqtyDelta_FxPV_EqEqtDe"]
    , ["Equity", "IssEqtyDelta_FxPV_EqEqtDe"]
    , ["Equity Future", "IssEqtyDelta_FxPV_EqEqtDe"]
    , ["Equity Swap", "IssEqtyDelta_FxPV_EqEqtDe"]
    , ["Equity Single Barrier Option", "IssEqtyDelta_FxPV_EqEqtDe"]
    , ["Bond Future", "IssuerNot_FxPV"]
    , ["CDS Index", "IssuerNot_FxPV"]
    , ["cdsIndex", "IssuerNot_FxPV"]
    , ["Credit Default Swap", "IssuerNot_FxPV"]
    , ["Credit Default Swap Option", "IssuerNotDelta_FxPV"]
    , ["Bond Option", "IssuerNotDelta_FxPV"]
    , ["Option on Bond Future", "IssuerNotDelta_FxPV"]
    , ["Bond", "IssuerPV_FxPV"]
    , ["Floating Rate Note", "IssuerPV_FxPV"]
    , ["Generic Convertible Bond", "IssuerPV_FxPV"]
    , ["Generic Bond", "IssuerPV_FxPV"]
    , ["Generic Inflation Indexed Bond", "IssuerPV_FxPV"]
    , ["UK Index-linked Gilt", "IssuerPV_FxPV"]
    , ["Mandatory Convertible Bond", "IssuerPV_FxPV"]
    , ["Synthetic CDO", "IssuerPV_FxPV"]
    , ["Generic Mortgage Backed Security", "IssuerPV_FxPV"]
    , ["Securitized Product", "IssuerPV_FxPV"]
    , ["Generic Convertible Bond Option", "IssuerNotDelta_FxPV_EqtyEqtDDe"]
    , ["Convertible Bond", "IssuerPV_FxPV_EqtyEqtDDe"]
    , ["dualAssetOption", "FxPV"]
    , ["Credit Index Option", "IssuerNotDelta_FxPV"]    
]

# Pooled Funds Variables
pooled_fund_psp_instrument_categorization_codes = [1025, 1125]

exposure_extended_columns = [
      "PositionDate"
    , "Object_Type"
    , "Position_Type"
    , "Position_Source"
    , "Portfolio_PSPPortfolioCode"
    , "Portfolio_PSPPortfolioID"
    , "Portfolio_Name"
    , "Instrument_CurrencyCode"
    , "Instrument_ReportingCurrencyCode"
    , "Constituent_CurrencyCode"
    , "Instrument_PSPInstrumentID"
    , "Instrument_PSPInstrumentCategorizationID"
    , "Instrument_PSPInstrumentCategorizationCode"
    , "Instrument_Description"
    , "Instrument_FinancialMaturityDate"
    , "UltimateUnderlying_PSPInstrumentID"
    , "UltimateUnderlying_PSPInstrumentCategorizationID"
    , "UltimateUnderlying_PSPInstrumentCategorizationCode"
    , "UltimateUnderlying_Description"
    , "UltimateUnderlying_FinancialMaturityDate"
    , "Constituee_PSPInstrumentID"
    , "Constituee_Type"
    , "Constituent_PSPInstrumentID"
    , "Constituent_PSPInstrumentCategorizationID"
    , "Constituent_PSPInstrumentCategorizationCode"
    , "Constituent_Description"
    , "Issuer_Code"
    , "Issuer_UltimateParentCode"
    , "Leg_PSPInstrumentLegID"
    , "Leg_Type"
    , "Leg_Direction"
    , "Leg_PositionLevel"
    , "Option_Style"
    , "Position_MarketValue_CAD"
    , "Position_NetAssetValue_CAD"
    , "Constituent_MarketValue_CAD"
    , "Constituent_NetAssetValue_CAD"
    , "Constituent_Weight"
    , "Constituent_Exposure_Issuer"
    , "Constituent_Exposure_Equity"
    , "Constituent_Exposure_FX"
    , "Constituent_Exposure_Commodity"
    , "MostRecent_CalendarKey"
    , "BatchKey"
    , "Portfolio_Key"
    , "Instrument_Key"
    , "RiskMetricsPositionType"
]

exposure_extended_mapping = { 'PositionDate' : 'POSITIONDATE'
                            , 'SourceDate' : 'SOURCEDATE'
                            , 'L1_PSPPortfolioCode' : 'L1_PSPPORTFOLIOCODE'
                            , 'L1_PSPPortfolioID' : 'L1_PSPPORTFOLIOID'
                            , 'L1_PortfolioName' : 'L1_PORTFOLIONAME'
                            , 'L2_PSPPortfolioCode' : 'L2_PSPPORTFOLIOCODE'
                            , 'L2_PSPPortfolioID' : 'L2_PSPPORTFOLIOID'
                            , 'L2_PortfolioName' : 'L2_PORTFOLIONAME'
                            , 'L3_PSPPortfolioCode' : 'L3_PSPPORTFOLIOCODE'
                            , 'L3_PSPPortfolioID' : 'L3_PSPPORTFOLIOID'
                            , 'L3_PortfolioName' : 'L3_PORTFOLIONAME'
                            , 'L4_PSPPortfolioCode' : 'L4_PSPPORTFOLIOCODE'
                            , 'L4_PSPPortfolioID' : 'L4_PSPPORTFOLIOID'
                            , 'L4_PortfolioName' : 'L4_PORTFOLIONAME'
                            , 'InvestmentStrategyCalc' : 'INVESTMENTSTRATEGYCALC'
                            , 'Portfolio_Name' : 'PORTFOLIO_NAME'
                            , 'Portfolio_Type' : 'PORTFOLIO_TYPE'
                            , 'Portfolio_MarketType' : 'PORTFOLIO_MARKETTYPE'
                            , 'Portfolio_AssetClass' : 'PORTFOLIO_ASSETCLASS'
                            , 'Portfolio_InvestmentTeam' : 'PORTFOLIO_INVESTMENTTEAM'
                            , 'Portfolio_ManagerType' : 'PORTFOLIO_MANAGERTYPE'
                            , 'Portfolio_ManagingStyle' : 'PORTFOLIO_MANAGINGSTYLE'
                            , 'Portfolio_ManagingDepartment' : 'PORTFOLIO_MANAGINGDEPARTMENT'
                            , 'Portfolio_OwnerDepartment' : 'PORTFOLIO_OWNERDEPARTMENT'
                            , 'Object_Type' : 'OBJECT_TYPE'
                            , 'Position_Type' : 'POSITION_TYPE'
                            , 'Position_Source' : 'POSITION_SOURCE'
                            , 'Instrument_CurrencyCode' : 'INSTRUMENT_CURRENCYCODE'
                            , 'Instrument_ReportingCurrencyCode' : 'INSTRUMENT_REPORTINGCURRENCYCODE'
                            , 'Constituent_CurrencyCode' : 'CONSTITUENT_CURRENCYCODE'
                            , 'Instrument_PSPInstrumentID' : 'INSTRUMENT_PSPINSTRUMENTID'
                            , 'Instrument_PSPInstrumentCategorizationID' : 'INSTRUMENT_PSPINSTRUMENTCATEGORIZATIONID'
                            , 'Instrument_PSPInstrumentCategorizationCode' : 'INSTRUMENT_PSPINSTRUMENTCATEGORIZATIONCODE'
                            , 'Instrument_Description' : 'INSTRUMENT_DESCRIPTION'
                            , 'Instrument_FinancialMaturityDate' : 'INSTRUMENT_FINANCIALMATURITYDATE'
                            , 'UltimateUnderlying_PSPInstrumentID' : 'ULTIMATEUNDERLYING_PSPINSTRUMENTID'
                            , 'UltimateUnderlying_PSPInstrumentCategorizationID' : 'ULTIMATEUNDERLYING_PSPINSTRUMENTCATEGORIZATIONID'
                            , 'UltimateUnderlying_PSPInstrumentCategorizationCode' : 'ULTIMATEUNDERLYING_PSPINSTRUMENTCATEGORIZATIONCODE'
                            , 'UltimateUnderlying_Description' : 'ULTIMATEUNDERLYING_DESCRIPTION'
                            , 'UltimateUnderlying_FinancialMaturityDate' : 'ULTIMATEUNDERLYING_FINANCIALMATURITYDATE'
                            , 'UltimateUnderlying_IssuerCode' : 'ULTIMATEUNDERLYING_ISSUERCODE'
                            , 'Constituent_PSPInstrumentID' : 'CONSTITUENT_PSPINSTRUMENTID'
                            , 'Constituent_PSPInstrumentCategorizationID' : 'CONSTITUENT_PSPINSTRUMENTCATEGORIZATIONID'
                            , 'Constituent_PSPInstrumentCategorizationCode' : 'CONSTITUENT_PSPINSTRUMENTCATEGORIZATIONCODE'
                            , 'Constituent_Description' : 'CONSTITUENT_DESCRIPTION'
                            , 'Constituent_FinancialMaturityDate' : 'CONSTITUENT_FINANCIALMATURITYDATE'
                            , 'Constituent_IssuerCode' : 'CONSTITUENT_ISSUERCODE'
                            , 'Constituent_GICSSectorCode' : 'CONSTITUENT_GICSSECTORCODE'
                            , 'Constituent_GICSSectorName' : 'CONSTITUENT_GICSSECTORNAME'
                            , 'Constituent_GICSIndustryGroupName' : 'CONSTITUENT_GICSINDUSTRYGROUPNAME'
                            , 'Constituent_GICSIndustryCode' : 'CONSTITUENT_GICSINDUSTRYCODE'
                            , 'Constituent_GICSIndustryName' : 'CONSTITUENT_GICSINDUSTRYNAME'
                            , 'Constituent_GICSSubIndustryName' : 'CONSTITUENT_GICSSUBINDUSTRYNAME'
                            , 'Constituent_GICSIndustryGroupCode' : 'CONSTITUENT_GICSINDUSTRYGROUPCODE'
                            , 'Constituent_GICSSubIndustryCode' : 'CONSTITUENT_GICSSUBINDUSTRYCODE'
                            , 'Constituent_Weight' : 'CONSTITUENT_WEIGHT'
                            , 'Leg_PSPInstrumentLegID' : 'LEG_PSPINSTRUMENTLEGID'
                            , 'Leg_Type' : 'LEG_TYPE'
                            , 'Leg_Direction' : 'LEG_DIRECTION'
                            , 'Leg_PositionLevel' : 'LEG_POSITIONLEVEL'
                            , 'Option_Style' : 'OPTION_STYLE'
                            , 'Issuer_Code' : 'ISSUER_CODE'
                            , 'Issuer_Name' : 'ISSUER_NAME'
                            , 'Issuer_PSPLegalEntityID' : 'ISSUER_PSPLEGALENTITYID'
                            , 'Issuer_RiskLocationCountryCode' : 'ISSUER_RISKLOCATIONCOUNTRYCODE'
                            , 'Issuer_NormalizedCountryCode' : 'ISSUER_NORMALIZEDCOUNTRYCODE'
                            , 'Issuer_BICSBETAClassificationID' : 'ISSUER_BICSBETACLASSIFICATIONID'
                            , 'Issuer_BICSBETASectorCode' : 'ISSUER_BICSBETASECTORCODE'
                            , 'Issuer_BICSBETASectorName' : 'ISSUER_BICSBETASECTORNAME'
                            , 'Issuer_BICSBETAIndustryGroupCode' : 'ISSUER_BICSBETAINDUSTRYGROUPCODE'
                            , 'Issuer_BICSBETAIndustryGroupName' : 'ISSUER_BICSBETAINDUSTRYGROUPNAME'
                            , 'Issuer_BICSBETAIndustryCode' : 'ISSUER_BICSBETAINDUSTRYCODE'
                            , 'Issuer_BICSBETAIndustryName' : 'ISSUER_BICSBETAINDUSTRYNAME'
                            , 'Issuer_BICSBETASubIndustryCode' : 'ISSUER_BICSBETASUBINDUSTRYCODE'
                            , 'Issuer_BICSBETASubIndustryName' : 'ISSUER_BICSBETASUBINDUSTRYNAME'
                            , 'Issuer_BICSBETAActivityCode' : 'ISSUER_BICSBETAACTIVITYCODE'
                            , 'Issuer_BICSBETAActivityName' : 'ISSUER_BICSBETAACTIVITYNAME'
                            , 'Issuer_BICSBETASubActivityCode' : 'ISSUER_BICSBETASUBACTIVITYCODE'
                            , 'Issuer_BICSBETASubActivityName' : 'ISSUER_BICSBETASUBACTIVITYNAME'
                            , 'Issuer_BICSBETASegmentCode' : 'ISSUER_BICSBETASEGMENTCODE'
                            , 'Issuer_BICSBETASegmentName' : 'ISSUER_BICSBETASEGMENTNAME'
                            , 'Issuer_LongTerm_LowestNormalizedRating' : 'ISSUER_LONGTERM_LOWESTNORMALIZEDRATING'
                            , 'Issuer_LongTerm_HighestNormalizedRating' : 'ISSUER_LONGTERM_HIGHESTNORMALIZEDRATING'
                            , 'Issuer_ShortTerm_LowestNormalizedRating' : 'ISSUER_SHORTTERM_LOWESTNORMALIZEDRATING'
                            , 'Issuer_ShortTerm_HighestNormalizedRating' : 'ISSUER_SHORTTERM_HIGHESTNORMALIZEDRATING'
                            , 'Issuer_UltimateParentCode' : 'ISSUER_ULTIMATEPARENTCODE'
                            , 'Issuer_Name_UltimateParent' : 'ISSUER_ULTIMATEPARENTNAME'
                            , 'Issuer_UltimateParentPSPLegalEntityID' : 'ISSUER_ULTIMATEPARENTPSPLEGALENTITYID'
                            , 'Issuer_UltimateParentRiskLocationCountryCode' : 'ISSUER_ULTIMATEPARENTRISKLOCATIONCOUNTRYCODE'
                            , 'Issuer_UltimateParentNormalizedCountryCode' : 'ISSUER_ULTIMATEPARENTNORMALIZEDCOUNTRYCODE'
                            , 'Issuer_UltimateParentBICSBETAClassificationID' : 'ISSUER_ULTIMATEPARENTBICSBETACLASSIFICATIONID'
                            , 'Issuer_UltimateParentBICSBETASectorCode' : 'ISSUER_ULTIMATEPARENTBICSBETASECTORCODE'
                            , 'Issuer_UltimateParentBICSBETASectorName' : 'ISSUER_ULTIMATEPARENTBICSBETASECTORNAME'
                            , 'Issuer_UltimateParentBICSBETAIndustryGroupCode' : 'ISSUER_ULTIMATEPARENTBICSBETAINDUSTRYGROUPCODE'
                            , 'Issuer_UltimateParentBICSBETAIndustryGroupName' : 'ISSUER_ULTIMATEPARENTBICSBETAINDUSTRYGROUPNAME'
                            , 'Issuer_UltimateParentBICSBETAIndustryCode' : 'ISSUER_ULTIMATEPARENTBICSBETAINDUSTRYCODE'
                            , 'Issuer_UltimateParentBICSBETAIndustryName' : 'ISSUER_ULTIMATEPARENTBICSBETAINDUSTRYNAME'
                            , 'Issuer_UltimateParentBICSBETASubIndustryCode' : 'ISSUER_ULTIMATEPARENTBICSBETASUBINDUSTRYCODE'
                            , 'Issuer_UltimateParentBICSBETASubIndustryName' : 'ISSUER_ULTIMATEPARENTBICSBETASUBINDUSTRYNAME'
                            , 'Issuer_UltimateParentBICSBETAActivityCode' : 'ISSUER_ULTIMATEPARENTBICSBETAACTIVITYCODE'
                            , 'Issuer_UltimateParentBICSBETAIndustryName' : 'ISSUER_ULTIMATEPARENTBICSBETAINDUSTRYNAME'
                            , 'Issuer_UltimateParentBICSBETASubActivityCode' : 'ISSUER_ULTIMATEPARENTBICSBETASUBACTIVITYCODE'
                            , 'Issuer_UltimateParentBICSBETASubActivityName' : 'ISSUER_ULTIMATEPARENTBICSBETASUBACTIVITYNAME'
                            , 'Issuer_UltimateParentBICSBETASegmentCode' : 'ISSUER_ULTIMATEPARENTBICSBETASEGMENTCODE'
                            , 'Issuer_UltimateParentBICSBETASegmentName' : 'ISSUER_ULTIMATEPARENTBICSBETASEGMENTNAME'
                            , 'Issuer_LongTerm_LowestNormalizedRating_UltimateParent' : 'ISSUER_LONGTERM_LOWESTNORMALIZEDRATING_ULTIMATEPARENT'
                            , 'Issuer_LongTerm_HighestNormalizedRating_UltimateParent' : 'ISSUER_LONGTERM_HIGHESTNORMALIZEDRATING_ULTIMATEPARENT'
                            , 'Issuer_ShortTerm_LowestNormalizedRating_UltimateParent' : 'ISSUER_SHORTTERM_LOWESTNORMALIZEDRATING_ULTIMATEPARENT'
                            , 'Issuer_ShortTerm_HighestNormalizedRating_UltimateParent' : 'ISSUER_SHORTTERM_HIGHESTNORMALIZEDRATING_ULTIMATEPARENT'
                            , 'Constituent_NetAssetValue_CAD' : 'CONSTITUENT_NETASSETVALUE_CAD'
                            , 'Constituent_Exposure_FX' : 'CONSTITUENT_EXPOSURE_FX'
                            , 'Constituent_Exposure_Issuer' : 'CONSTITUENT_EXPOSURE_ISSUER'
                            , 'Constituent_Exposure_Equity' : 'CONSTITUENT_EXPOSURE_EQUITY'
                            , 'Constituent_Exposure_Commodity' : 'CONSTITUENT_EXPOSURE_COMMODITY'
                            , 'MostRecent_CalendarKey' : 'MOSTRECENT_CALENDARKEY'
                            , 'BatchKey' : 'BATCHKEY'
                            , 'Portfolio_Key' : 'PORTFOLIO_KEY'
                            , 'Instrument_Key' : 'INSTRUMENT_KEY'
                            , 'RiskMetricsPositionType' : 'RISKMETRICSPOSITIONTYPE'
                            , 'calc_formula' : 'CALC_FORMULA'
                            , 'calc_type' : 'CALC_TYPE'
                            }


exposure_non_extended_columns = [
      "PositionDate"
    , "Object_Type"
    , "Position_Type"
    , "Position_Source"
    , "Portfolio_PSPPortfolioCode"
    , "Portfolio_PSPPortfolioID"
    , "Instrument_CurrencyCode"
    , "Instrument_ReportingCurrencyCode"
    , "Instrument_PSPInstrumentID"
    , "Instrument_PSPInstrumentCategorizationID"
    , "Instrument_PSPInstrumentCategorizationCode"
    , "Instrument_Description"
    , "UltimateUnderlying_PSPInstrumentID"
    , "UltimateUnderlying_PSPInstrumentCategorizationID"
    , "UltimateUnderlying_PSPInstrumentCategorizationCode"
    , "UltimateUnderlying_Description"
    , "UltimateUnderlying_IssuerCode"
    , "UltimateUnderlying_IndexProxyPSPInstrumentID"
    , "Instrument_RiskLocationCountryCode"
    , "Instrument_NormalizedCountryCode"
    , "Instrument_GeographyName"
    , "Instrument_BICSBETAClassificationID"
    , "Instrument_BICSBETASectorCode"
    , "Instrument_BICSBETASectorName"
    , "Instrument_BICSBETAIndustryGroupCode"
    , "Instrument_BICSBETAIndustryGroupName"
    , "Instrument_BICSBETAIndustryCode"
    , "Instrument_BICSBETAIndustryName"
    , "Instrument_BICSBETASubIndustryCode"
    , "Instrument_BICSBETASubIndustryName"
    , "Instrument_BICSBETAActivityCode"
    , "Instrument_BICSBETAActivityName"
    , "Instrument_BICSBETASubActivityCode"
    , "Instrument_BICSBETASubActivityName"
    , "Instrument_BICSBETASegmentCode"
    , "Instrument_BICSBETASegmentName"
    , "Instrument_GICSSectorCode"
    , "Instrument_GICSSectorName"
    , "Instrument_GICSIndustryGroupName"
    , "Instrument_GICSIndustryCode"
    , "Instrument_GICSIndustryName"
    , "Instrument_GICSSubIndustryName"
    , "Leg_PSPInstrumentLegID"
    , "Leg_Type"
    , "Leg_Direction"
    , "Leg_PositionLevel"
    , "Option_Style"
    , "Position_NetAssetValue_CAD"
    , "Exposure_FI"
    , "Exposure_CR"
    , "Exposure_Issuer"
    , "Exposure_Equity"
    , "Exposure_FX"
    , "Exposure_Commodity"
    , 'Index_Key'
    , "MostRecent_CalendarKey"
    , "BatchKey"
    , "Portfolio_Key"
    , "Instrument_Key"
    , "RiskMetricsPositionType"
    , "normal_calculation_family"
    , "exotic_calculation_family"
    , "unitary_benchmark_calculation_family"
    , "use_pooled_fund_calculations"
    , "SourceDate"
    , "Instrument_FinancialMaturityDate"
    , "UltimateUnderlying_FinancialMaturityDate"
]

constituee_columns = [
      "PositionDate"
    , 'SourceDate'
    , "Constituee_PSPInstrumentID"
    , "Constituee_Type"
    , "Constituent_PSPInstrumentID"
    , "Constituent_Family"
    , "Constituent_PSPInstrumentCategorizationID"
    , "Constituent_PSPInstrumentCategorizationCode"
    , "Constituent_Description"
    , "Constituent_Market"
    , "Constituent_Type"
    , "Constituent_IssuerCode"
    , "Constituent_CurrencyCode"
    #, "Constituent_AccountingCurrencyCode"
    #, "Constituent_EconomicCurrencyCode"
    , "Constituent_Weight"
    , "Constituent_IssuerExposureFactor"
    , "Constituent_EquityExposureFactor"
    , "Constituent_FinancialMaturityDate"
]


final_positions_columns = [
      "PositionDate"
    , "SourceDate"
    , "Portfolio_PSPPortfolioCode"
    , "Portfolio_PSPPortfolioID"
    , "Benchmark_PSPBenchmarkCode"
    , "Benchmark_PSPBenchmarkID"
    , "Index_PSPInstrumentID"
    , "Object_Type"
    , "Position_Type"
    , "Position_Source"
    , "Instrument_CurrencyCode"
    , "Instrument_ReportingCurrencyCode"
    , "Instrument_PSPInstrumentID"
    , "Instrument_Family"
    , "Instrument_PSPInstrumentCategorizationID"
    , "Instrument_PSPInstrumentCategorizationCode"
    , "Instrument_Description"
    , "Instrument_Market"
    , "Instrument_Type"
    , "Instrument_IssuerCode"
    , "Instrument_FinancialMaturityDate"
    , "Instrument_IndexProxyPSPInstrumentID"
    , "Instrument_RiskLocationCountryCode"
    , "Instrument_NormalizedCountryCode"
    , "Instrument_GeographyName"
    , "Instrument_BICSBETAClassificationID"
    , "Instrument_BICSBETASectorCode"
    , "Instrument_BICSBETASectorName"
    , "Instrument_BICSBETAIndustryGroupCode"
    , "Instrument_BICSBETAIndustryGroupName"
    , "Instrument_BICSBETAIndustryCode"
    , "Instrument_BICSBETAIndustryName"
    , "Instrument_BICSBETASubIndustryCode"
    , "Instrument_BICSBETASubIndustryName"
    , "Instrument_BICSBETAActivityCode"
    , "Instrument_BICSBETAActivityName"
    , "Instrument_BICSBETASubActivityCode"
    , "Instrument_BICSBETASubActivityName"
    , "Instrument_BICSBETASegmentCode"
    , "Instrument_BICSBETASegmentName"
    , "Instrument_GICSSectorCode"
    , "Instrument_GICSSectorName"
    , "Instrument_GICSIndustryGroupName"
    , "Instrument_GICSIndustryCode"
    , "Instrument_GICSIndustryName"
    , "Instrument_GICSSubIndustryName"
    , "UltimateUnderlying_PSPInstrumentID"
    , "UltimateUnderlying_Family"
    , "UltimateUnderlying_PSPInstrumentCategorizationID"
    , "UltimateUnderlying_PSPInstrumentCategorizationCode"
    , "UltimateUnderlying_Description"
    , "UltimateUnderlying_Market"
    , "UltimateUnderlying_Type"
    , "UltimateUnderlying_IssuerCode"
    , "UltimateUnderlying_FinancialMaturityDate"
    , "UltimateUnderlying_IndexProxyPSPInstrumentID"
    , "UltimateUnderlying_GICSSectorCode"
    , "UltimateUnderlying_GICSSectorName"
    , "UltimateUnderlying_GICSIndustryGroupName"
    , "UltimateUnderlying_GICSIndustryCode"
    , "UltimateUnderlying_GICSIndustryName"
    , "UltimateUnderlying_GICSSubIndustryName"
    , "Leg_PSPInstrumentLegID"
    , "Leg_Type"
    , "Leg_FirstResetDate"
    , "Leg_LastResetDate"
    , "Leg_Direction"
    , "Leg_PositionLevel"
    , "Position_Quantity"
    , "Position_NominalAmount"
    , "Position_MarketValue_CAD"
    , "Position_AccruedInterestValue_CAD"
    , "Position_TaxReclaimValue_CAD"
    , "Position_NetAssetValue_CAD"
    , "Position_ExposureValue_CAD"
    , "Option_Style"
    , "Option_ContractSize"
    , "Option_ConversionRatio"
    , "Option_UnderlyingPSPInstrumentID"
    , "Future_ContractSize"
    , "Future_TickSize"
    , "Future_TickValue"
    , "Future_ContractSymbol"
    , "Future_UnderlyingPSPInstrumentID"
    , "OptionFuture_ContractSymbol"
    , "Forward_UnderlyingPSPInstrumentID"
    , "Forward_Price"
    , "BatchKey"
    , "MostRecent_CalendarKey"
    , "Index_Key"
    , "Portfolio_Key"
    , "Instrument_Key"
    , "RiskMetricsPositionType"
    , "Position_Delta"
    , "Position_NotionalInBaseCurrency"
    , "Position_CommodityDollarDelta"
    , "Position_EquityDollarDelta"
    , "Position_PresentValue"
    , "Position_KRD"
    , "Position_CurrencyDollarDelta"
    , "Position_Total_PresentValue"
    , "Position_Total_KRD"
    , "Position_Total_CurrencyDollarDelta"
    , "Final_Ratio_NAV_PresentValue" #NAV_ESB / PresentValue_ESB
]

pooled_funds_scaling_columns = [
      "Position_MarketValue_CAD"
    , "Position_NetAssetValue_CAD"
    #, "Exposure_FI"
    #, "Exposure_CR"
    #, "Exposure_Issuer"
    #, "Exposure_Equity"
    #, "Exposure_FX"
    #, "Exposure_Commodity"
]

pooled_funds_ratio_columns = [
      "CalendarDate"
    , "FundPSPInstrumentID"
    , "PSPPortfolioID"
    , "PSPPortfolioCode"
    , "ratio"
    , "MarketType"
    , "AssetClassName"
    , "InvestmentTeamName"
]

region_mapping = [
    [  "AD"
     , "Andorra"
     , "EUR"
     , "Southern Europe"
     , "Southern Europe"
     , "Europe"
    ],
    [
        "AE",
        "United Arab Emirates",
        "AED",
        "Western Asia",
        "Western Asia",
        "Asia",
    ],
    ["AF", "Afghanistan", "AFN", "Southern Asia", "Southern Asia", "Asia"],
    [
        "AG",
        "Antigua And Barbuda",
        "XCD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "AI",
        "Anguilla",
        "XCD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["AL", "Albania", "ALL", "Southern Europe", "Southern Europe", "Europe"],
    ["AM", "Armenia", "AMD", "Western Asia", "Western Asia", "Asia"],
    [
        "AN",
        "Netherlands Antilles",
        "ANG",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["AO", "Angola", "AOA", "Middle Africa", "Sub-Saharan Africa", "Africa"],
    ["AQ", "Antarctica", "XXX", "", "", ""],
    [
        "AR",
        "Argentina",
        "ARS",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["AS", "American Samoa", "USD", "Polynesia", "Polynesia", "Oceania"],
    ["AT", "Austria", "EUR", "Western Europe", "Western Europe", "Europe"],
    [
        "AU",
        "Australia",
        "AUD",
        "Australia and New Zealand",
        "Australia and New Zealand",
        "Oceania",
    ],
    [
        "AW",
        "Aruba",
        "AWG",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "AX",
        "Åland Islands",
        "EUR",
        "Northern Europe",
        "Northern Europe",
        "Europe",
    ],
    ["AZ", "Azerbaijan", "AZN", "Western Asia", "Western Asia", "Asia"],
    [
        "BA",
        "Bosnia And Herzegovina",
        "BAM",
        "Southern Europe",
        "Southern Europe",
        "Europe",
    ],
    [
        "BB",
        "Barbados",
        "BBD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["BD", "Bangladesh", "BDT", "Southern Asia", "Southern Asia", "Asia"],
    ["BE", "Belgium", "EUR", "Western Europe", "Western Europe", "Europe"],
    [
        "BF",
        "Burkina Faso",
        "XOF",
        "Western Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["BG", "Bulgaria", "BGN", "Eastern Europe", "Eastern Europe", "Europe"],
    ["BH", "Bahrain", "BHD", "Western Asia", "Western Asia", "Asia"],
    ["BI", "Burundi", "BIF", "Eastern Africa", "Sub-Saharan Africa", "Africa"],
    ["BJ", "Benin", "XOF", "Western Africa", "Sub-Saharan Africa", "Africa"],
    [
        "BL",
        "Saint Barthélemy",
        "EUR",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "BM",
        "Bermuda",
        "BMD",
        "Northern America",
        "Northern America",
        "Americas",
    ],
    [
        "BN",
        "Brunei Darussalam",
        "BND",
        "South-eastern Asia",
        "South-eastern Asia",
        "Asia",
    ],
    [
        "BO",
        "Bolivia",
        "BOB",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "BQ",
        "Bonaire, Sint Eustatius and Saba",
        "USD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "BR",
        "Brazil",
        "BRL",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "BS",
        "Bahamas",
        "BSD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["BT", "Bhutan", "BTN", "Southern Asia", "Southern Asia", "Asia"],
    [
        "BV",
        "Bouvet Island",
        "NOK",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "BW",
        "Botswana",
        "BWP",
        "Southern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["BY", "Belarus", "BYR", "Eastern Europe", "Eastern Europe", "Europe"],
    [
        "BZ",
        "Belize",
        "BZD",
        "Central America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "CA",
        "Canada",
        "CAD",
        "Northern America",
        "Northern America",
        "Americas",
    ],
    [
        "CC",
        "Cocos (Keeling) Islands",
        "AUD",
        "Australia and New Zealand",
        "Australia and New Zealand",
        "Oceania",
    ],
    [
        "CD",
        "Congo, The Democratic Republic Of The",
        "CDF",
        "Middle Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    [
        "CF",
        "Central African Republic",
        "XAF",
        "Middle Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["CG", "Congo", "XAF", "Middle Africa", "Sub-Saharan Africa", "Africa"],
    ["CH", "Switzerland", "CHF", "Western Europe", "Western Europe", "Europe"],
    [
        "CI",
        "Côte D'ivoire",
        "XOF",
        "Western Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["CK", "Cook Islands", "NZD", "Polynesia", "Polynesia", "Oceania"],
    [
        "CL",
        "Chile",
        "CLP",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["CM", "Cameroon", "XAF", "Middle Africa", "Sub-Saharan Africa", "Africa"],
    ["CN", "China", "CNY", "Eastern Asia", "Eastern Asia", "Asia"],
    [
        "CO",
        "Colombia",
        "COP",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "CR",
        "Costa Rica",
        "CRC",
        "Central America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "CU",
        "Cuba",
        "CUP",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "CV",
        "Cape Verde",
        "CVE",
        "Western Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    [
        "CW",
        "Curacao",
        "ANG",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "CX",
        "Christmas Island",
        "AUD",
        "Australia and New Zealand",
        "Australia and New Zealand",
        "Oceania",
    ],
    ["CY", "Cyprus", "EUR", "Western Asia", "Western Asia", "Asia"],
    [
        "CZ",
        "Czech Republic",
        "CZK",
        "Eastern Europe",
        "Eastern Europe",
        "Europe",
    ],
    ["DE", "Germany", "EUR", "Western Europe", "Western Europe", "Europe"],
    [
        "DJ",
        "Djibouti",
        "DJF",
        "Eastern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["DK", "Denmark", "DKK", "Northern Europe", "Northern Europe", "Europe"],
    [
        "DM",
        "Dominica",
        "XCD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "DO",
        "Dominican Republic",
        "DOP",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["DZ", "Algeria", "DZD", "Northern Africa", "Northern Africa", "Africa"],
    [
        "EC",
        "Ecuador",
        "USD",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["EE", "Estonia", "EUR", "Northern Europe", "Northern Europe", "Europe"],
    ["EG", "Egypt", "EGP", "Northern Africa", "Northern Africa", "Africa"],
    [
        "EH",
        "Western Sahara",
        "MAD",
        "Northern Africa",
        "Northern Africa",
        "Africa",
    ],
    ["ER", "Eritrea", "ERN", "Eastern Africa", "Sub-Saharan Africa", "Africa"],
    ["ES", "Spain", "EUR", "Southern Europe", "Southern Europe", "Europe"],
    [
        "ET",
        "Ethiopia",
        "ETB",
        "Eastern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["FI", "Finland", "EUR", "Northern Europe", "Northern Europe", "Europe"],
    ["FJ", "Fiji", "FJD", "Melanesia", "Melanesia", "Oceania"],
    [
        "FK",
        "Falkland Islands (Malvinas)",
        "FKP",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "FM",
        "Micronesia, Federated States Of",
        "USD",
        "Micronesia",
        "Micronesia",
        "Oceania",
    ],
    [
        "FO",
        "Faroe Islands",
        "DKK",
        "Northern Europe",
        "Northern Europe",
        "Europe",
    ],
    ["FR", "France", "EUR", "Western Europe", "Western Europe", "Europe"],
    ["GA", "Gabon", "XAF", "Middle Africa", "Sub-Saharan Africa", "Africa"],
    [
        "GB",
        "United Kingdom",
        "GBP",
        "Northern Europe",
        "Northern Europe",
        "Europe",
    ],
    [
        "GD",
        "Grenada",
        "XCD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["GE", "Georgia", "GEL", "Western Asia", "Western Asia", "Asia"],
    [
        "GF",
        "French Guiana",
        "EUR",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["GG", "Guernsey", "GBP", "Channel Islands", "Northern Europe", "Europe"],
    ["GH", "Ghana", "GHS", "Western Africa", "Sub-Saharan Africa", "Africa"],
    ["GI", "Gibraltar", "GIP", "Southern Europe", "Southern Europe", "Europe"],
    [
        "GL",
        "Greenland",
        "DKK",
        "Northern America",
        "Northern America",
        "Americas",
    ],
    ["GM", "Gambia", "GMD", "Western Africa", "Sub-Saharan Africa", "Africa"],
    ["GN", "Guinea", "GNF", "Western Africa", "Sub-Saharan Africa", "Africa"],
    [
        "GP",
        "Guadeloupe",
        "EUR",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "GQ",
        "Equatorial Guinea",
        "XAF",
        "Middle Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["GR", "Greece", "EUR", "Southern Europe", "Southern Europe", "Europe"],
    [
        "GS",
        "South Georgia And The South Sandwich Islands",
        "GBP",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "GT",
        "Guatemala",
        "GTQ",
        "Central America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["GU", "Guam", "USD", "Micronesia", "Micronesia", "Oceania"],
    [
        "GW",
        "Guinea-Bissau",
        "XOF",
        "Western Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    [
        "GY",
        "Guyana",
        "GYD",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["HK", "Hong Kong", "HKD", "Eastern Asia", "Eastern Asia", "Asia"],
    [
        "HM",
        "Heard Island And Mcdonald Islands",
        "AUD",
        "Australia and New Zealand",
        "Australia and New Zealand",
        "Oceania",
    ],
    [
        "HN",
        "Honduras",
        "HNL",
        "Central America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["HR", "Croatia", "HRK", "Southern Europe", "Southern Europe", "Europe"],
    [
        "HT",
        "Haiti",
        "HTG",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["HU", "Hungary", "HUF", "Eastern Europe", "Eastern Europe", "Europe"],
    [
        "ID",
        "Indonesia",
        "IDR",
        "South-eastern Asia",
        "South-eastern Asia",
        "Asia",
    ],
    ["IE", "Ireland", "EUR", "Northern Europe", "Northern Europe", "Europe"],
    ["IL", "Israel", "ILS", "Western Asia", "Western Asia", "Asia"],
    [
        "IM",
        "Isle Of Man",
        "GBP",
        "Northern Europe",
        "Northern Europe",
        "Europe",
    ],
    ["IN", "India", "INR", "Southern Asia", "Southern Asia", "Asia"],
    [
        "IO",
        "British Indian Ocean Territory",
        "GBP",
        "Eastern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["IQ", "Iraq", "IQD", "Western Asia", "Western Asia", "Asia"],
    [
        "IR",
        "Iran, Islamic Republic Of",
        "IRR",
        "Southern Asia",
        "Southern Asia",
        "Asia",
    ],
    ["IS", "Iceland", "ISK", "Northern Europe", "Northern Europe", "Europe"],
    ["IT", "Italy", "EUR", "Southern Europe", "Southern Europe", "Europe"],
    ["JE", "Jersey", "GBP", "Channel Islands", "Northern Europe", "Europe"],
    [
        "JM",
        "Jamaica",
        "JMD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["JO", "Jordan", "JOD", "Western Asia", "Western Asia", "Asia"],
    ["JP", "Japan", "JPY", "Eastern Asia", "Eastern Asia", "Asia"],
    ["KE", "Kenya", "KES", "Eastern Africa", "Sub-Saharan Africa", "Africa"],
    ["KG", "Kyrgyzstan", "KGS", "Central Asia", "Central Asia", "Asia"],
    [
        "KH",
        "Cambodia",
        "KHR",
        "South-eastern Asia",
        "South-eastern Asia",
        "Asia",
    ],
    ["KI", "Kiribati", "AUD", "Micronesia", "Micronesia", "Oceania"],
    ["KM", "Comoros", "KMF", "Eastern Africa", "Sub-Saharan Africa", "Africa"],
    [
        "KN",
        "Saint Kitts And Nevis",
        "XCD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "KP",
        "Korea, Democratic People's Republic Of",
        "KPW",
        "Eastern Asia",
        "Eastern Asia",
        "Asia",
    ],
    [
        "KR",
        "Korea, Republic Of",
        "KRW",
        "Eastern Asia",
        "Eastern Asia",
        "Asia",
    ],
    ["KW", "Kuwait", "KWD", "Western Asia", "Western Asia", "Asia"],
    [
        "KY",
        "Cayman Islands",
        "KYD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["KZ", "Kazakhstan", "KZT", "Central Asia", "Central Asia", "Asia"],
    [
        "LA",
        "Lao People's Democratic Republic",
        "LAK",
        "South-eastern Asia",
        "South-eastern Asia",
        "Asia",
    ],
    ["LB", "Lebanon", "LBP", "Western Asia", "Western Asia", "Asia"],
    [
        "LC",
        "Saint Lucia",
        "XCD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "LI",
        "Liechtenstein",
        "CHF",
        "Western Europe",
        "Western Europe",
        "Europe",
    ],
    ["LK", "Sri Lanka", "LKR", "Southern Asia", "Southern Asia", "Asia"],
    ["LR", "Liberia", "LRD", "Western Africa", "Sub-Saharan Africa", "Africa"],
    [
        "LS",
        "Lesotho",
        "LSL",
        "Southern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["LT", "Lithuania", "LTL", "Northern Europe", "Northern Europe", "Europe"],
    ["LU", "Luxembourg", "EUR", "Western Europe", "Western Europe", "Europe"],
    ["LV", "Latvia", "EUR", "Northern Europe", "Northern Europe", "Europe"],
    [
        "LY",
        "Libyan Arab Jamahiriya",
        "LYD",
        "Northern Africa",
        "Northern Africa",
        "Africa",
    ],
    ["MA", "Morocco", "MAD", "Northern Africa", "Northern Africa", "Africa"],
    ["MC", "Monaco", "EUR", "Western Europe", "Western Europe", "Europe"],
    [
        "MD",
        "Moldova, Republic Of",
        "MDL",
        "Eastern Europe",
        "Eastern Europe",
        "Europe",
    ],
    [
        "ME",
        "Montenegro",
        "EUR",
        "Southern Europe",
        "Southern Europe",
        "Europe",
    ],
    [
        "MF",
        "Saint Martin",
        "EUR",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "MG",
        "Madagascar",
        "MGA",
        "Eastern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["MH", "Marshall Islands", "USD", "Micronesia", "Micronesia", "Oceania"],
    [
        "MK",
        "Macedonia, The Former Yugoslav Republic Of",
        "MKD",
        "Southern Europe",
        "Southern Europe",
        "Europe",
    ],
    ["ML", "Mali", "XOF", "Western Africa", "Sub-Saharan Africa", "Africa"],
    [
        "MM",
        "Myanmar",
        "MMK",
        "South-eastern Asia",
        "South-eastern Asia",
        "Asia",
    ],
    ["MN", "Mongolia", "MNT", "Eastern Asia", "Eastern Asia", "Asia"],
    ["MO", "Macao", "MOP", "Eastern Asia", "Eastern Asia", "Asia"],
    [
        "MP",
        "Northern Mariana Islands",
        "USD",
        "Micronesia",
        "Micronesia",
        "Oceania",
    ],
    [
        "MQ",
        "Martinique",
        "EUR",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "MR",
        "Mauritania",
        "MRO",
        "Western Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    [
        "MS",
        "Montserrat",
        "XCD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["MT", "Malta", "EUR", "Southern Europe", "Southern Europe", "Europe"],
    [
        "MU",
        "Mauritius",
        "MUR",
        "Eastern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["MV", "Maldives", "MVR", "Southern Asia", "Southern Asia", "Asia"],
    ["MW", "Malawi", "MWK", "Eastern Africa", "Sub-Saharan Africa", "Africa"],
    [
        "MX",
        "Mexico",
        "MXN",
        "Central America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "MY",
        "Malaysia",
        "MYR",
        "South-eastern Asia",
        "South-eastern Asia",
        "Asia",
    ],
    [
        "MZ",
        "Mozambique",
        "MZN",
        "Eastern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    [
        "NA",
        "Namibia",
        "NAD",
        "Southern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["NC", "New Caledonia", "XPF", "Melanesia", "Melanesia", "Oceania"],
    ["NE", "Niger", "XOF", "Western Africa", "Sub-Saharan Africa", "Africa"],
    [
        "NF",
        "Norfolk Island",
        "AUD",
        "Australia and New Zealand",
        "Australia and New Zealand",
        "Oceania",
    ],
    ["NG", "Nigeria", "NGN", "Western Africa", "Sub-Saharan Africa", "Africa"],
    [
        "NI",
        "Nicaragua",
        "NIO",
        "Central America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["NL", "Netherlands", "EUR", "Western Europe", "Western Europe", "Europe"],
    ["NO", "Norway", "NOK", "Northern Europe", "Northern Europe", "Europe"],
    ["NP", "Nepal", "NPR", "Southern Asia", "Southern Asia", "Asia"],
    ["NR", "Nauru", "AUD", "Micronesia", "Micronesia", "Oceania"],
    ["NU", "Niue", "NZD", "Polynesia", "Polynesia", "Oceania"],
    [
        "NZ",
        "New Zealand",
        "NZD",
        "Australia and New Zealand",
        "Australia and New Zealand",
        "Oceania",
    ],
    ["OM", "Oman", "OMR", "Western Asia", "Western Asia", "Asia"],
    [
        "PA",
        "Panama",
        "PAB",
        "Central America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "PE",
        "Peru",
        "PEN",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["PF", "French Polynesia", "XPF", "Polynesia", "Polynesia", "Oceania"],
    ["PG", "Papua New Guinea", "PGK", "Melanesia", "Melanesia", "Oceania"],
    [
        "PH",
        "Philippines",
        "PHP",
        "South-eastern Asia",
        "South-eastern Asia",
        "Asia",
    ],
    ["PK", "Pakistan", "PKR", "Southern Asia", "Southern Asia", "Asia"],
    ["PL", "Poland", "PLN", "Eastern Europe", "Eastern Europe", "Europe"],
    [
        "PM",
        "Saint Pierre And Miquelon",
        "EUR",
        "Northern America",
        "Northern America",
        "Americas",
    ],
    ["PN", "Pitcairn", "NZD", "Polynesia", "Polynesia", "Oceania"],
    [
        "PR",
        "Puerto Rico",
        "USD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "PS",
        "Palestinian Territory, Occupied",
        "ILS",
        "Western Asia",
        "Western Asia",
        "Asia",
    ],
    ["PT", "Portugal", "EUR", "Southern Europe", "Southern Europe", "Europe"],
    ["PW", "Palau", "USD", "Micronesia", "Micronesia", "Oceania"],
    [
        "PY",
        "Paraguay",
        "PYG",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["QA", "Qatar", "QAR", "Western Asia", "Western Asia", "Asia"],
    ["RE", "Réunion", "EUR", "Eastern Africa", "Sub-Saharan Africa", "Africa"],
    ["RO", "Romania", "RON", "Eastern Europe", "Eastern Europe", "Europe"],
    ["RS", "Serbia", "RSD", "Southern Europe", "Southern Europe", "Europe"],
    [
        "RU",
        "Russian Federation",
        "RUB",
        "Eastern Europe",
        "Eastern Europe",
        "Europe",
    ],
    ["RW", "Rwanda", "RWF", "Eastern Africa", "Sub-Saharan Africa", "Africa"],
    ["SA", "Saudi Arabia", "SAR", "Western Asia", "Western Asia", "Asia"],
    ["SB", "Solomon Islands", "SBD", "Melanesia", "Melanesia", "Oceania"],
    [
        "SC",
        "Seychelles",
        "SCR",
        "Eastern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["SD", "Sudan", "SDG", "Northern Africa", "Northern Africa", "Africa"],
    ["SE", "Sweden", "SEK", "Northern Europe", "Northern Europe", "Europe"],
    [
        "SG",
        "Singapore",
        "SGD",
        "South-eastern Asia",
        "South-eastern Asia",
        "Asia",
    ],
    [
        "SH",
        "Saint Helena",
        "SHP",
        "Western Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["SI", "Slovenia", "EUR", "Southern Europe", "Southern Europe", "Europe"],
    [
        "SJ",
        "Svalbard And Jan Mayen",
        "NOK",
        "Northern Europe",
        "Northern Europe",
        "Europe",
    ],
    ["SK", "Slovakia", "EUR", "Eastern Europe", "Eastern Europe", "Europe"],
    [
        "SL",
        "Sierra Leone",
        "SLL",
        "Western Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    [
        "SM",
        "San Marino",
        "EUR",
        "Southern Europe",
        "Southern Europe",
        "Europe",
    ],
    ["SN", "Senegal", "XOF", "Western Africa", "Sub-Saharan Africa", "Africa"],
    ["SO", "Somalia", "SOS", "Eastern Africa", "Sub-Saharan Africa", "Africa"],
    [
        "SR",
        "Suriname",
        "SRD",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "SS",
        "South Sudan",
        "SSP",
        "Eastern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    [
        "ST",
        "Sao Tome And Principe",
        "STD",
        "Middle Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    [
        "SV",
        "El Salvador",
        "USD",
        "Central America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "SX",
        "Sint Maarten(Dutch part)",
        "ANG",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "SY",
        "Syrian Arab Republic",
        "SYP",
        "Western Asia",
        "Western Asia",
        "Asia",
    ],
    [
        "SZ",
        "Swaziland",
        "SZL",
        "Southern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    [
        "TC",
        "Turks And Caicos Islands",
        "USD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["TD", "Chad", "XAF", "Middle Africa", "Sub-Saharan Africa", "Africa"],
    [
        "TF",
        "French Southern Territories",
        "EUR",
        "Eastern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["TG", "Togo", "XOF", "Western Africa", "Sub-Saharan Africa", "Africa"],
    [
        "TH",
        "Thailand",
        "THB",
        "South-eastern Asia",
        "South-eastern Asia",
        "Asia",
    ],
    ["TJ", "Tajikistan", "TJS", "Central Asia", "Central Asia", "Asia"],
    ["TK", "Tokelau", "NZD", "Polynesia", "Polynesia", "Oceania"],
    [
        "TL",
        "Timor-Leste",
        "USD",
        "South-eastern Asia",
        "South-eastern Asia",
        "Asia",
    ],
    ["TM", "Turkmenistan", "TMT", "Central Asia", "Central Asia", "Asia"],
    ["TN", "Tunisia", "TND", "Northern Africa", "Northern Africa", "Africa"],
    ["TO", "Tonga", "TOP", "Polynesia", "Polynesia", "Oceania"],
    ["TR", "Turkey", "TRY", "Western Asia", "Western Asia", "Asia"],
    [
        "TT",
        "Trinidad And Tobago",
        "TTD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["TV", "Tuvalu", "AUD", "Polynesia", "Polynesia", "Oceania"],
    [
        "TW",
        "Taiwan, Province Of China",
        "TWD",
        "Eastern Asia",
        "Eastern Asia",
        "Asia",
    ],
    [
        "TZ",
        "Tanzania, United Republic Of",
        "TZS",
        "Eastern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["UA", "Ukraine", "UAH", "Eastern Europe", "Eastern Europe", "Europe"],
    ["UG", "Uganda", "UGX", "Eastern Africa", "Sub-Saharan Africa", "Africa"],
    [
        "UM",
        "United States Minor Outlying Islands",
        "USD",
        "Micronesia",
        "Micronesia",
        "Oceania",
    ],
    [
        "US",
        "United States",
        "USD",
        "Northern America",
        "Northern America",
        "Americas",
    ],
    [
        "UY",
        "Uruguay",
        "UYU",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    ["UZ", "Uzbekistan", "UZS", "Central Asia", "Central Asia", "Asia"],
    [
        "VA",
        "Vatican City State",
        "EUR",
        "Southern Europe",
        "Southern Europe",
        "Europe",
    ],
    [
        "VC",
        "Saint Vincent And The Grenadines",
        "XCD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "VE",
        "Venezuela",
        "VEF",
        "South America",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "VG",
        "Virgin Islands, British",
        "USD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "VI",
        "Virgin Islands, U.S.",
        "USD",
        "Caribbean",
        "Latin America and the Caribbean",
        "Americas",
    ],
    [
        "VN",
        "Viet Nam",
        "VND",
        "South-eastern Asia",
        "South-eastern Asia",
        "Asia",
    ],
    ["VU", "Vanuatu", "VUV", "Melanesia", "Melanesia", "Oceania"],
    ["WF", "Wallis And Futuna", "XPF", "Polynesia", "Polynesia", "Oceania"],
    ["WS", "Samoa", "WST", "Polynesia", "Polynesia", "Oceania"],
    ["XK", "Kosovo", "EUR", "Southern Europe", "Southern Europe", "Europe"],
    ["YE", "Yemen", "YER", "Western Asia", "Western Asia", "Asia"],
    ["YT", "Mayotte", "EUR", "Eastern Africa", "Sub-Saharan Africa", "Africa"],
    [
        "ZA",
        "South Africa",
        "ZAR",
        "Southern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
    ["ZM", "Zambia", "ZMW", "Eastern Africa", "Sub-Saharan Africa", "Africa"],
    [
        "ZW",
        "Zimbabwe",
        "ZWR",
        "Eastern Africa",
        "Sub-Saharan Africa",
        "Africa",
    ],
]

col_maping_v2_to_v1 = {'PositionDate':'ValuationDate'
                  ,'Portfolio_PSPPortfolioID':'PSPPortfolioID'
                  ,'Instrument_PSPInstrumentID':'PSPInstrumentID'  #set to -1 for pooled funds
                  ,'Leg_PSPInstrumentLegID':'PSPInstrumentLegID'  #set to -1 for pooled funds
                  ,'Constituent_PSPInstrumentID':'PSPInstrumentID_extended'  #set to -1 for pooled funds
                  ,'Issuer_PSPLegalEntityID':'PSPLegalEntityID_extended'   #set to -1 for pooled funds
                  ,'Constituent_Exposure_Issuer': 'CalculatedIssuerExposureinCAD'
                  ,'Instrument_BICSBETAClassificationID':'PSPIndustryClassificationID'  #isnull avec issuer
                  ,'Instrument_RiskLocationCountryCode': 'CountryCode'  #isnull avec issuer
                  }
#sharepoint folder exposure v1
exposure_v1_root_folder = 'C://Users//'
exposure_v1_folder_path = '//PSP Investments//D&A Collaboration - Exposure files//' ### change folder to 'D&A Collaboration - Exposure files' to go in prod
exposure_v1_file_name = 'Exposure.csv' ### change name to 'Exposure.csv' to go use in prod

col_mapping_tfe_mra = {'PositionDate':'CalendarDate'
                      ,'Object_Type':'Object_Type'
                      ,'Portfolio_PSPPortfolioID':'PortfolioID'
                      ,'Portfolio_PSPPortfolioCode':'PortfolioCode'
                      ,'Instrument_PSPInstrumentCategorizationID':'Instrument_PSPInstrumentCategorizationID'
                      ,'Instrument_PSPInstrumentCategorizationCode':'Instrument_PSPInstrumentCategorizationCode'
                      ,'Constituent_PSPInstrumentCategorizationID':'Constituent_PSPInstrumentCategorizationID'
                      ,'Constituent_PSPInstrumentCategorizationCode':'Constituent_PSPInstrumentCategorizationCode'
                      ,'Exposure_Issuer':'Exposure_Issuer'
                      ,'Exposure_Equity':'Exposure_Equity'
                      ,'Exposure_Commodity':'Exposure_Commodity'
                      }

col_mapping_creditriskdm_to_tfe = {  'ValuationDate': 'valuation_date'
                                    ,'Source':'benchmark_assignation'
                                    ,'PSPPortfolioCode':'l4_psp_portfolio_code'
                                    ,'PSPInstrumentCategorizationCode':'instrument_psp_instrument_categorization_code'
                                    ,'ConstituentPSPInstrumentCategorizationCode':'constituent_psp_instrument_categorization_code'
                                    ,'Exposure':'constituent_issuer_exposure'}

dim_issuer_columns = [ 'Issuer_Code'
                     , 'Issuer_Name'
                     , 'Issuer_PSPLegalEntityID'
                     , 'Issuer_UltimateParentCode'
                     , 'Issuer_RiskLocationCountryCode'
                     , 'Issuer_NormalizedCountryCode'
                     , 'Issuer_BICSBETAClassificationID'
                     , 'Issuer_BICSBETASectorCode'
                     , 'Issuer_BICSBETASectorName'
                     , 'Issuer_BICSBETAIndustryGroupCode'
                     , 'Issuer_BICSBETAIndustryGroupName'
                     , 'Issuer_BICSBETAIndustryCode'
                     , 'Issuer_BICSBETAIndustryName'
                     , 'Issuer_BICSBETASubIndustryCode'
                     , 'Issuer_BICSBETASubIndustryName'
                     , 'Issuer_BICSBETAActivityCode'
                     , 'Issuer_BICSBETAActivityName'
                     , 'Issuer_BICSBETASubActivityCode'
                     , 'Issuer_BICSBETASubActivityName'
                     , 'Issuer_BICSBETASegmentCode'
                     , 'Issuer_BICSBETASegmentName'
                     , 'Issuer_Name_UltimateParent'
                     , 'Issuer_UltimateParentPSPLegalEntityID'
                     , 'Issuer_UltimateParentRiskLocationCountryCode'
                     , 'Issuer_UltimateParentNormalizedCountryCode'
                     , 'Issuer_UltimateParentBICSBETAClassificationID'
                     , 'Issuer_UltimateParentBICSBETASectorCode'
                     , 'Issuer_UltimateParentBICSBETASectorName'
                     , 'Issuer_UltimateParentBICSBETAIndustryGroupCode'
                     , 'Issuer_UltimateParentBICSBETAIndustryGroupName'
                     , 'Issuer_UltimateParentBICSBETAIndustryCode'
                     , 'Issuer_UltimateParentBICSBETAIndustryName'
                     , 'Issuer_UltimateParentBICSBETASubIndustryCode'
                     , 'Issuer_UltimateParentBICSBETASubIndustryName'
                     , 'Issuer_UltimateParentBICSBETAActivityCode'
                     , 'Issuer_UltimateParentBICSBETAActivityName'
                     , 'Issuer_UltimateParentBICSBETASubActivityCode'
                     , 'Issuer_UltimateParentBICSBETASubActivityName'
                     , 'Issuer_UltimateParentBICSBETASegmentCode'
                     , 'Issuer_UltimateParentBICSBETASegmentName'
                     , 'Issuer_EquityExposureFactor'
                     , 'Issuer_IssuerExposureFactor'
                     , 'Issuer_FxExposureFactor'
                     , 'Issuer_CommodityExposureFactor'
                     , 'Issuer_FIExposureFactor'
                     , 'Issuer_CRExposureFactor'
                     , 'Issuer_LongTerm_LowestNormalizedRating'
                     , 'Issuer_LongTerm_HighestNormalizedRating'
                     , 'Issuer_ShortTerm_LowestNormalizedRating'
                     , 'Issuer_ShortTerm_HighestNormalizedRating'
                     , 'Issuer_LongTerm_LowestNormalizedRating_UltimateParent'
                     , 'Issuer_LongTerm_HighestNormalizedRating_UltimateParent'
                     , 'Issuer_ShortTerm_LowestNormalizedRating_UltimateParent'
                     , 'Issuer_ShortTerm_HighestNormalizedRating_UltimateParent'
                    ]

dim_countries_columns = [ 'Country_ISOCode'
                         , 'Country_Name'
                         , 'Country_CurrencyCode'
                         , 'Country_IntermediateRegion'
                         , 'Country_SubRegion'
                         , 'Country_Region'
                        ]

dim_gics_columns = [ 'PSPInstrumentID'
                   , 'SectorCode'
                   , 'SectorName'
                   , 'IndustryGroupCode'
                   , 'IndustryGroupName'
                   , 'IndustryCode'
                   , 'IndustryName'
                   , 'SubIndustryCode'
                   , 'SubIndustryName'
                   ]

dim_portfolios_columns = [  'L1_PSPPortfolioCode'
                          , 'L1_PSPPortfolioID'
                          , 'L1_PortfolioName'
                          , 'L1_PortfolioType'
                          , 'L1_ManagingDepartment'
                          , 'L1_ManagerType'
                          , 'L1_ManagingStyle'
                          , 'L1_PSPAssetClassAllocationCode'
                          , 'L1_AssetClassAllocationDescription'
                          , 'L1_PortfolioStyle'
                          , 'L1_OwnerDepartment'
                          , 'L1_PSPInvestmentTeamCode'
                          , 'L1_InvestmentTeamName'
                          , 'L2_PSPPortfolioCode'
                          , 'L2_PSPPortfolioID'
                          , 'L2_PortfolioName'
                          , 'L2_PortfolioType'
                          , 'L2_ManagingDepartment'
                          , 'L2_ManagerType'
                          , 'L2_ManagingStyle'
                          , 'L2_PSPAssetClassAllocationCode'
                          , 'L2_AssetClassAllocationDescription'
                          , 'L2_PortfolioStyle'
                          , 'L2_OwnerDepartment'
                          , 'L2_PSPInvestmentTeamCode'
                          , 'L2_InvestmentTeamName'
                          , 'L3_PSPPortfolioCode'
                          , 'L3_PSPPortfolioID'
                          , 'L3_PortfolioName'
                          , 'L3_PortfolioType'
                          , 'L3_ManagingDepartment'
                          , 'L3_ManagerType'
                          , 'L3_ManagingStyle'
                          , 'L3_PSPAssetClassAllocationCode'
                          , 'L3_AssetClassAllocationDescription'
                          , 'L3_PortfolioStyle'
                          , 'L3_OwnerDepartment'
                          , 'L3_PSPInvestmentTeamCode'
                          , 'L3_InvestmentTeamName'
                          , 'L4_PSPPortfolioCode'
                          , 'L4_PSPPortfolioID'
                          , 'L4_PortfolioName'
                          , 'L4_PortfolioType'
                          , 'L4_ManagingDepartment'
                          , 'L4_ManagerType'
                          , 'L4_ManagingStyle'
                          , 'L4_PSPAssetClassAllocationCode'
                          , 'L4_AssetClassAllocationDescription'
                          , 'L4_PortfolioStyle'
                          , 'L4_OwnerDepartment'
                          , 'L4_PSPInvestmentTeamCode'
                          , 'L4_InvestmentTeamName'
                          , 'InvestmentStrategyCalc'
                         ]

fact_exposure_columns = [  'PositionDate'
                         , 'Object_Type'
                         , 'Position_Type'
                         , 'Position_Source'
                         , 'Portfolio_PSPPortfolioCode'
                         , 'Portfolio_PSPPortfolioID'
                         , 'Instrument_CurrencyCode'
                         , 'Instrument_ReportingCurrencyCode'
                         , 'Instrument_PSPInstrumentID'
                         , 'Instrument_PSPInstrumentCategorizationID'
                         , 'Instrument_PSPInstrumentCategorizationCode'
                         , 'Instrument_Description'
                         , 'UltimateUnderlying_PSPInstrumentID'
                         , 'UltimateUnderlying_PSPInstrumentCategorizationID'
                         , 'UltimateUnderlying_PSPInstrumentCategorizationCode'
                         , 'UltimateUnderlying_Description'
                         , 'UltimateUnderlying_IssuerCode'
                         , 'UltimateUnderlying_IndexProxyPSPInstrumentID'
                         , 'Instrument_RiskLocationCountryCode'
                         , 'Instrument_NormalizedCountryCode'
                         , 'Instrument_GeographyName'
                         , 'Instrument_BICSBETAClassificationID'
                         , 'Instrument_BICSBETASectorCode'
                         , 'Instrument_BICSBETASectorName'
                         , 'Instrument_BICSBETAIndustryGroupCode'
                         , 'Instrument_BICSBETAIndustryGroupName'
                         , 'Instrument_BICSBETAIndustryCode'
                         , 'Instrument_BICSBETAIndustryName'
                         , 'Instrument_BICSBETASubIndustryCode'
                         , 'Instrument_BICSBETASubIndustryName'
                         , 'Instrument_BICSBETAActivityCode'
                         , 'Instrument_BICSBETAActivityName'
                         , 'Instrument_BICSBETASubActivityCode'
                         , 'Instrument_BICSBETASubActivityName'
                         , 'Instrument_BICSBETASegmentCode'
                         , 'Instrument_BICSBETASegmentName'
                         , 'Instrument_GICSSectorCode'
                         , 'Instrument_GICSSectorName'
                         , 'Instrument_GICSIndustryGroupName'
                         , 'Instrument_GICSIndustryCode'
                         , 'Instrument_GICSIndustryName'
                         , 'Instrument_GICSSubIndustryName'
                         , 'Leg_PSPInstrumentLegID'
                         , 'Leg_Type'
                         , 'Leg_Direction'
                         , 'Leg_PositionLevel'
                         , 'Option_Style'
                         , 'Position_NetAssetValue_CAD'
                         , 'Exposure_FI'
                         , 'Exposure_CR'
                         , 'Exposure_Issuer'
                         , 'Exposure_Equity'
                         , 'Exposure_FX'
                         , 'Exposure_Commodity'
                         , 'MostRecent_CalendarKey'
                         , 'BatchKey'
                         , 'Portfolio_Key'
                         , 'Instrument_Key'
                         , 'RiskMetricsPositionType'
                         , 'normal_calculation_family'
                         , 'exotic_calculation_family'
                         , 'use_pooled_fund_calculations'
                         , 'SourceDate'
                         , 'Instrument_FinancialMaturityDate'
                         , 'UltimateUnderlying_FinancialMaturityDate'
                        ]

fact_all_constituents_columns = [  'PositionDate'
                                 , 'Constituent_IssuerName'
                                 , 'Constituent_IssuerCode'
                                 , 'Constituent_CurrencyCode'
                                 , 'Constituent_Weight'
                                 , 'Constituent_Family'
                                 , 'Constituent_PSPInstrumentID'
                                 , 'Constituent_PSPInstrumentCategorizationID'
                                 , 'Constituent_PSPInstrumentCategorizationCode'
                                 , 'Constituent_Description'
                                 , 'Constituent_Market'
                                 , 'Constituent_Type'
                                 , 'Constituee_PSPInstrumentID'
                                 , 'Constituee_Type'
                                 , 'Constituent_IssuerExposureFactor'
                                 , 'Constituent_EquityExposureFactor'
                                 , 'Constituent_FinancialMaturityDate'
                                ]

fact_portfolios_columns = [  'PositionDate'
                           , 'Portfolio_PSPPortfolioCode'
                           , 'Portfolio_PSPPortfolioID'
                           , 'Portfolio_Name'
                           , 'Portfolio_Type'
                           , 'Portfolio_MarketType'
                           , 'Portfolio_AssetClass'
                           , 'Portfolio_InvestmentTeam'
                           , 'Portfolio_ManagerType'
                           , 'Portfolio_ManagingStyle'
                           , 'Portfolio_ManagingDepartment'
                           , 'Portfolio_OwnerDepartment'
                           , 'Portfolio_Position_Count'
                           , 'Portfolio_Position_MarketValue_CAD'
                           , 'Portfolio_Position_NetAssetValue_CAD'
                           , 'Portfolio_Internal_Count'
                           , 'Portfolio_Internal_MarketValue_CAD'
                           , 'Portfolio_Internal_NetAssetValue_CAD'
                           , 'Portfolio_PooledFund_Count'
                           , 'Portfolio_PooledFund_MarketValue_CAD'
                           , 'Portfolio_PooledFund_NetAssetValue_CAD'
                          ]

fact_unitary_benchmarks_columns = [  'PositionDate'
                                  , 'Benchmark_PSPBenchmarkCode'
                                  , 'Benchmark_PSPBenchmarkID'
                                  , 'Instrument_CurrencyCode'
                                  , 'Instrument_ReportingCurrencyCode'
                                  , 'Instrument_PSPInstrumentID'
                                  , 'Instrument_PSPInstrumentCategorizationID'
                                  , 'Instrument_PSPInstrumentCategorizationCode'
                                  , 'Instrument_Description'
                                  , 'Instrument_IssuerCode'
                                  #, 'UltimateUnderlying_ReportingCurrencyCode'
                                  , 'UltimateUnderlying_PSPInstrumentID'
                                  , 'UltimateUnderlying_PSPInstrumentCategorizationID'
                                  , 'UltimateUnderlying_PSPInstrumentCategorizationCode'
                                  , 'UltimateUnderlying_Description'
                                  , 'UltimateUnderlying_IssuerCode'
                                  , 'Position_NetAssetValue_CAD'
                                  , 'Exposure_FI'
                                  , 'Exposure_CR'
                                  , 'Exposure_Issuer'
                                  , 'Exposure_Equity'
                                  , 'Exposure_FX'
                                  , 'Exposure_Commodity'
                                  , 'unitary_benchmark_calculation_family'
                                  , 'SourceDate'
                                  , 'Instrument_FinancialMaturityDate'
                                  , 'UltimateUnderlying_FinancialMaturityDate'
                                 ]


fact_unitary_indices_columns = [  'PositionDate'
                                , 'Index_PSPInstrumentID'
                                , 'Instrument_CurrencyCode'
                                , 'Instrument_ReportingCurrencyCode'
                                , 'Instrument_PSPInstrumentID'
                                , 'Instrument_PSPInstrumentCategorizationID'
                                , 'Instrument_PSPInstrumentCategorizationCode'
                                , 'Instrument_Description'
                                , 'UltimateUnderlying_PSPInstrumentID'
                                , 'UltimateUnderlying_PSPInstrumentCategorizationID'
                                , 'UltimateUnderlying_PSPInstrumentCategorizationCode'
                                , 'UltimateUnderlying_Description'
                                , 'UltimateUnderlying_IssuerCode'
                                , 'Position_NetAssetValue_CAD'
                                , 'Exposure_FI'
                                , 'Exposure_CR'
                                , 'Exposure_Issuer'
                                , 'Exposure_Equity'
                                , 'Exposure_FX'
                                , 'Exposure_Commodity'
                                , 'unitary_benchmark_calculation_family'
                                , 'SourceDate'
                                , 'Instrument_FinancialMaturityDate'
                                , 'UltimateUnderlying_FinancialMaturityDate'
                                , 'Index_Key'
                                , 'MostRecent_CalendarKey'
                                , 'BatchKey'
                                , 'Instrument_Key'
                               ]

csv_columns = {  'dim_issuers' : dim_issuer_columns
               , 'dim_countries' : dim_countries_columns
               , 'dim_gics' : dim_gics_columns
               , 'dim_portfolios': dim_portfolios_columns
               , 'fact_exposure': fact_exposure_columns
               , 'fact_all_constituents': fact_all_constituents_columns
               , 'fact_portfolios': fact_portfolios_columns
               , 'fact_unitary_benchmarks': fact_unitary_benchmarks_columns
               , 'fact_unitary_indices': fact_unitary_indices_columns}

