dim_countries_dict =    { 'file_format': 'csv'
                        , 'keys_columns': ['Country_ISOCode']
                        , 'attributes_columns': [  'Country_Name'
                                                  , 'Country_CurrencyCode'
                                                  , 'Country_IntermediateRegion'
                                                  , 'Country_SubRegion'
                                                  , 'Country_Region'
                                                ] 
                        }

dim_issuers_dict =    { 'file_format': 'csv'
                      , 'keys_columns': ['Issuer_Code']
                      , 'attributes_columns': ['Issuer_Name','Issuer_PSPLegalEntityID','Issuer_UltimateParentCode','Issuer_RiskLocationCountryCode','Issuer_NormalizedCountryCode','Issuer_BICSBETAClassificationID','Issuer_BICSBETASectorCode','Issuer_BICSBETASectorName','Issuer_BICSBETAIndustryGroupCode','Issuer_BICSBETAIndustryGroupName','Issuer_BICSBETAIndustryCode','Issuer_BICSBETAIndustryName','Issuer_BICSBETASubIndustryCode','Issuer_BICSBETASubIndustryName','Issuer_BICSBETAActivityCode','Issuer_BICSBETAActivityName','Issuer_BICSBETASubActivityCode','Issuer_BICSBETASubActivityName','Issuer_BICSBETASegmentCode','Issuer_BICSBETASegmentName','Issuer_Name_UltimateParent','Issuer_UltimateParentPSPLegalEntityID','Issuer_UltimateParentRiskLocationCountryCode','Issuer_UltimateParentNormalizedCountryCode','Issuer_UltimateParentBICSBETAClassificationID','Issuer_UltimateParentBICSBETASectorCode','Issuer_UltimateParentBICSBETASectorName','Issuer_UltimateParentBICSBETAIndustryGroupCode','Issuer_UltimateParentBICSBETAIndustryGroupName','Issuer_UltimateParentBICSBETAIndustryCode','Issuer_UltimateParentBICSBETAIndustryName','Issuer_UltimateParentBICSBETASubIndustryCode','Issuer_UltimateParentBICSBETASubIndustryName','Issuer_UltimateParentBICSBETAActivityCode','Issuer_UltimateParentBICSBETAActivityName','Issuer_UltimateParentBICSBETASubActivityCode','Issuer_UltimateParentBICSBETASubActivityName','Issuer_UltimateParentBICSBETASegmentCode','Issuer_UltimateParentBICSBETASegmentName','Issuer_LongTerm_LowestNormalizedRating','Issuer_LongTerm_HighestNormalizedRating','Issuer_ShortTerm_LowestNormalizedRating','Issuer_ShortTerm_HighestNormalizedRating','Issuer_LongTerm_LowestNormalizedRating_UltimateParent','Issuer_LongTerm_HighestNormalizedRating_UltimateParent','Issuer_ShortTerm_LowestNormalizedRating_UltimateParent','Issuer_ShortTerm_HighestNormalizedRating_UltimateParent'] 
                      , 'data_columns': ['Issuer_EquityExposureFactor','Issuer_IssuerExposureFactor','Issuer_FxExposureFactor','Issuer_CommodityExposureFactor','Issuer_FIExposureFactor','Issuer_CRExposureFactor'] 
                      , 'data_format' : {  'Int64': ['Issuer_Code','Issuer_PSPLegalEntityID','Issuer_BICSBETAClassificationID','Issuer_BICSBETASectorCode','Issuer_BICSBETAIndustryGroupCode','Issuer_BICSBETAIndustryCode','Issuer_BICSBETASubIndustryCode','Issuer_BICSBETAActivityCode','Issuer_BICSBETASubActivityCode','Issuer_BICSBETASegmentCode','Issuer_UltimateParentPSPLegalEntityID','Issuer_UltimateParentBICSBETAClassificationID','Issuer_UltimateParentBICSBETASectorCode','Issuer_UltimateParentBICSBETAIndustryGroupCode','Issuer_UltimateParentBICSBETAIndustryCode','Issuer_UltimateParentBICSBETASubIndustryCode','Issuer_UltimateParentBICSBETAActivityCode','Issuer_UltimateParentBICSBETASubActivityCode','Issuer_UltimateParentBICSBETASegmentCode']
                                         , 'float': ['Issuer_EquityExposureFactor','Issuer_IssuerExposureFactor','Issuer_FxExposureFactor','Issuer_CommodityExposureFactor','Issuer_FIExposureFactor','Issuer_CRExposureFactor']
                                         }
                      , 'data_derror_tolerance' : 1000
                      , 'data_perror_tolerance' : 0.0001
                      }

dim_gics_dict   =    { 'file_format': 'csv'
                      , 'keys_columns': ['PSPInstrumentID']
                      , 'attributes_columns': ['SectorName','IndustryGroupName','IndustryName','SubIndustryName'] 
                      , 'data_columns': ['SectorCode','IndustryGroupCode','IndustryCode','SubIndustryCode'] 
                      , 'data_format' : {  'Int64': ['PSPInstrumentID','SectorCode','IndustryGroupCode','IndustryCode','SubIndustryCode']
                                        }
                      , 'data_derror_tolerance' : 0
                      , 'data_perror_tolerance' : 0.0001
                      }                      

dim_portfolios_dict =    { 'file_format': 'csv'
                      , 'keys_columns': ['L4_PSPPortfolioID']
                      , 'attributes_columns': ['L1_PSPPortfolioCode','L1_PortfolioName','L1_PortfolioType','L1_ManagingDepartment','L1_ManagerType','L1_ManagingStyle','L1_AssetClassAllocationDescription','L1_PortfolioStyle','L1_OwnerDepartment','L1_PSPInvestmentTeamCode','L1_InvestmentTeamName','L2_PSPPortfolioCode','L2_PortfolioName','L2_PortfolioType','L2_ManagingDepartment','L2_ManagerType','L2_ManagingStyle','L2_AssetClassAllocationDescription','L2_PortfolioStyle','L2_OwnerDepartment','L2_PSPInvestmentTeamCode','L2_InvestmentTeamName','L3_PSPPortfolioCode','L3_PortfolioName','L3_PortfolioType','L3_ManagingDepartment','L3_ManagerType','L3_ManagingStyle','L3_AssetClassAllocationDescription','L3_PortfolioStyle','L3_OwnerDepartment','L3_PSPInvestmentTeamCode','L3_InvestmentTeamName','L4_PSPPortfolioCode','L4_PortfolioName','L4_PortfolioType','L4_ManagingDepartment','L4_ManagerType','L4_ManagingStyle','L4_AssetClassAllocationDescription','L4_PortfolioStyle','L4_OwnerDepartment','L4_PSPInvestmentTeamCode','L4_InvestmentTeamName','InvestmentStrategyCalc','L1_PSPAssetClassAllocationCode','L2_PSPAssetClassAllocationCode','L3_PSPAssetClassAllocationCode','L4_PSPAssetClassAllocationCode'] 
                      , 'data_columns': ['L1_PSPPortfolioID','L2_PSPPortfolioID','L3_PSPPortfolioID'] 
                      , 'data_format' : {  'Int64': ['L1_PSPPortfolioID','L2_PSPPortfolioID','L3_PSPPortfolioID','L4_PSPPortfolioID']
                                         }
                      , 'data_derror_tolerance' : 1000
                      , 'data_perror_tolerance' : 0.0001
                      }

#fact_all_constituents_credit_index_dict =    { 'file_format': 'dataframe'
#                                             , 'keys_columns': ['PositionDate','Constituent_Description','Constituee_PSPInstrumentID']
#                                             , 'attributes_columns': ['Constituent_IssuerName','Constituent_CurrencyCode','Constituent_Family','Constituent_PSPInstrumentCategorizationCode','Constituent_Market','Constituent_Type','Constituee_Type','Constituent_FinancialMaturityDate'] 
#                                             , 'data_columns': ['Constituent_IssuerCode','Constituent_Weight','Constituent_PSPInstrumentID','Constituent_PSPInstrumentCategorizationID','Constituent_IssuerExposureFactor','Constituent_EquityExposureFactor'] 
#                                             , 'data_format' : {  'Int64': ['Constituent_IssuerCode','Constituent_PSPInstrumentID','Constituent_PSPInstrumentCategorizationID']
#                                                                , 'float': ['Constituent_Weight','Constituent_IssuerExposureFactor','Constituent_EquityExposureFactor']
#                                                                , 'date': ['PositionDate','Constituent_FinancialMaturityDate']
#                                                                }
#                                             , 'data_derror_tolerance' : 1000
#                                             , 'data_perror_tolerance' : 0.00001
#                                             }                    

fact_all_constituents_dict =    { 'file_format': 'csv'
                                , 'keys_columns': ['PositionDate','Constituent_PSPInstrumentID','Constituee_PSPInstrumentID','Constituent_Description']
                                , 'attributes_columns': ['Constituent_IssuerName','Constituent_CurrencyCode','Constituent_Family','Constituent_PSPInstrumentCategorizationCode','Constituent_Market','Constituent_Type','Constituee_Type','Constituent_FinancialMaturityDate'] 
                                , 'data_columns': ['Constituent_IssuerCode','Constituent_Weight','Constituent_PSPInstrumentCategorizationID','Constituent_IssuerExposureFactor','Constituent_EquityExposureFactor'] 
                                , 'data_format' : {  'Int64': ['Constituent_IssuerCode','Constituent_PSPInstrumentID','Constituent_PSPInstrumentCategorizationID']
                                                   , 'float': ['Constituent_Weight','Constituent_IssuerExposureFactor','Constituent_EquityExposureFactor']
                                                   , 'date': ['PositionDate','Constituent_FinancialMaturityDate']
                                                   }
                                , 'data_derror_tolerance' : 1000
                                , 'data_perror_tolerance' : 0.0001
                                }                                             

#fact_exposure_no_pspinstrumentid_dict =   { 'file_format': 'dataframe'
#                                          , 'keys_columns': ['PositionDate','Object_Type','Portfolio_PSPPortfolioCode','Instrument_CurrencyCode','Instrument_ReportingCurrencyCode','Instrument_Description']
#                                          , 'attributes_columns': ['Position_Type','Position_Source','Portfolio_PSPPortfolioID','Instrument_PSPInstrumentCategorizationID','Instrument_PSPInstrumentCategorizationCode','Instrument_PSPInstrumentID','Leg_PSPInstrumentLegID','UltimateUnderlying_PSPInstrumentID','UltimateUnderlying_PSPInstrumentCategorizationID','UltimateUnderlying_PSPInstrumentCategorizationCode','UltimateUnderlying_Description','UltimateUnderlying_IssuerCode','UltimateUnderlying_IndexProxyPSPInstrumentID','Instrument_RiskLocationCountryCode','Instrument_NormalizedCountryCode','Instrument_GeographyName','Instrument_BICSBETAClassificationID','Instrument_BICSBETASectorCode','Instrument_BICSBETASectorName','Instrument_BICSBETAIndustryGroupCode','Instrument_BICSBETAIndustryGroupName','Instrument_BICSBETAIndustryCode','Instrument_BICSBETAIndustryName','Instrument_BICSBETASubIndustryCode','Instrument_BICSBETASubIndustryName','Instrument_BICSBETAActivityCode','Instrument_BICSBETAActivityName','Instrument_BICSBETASubActivityCode','Instrument_BICSBETASubActivityName','Instrument_BICSBETASegmentCode','Instrument_BICSBETASegmentName','Instrument_GICSSectorCode','Instrument_GICSSectorName','Instrument_GICSIndustryGroupName','Instrument_GICSIndustryCode','Instrument_GICSIndustryName','Instrument_GICSSubIndustryName','Leg_Type','Leg_Direction','Leg_PositionLevel','Option_Style','MostRecent_CalendarKey','BatchKey','Portfolio_Key','Instrument_Key','RiskMetricsPositionType','normal_calculation_family','exotic_calculation_family','use_pooled_fund_calculations','SourceDate','Instrument_FinancialMaturityDate','UltimateUnderlying_FinancialMaturityDate'] 
#                                          , 'data_columns': ['Position_NetAssetValue_CAD','Exposure_FI','Exposure_CR','Exposure_Issuer','Exposure_Equity','Exposure_FX','Exposure_Commodity'] 
#                                          , 'data_format' : {  'Int64': ['Portfolio_PSPPortfolioID','Instrument_PSPInstrumentID','Instrument_PSPInstrumentCategorizationID','UltimateUnderlying_PSPInstrumentID','UltimateUnderlying_PSPInstrumentCategorizationID','UltimateUnderlying_IndexProxyPSPInstrumentID','Instrument_BICSBETAClassificationID','Instrument_BICSBETASectorCode','Instrument_BICSBETAIndustryGroupCode','Instrument_BICSBETAIndustryCode','Instrument_BICSBETASubIndustryCode','Instrument_BICSBETAActivityCode','Instrument_BICSBETASubActivityCode','Instrument_BICSBETASegmentCode','Instrument_GICSSectorCode','Instrument_GICSIndustryCode','Leg_PSPInstrumentLegID','BatchKey','Portfolio_Key','Instrument_Key']
#                                                          , 'float': ['Position_NetAssetValue_CAD','Exposure_FI','Exposure_CR','Exposure_Issuer','Exposure_Equity','Exposure_FX','Exposure_Commodity']
#                                                          , 'date': ['PositionDate','MostRecent_CalendarKey','SourceDate']
#                                                          }
#                                          , 'data_derror_tolerance' : 1000
#                                          , 'data_perror_tolerance' : 0.00001
#                                          }                         

fact_exposure_dict =   { 'file_format': 'csv'
                       , 'keys_columns': ['PositionDate','Object_Type','Portfolio_PSPPortfolioCode','Instrument_CurrencyCode','Instrument_ReportingCurrencyCode','Instrument_PSPInstrumentID','Leg_PSPInstrumentLegID','Instrument_RiskLocationCountryCode','Instrument_BICSBETAClassificationID','Instrument_Key'] #'Instrument_Description',
                       , 'attributes_columns': ['Position_Type','Position_Source','Portfolio_PSPPortfolioID','Instrument_PSPInstrumentCategorizationID','Instrument_PSPInstrumentCategorizationCode','UltimateUnderlying_PSPInstrumentID','UltimateUnderlying_PSPInstrumentCategorizationID','UltimateUnderlying_PSPInstrumentCategorizationCode','UltimateUnderlying_Description','UltimateUnderlying_IssuerCode','UltimateUnderlying_IndexProxyPSPInstrumentID','Instrument_NormalizedCountryCode','Instrument_GeographyName','Instrument_BICSBETASectorCode','Instrument_BICSBETASectorName','Instrument_BICSBETAIndustryGroupCode','Instrument_BICSBETAIndustryGroupName','Instrument_BICSBETAIndustryCode','Instrument_BICSBETAIndustryName','Instrument_BICSBETASubIndustryCode','Instrument_BICSBETASubIndustryName','Instrument_BICSBETAActivityCode','Instrument_BICSBETAActivityName','Instrument_BICSBETASubActivityCode','Instrument_BICSBETASubActivityName','Instrument_BICSBETASegmentCode','Instrument_BICSBETASegmentName','Instrument_GICSSectorCode','Instrument_GICSSectorName','Instrument_GICSIndustryGroupName','Instrument_GICSIndustryCode','Instrument_GICSIndustryName','Instrument_GICSSubIndustryName','Leg_Type','Leg_Direction','Leg_PositionLevel','Option_Style','MostRecent_CalendarKey','BatchKey','Portfolio_Key','RiskMetricsPositionType','normal_calculation_family','exotic_calculation_family','use_pooled_fund_calculations','SourceDate','Instrument_FinancialMaturityDate','UltimateUnderlying_FinancialMaturityDate'] 
                       , 'data_columns': ['Position_NetAssetValue_CAD','Exposure_FI','Exposure_CR','Exposure_Issuer','Exposure_Equity','Exposure_FX','Exposure_Commodity'] 
                       , 'data_format' : {  'Int64': ['Portfolio_PSPPortfolioID','Instrument_PSPInstrumentID','Instrument_PSPInstrumentCategorizationID','UltimateUnderlying_PSPInstrumentID','UltimateUnderlying_PSPInstrumentCategorizationID','UltimateUnderlying_IndexProxyPSPInstrumentID','Instrument_BICSBETAClassificationID','Instrument_BICSBETASectorCode','Instrument_BICSBETAIndustryGroupCode','Instrument_BICSBETAIndustryCode','Instrument_BICSBETASubIndustryCode','Instrument_BICSBETAActivityCode','Instrument_BICSBETASubActivityCode','Instrument_BICSBETASegmentCode','Instrument_GICSSectorCode','Instrument_GICSIndustryCode','Leg_PSPInstrumentLegID','BatchKey','Portfolio_Key','Instrument_Key']
                                          , 'float': ['Position_NetAssetValue_CAD','Exposure_FI','Exposure_CR','Exposure_Issuer','Exposure_Equity','Exposure_FX','Exposure_Commodity']
                                          , 'date': ['PositionDate','MostRecent_CalendarKey','SourceDate']
                                          }
                       , 'data_derror_tolerance' : 1000
                       , 'data_perror_tolerance' : 0.0001
                       }             

fact_portfolios_dict = { 'file_format': 'csv'
                       , 'keys_columns': ['PositionDate','Portfolio_PSPPortfolioCode']
                       , 'attributes_columns': ['Portfolio_PSPPortfolioID','Portfolio_Name','Portfolio_Type','Portfolio_MarketType','Portfolio_AssetClass','Portfolio_InvestmentTeam','Portfolio_ManagerType','Portfolio_ManagingStyle','Portfolio_ManagingDepartment','Portfolio_OwnerDepartment'] 
                       , 'data_columns': ['Portfolio_Position_Count','Portfolio_Position_MarketValue_CAD','Portfolio_Position_NetAssetValue_CAD','Portfolio_Internal_Count','Portfolio_Internal_MarketValue_CAD','Portfolio_Internal_NetAssetValue_CAD','Portfolio_PooledFund_Count','Portfolio_PooledFund_MarketValue_CAD','Portfolio_PooledFund_NetAssetValue_CAD'] 
                       , 'data_format' : {  'Int64': ['Portfolio_PSPPortfolioID','Portfolio_Position_Count','Portfolio_Internal_Count','Portfolio_PooledFund_Count']
                                          , 'float': ['Portfolio_Position_MarketValue_CAD','Portfolio_Position_NetAssetValue_CAD','Portfolio_Internal_MarketValue_CAD','Portfolio_Internal_NetAssetValue_CAD','Portfolio_PooledFund_MarketValue_CAD','Portfolio_PooledFund_NetAssetValue_CAD']
                                          , 'date': ['PositionDate']
                                          }
                       , 'data_derror_tolerance' : 1000
                       , 'data_perror_tolerance' : 0.0001
                      }



##Raw Query validation
private_markets_query_dict =   { 'file_format': 'dataframe'
                               , 'keys_columns': ['PositionDate','Portfolio_PSPPortfolioCode','Instrument_PSPInstrumentID','Instrument_CurrencyCode','Instrument_RiskLocationCountryCode','Instrument_BICSBETAClassificationID','Instrument_GeographyName']
                               , 'attributes_columns': ['SourceDate','Portfolio_PSPPortfolioID','Portfolio_Name','Portfolio_MarketType','Portfolio_AssetClass','Portfolio_InvestmentTeam','Portfolio_ManagerType','Portfolio_ManagingStyle','Portfolio_ManagingDepartment','Portfolio_OwnerDepartment','Leg_PSPInstrumentLegID','Instrument_NormalizedCountryCode','Instrument_BICSBETASectorCode','Instrument_BICSBETASectorName','Instrument_BICSBETAIndustryGroupCode','Instrument_BICSBETAIndustryGroupName','Instrument_BICSBETAIndustryCode','Instrument_BICSBETAIndustryName','Instrument_BICSBETASubIndustryCode','Instrument_BICSBETASubIndustryName','Instrument_BICSBETAActivityCode','Instrument_BICSBETAActivityName','Instrument_BICSBETASubActivityCode','Instrument_BICSBETASubActivityName','Instrument_BICSBETASegmentCode','Instrument_BICSBETASegmentName'] 
                               , 'data_columns': ['Position_Quantity','Position_NominalAmount','Position_MarketValue_CAD','Position_AccruedInterestValue_CAD','Position_TaxReclaimValue_CAD','Position_NetAssetValue_CAD','Position_ExposureValue_CAD'] 
                               , 'data_format' : {  'Int64': ['Portfolio_PSPPortfolioID','Instrument_PSPInstrumentID','Leg_PSPInstrumentLegID','Instrument_BICSBETAClassificationID']
                                                  , 'float': ['Position_Quantity','Position_NominalAmount','Position_MarketValue_CAD','Position_AccruedInterestValue_CAD','Position_TaxReclaimValue_CAD','Position_NetAssetValue_CAD','Position_ExposureValue_CAD']
                                                  , 'date': ['PositionDate','SourceDate']
                                                  }
                               , 'data_derror_tolerance' : 1000
                               , 'data_perror_tolerance' : 0.00001
                               }                                                                               


all_tfe_validation_constants = {  'dim_countries': dim_countries_dict
                                , 'dim_gics': dim_gics_dict
                                , 'dim_portfolios': dim_portfolios_dict
                                , 'fact_all_constituents': fact_all_constituents_dict
                                , 'dim_issuers': dim_issuers_dict
                                , 'fact_exposure': fact_exposure_dict
                                , 'fact_portfolios': fact_portfolios_dict}