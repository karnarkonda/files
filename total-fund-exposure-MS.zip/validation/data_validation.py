from utils.data_acquisition import try_dictionnary_acquisition
import pandas as pd
pd.options.display.max_rows = 100
pd.options.display.max_columns = 100

def function_compare_report(  path: str
                            , comparison: str
                            , result_function_compare_dataset
                            , do_not_investigate = []
                            , verbose = False
                            ):
        
        dataset_to_investigate = []
        dataframe_to_investigate = []
        report_path = path + 'comparison_' + comparison  + '.xlsx'
        with pd.ExcelWriter(report_path) as writer:
                for dataset in result_function_compare_dataset:
                        dataset_dataframe = try_dictionnary_acquisition('dataframe', result_function_compare_dataset[dataset])
                        dataset_result    = try_dictionnary_acquisition('result', result_function_compare_dataset[dataset])
                        if dataset_dataframe is not None and verbose:
                                print(dataset, dataset_result)
                                if dataset_result>0:
                                        if verbose:
                                                display(dataset_dataframe)
                                        if dataset not in do_not_investigate:
                                                dataset_to_investigate.append([dataset, dataset_result])
                                        dataset_columns = [col for col in dataset_dataframe.columns]
                                        dataset_dataframe['status'] = ''
                                        dataset_dataframe = dataset_dataframe[['status'] + dataset_columns]
                                        dataframe_to_investigate.append([dataset, dataset_dataframe])
                if len(dataset_to_investigate)>0 :

                        requires_validation = True
                        df_to_investigate = pd.DataFrame(dataset_to_investigate, columns = ['dataset','rows'])
                        df_to_investigate['status'] = ''
                        df_to_investigate.to_excel(writer, sheet_name = 'status', index = False)
                        for row in dataframe_to_investigate:
                                dataset_name = row[0]
                                dataset_df = row[1]
                                if len(dataset_df.index) >= 1048576:
                                        dataset_df.to_csv(path + dataset_name + '.csv')
                                else:
                                        dataset_df.to_excel(writer, sheet_name = dataset_name, index = False)
                else:
                        requires_validation = False

        return requires_validation

def function_compare_dataset(  compare_dictionary
                             , path_PRE = None
                             , path_POST = None
                             , df_PRE = None
                             , df_POST= None
                             ):
        file_format           = try_dictionnary_acquisition('file_format', compare_dictionary)
        data_format           = try_dictionnary_acquisition('data_format',compare_dictionary)
        keys_columns          = try_dictionnary_acquisition('keys_columns', compare_dictionary)
        attributes_columns    = try_dictionnary_acquisition('attributes_columns', compare_dictionary)
        data_columns          = try_dictionnary_acquisition('data_columns', compare_dictionary)
        data_derror_tolerance = try_dictionnary_acquisition('data_derror_tolerance', compare_dictionary, 0)
        data_perror_tolerance = try_dictionnary_acquisition('data_perror_tolerance', compare_dictionary, 0)

        result_dict = {}

        #Check if file format is defined
        if (file_format is None):
                result_dict['status']  = 'Failure'
                result_dict['message'] = 'Dataset file_format is missing'
                return result_dict

        #Check if keys columns is defined
        if (keys_columns is None):
                result_dict['status']  = 'Failure'
                result_dict['message'] = 'Dataset keys_columns is missing'
                return result_dict
        
        #Define full columns vector with keys and attributes and data columns if applicable
        full_columns = keys_columns + (attributes_columns if attributes_columns is not None else []) + (data_columns if data_columns is not None else [])
        
        #Genrates compare columns with version for PRE and POST dataset
        compare_columns = [row for row in full_columns if row not in keys_columns]
        compare_columns_PRE  = [column + '_PRE' for column in compare_columns]
        compare_columns_POST = [column + '_POST' for column in compare_columns]

        #Extract files based on provided format
        #Csv type file
        if file_format == 'csv':
                current_file_PRE  = pd.read_csv(path_PRE, delimiter = ';')[full_columns]
                current_file_POST = pd.read_csv(path_POST, delimiter = ';')[full_columns]
                #display(current_file_PRE)
                #display(current_file_POST)
                #To be deleted, used for test
                #current_file_PRE = current_file_PRE[current_file_PRE['Country_ISOCode']!='AD']
                #current_file_POST = current_file_POST[current_file_POST['Country_ISOCode']!='AE']
                
        #Dataframe type file bypass file loading and use provided dataframe
        elif file_format == 'dataframe':
                if df_PRE is None:
                        result_dict['status']  = 'Failure'
                        result_dict['message'] = 'Missing PRE dataframe using dataframe format'
                        return result_dict
                if df_POST is None:
                        result_dict['status']  = 'Failure'
                        result_dict['message'] = 'Missing POST dataframe using dataframe format'
                        return result_dict
                else:
                        current_file_PRE   = df_PRE[full_columns]
                        current_file_POST  = df_POST[full_columns]
        
        #Format columns based on provided data_format dictionnary
        if data_format is not None:
                for format in data_format:
                        print(format)
                        if format == 'date':
                                for date_column in data_format[format]:
                                        try:
                                                current_file_PRE[date_column]  = pd.to_datetime(current_file_PRE[date_column], format = '%Y-%m-%d')
                                                current_file_POST[date_column] = pd.to_datetime(current_file_POST[date_column], format = '%Y-%m-%d')
                                        except Exception as error:
                                                print('Issuer casting ' + date_column + ' to ' + format + '. Reverting to original format')
                                                print(str(error))
                                                
                        elif format == 'float':
                                for column in data_format[format]:
                                        try:
                                                current_file_PRE[column]  = current_file_PRE[column].astype(format).round(decimals = 2)
                                                current_file_POST[column] = current_file_POST[column].astype(format).round(decimals = 2)
                                        except Exception as error:
                                                print('Issuer casting ' + column + ' to ' + format + '. Reverting to original format')
                                                print(str(error))
                        else:
                                for column in data_format[format]:
                                        try:
                                                current_file_PRE[column]  = current_file_PRE[column].astype(format)
                                                current_file_POST[column] = current_file_POST[column].astype(format)
                                        except Exception as error:
                                                print('Issuer casting ' + column + ' to ' + format + '. Reverting to original format')
                                                print(str(error))

        
        #Identify duplicates for PRE and POST
        duplicate_from_PRE     = current_file_PRE[current_file_PRE.duplicated(subset = keys_columns, keep = False)][keys_columns + compare_columns].sort_values(keys_columns).copy(deep = True)
        duplicate_from_POST    = current_file_POST[current_file_POST.duplicated(subset = keys_columns, keep = False)][keys_columns + compare_columns].sort_values(keys_columns).copy(deep = True)
        #result_dict['detailed_duplicate_from_PRE']  = {'result' : len(duplicate_from_PRE.index), 'dataframe': duplicate_from_PRE}
        #result_dict['detailed_duplicate_from_POST'] = {'result' : len(duplicate_from_POST.index), 'dataframe': duplicate_from_POST}

        #duplicate shared in both PRE and POST
        duplicate_unique_PRE_df  = current_file_PRE[current_file_PRE.duplicated(subset = keys_columns, keep = False)][keys_columns].drop_duplicates()
        result_dict['duplicate_from_PRE']  = {'result' : len(duplicate_unique_PRE_df.index), 'dataframe': duplicate_unique_PRE_df}

        duplicate_unique_POST_df = current_file_POST[current_file_POST.duplicated(subset = keys_columns, keep = False)][keys_columns].drop_duplicates()
        result_dict['duplicate_from_POST']  = {'result' : len(duplicate_unique_POST_df.index), 'dataframe': duplicate_unique_POST_df}
        duplicate_shared_df = duplicate_unique_PRE_df.merge(  duplicate_unique_POST_df
                                                            , on = keys_columns
                                                            , how = 'inner'
                                                            , indicator = True
                                                           )

        result_dict['shared_duplicate'] = {'result' : len(duplicate_shared_df.index), 'dataframe': duplicate_shared_df}

        #Merge both dataset, excluding duplicated data
        current_file_PRE  = current_file_PRE.drop_duplicates(subset = keys_columns)
        current_file_POST = current_file_POST.drop_duplicates(subset = keys_columns)

        master_file = current_file_PRE.merge(  current_file_POST
                                             , on = keys_columns
                                             , how = 'outer'
                                             , suffixes = ['_PRE','_POST']
                                             , indicator = True
                                             )
        
        #Identify missing data from PRE and POST merge
        missing_from_PRE  = master_file[master_file['_merge'] == 'right_only'].copy(deep = True).drop(columns = ['_merge'] + compare_columns_PRE)[keys_columns + compare_columns_POST].sort_values(keys_columns)
        missing_from_POST = master_file[master_file['_merge'] == 'left_only'].copy(deep = True).drop(columns = ['_merge'] + compare_columns_POST)[keys_columns + compare_columns_PRE].sort_values(keys_columns)
        result_dict['missing_from_PRE'] =  {'result' : len(missing_from_PRE.index), 'dataframe': missing_from_PRE}
        result_dict['missing_from_POST'] = {'result' : len(missing_from_POST.index), 'dataframe': missing_from_POST}

        master_file = master_file[master_file['_merge'] == 'both'].copy(deep = True)

        if attributes_columns is not None:
                comparison_attributes = None
                agg_comparison_attributes = None
                attributes_columns_PRE  = [column + '_PRE' for column in attributes_columns]
                attributes_columns_POST = [column + '_POST' for column in attributes_columns]
                attributes_columns_FULL = attributes_columns_PRE + attributes_columns_POST
                attributes_columns_FULL.sort()

                for id in range(len(attributes_columns)):
                        current_column        = attributes_columns[id]
                        current_column_PRE    = attributes_columns_PRE[id]
                        current_column_POST   = attributes_columns_POST[id]

                        current_attribute_df = master_file[keys_columns + [current_column_PRE, current_column_POST]].copy(deep = True)
                        current_attribute_df['attribute_name'] = current_column
                        current_attribute_df = current_attribute_df.rename(columns = {  current_column_PRE: 'attribute_value_pre'
                                                                                      , current_column_POST: 'attribute_value_post'})
                        current_attribute_df['attribute_status'] = 0
                        current_attribute_df['attribute_failure'] = 0

                        #We define a filter in case any data are missing, both in PRE and in POST
                        pre_nan_filter = (current_attribute_df['attribute_value_pre'].isnull())
                        post_nan_filter = (current_attribute_df['attribute_value_post'].isnull())
                        non_equality_filter  = (current_attribute_df['attribute_value_pre'] != current_attribute_df['attribute_value_post'])
                        
                        pre_nan_only_filter         = (pre_nan_filter)&(~post_nan_filter)
                        post_nan_only_filter        = ~(pre_nan_filter)&(post_nan_filter)
                        both_nan_filter             = (pre_nan_filter)&(post_nan_filter)
                        any_nan_filter              = (pre_nan_filter)|(post_nan_filter)
                        non_equality_non_nan_filter = (non_equality_filter)&(~any_nan_filter)
                        equality_non_nan_filter     = (~non_equality_filter)&(~any_nan_filter)

                        #We define a filter in case both data are missing, both in PRE and in POST
                        current_attribute_df.loc[both_nan_filter, 'attribute_status'] = '0_0'
                        current_attribute_df.loc[both_nan_filter, 'attribute_0_0'] = 1
                        current_attribute_df.loc[both_nan_filter, 'attribute_failure'] = 0
                              
                        #We define a filter in case PRE is nan and POST is not nan
                        current_attribute_df.loc[pre_nan_only_filter, 'attribute_status'] = '0_1'
                        current_attribute_df.loc[pre_nan_only_filter, 'attribute_0_1'] = 1
                        current_attribute_df.loc[pre_nan_only_filter, 'attribute_failure'] = 1
                        
                        #We define a filter in case PRE is not nan and POST is nan
                        current_attribute_df.loc[post_nan_only_filter, 'attribute_status'] = '1_0'
                        current_attribute_df.loc[post_nan_only_filter, 'attribute_1_0'] = 1
                        current_attribute_df.loc[post_nan_only_filter, 'attribute_failure'] = 1
                        
                        #We define a filter in case PRE is different than POST, but both are not nan
                        current_attribute_df.loc[non_equality_non_nan_filter, 'attribute_status'] = '1_1_D'
                        current_attribute_df.loc[non_equality_non_nan_filter, 'attribute_1_1_D'] = 1
                        current_attribute_df.loc[non_equality_non_nan_filter, 'attribute_failure'] = 1

                        #We define a filter in case PRE is POST, but both are not nan
                        current_attribute_df.loc[equality_non_nan_filter, 'attribute_status'] = '1_1_S'
                        current_attribute_df.loc[equality_non_nan_filter, 'attribute_1_1_S'] = 1
                        current_attribute_df.loc[equality_non_nan_filter, 'attribute_failure'] = 0

                        current_attribute_df['attribute_0_0']   = current_attribute_df['attribute_0_0'].fillna(0)    
                        current_attribute_df['attribute_0_1']   = current_attribute_df['attribute_0_1'].fillna(0) 
                        current_attribute_df['attribute_1_0']   = current_attribute_df['attribute_1_0'].fillna(0)  
                        current_attribute_df['attribute_1_1_D'] = current_attribute_df['attribute_1_1_D'].fillna(0)  
                        current_attribute_df['attribute_1_1_S'] = current_attribute_df['attribute_1_1_S'].fillna(0)  

                        current_attribute_df['logic_test'] = current_attribute_df['attribute_0_0'] + current_attribute_df['attribute_0_1'] + current_attribute_df['attribute_1_0'] + current_attribute_df['attribute_1_1_D'] + current_attribute_df['attribute_1_1_S']
                        current_attribute_df['total'] = 1

                        agg_total_0_0   = pd.NamedAgg(column = 'attribute_0_0', aggfunc = 'sum')
                        agg_total_0_1   = pd.NamedAgg(column = 'attribute_0_1', aggfunc = 'sum')
                        agg_total_1_0   = pd.NamedAgg(column = 'attribute_1_0', aggfunc = 'sum')
                        agg_total_1_1_D = pd.NamedAgg(column = 'attribute_1_1_D', aggfunc = 'sum')
                        agg_total_1_1_S = pd.NamedAgg(column = 'attribute_1_1_S', aggfunc = 'sum')
                        agg_total_logic = pd.NamedAgg(column = 'logic_test', aggfunc = 'sum')
                        agg_total       = pd.NamedAgg(column = 'total', aggfunc = 'sum')

                        current_agg = current_attribute_df.groupby(['attribute_name'], dropna = False).agg(  total_0_0   = agg_total_0_0
                                                                                                           , total_0_1   = agg_total_0_1
                                                                                                           , total_1_0   = agg_total_1_0
                                                                                                           , total_1_1_D = agg_total_1_1_D
                                                                                                           , total_1_1_S = agg_total_1_1_S
                                                                                                           , total_logic = agg_total_logic
                                                                                                           , total       = agg_total)
                        #display(current_agg)
                        current_agg = current_agg.astype('int').reset_index()

                        if agg_comparison_attributes is None:
                                agg_comparison_attributes = current_agg
                        else:
                                agg_comparison_attributes = pd.concat([agg_comparison_attributes, current_agg])

                        current_attribute_failure_df = current_attribute_df[current_attribute_df['attribute_failure'] == 1][['attribute_name'] + keys_columns + ['attribute_status','attribute_value_pre','attribute_value_post']]
                        if len(current_attribute_failure_df.index)>0:
                                if comparison_attributes is None:
                                        comparison_attributes = current_attribute_failure_df
                                else:
                                        comparison_attributes = pd.concat([comparison_attributes, current_attribute_failure_df])

                if agg_comparison_attributes is None:
                        result_dict['attributes_agg_analysis'] = {'result' : 0, 'dataframe': None}
                else:
                        result_dict['attributes_agg_analysis'] = {'result' : len(agg_comparison_attributes.index), 'dataframe': agg_comparison_attributes}

                if comparison_attributes is None:
                        result_dict['comparison_attributes'] = {'result' : 0, 'dataframe': None}
                else:
                        result_dict['comparison_attributes'] = {'result' : len(comparison_attributes.index), 'dataframe': comparison_attributes}
                        

        if data_columns is not None:
                comparison_data = None
                agg_comparison_data = None
                data_columns_PRE  = [column + '_PRE' for column in data_columns]
                data_columns_POST = [column + '_POST' for column in data_columns]
                data_columns_FULL = data_columns_PRE + data_columns_POST
                data_columns_FULL.sort()

                for id in range(len(data_columns)):
                        current_column        = data_columns[id]
                        current_column_PRE    = data_columns_PRE[id]
                        current_column_POST   = data_columns_POST[id]

                        current_data_df = master_file[keys_columns + [current_column_PRE, current_column_POST]].copy(deep = True)
                        current_data_df['data_name'] = current_column
                        current_data_df = current_data_df.rename(columns = {  current_column_PRE: 'data_value_pre'
                                                                            , current_column_POST: 'data_value_post'})
                        current_data_df['data_status'] = 0
                        current_data_df['data_failure'] = 0

                        #We define a filter in case any data are missing, both in PRE and in POST
                        pre_nan_filter = (current_data_df['data_value_pre'].isnull())
                        post_nan_filter = (current_data_df['data_value_post'].isnull())
                        non_equality_filter = (current_data_df['data_value_pre'] != current_data_df['data_value_post'])
                        derror_pass_filter  = (abs(current_data_df['data_value_post'] - current_data_df['data_value_pre']) <= data_derror_tolerance)
                        perror_pass_filter  = (abs(current_data_df['data_value_post'] / current_data_df['data_value_pre'] - 1.0) <= data_perror_tolerance)
                        error_pass_filter   = (derror_pass_filter)&(perror_pass_filter)
                        
                        pre_nan_only_filter                  = (pre_nan_filter)&(~post_nan_filter)
                        post_nan_only_filter                 = ~(pre_nan_filter)&(post_nan_filter)
                        both_nan_filter                      = (pre_nan_filter)&(post_nan_filter)
                        any_nan_filter                       = (pre_nan_filter)|(post_nan_filter)
                        non_equality_non_nan_pass_filter     = (non_equality_filter)&(~any_nan_filter)&(error_pass_filter)
                        non_equality_non_nan_non_pass_filter = (non_equality_filter)&(~any_nan_filter)&(~error_pass_filter)
                        equality_non_nan_filter              = (~non_equality_filter)&(~any_nan_filter)

                        #We define a filter in case both data are missing, both in PRE and in POST
                        current_data_df.loc[both_nan_filter, 'data_status'] = '0_0'
                        current_data_df.loc[both_nan_filter, 'data_0_0'] = 1
                        current_data_df.loc[both_nan_filter, 'data_failure'] = 0
                        current_data_df.loc[both_nan_filter, 'data_derror'] = 0
                        current_data_df.loc[both_nan_filter, 'data_perror'] = 0
                              
                        #We define a filter in case PRE is nan and POST is not nan
                        current_data_df.loc[pre_nan_only_filter, 'data_status'] = '0_1'
                        current_data_df.loc[pre_nan_only_filter, 'data_0_1'] = 1
                        current_data_df.loc[pre_nan_only_filter, 'data_failure'] = 1
                        current_data_df.loc[pre_nan_only_filter, 'data_derror'] = current_data_df.loc[pre_nan_only_filter, 'data_value_post']
                        current_data_df.loc[pre_nan_only_filter, 'data_perror'] = float('inf')
                        
                        #We define a filter in case PRE is not nan and POST is nan
                        current_data_df.loc[post_nan_only_filter, 'data_status'] = '1_0'
                        current_data_df.loc[post_nan_only_filter, 'data_1_0'] = 1
                        current_data_df.loc[post_nan_only_filter, 'data_failure'] = 1
                        current_data_df.loc[post_nan_only_filter, 'data_derror'] = -1.0 * current_data_df.loc[post_nan_only_filter, 'data_value_pre']
                        current_data_df.loc[post_nan_only_filter, 'data_perror'] = -1.0
                        
                        #We define a filter in case PRE is different than POST, but both are not nan and they do not pass error filter
                        current_data_df.loc[non_equality_non_nan_pass_filter, 'data_status'] = '1_1_S'
                        current_data_df.loc[non_equality_non_nan_pass_filter, 'data_1_1_S'] = 1
                        current_data_df.loc[non_equality_non_nan_pass_filter, 'data_failure'] = 0
                        current_data_df.loc[non_equality_non_nan_pass_filter, 'data_derror'] = current_data_df.loc[non_equality_non_nan_pass_filter, 'data_value_post'] - current_data_df.loc[non_equality_non_nan_pass_filter, 'data_value_pre']
                        current_data_df.loc[non_equality_non_nan_pass_filter, 'data_perror'] = current_data_df.loc[non_equality_non_nan_pass_filter, 'data_value_post'] / current_data_df.loc[non_equality_non_nan_pass_filter, 'data_value_pre'] - 1.0

                        #We define a filter in case PRE is different than POST, but both are not nan and they pass error filter
                        current_data_df.loc[non_equality_non_nan_non_pass_filter, 'data_status'] = '1_1_D'
                        current_data_df.loc[non_equality_non_nan_non_pass_filter, 'data_1_1_D'] = 1
                        current_data_df.loc[non_equality_non_nan_non_pass_filter, 'data_failure'] = 1
                        current_data_df.loc[non_equality_non_nan_non_pass_filter, 'data_derror'] = current_data_df.loc[non_equality_non_nan_non_pass_filter, 'data_value_post'] - current_data_df.loc[non_equality_non_nan_non_pass_filter, 'data_value_pre']
                        current_data_df.loc[non_equality_non_nan_non_pass_filter, 'data_perror'] = current_data_df.loc[non_equality_non_nan_non_pass_filter, 'data_value_post'] / current_data_df.loc[non_equality_non_nan_non_pass_filter, 'data_value_pre'] - 1.0

                        #We define a filter in case PRE is POST, but both are not nan
                        current_data_df.loc[equality_non_nan_filter, 'data_status'] = '1_1_S'
                        current_data_df.loc[equality_non_nan_filter, 'data_1_1_S'] = 1
                        current_data_df.loc[equality_non_nan_filter, 'data_failure'] = 0
                        current_data_df.loc[equality_non_nan_filter, 'data_derror'] = 0
                        current_data_df.loc[equality_non_nan_filter, 'data_perror'] = 0

                        current_data_df['data_0_0']   = current_data_df['data_0_0'].fillna(0)    
                        current_data_df['data_0_1']   = current_data_df['data_0_1'].fillna(0) 
                        current_data_df['data_1_0']   = current_data_df['data_1_0'].fillna(0)  
                        current_data_df['data_1_1_D'] = current_data_df['data_1_1_D'].fillna(0)  
                        current_data_df['data_1_1_S'] = current_data_df['data_1_1_S'].fillna(0)  

                        current_data_df['logic_test'] = current_data_df['data_0_0'] + current_data_df['data_0_1'] + current_data_df['data_1_0'] + current_data_df['data_1_1_D'] + current_data_df['data_1_1_S']
                        current_data_df['total'] = 1

                        agg_total_0_0   = pd.NamedAgg(column = 'data_0_0', aggfunc = 'sum')
                        agg_total_0_1   = pd.NamedAgg(column = 'data_0_1', aggfunc = 'sum')
                        agg_total_1_0   = pd.NamedAgg(column = 'data_1_0', aggfunc = 'sum')
                        agg_total_1_1_D = pd.NamedAgg(column = 'data_1_1_D', aggfunc = 'sum')
                        agg_total_1_1_S = pd.NamedAgg(column = 'data_1_1_S', aggfunc = 'sum')
                        agg_total_logic = pd.NamedAgg(column = 'logic_test', aggfunc = 'sum')
                        agg_total       = pd.NamedAgg(column = 'total', aggfunc = 'sum')

                        current_agg = current_data_df.groupby(['data_name'], dropna = False).agg(  total_0_0   = agg_total_0_0
                                                                                                 , total_0_1   = agg_total_0_1
                                                                                                 , total_1_0   = agg_total_1_0
                                                                                                 , total_1_1_D = agg_total_1_1_D
                                                                                                 , total_1_1_S = agg_total_1_1_S
                                                                                                 , total_logic = agg_total_logic
                                                                                                 , total       = agg_total)
                        #display(current_agg)
                        current_agg = current_agg.astype('int').reset_index()

                        if agg_comparison_data is None:
                                agg_comparison_data = current_agg
                        else:
                                agg_comparison_data = pd.concat([agg_comparison_data, current_agg])

                        current_data_failure_df = current_data_df[current_data_df['data_failure'] == 1][['data_name'] + keys_columns + ['data_status','data_value_pre','data_value_post', 'data_derror', 'data_perror']]
                        if len(current_data_failure_df.index)>0:
                                if comparison_data is None:
                                        comparison_data = current_data_failure_df
                                else:
                                        comparison_data = pd.concat([comparison_data, current_data_failure_df])

                if agg_comparison_data is None:
                        result_dict['data_agg_analysis'] = {'result' : 0, 'dataframe': None}
                else:
                        result_dict['data_agg_analysis'] = {'result' : len(agg_comparison_data.index), 'dataframe': agg_comparison_data}

                if comparison_data is None:
                        result_dict['comparison_data'] = {'result' : 0, 'dataframe': None}
                else:
                        result_dict['comparison_data'] = {'result' : len(comparison_data.index), 'dataframe': comparison_data}
                        
            
        
        return result_dict