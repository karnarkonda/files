""" Pytest auto-import module"""

import pytest
import requests


@pytest.fixture(autouse=True)
def disable_network_calls(monkeypatch):
    """
    A fixture that blocks tests from making real network calls during test
    execution. External dependecy calls(e.g API calls) should always be mocked.
    """

    def disable_get():
        raise RuntimeError("Network access not allowed during testing!")

    def disable_post():
        raise RuntimeError("Network access not allowed during testing!")

    monkeypatch.setattr(requests, "get", lambda *args, **kwargs: disable_get())
    monkeypatch.setattr(
        requests, "post", lambda *args, **kwargs: disable_post()
    )
