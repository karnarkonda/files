<#

#>

param (
    [string]$projDir = 'D:\TotalFundExposure-MS\s',
    [string]$env = 'uat',
    [string]$port = '8080'
)

# Start the service.
Write-Host ">>>> Starting up TFE-Service Server."
Write-Host ">>>> Environment: $env"
Write-Host ">>>> Project Directory: $projDir"
Write-Host ">>>> Service/Network Port: $port"

[System.Environment]::SetEnvironmentVariable('ENV', $env, 'Machine')

Set-Location -Path $projDir -Passthru

& ".venv\Scripts\Activate.ps1"

uvicorn app.server:api --host 0.0.0.0 --log-config .\server.ini --port $port

Write-Host ">>>> Done Executing startup script."