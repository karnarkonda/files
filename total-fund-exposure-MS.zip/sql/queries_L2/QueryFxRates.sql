SELECT
      convert(date,Fx.EffectiveRateDate) as 'PositionDate'
    , Fx.QuoteCurrencyIsoCode            AS 'Instrument_CurrencyCode'
    , 1.0/Fx.SpotMidExchangeRate         AS 'Position_FXRates_CurrencyCode_to_CAD'
FROM PSPDW2.PSPDW.ForeignCurrencyExchangeRates Fx
where 
        Fx.IsActiveForeignCurrencyExchangeRate = 1 
    AND Fx.BaseCurrencyIsoCode = 'CAD' 
    AND Fx.Source='PSP' AND Fx.ExchangeRateType = 'SPOT'
    AND Fx.EffectiveRateDate in (__final_position_dates__)
order by 
      Fx.EffectiveRateDate
    , Fx.QuoteCurrencyIsoCode