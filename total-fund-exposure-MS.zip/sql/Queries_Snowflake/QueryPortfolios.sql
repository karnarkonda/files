WITH portfolio_hierarchy AS
(
--Query for L1 ultimate child
      SELECT
              L1_PSP_PORTFOLIO_CODE AS L1_PSP_PORTFOLIO_CODE
            , L1_PSP_PORTFOLIO_CODE AS L2_PSP_PORTFOLIO_CODE
            , L1_PSP_PORTFOLIO_CODE AS L3_PSP_PORTFOLIO_CODE
            , L1_PSP_PORTFOLIO_CODE AS L4_PSP_PORTFOLIO_CODE
      FROM __database_warehouse__WAREHOUSE.PORTFOLIO_V1 
      WHERE 
                is_ultimate_child = TRUE
            AND PSP_PORTFOLIO_ID IN (__psp_portfolio_ids__)
            AND PSP_PORTFOLIO_CODE = L1_PSP_PORTFOLIO_CODE
      UNION
--Query for L2 ultimate child
      SELECT
              L1_PSP_PORTFOLIO_CODE AS L1_PSP_PORTFOLIO_CODE
            , L2_PSP_PORTFOLIO_CODE AS L2_PSP_PORTFOLIO_CODE
            , L2_PSP_PORTFOLIO_CODE AS L3_PSP_PORTFOLIO_CODE
            , L2_PSP_PORTFOLIO_CODE AS L4_PSP_PORTFOLIO_CODE
      FROM __database_warehouse__WAREHOUSE.PORTFOLIO_V1 
      WHERE 
                is_ultimate_child = TRUE
            AND PSP_PORTFOLIO_ID IN (__psp_portfolio_ids__)
            AND PSP_PORTFOLIO_CODE = L2_PSP_PORTFOLIO_CODE
      UNION
--Query for L3 ultimate child
      SELECT
              L1_PSP_PORTFOLIO_CODE AS L1_PSP_PORTFOLIO_CODE
            , L2_PSP_PORTFOLIO_CODE AS L2_PSP_PORTFOLIO_CODE
            , L3_PSP_PORTFOLIO_CODE AS L3_PSP_PORTFOLIO_CODE
            , L3_PSP_PORTFOLIO_CODE AS L4_PSP_PORTFOLIO_CODE
      FROM __database_warehouse__WAREHOUSE.PORTFOLIO_V1 
      WHERE 
                is_ultimate_child = TRUE
            AND PSP_PORTFOLIO_ID IN (__psp_portfolio_ids__)
            AND PSP_PORTFOLIO_CODE = L3_PSP_PORTFOLIO_CODE
      UNION
--Query for L4 ultimate child
      SELECT
              L1_PSP_PORTFOLIO_CODE AS L1_PSP_PORTFOLIO_CODE
            , L2_PSP_PORTFOLIO_CODE AS L2_PSP_PORTFOLIO_CODE
            , L3_PSP_PORTFOLIO_CODE AS L3_PSP_PORTFOLIO_CODE
            , L4_PSP_PORTFOLIO_CODE AS L4_PSP_PORTFOLIO_CODE
      FROM __database_warehouse__WAREHOUSE.PORTFOLIO_V1 
      WHERE 
                is_ultimate_child = TRUE
            AND PSP_PORTFOLIO_ID IN (__psp_portfolio_ids__)
            AND PSP_PORTFOLIO_CODE = L4_PSP_PORTFOLIO_CODE
      UNION
--Query for L5 ultimate child
      SELECT
              L2_PSP_PORTFOLIO_CODE AS L1_PSP_PORTFOLIO_CODE
            , L3_PSP_PORTFOLIO_CODE AS L2_PSP_PORTFOLIO_CODE
            , L4_PSP_PORTFOLIO_CODE AS L3_PSP_PORTFOLIO_CODE
            , L5_PSP_PORTFOLIO_CODE AS L4_PSP_PORTFOLIO_CODE
      FROM __database_warehouse__WAREHOUSE.PORTFOLIO_V1 
      WHERE 
                is_ultimate_child = TRUE
            AND PSP_PORTFOLIO_ID IN (__psp_portfolio_ids__)
            AND PSP_PORTFOLIO_CODE = L5_PSP_PORTFOLIO_CODE
      UNION
--Query for L6 ultimate child
      SELECT
              L3_PSP_PORTFOLIO_CODE AS L1_PSP_PORTFOLIO_CODE
            , L4_PSP_PORTFOLIO_CODE AS L2_PSP_PORTFOLIO_CODE
            , L5_PSP_PORTFOLIO_CODE AS L3_PSP_PORTFOLIO_CODE
            , L6_PSP_PORTFOLIO_CODE AS L4_PSP_PORTFOLIO_CODE
      FROM __database_warehouse__WAREHOUSE.PORTFOLIO_V1 
      WHERE 
                is_ultimate_child = TRUE
            AND PSP_PORTFOLIO_ID IN (__psp_portfolio_ids__)
            AND PSP_PORTFOLIO_CODE = L6_PSP_PORTFOLIO_CODE

)
SELECT
      L1.PSP_PORTFOLIO_CODE                AS L1_PSPPortfolioCode                
    , L1.PSP_PORTFOLIO_ID                  AS L1_PSPPortfolioID                    
    , L1.PORTFOLIO_NAME                    AS L1_PortfolioName                    
    , L1.PORTFOLIO_TYPE                    AS L1_PortfolioType                    
    , L1.MANAGING_DEPARTMENT               AS L1_ManagingDepartment                        
    , L1.MANAGER_TYPE                      AS L1_ManagerType                    
    , L1.MANAGING_STYLE                    AS L1_ManagingStyle                    
    , NULL                                 AS L1_PSPAssetClassAllocationCode    
    , NULL                                 AS L1_AssetClassAllocationDescription
    , L1.PORTFOLIO_STYLE                   AS L1_PortfolioStyle                    
    , L1.OWNER_DEPARTMENT                  AS L1_OwnerDepartment                
    , L1.PSP_INVESTMENT_TEAM_CODE          AS L1_PSPInvestmentTeamCode            
    , L1.INVESTMENT_TEAM_NAME              AS L1_InvestmentTeamName    
    
    , L2.PSP_PORTFOLIO_CODE                AS L2_PSPPortfolioCode                            
    , L2.PSP_PORTFOLIO_ID                  AS L2_PSPPortfolioID                    
    , L2.PORTFOLIO_NAME                    AS L2_PortfolioName                    
    , L2.PORTFOLIO_TYPE                    AS L2_PortfolioType                    
    , L2.MANAGING_DEPARTMENT               AS L2_ManagingDepartment                
    , L2.MANAGER_TYPE                      AS L2_ManagerType                    
    , L2.MANAGING_STYLE                    AS L2_ManagingStyle                    
    , NULL                                 AS L2_PSPAssetClassAllocationCode    
    , NULL                                 AS L2_AssetClassAllocationDescription
    , L2.PORTFOLIO_STYLE                   AS L2_PortfolioStyle                    
    , L2.OWNER_DEPARTMENT                  AS L2_OwnerDepartment                
    , L2.PSP_INVESTMENT_TEAM_CODE          AS L2_PSPInvestmentTeamCode            
    , L2.INVESTMENT_TEAM_NAME              AS L2_InvestmentTeamName                
    
    , L3.PSP_PORTFOLIO_CODE                AS L3_PSPPortfolioCode                 
    , L3.PSP_PORTFOLIO_ID                  AS L3_PSPPortfolioID                    
    , L3.PORTFOLIO_NAME                    AS L3_PortfolioName                    
    , L3.PORTFOLIO_TYPE                    AS L3_PortfolioType                    
    , L3.MANAGING_DEPARTMENT               AS L3_ManagingDepartment            
    , L3.MANAGER_TYPE                      AS L3_ManagerType                    
    , L3.MANAGING_STYLE                    AS L3_ManagingStyle                    
    , NULL                                 AS L3_PSPAssetClassAllocationCode    
    , NULL                                 AS L3_AssetClassAllocationDescription
    , L3.PORTFOLIO_STYLE                   AS L3_PortfolioStyle                    
    , L3.OWNER_DEPARTMENT                  AS L3_OwnerDepartment                
    , L3.PSP_INVESTMENT_TEAM_CODE          AS L3_PSPInvestmentTeamCode            
    , L3.INVESTMENT_TEAM_NAME              AS L3_InvestmentTeamName                    
    
    , L4.PSP_PORTFOLIO_CODE                AS L4_PSPPortfolioCode                
    , L4.PSP_PORTFOLIO_ID                  AS L4_PSPPortfolioID                    
    , L4.PORTFOLIO_NAME                    AS L4_PortfolioName                    
    , L4.PORTFOLIO_TYPE                    AS L4_PortfolioType                    
    , L4.MANAGING_DEPARTMENT               AS L4_ManagingDepartment                    
    , L4.MANAGER_TYPE                      AS L4_ManagerType                    
    , L4.MANAGING_STYLE                    AS L4_ManagingStyle                    
    , NULL                                 AS L4_PSPAssetClassAllocationCode    
    , NULL                                 AS L4_AssetClassAllocationDescription
    , L4.PORTFOLIO_STYLE                   AS L4_PortfolioStyle                    
    , L4.OWNER_DEPARTMENT                  AS L4_OwnerDepartment                
    , L4.PSP_INVESTMENT_TEAM_CODE          AS L4_PSPInvestmentTeamCode            
    , L4.INVESTMENT_TEAM_NAME              AS L4_InvestmentTeamName  
    
    ,case 
            WHEN  AC.MARKET_TYPE = 'Public Market' AND L4.PSP_INVESTMENT_TEAM_CODE IN ('PFI') 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE) NOT IN ('Legacy','Internal Borrowings','Subsidiary') 
                                                            AND COALESCE(L1.MANAGING_STYLE,L4.MANAGING_STYLE) IN ('Active')     
                                                            AND COALESCE(L1.MANAGER_TYPE,L4.MANAGER_TYPE) IN ('External') 
                  THEN 'Public Fixed Income - Active - External'

            WHEN  AC.MARKET_TYPE = 'Public Market' AND L4.PSP_INVESTMENT_TEAM_CODE IN ('PFI') 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE) NOT IN ('Legacy','Internal Borrowings','Subsidiary')  
                                                            AND COALESCE(L1.MANAGING_STYLE,L4.MANAGING_STYLE) IN ('Active')    
                                                            AND COALESCE(L1.MANAGER_TYPE,L4.MANAGER_TYPE) IN ('Internal') 
                  THEN 'Public Fixed Income - Active - Internal'         
                                                     
            WHEN  AC.MARKET_TYPE = 'Public Market' AND L4.PSP_INVESTMENT_TEAM_CODE IN ('PFI') 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE) NOT IN ('Legacy','Internal Borrowings','Subsidiary')  
                                                            AND COALESCE(L1.MANAGING_STYLE,L4.MANAGING_STYLE) IN ('Passive')   
                                                            AND COALESCE(L1.MANAGER_TYPE,L4.MANAGER_TYPE) IN ('External') 
                  THEN 'Public Fixed Income - Passive - External'

            WHEN  AC.MARKET_TYPE = 'Public Market' AND L4.PSP_INVESTMENT_TEAM_CODE IN ('PFI') 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE) NOT IN ('Legacy','Internal Borrowings','Subsidiary')  
                                                            AND COALESCE(L1.MANAGING_STYLE,L4.MANAGING_STYLE) IN ('Passive')   
                                                            AND COALESCE(L1.MANAGER_TYPE, L4.MANAGER_TYPE ) IN ('Internal') 
                  THEN 'Public Fixed Income - Passive - Internal'

            WHEN  AC.MARKET_TYPE = 'Public Market' AND L4.PSP_INVESTMENT_TEAM_CODE IN ('PEQ') 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE)  NOT IN ('Legacy','Internal Borrowings','Subsidiary')  
                                                            AND COALESCE(L1.MANAGING_STYLE,L4.MANAGING_STYLE) IN ('Passive')   
                                                            AND COALESCE(L1.MANAGER_TYPE,L4.MANAGER_TYPE) IN ('External') 
                  THEN 'Public Equity - Passive - External'

            WHEN  AC.MARKET_TYPE = 'Public Market' AND L4.PSP_INVESTMENT_TEAM_CODE IN ('PEQ') 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE)  NOT IN ('Legacy','Internal Borrowings','Subsidiary')  
                                                            AND COALESCE(L1.MANAGING_STYLE,L4.MANAGING_STYLE) IN ('Passive')   
                                                            AND COALESCE(L1.MANAGER_TYPE,L4.MANAGER_TYPE) IN ('Internal') 
                  THEN 'Public Equity - Passive - Internal' 
                                                            
            WHEN  AC.MARKET_TYPE = 'Public Market' AND L4.PSP_INVESTMENT_TEAM_CODE IN ('PEQ') 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE)  NOT IN ('Legacy','Internal Borrowings','Subsidiary')  
                                                            AND COALESCE(L1.MANAGING_STYLE,L4.MANAGING_STYLE) IN ('Active')    
                                                            AND COALESCE(L1.MANAGER_TYPE,L4.MANAGER_TYPE) IN ('External') 
                  THEN 'Public Equity - Active - External'

            WHEN  AC.MARKET_TYPE = 'Public Market' AND L4.PSP_INVESTMENT_TEAM_CODE IN ('PEQ') 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE)  NOT IN ('Legacy','Internal Borrowings','Subsidiary')  
                                                            AND COALESCE(L1.MANAGING_STYLE,L4.MANAGING_STYLE) IN ('Active')    
                                                            AND COALESCE(L1.MANAGER_TYPE,L4.MANAGER_TYPE) IN ('Internal') 
                  THEN 'Public Equity - Active - Internal'


            WHEN  AC.MARKET_TYPE = 'Public Market' AND L4.PSP_INVESTMENT_TEAM_CODE IN ('ALT') 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE) NOT IN ('Legacy','Internal Borrowings','Subsidiary')  
                                                            AND COALESCE(L1.MANAGER_TYPE,L4.MANAGER_TYPE) IN ('External') 
                  THEN 'Alternatives - External'

            WHEN  AC.MARKET_TYPE = 'Public Market' AND L4.PSP_INVESTMENT_TEAM_CODE IN ('ALT') 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE) NOT IN ('Legacy','Internal Borrowings','Subsidiary')  
                                                            AND COALESCE(L1.MANAGER_TYPE,L4.MANAGER_TYPE) IN ('Internal') 
                  THEN 'Alternatives - Internal'                                              
--- 
            WHEN  AC.MARKET_TYPE = 'Public Market' AND L4.PSP_INVESTMENT_TEAM_CODE IN ('PS') 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE) NOT IN ('Legacy','Internal Borrowings','Subsidiary') 
                  THEN 'Public Global Macro'

            WHEN  AC.MARKET_TYPE = 'Public Market' 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE) IN ('Legacy')
                  THEN 'Legacy'

            WHEN  AC.MARKET_TYPE = 'Public Market' 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE) IN ('Internal Borrowings')
                  THEN 'Internal Borrowings'

            WHEN  AC.MARKET_TYPE = 'Public Market' 
                                                            AND COALESCE(L1.PORTFOLIO_STYLE,L4.PORTFOLIO_STYLE) IN ('Subsidiary')
                  THEN 'Subsidiary'

            Else  'Other'
     end AS InvestmentStrategyCalc
FROM portfolio_hierarchy PE
INNER JOIN __database_warehouse__WAREHOUSE.PORTFOLIO_V1 L1 ON L1.PSP_PORTFOLIO_CODE = PE.L1_PSP_PORTFOLIO_CODE
INNER JOIN __database_warehouse__WAREHOUSE.PORTFOLIO_V1 L2 ON L2.PSP_PORTFOLIO_CODE = PE.L2_PSP_PORTFOLIO_CODE
INNER JOIN __database_warehouse__WAREHOUSE.PORTFOLIO_V1 L3 ON L3.PSP_PORTFOLIO_CODE = PE.L3_PSP_PORTFOLIO_CODE
INNER JOIN __database_warehouse__WAREHOUSE.PORTFOLIO_V1 L4 ON L4.PSP_PORTFOLIO_CODE = PE.L4_PSP_PORTFOLIO_CODE
INNER JOIN __database_warehouse__WAREHOUSE.ASSET_CLASS_V1 AC ON AC.PSP_ASSET_CLASS_ID = L4.PSP_ASSET_CLASS_ID AND AC.BENCHMARK_ASSIGNATION_NAME = 'Total Fund Benchmark'