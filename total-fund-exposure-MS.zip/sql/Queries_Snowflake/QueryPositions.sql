SELECT
      PPL.VALUATION_DATE                 AS PositionDate
    , PPL.PSP_PORTFOLIO_CODE             AS Portfolio_PSPPortfolioCode
    , PPL.PSP_PORTFOLIO_ID               AS Portfolio_PSPPortfolioID
    , PPL.PORTFOLIO_NAME                 AS Portfolio_Name
    , AC.MARKET_TYPE                     AS Portfolio_MarketType
    , AC.ASSET_CLASS_NAME                AS Portfolio_AssetClass
    , PBH.INVESTMENT_TEAM_NAME           AS Portfolio_InvestmentTeam
    , PBH.MANAGER_TYPE                   AS Portfolio_ManagerType
    , PBH.MANAGING_STYLE                 AS Portfolio_ManagingStyle
    , PBH.MANAGING_DEPARTMENT            AS Portfolio_ManagingDepartment
    , PBH.OWNER_DEPARTMENT               AS Portfolio_OwnerDepartment
    , PPL.PSP_INSTRUMENT_ID              AS Instrument_PSPInstrumentID
    , PPL.POSITION_CURRENCY_CODE         AS Instrument_CurrencyCode
    , CASE PPL.LEG_TYPE WHEN 'CreditFee' THEN -1 WHEN 'CreditProtection' THEN 1 ELSE CASE PPL.POSITION_LEVEL WHEN  'PaidLeg' THEN -1 WHEN 'ReceivedLeg' THEN 1 ELSE NULL END END AS Leg_PSPInstrumentLegID
    , PPL.POSITION_LEVEL                 AS Leg_PositionLevel
    , PPL.TOTAL_QUANTITY                 AS Position_Quantity
    , PPL.TOTAL_QUANTITY_NOMINAL_AMOUNT  AS Position_NominalAmount
    , PPL.MARKET_VALUE_IN_CAD            AS Position_MarketValue_CAD
    , PPL.ACCRUAL_VALUE_IN_CAD           AS Position_AccruedInterestValue_CAD
    , PPL.TAX_RECLAIM_AMOUNT_IN_CAD      AS Position_TaxReclaimValue_CAD
    , PPL.NET_ASSET_VALUE_IN_CAD         AS Position_NetAssetValue_CAD
FROM __database_warehouse__WAREHOUSE.POSITION_PER_LEG_V1 PPL
LEFT JOIN __database_warehouse__WAREHOUSE.PORTFOLIO_HISTORY_V1 PBH ON 
        PBH.EFFECTIVE_BUSINESS_DATE_FROM <= PPL.VALUATION_DATE
    AND IFNULL(PBH.EFFECTIVE_BUSINESS_DATE_TO, '2199-12-31') > PPL.VALUATION_DATE
    AND PBH.PSP_PORTFOLIO_CODE = PPL.PSP_PORTFOLIO_CODE
LEFT JOIN __database_warehouse__WAREHOUSE.ASSET_CLASS_V1 AC ON 
        AC.PSP_ASSET_CLASS_ID = PBH.PSP_ASSET_CLASS_ID 
    AND AC.IS_DEFAULT_BENCHMARK_ASSIGNATION = TRUE
LEFT JOIN __database_warehouse__WAREHOUSE.PORTFOLIO_V1 PF ON 
        PF.PSP_PORTFOLIO_CODE = PPL.PSP_PORTFOLIO_CODE 
WHERE 
        PPL.VALUATION_DATE in (__position_dates__)
    AND PPL.PORTFOLIO_TYPE = 'Investment'
    __exclusions_psp_instrument_ids__
    __psp_portfolio_ids__
    __exclusions_psp_fund_codes__