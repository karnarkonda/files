/* Production Mode
rule is:
    last 5 business days (will change when we implement the batch logic)
    last end of month should not be past the accounting closure date 
    we compute at t for t-1 to make sure all the RiskMetrics batches are completed
    */
WITH business_days 
AS(
    SELECT 
        CALENDAR_DATE 
    FROM __database_warehouse__WAREHOUSE.DATE_V1
    WHERE 
        IS_WEEKEND = FALSE AND CALENDAR_DATE <= __evaluation_date__ 
    ORDER BY CALENDAR_DATE DESC  
    LIMIT 5
    OFFSET 1
    )
(SELECT * FROM business_days)
UNION
(SELECT DISTINCT
    LAST_DAY_OF_MONTH
FROM __database_warehouse__WAREHOUSE.DATE_V1
WHERE 
    LAST_DAY_OF_MONTH < __evaluation_date__
    AND LAST_DAY_OF_MONTH NOT IN (SELECT * FROM business_days)
    AND IS_ACCOUNTING_PERIOD_CLOSED = 'NO'
ORDER BY LAST_DAY_OF_MONTH DESC  
LIMIT 1)