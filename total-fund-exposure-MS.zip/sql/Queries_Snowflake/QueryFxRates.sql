SELECT
      EFFECTIVE_RATE_DATE        AS PositionDate
    , QUOTE_CURRENCY_CODE        AS Instrument_CurrencyCode
    , SPOT_MID_EXCHANGE_RATE     AS Position_FXRates_CurrencyCode_to_CAD
FROM __database_warehouse__WAREHOUSE.FOREIGN_CURRENCY_EXCHANGE_RATE_V2 FX
WHERE 
        FX.BASE_CURRENCY_CODE = 'CAD' 
    AND FX.SOURCE='PSP'
    AND FX.EFFECTIVE_RATE_DATE in (__final_position_dates__)
ORDER BY 
      FX.EFFECTIVE_RATE_DATE
    , FX.QUOTE_CURRENCY_CODE