WITH futures AS (
 SELECT 
    PSP_INSTRUMENT_ID
   ,UNDERLYING_PSP_INSTRUMENT_ID
   ,CONTRACT_SYMBOL
 FROM __database_warehouse__WAREHOUSE.INSTRUMENT_V1  where INSTRUMENT_FAMILY = 'Futures'
)

SELECT DISTINCT
  I.PSP_INSTRUMENT_ID                                                    AS Instrument_PSPInstrumentID
, I.INSTRUMENT_FAMILY                                                    AS Instrument_Family
, I.PSP_INSTRUMENT_CATEGORIZATION_ID                                     AS Instrument_PSPInstrumentCategorizationID
, I.PSP_INSTRUMENT_CATEGORIZATION_CODE                                   AS Instrument_PSPInstrumentCategorizationCode
, I.INSTRUMENT_DESCRIPTION                                               AS Instrument_Description
, I.INSTRUMENT_MARKET                                                    AS Instrument_Market
, I.INSTRUMENT_TYPE                                                      AS Instrument_Type
, IFNULL(LE.BLOOMBERG_ISSUER_CODE,0)                                     AS Instrument_IssuerCode
, GREATEST(RECEIVED_PENULTIMATE_PAYMENT_DATE, PAID_PENULTIMATE_PAYMENT_DATE)  AS Instrument_PenultimatePaymentDate
, I.INSTRUMENT_CURRENCY_CODE                                             AS Instrument_CurrencyCode
, NULLIF(I.UNDERLYING_PSP_INSTRUMENT_ID,-1)                              AS Underlying_PSPInstrumentID
, COALESCE(NULLIF(F.UNDERLYING_PSP_INSTRUMENT_ID,-1), NULLIF(I.UNDERLYING_PSP_INSTRUMENT_ID,-1)) AS Coal_Underlying_PSPInstrumentID
, I.OPTION_STYLE                                                         AS Option_Style
, I.CONTRACT_SIZE                                                        AS ContractSize
, I.CONTRACT_SYMBOL                                                      AS Future_ContractSymbol
, F.CONTRACT_SYMBOL                                                      AS OptionFuture_ContractSymbol
, I.CONVERSION_RATIO                                                     AS Option_ConversionRatio
, I.FORWARD_PRICE                                                        AS Forward_Price
, I.TICK_SIZE                                                            AS Future_TickSize
, I.TICK_VALUE                                                           AS Future_TickValue
, IFNULL(NULLIF(I.INDEX_PROXY_PSP_INSTRUMENT_ID,-1),I.PSP_INSTRUMENT_ID) AS Instrument_IndexProxyPSPInstrumentID

FROM __database_warehouse__WAREHOUSE.INSTRUMENT_V1 I
LEFT JOIN __database_warehouse__WAREHOUSE.LEGAL_ENTITY_V1 LE ON LE.PSP_LEGAL_ENTITY_ID = I.ISSUER_PSP_LEGAL_ENTITY_ID
LEFT JOIN futures F ON F.PSP_INSTRUMENT_ID = I.UNDERLYING_PSP_INSTRUMENT_ID AND I.UNDERLYING_PSP_INSTRUMENT_ID <> -1
