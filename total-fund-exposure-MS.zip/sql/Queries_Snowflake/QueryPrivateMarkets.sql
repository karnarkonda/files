WITH 
private_data_calendar AS 
(
    SELECT 
        D.CALENDAR_DATE
        , PE.PSP_PORTFOLIO_CODE
        , MAX(PE.EFFECTIVE_DATE) as MAX_EFFECTIVE_DATE
    FROM __database_warehouse__WAREHOUSE.DATE_V1 D
    INNER JOIN __database_warehouse__WAREHOUSE.POSITION_EXPOSURE_V1 PE on D.CALENDAR_DATE >= PE.EFFECTIVE_DATE
    WHERE 
            D.CALENDAR_DATE in (__final_position_dates__)
        AND PE.PSP_PORTFOLIO_CODE COLLATE '' LIKE 'HE1013%' = FALSE
        AND PE.PSP_PORTFOLIO_CODE COLLATE '' REGEXP 'PP[0-9]+[A-Z]' = FALSE
    GROUP BY 
        D.CALENDAR_DATE
        , PE.PSP_PORTFOLIO_CODE
),
portfolio_data AS 
(
    SELECT 
        DC.CALENDAR_DATE
        , P.PSP_PORTFOLIO_ID
        , P.PSP_PORTFOLIO_CODE
        , P.PORTFOLIO_NAME
        , AC.MARKET_TYPE
        , AC.ASSET_CLASS_NAME
        , PH.INVESTMENT_TEAM_NAME
        , PH.MANAGER_TYPE
        , PH.MANAGING_STYLE
        , PH.MANAGING_DEPARTMENT
        , PH.OWNER_DEPARTMENT
    FROM private_data_calendar DC
    LEFT JOIN __database_warehouse__WAREHOUSE.PORTFOLIO_V1 P ON P.PSP_PORTFOLIO_CODE = DC.PSP_PORTFOLIO_CODE AND P.IS_ULTIMATE_CHILD = TRUE
    LEFT JOIN __database_warehouse__WAREHOUSE.PORTFOLIO_HISTORY_V1 PH ON PH.PSP_PORTFOLIO_CODE = P.PSP_PORTFOLIO_CODE AND IFNULL(PH.EFFECTIVE_BUSINESS_DATE_FROM,'1900-01-01')<= DC.CALENDAR_DATE AND IFNULL(PH.EFFECTIVE_BUSINESS_DATE_TO,'2100-01-01') > DC.CALENDAR_DATE
    LEFT JOIN __database_warehouse__WAREHOUSE.ASSET_CLASS_V1 AC ON AC.PSP_ASSET_CLASS_ID = PH.PSP_ASSET_CLASS_ID AND AC.IS_DEFAULT_BENCHMARK_ASSIGNATION = TRUE
),
private_data_nav AS 
(
    SELECT 
        DC.CALENDAR_DATE
        , DC.MAX_EFFECTIVE_DATE
        , DC.PSP_PORTFOLIO_CODE
        , CAST(SUM(PE.NET_ASSET_VALUE_IN_CAD) AS FLOAT) AS TOTAL_NET_ASSET_VALUE_IN_CAD
    FROM private_data_calendar DC
    INNER JOIN __database_warehouse__WAREHOUSE.POSITION_EXPOSURE_V1 PE on PE.EFFECTIVE_DATE = DC.MAX_EFFECTIVE_DATE AND PE.PSP_PORTFOLIO_CODE = DC.PSP_PORTFOLIO_CODE
    GROUP BY 
        DC.CALENDAR_DATE
        , DC.MAX_EFFECTIVE_DATE
        , DC.PSP_PORTFOLIO_CODE
),
position_per_leg_data AS
(
    SELECT 
        DC.CALENDAR_DATE
        , DC.PSP_PORTFOLIO_CODE
        , SUM(PPL.NET_ASSET_VALUE_IN_CAD) as TOTAL_NET_ASSET_VALUE_IN_CAD
    FROM private_data_calendar DC
    INNER JOIN __database_warehouse__WAREHOUSE.POSITION_PER_LEG_V1 PPL ON PPL.PSP_PORTFOLIO_CODE = DC.PSP_PORTFOLIO_CODE AND PPL.VALUATION_DATE = DC.CALENDAR_DATE
    GROUP BY 
        DC.CALENDAR_DATE
        , DC.PSP_PORTFOLIO_CODE
),
private_exposure_data AS 
(
    SELECT 
          DC.CALENDAR_DATE
        , DC.MAX_EFFECTIVE_DATE
        , DC.PSP_PORTFOLIO_CODE
        , IFNULL(NULLIF(PE.PSP_INSTRUMENT_ID,-1),0)     AS PSP_INSTRUMENT_ID
        , IFNULL(NULLIF(PE.CURRENCY_CODE,'N/A'), 'Non') AS CURRENCY_CODE
        , NULLIF(PE.COUNTRY_CODE,'N/A')                 AS COUNTRY_CODE
        , NULL                                          AS REGION_NAME
        , PE.BICSBETA_PSP_INDUSTRY_CLASSIFICATION_ID
        , NULLIF(IC.SECTOR_CODE,'N/A')                  AS SECTOR_CODE
        , NULLIF(IC.SECTOR_NAME,'N/A')                  AS SECTOR_NAME
        , NULLIF(IC.INDUSTRY_GROUP_CODE,'N/A')          AS INDUSTRY_GROUP_CODE
        , NULLIF(IC.INDUSTRY_GROUP_NAME,'N/A')          AS INDUSTRY_GROUP_NAME
        , NULLIF(IC.INDUSTRY_CODE,'N/A')                AS INDUSTRY_CODE
        , NULLIF(IC.INDUSTRY_NAME,'N/A')                AS INDUSTRY_NAME
        , NULLIF(IC.SUB_INDUSTRY_CODE,'N/A')            AS SUB_INDUSTRY_CODE
        , NULLIF(IC.SUB_INDUSTRY_NAME,'N/A')            AS SUB_INDUSTRY_NAME
        , NULLIF(IC.ACTIVITY_CODE,'N/A')                AS ACTIVITY_CODE
        , NULLIF(IC.ACTIVITY_NAME,'N/A')                AS ACTIVITY_NAME
        , NULLIF(IC.SUB_ACTIVITY_CODE,'N/A')            AS SUB_ACTIVITY_CODE
        , NULLIF(IC.SUB_ACTIVITY_NAME,'N/A')            AS SUB_ACTIVITY_NAME
        , NULLIF(IC.SEGMENT_CODE,'N/A')                 AS SEGMENT_CODE
        , NULLIF(IC.SEGMENT_NAME,'N/A')                 AS SEGMENT_NAME
        , CAST(SUM(PE.NET_ASSET_VALUE_IN_CAD) AS FLOAT) AS NET_ASSET_VALUE_IN_CAD
    FROM private_data_calendar DC
    INNER JOIN __database_warehouse__WAREHOUSE.POSITION_EXPOSURE_V1 PE on PE.EFFECTIVE_DATE = DC.MAX_EFFECTIVE_DATE and PE.PSP_PORTFOLIO_CODE = DC.PSP_PORTFOLIO_CODE
    LEFT JOIN __database_warehouse__WAREHOUSE.INDUSTRY_CLASSIFICATION_V1 IC ON IC.CLASSIFICATION_SCHEME = 'BICSBETA' AND IC.PSP_INDUSTRY_CLASSIFICATION_ID = PE.BICSBETA_PSP_INDUSTRY_CLASSIFICATION_ID
    GROUP BY 
          DC.CALENDAR_DATE
        , DC.MAX_EFFECTIVE_DATE
        , DC.PSP_PORTFOLIO_CODE
        , PE.PSP_INSTRUMENT_ID
        , PE.CURRENCY_CODE
        , PE.COUNTRY_CODE
        , PE.BICSBETA_PSP_INDUSTRY_CLASSIFICATION_ID
        , IC.SECTOR_CODE
        , IC.SECTOR_NAME
        , IC.INDUSTRY_GROUP_CODE
        , IC.INDUSTRY_GROUP_NAME
        , IC.INDUSTRY_CODE
        , IC.INDUSTRY_NAME
        , IC.SUB_INDUSTRY_CODE
        , IC.SUB_INDUSTRY_NAME
        , IC.ACTIVITY_CODE
        , IC.ACTIVITY_NAME
        , IC.SUB_ACTIVITY_CODE
        , IC.SUB_ACTIVITY_NAME
        , IC.SEGMENT_CODE
        , IC.SEGMENT_NAME
)
SELECT
      DC.CALENDAR_DATE                                                                                                    AS PositionDate
    , DC.MAX_EFFECTIVE_DATE                                                                                               AS SourceDate
                     
    , P.PSP_PORTFOLIO_CODE                                                                                                AS Portfolio_PSPPortfolioCode
    , P.PSP_PORTFOLIO_ID                                                                                                  AS Portfolio_PSPPortfolioID
    , P.PORTFOLIO_NAME                                                                                                    AS Portfolio_Name
    , P.MARKET_TYPE                                                                                                       AS Portfolio_MarketType
    , P.ASSET_CLASS_NAME                                                                                                  AS Portfolio_AssetClass
    , P.INVESTMENT_TEAM_NAME                                                                                              AS Portfolio_InvestmentTeam
    , P.MANAGER_TYPE                                                                                                      AS Portfolio_ManagerType
    , P.MANAGING_STYLE                                                                                                    AS Portfolio_ManagingStyle
    , P.MANAGING_DEPARTMENT                                                                                               AS Portfolio_ManagingDepartment
    , P.OWNER_DEPARTMENT                                                                                                  AS Portfolio_OwnerDepartment
                     
    , PE.PSP_INSTRUMENT_ID                                                                                                AS Instrument_PSPInstrumentID
    , NULLIF(PE.CURRENCY_CODE,'N/A')                                                                                      AS Instrument_CurrencyCode
    , 0                                                                                                                   AS Leg_PSPInstrumentLegID
    , IFNULL(PE.NET_ASSET_VALUE_IN_CAD / NULLIF(PN.TOTAL_NET_ASSET_VALUE_IN_CAD,0) * PPL.TOTAL_NET_ASSET_VALUE_IN_CAD, 0) AS Position_Quantity
    , IFNULL(PE.NET_ASSET_VALUE_IN_CAD / NULLIF(PN.TOTAL_NET_ASSET_VALUE_IN_CAD,0) * PPL.TOTAL_NET_ASSET_VALUE_IN_CAD, 0) AS Position_NominalAmount
    , IFNULL(PE.NET_ASSET_VALUE_IN_CAD / NULLIF(PN.TOTAL_NET_ASSET_VALUE_IN_CAD,0) * PPL.TOTAL_NET_ASSET_VALUE_IN_CAD, 0) AS Position_MarketValue_CAD
    , 0                                                                                                                   AS Position_AccruedInterestValue_CAD
    , 0                                                                                                                   AS Position_TaxReclaimValue_CAD
    , IFNULL(PE.NET_ASSET_VALUE_IN_CAD / NULLIF(PN.TOTAL_NET_ASSET_VALUE_IN_CAD,0) * PPL.TOTAL_NET_ASSET_VALUE_IN_CAD, 0) AS Position_NetAssetValue_CAD
    , IFNULL(PE.NET_ASSET_VALUE_IN_CAD / NULLIF(PN.TOTAL_NET_ASSET_VALUE_IN_CAD,0) * PPL.TOTAL_NET_ASSET_VALUE_IN_CAD, 0) AS Position_ExposureValue_CAD
    
    , REPLACE(PE.COUNTRY_CODE,'N/A','None')                                                                               AS Instrument_RiskLocationCountryCode
    , REPLACE(PE.COUNTRY_CODE,'N/A','None')                                                                               AS Instrument_NormalizedCountryCode
    , REPLACE(PE.REGION_NAME,'N/A','None')                                                                                AS Instrument_GeographyName
                         
    , PE.BICSBETA_PSP_INDUSTRY_CLASSIFICATION_ID                                                                          AS Instrument_BICSBETAClassificationID
    , PE.SECTOR_CODE                                                                                                      AS Instrument_BICSBETASectorCode
    , PE.SECTOR_NAME                                                                                                      AS Instrument_BICSBETASectorName
    , PE.INDUSTRY_GROUP_CODE                                                                                              AS Instrument_BICSBETAIndustryGroupCode
    , PE.INDUSTRY_GROUP_NAME                                                                                              AS Instrument_BICSBETAIndustryGroupName
    , PE.INDUSTRY_CODE                                                                                                    AS Instrument_BICSBETAIndustryCode
    , PE.INDUSTRY_NAME                                                                                                    AS Instrument_BICSBETAIndustryName
    , PE.SUB_INDUSTRY_CODE                                                                                                AS Instrument_BICSBETASubIndustryCode
    , PE.SUB_INDUSTRY_NAME                                                                                                AS Instrument_BICSBETASubIndustryName
    , PE.ACTIVITY_CODE                                                                                                    AS Instrument_BICSBETAActivityCode
    , PE.ACTIVITY_NAME                                                                                                    AS Instrument_BICSBETAActivityName
    , PE.SUB_ACTIVITY_CODE                                                                                                AS Instrument_BICSBETASubActivityCode
    , PE.SUB_ACTIVITY_NAME                                                                                                AS Instrument_BICSBETASubActivityName
    , PE.SEGMENT_CODE                                                                                                     AS Instrument_BICSBETASegmentCode
    , PE.SEGMENT_NAME                                                                                                     AS Instrument_BICSBETASegmentName
FROM private_data_calendar DC
INNER JOIN portfolio_data P ON P.CALENDAR_DATE = DC.CALENDAR_DATE AND P.PSP_PORTFOLIO_CODE = DC.PSP_PORTFOLIO_CODE 
INNER JOIN private_data_nav PN on PN.CALENDAR_DATE = DC.CALENDAR_DATE and PN.PSP_PORTFOLIO_CODE = DC.PSP_PORTFOLIO_CODE 
INNER JOIN position_per_leg_data PPL ON PPL.CALENDAR_DATE = DC.CALENDAR_DATE AND PPL.PSP_PORTFOLIO_CODE = DC.PSP_PORTFOLIO_CODE 
INNER JOIN private_exposure_data PE ON PE.CALENDAR_DATE = DC.CALENDAR_DATE AND PE.PSP_PORTFOLIO_CODE = DC.PSP_PORTFOLIO_CODE 
ORDER BY
      DC.CALENDAR_DATE
    , P.PSP_PORTFOLIO_CODE
    , PE.PSP_INSTRUMENT_ID