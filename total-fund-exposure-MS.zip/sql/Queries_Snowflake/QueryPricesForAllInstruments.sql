SELECT
      EVALUATION_DATE                                          AS PositionDate
    , PSP_INSTRUMENT_ID                                        AS Instrument_PSPInstrumentID
    , IFNULL(PRICE_CURRENCY_CODE,PRESENT_VALUE_CURRENCY_CODE)  AS Price_CurrencyCode
    , IFNULL(PRICE,PRESENT_VALUE)                              AS Price_Local
    , IFNULL(PRICE_IN_CAD,PRESENT_VALUE_IN_CAD)                AS Price_CAD
FROM __database_warehouse__WAREHOUSE.INSTRUMENT_PRICE_V1
WHERE
        EVALUATION_DATE in (__final_position_dates__)
    AND PSP_INSTRUMENT_ID IN (__price_psp_instrument_ids__)