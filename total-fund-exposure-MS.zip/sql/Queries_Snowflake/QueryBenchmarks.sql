SELECT
      BC.EFFECTIVE_DATE                                            AS PositionDate
    , AC.ASSET_CLASS_NAME                                          AS AssetClass_Name
    , BC.PSP_BENCHMARK_CODE                                        AS AssetClass_PSPBenchmarkCode
    , AC.BENCHMARK_ASSIGNATION_NAME                                AS AssetClass_BenchmarkAssignationDescription                          
    , BC.BENCHMARK_NAME                                            AS Benchmark_Name    
    , IFNULL(NULLIF(BC.NET_ASSET_VALUE_CALCULATION_CURRENCY_CODE,'N/A'),I.INSTRUMENT_CURRENCY_CODE)  AS Benchmark_CurrencyCode 
    , BC.PSP_INSTRUMENT_ID                                         AS Benchmark_PSPInstrumentID        
    , BC.WEIGHT                                                    AS Benchmark_Weight 
    , IFNULL(NULLIF(I.INDEX_PROXY_PSP_INSTRUMENT_ID,-1), I.PSP_INSTRUMENT_ID) AS Benchmark_FinalPSPInstrumentID
FROM __database_warehouse__WAREHOUSE.ASSET_CLASS_V1 AC
INNER JOIN __database_warehouse__WAREHOUSE.ASSET_CLASS_ALLOCATION_V1 ACB ON ACB.PSP_ASSET_CLASS_ID = AC.PSP_ASSET_CLASS_ID 
       AND AC.PSP_BENCHMARK_ASSIGNATION_ID = ACB.PSP_BENCHMARK_ASSIGNATION_ID
INNER JOIN __database_warehouse__WAREHOUSE.BENCHMARK_CONSTITUENT_V1 BC ON BC.PSP_BENCHMARK_ID = ACB.PSP_BENCHMARK_ID AND BC.EFFECTIVE_DATE = ACB.EVALUATION_DATE
INNER JOIN __database_warehouse__WAREHOUSE.INSTRUMENT_V1 I ON I.PSP_INSTRUMENT_ID = BC.PSP_INSTRUMENT_ID
WHERE
        BC.EFFECTIVE_DATE IN (__final_position_dates__)
    AND AC.ASSET_CLASS_NAME IN (__psp_asset_class_names__)