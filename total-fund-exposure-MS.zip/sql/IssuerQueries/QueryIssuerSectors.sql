SELECT
      IIC.IssuerCode                    AS 'Issuer_Code'
    , IIC.PSPIndustryClassificationID   AS 'Issuer_BICSBETAClassificationID'
    , ICAL.SectorCode                   AS 'Issuer_BICSBETASectorCode'
    , ICAl.SectorName                   AS 'Issuer_BICSBETASectorName'
    , ICAL.IndustryGroupCode            AS 'Issuer_BICSBETAIndustryGroupCode'
    , ICAl.IndustryGroupName            AS 'Issuer_BICSBETAIndustryGroupName'
    , ICAL.IndustryCode                 AS 'Issuer_BICSBETAIndustryCode'
    , ICAl.IndustryName                 AS 'Issuer_BICSBETAIndustryName'
    , ICAL.SubIndustryCode              AS 'Issuer_BICSBETASubIndustryCode'
    , ICAl.SubIndustryName              AS 'Issuer_BICSBETASubIndustryName'
    , ICAL.ActivityCode                 AS 'Issuer_BICSBETAActivityCode'
    , ICAl.ActivityName                 AS 'Issuer_BICSBETAActivityName'
    , ICAL.SubActivityCode              AS 'Issuer_BICSBETASubActivityCode'
    , ICAl.SubActivityName              AS 'Issuer_BICSBETASubActivityName'
    , ICAL.SegmentCode                  AS 'Issuer_BICSBETASegmentCode'
    , ICAl.SegmentName                  AS 'Issuer_BICSBETASegmentName'
FROM PSPDW2.PSPDW.IssuerIndustryClassification IIC
INNER JOIN [PSPDW2].[PSPDW].[IndustryClassification_AllLevels] ICAL 
  ON ICAL.PSPIndustryClassificationID = IIC.PSPIndustryClassificationID 
    AND ICAL.ClassificationScheme = 'BICSBETA' 
where  
        IIC.ClassificationScheme = 'BICSBETA' 
    AND IIC.ClassificationSource ='BLOOMBERG'
    AND IIC.IssuerCode in (__psp_all_issuer_codes__)
    AND IIC.DateWindowFrom <= __issuer_date__  AND isnull(IIC.DateWindowTo,'2100-01-01') > __issuer_date__
    AND ICAL.DateWindowFrom <= __issuer_date__ AND isnull(ICAL.DateWindowTo,'2100-01-01') > __issuer_date__
    AND IIC.IsActivePSPDW = 1