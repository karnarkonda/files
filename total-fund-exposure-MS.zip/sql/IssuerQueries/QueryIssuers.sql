WITH 
    PSPIssuerCodes(IssuerCode)
AS (SELECT 
      CAST(VALUE AS INT)
    FROM OPENJSON('[__psp_issuer_codes__]')
    ),
    preIssuers(IssuerCode, UltimateParentIssuerCode)
AS (SELECT
      I.IssuerCode
    , I.UltimateParentIssuerCode
    FROM PSPIssuerCodes P
    INNER JOIN PSPDW2.PSPDW.Issuers I ON I.IssuerCode = P.IssuerCode
        AND I.DateWindowFrom <= __issuer_date__ AND isnull(I.DateWindowTo,'2100-01-01') > __issuer_date__
    ),
    preIssuersParent(IssuerCode)
AS (SELECT
      I.IssuerCode
    FROM preIssuers PI
    INNER JOIN PSPDW2.PSPDW.Issuers I ON I.IssuerCode = PI.UltimateParentIssuerCode
    WHERE 
            PI.UltimateParentIssuerCode IS NOT NULL
        AND PI.UltimateParentIssuerCode <> PI.IssuerCode
        AND I.DateWindowFrom <= __issuer_date__ AND isnull(I.DateWindowTo,'2100-01-01') > __issuer_date__
    GROUP BY I.IssuerCode
    ),
    allIssuerCode(IssuerCode)
AS (SELECT
          IssuerCode
    FROM preIssuers
    UNION
    SELECT
          IssuerCode
    FROM preIssuersParent
    )
SELECT
      I.IssuerCode                                     AS 'Issuer_Code'
    , I.IssuerName                                     AS 'Issuer_Name'
    , I.PSPLegalEntityID                               AS 'Issuer_PSPLegalEntityID'
    , ISNULL(I.UltimateParentIssuerCode, I.IssuerCode) AS 'Issuer_UltimateParentCode'
    , I.RiskLocationCountryCode                        AS 'Issuer_RiskLocationCountryCode'
    , LE.NormalizedCountryCode                          AS 'Issuer_NormalizedCountryCode'
FROM allIssuerCode AI
INNER JOIN PSPDW2.PSPDW.Issuers I ON I.IssuerCode = AI.IssuerCode
LEFT JOIN PSPDW2.PSPDW.LegalEntity LE 
    ON I.PSPLegalEntityID = LE.PSPLegalEntityID 
        AND LE.DateWindowFrom <= __issuer_date__ 
        AND isnull(LE.DateWindowTo,'2100-01-01') > __issuer_date__
WHERE 
        I.DateWindowFrom <= __issuer_date__ AND isnull(I.DateWindowTo,'2100-01-01') > __issuer_date__
