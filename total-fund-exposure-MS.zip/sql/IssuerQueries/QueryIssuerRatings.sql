WITH latest_rating_date(IssuerCode, EvaluationDate_LongTerm, EvaluationDate_ShortTerm)
AS  (
    SELECT 
          IssuerCode
        , MAX(CASE WHEN CreditRatingTerm = 'Long Term' THEN EvaluationDate ELSE NULL END) 
        , MAX(CASE WHEN CreditRatingTerm = 'Short Term' THEN EvaluationDate ELSE NULL END)
    FROM [PSPDW2].[PSPDW].IssuerNormalizedCreditRating INCR 
    WHERE  
            IssuerCode in (__psp_all_issuer_codes__)
        AND EvaluationDate <= __issuer_date__
        AND IsActiveIssuerNormalizedCreditRating = 1
    GROUP BY
          IssuerCode
    )
SELECT 
      LRD.IssuerCode                  AS 'Issuer_Code'
    , INCR_LT.LowestNormalizedRating  AS 'Issuer_LongTerm_LowestNormalizedRating'  
    , INCR_LT.HighestNormalizedRating AS 'Issuer_LongTerm_HighestNormalizedRating'
    , INCR_ST.LowestNormalizedRating  AS 'Issuer_ShortTerm_LowestNormalizedRating' 
    , INCR_ST.HighestNormalizedRating  AS 'Issuer_ShortTerm_HighestNormalizedRating' 
FROM latest_rating_date LRD
LEFT JOIN [PSPDW2].[PSPDW].IssuerNormalizedCreditRating INCR_LT ON INCR_LT.IssuerCode = LRD.IssuerCode AND INCR_LT.EvaluationDate = LRD.EvaluationDate_LongTerm  AND INCR_LT.CreditRatingTerm = 'Long Term'  AND INCR_LT.IsActiveIssuerNormalizedCreditRating = 1
LEFT JOIN [PSPDW2].[PSPDW].IssuerNormalizedCreditRating INCR_ST ON INCR_ST.IssuerCode = LRD.IssuerCode AND INCR_ST.EvaluationDate = LRD.EvaluationDate_ShortTerm AND INCR_ST.CreditRatingTerm = 'Short Term' AND INCR_ST.IsActiveIssuerNormalizedCreditRating = 1