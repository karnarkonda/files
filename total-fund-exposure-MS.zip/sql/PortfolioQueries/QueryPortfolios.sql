SELECT
      L1.PSPPortfolioCode                AS 'L1_PSPPortfolioCode'                
    , L1.PSPPortfolioID                  AS 'L1_PSPPortfolioID'                    
    , L1.PortfolioName                   AS 'L1_PortfolioName'                    
    , L1.PortfolioType                   AS 'L1_PortfolioType'                    
    , L1.ManagingDepartment              AS 'L1_ManagingDepartment'                        
    , L1.ManagerType                     AS 'L1_ManagerType'                    
    , L1.ManagingStyle                   AS 'L1_ManagingStyle'                    
    , L1.PSPAssetClassAllocationCode     AS 'L1_PSPAssetClassAllocationCode'    
    , L1.AssetClassAllocationDescription AS 'L1_AssetClassAllocationDescription'
    , L1.PortfolioStyle                  AS 'L1_PortfolioStyle'                    
    , L1.OwnerDepartment                 AS 'L1_OwnerDepartment'                
    , L1.PSPInvestmentTeamCode           AS 'L1_PSPInvestmentTeamCode'            
    , L1.InvestmentTeamName              AS 'L1_InvestmentTeamName'    
    
    , L2.PSPPortfolioCode                AS 'L2_PSPPortfolioCode'                            
    , L2.PSPPortfolioID                  AS 'L2_PSPPortfolioID'                    
    , L2.PortfolioName                   AS 'L2_PortfolioName'                    
    , L2.PortfolioType                   AS 'L2_PortfolioType'                    
    , L2.ManagingDepartment              AS 'L2_ManagingDepartment'                
    , L2.ManagerType                     AS 'L2_ManagerType'                    
    , L2.ManagingStyle                   AS 'L2_ManagingStyle'                    
    , L2.PSPAssetClassAllocationCode     AS 'L2_PSPAssetClassAllocationCode'    
    , L2.AssetClassAllocationDescription AS 'L2_AssetClassAllocationDescription'
    , L2.PortfolioStyle                  AS 'L2_PortfolioStyle'                    
    , L2.OwnerDepartment                 AS 'L2_OwnerDepartment'                
    , L2.PSPInvestmentTeamCode           AS 'L2_PSPInvestmentTeamCode'            
    , L2.InvestmentTeamName              AS 'L2_InvestmentTeamName'                
    
    , L3.PSPPortfolioCode                AS 'L3_PSPPortfolioCode'                 
    , L3.PSPPortfolioID                  AS 'L3_PSPPortfolioID'                    
    , L3.PortfolioName                   AS 'L3_PortfolioName'                    
    , L3.PortfolioType                   AS 'L3_PortfolioType'                    
    , L3.ManagingDepartment              AS 'L3_ManagingDepartment'            
    , L3.ManagerType                     AS 'L3_ManagerType'                    
    , L3.ManagingStyle                   AS 'L3_ManagingStyle'                    
    , L3.PSPAssetClassAllocationCode     AS 'L3_PSPAssetClassAllocationCode'    
    , L3.AssetClassAllocationDescription AS 'L3_AssetClassAllocationDescription'
    , L3.PortfolioStyle                  AS 'L3_PortfolioStyle'                    
    , L3.OwnerDepartment                 AS 'L3_OwnerDepartment'                
    , L3.PSPInvestmentTeamCode           AS 'L3_PSPInvestmentTeamCode'            
    , L3.InvestmentTeamName              AS 'L3_InvestmentTeamName'                    
    
    , L4.PSPPortfolioCode                AS 'L4_PSPPortfolioCode'                
    , L4.PSPPortfolioID                  AS 'L4_PSPPortfolioID'                    
    , L4.PortfolioName                   AS 'L4_PortfolioName'                    
    , L4.PortfolioType                   AS 'L4_PortfolioType'                    
    , L4.ManagingDepartment              AS 'L4_ManagingDepartment'                    
    , L4.ManagerType                     AS 'L4_ManagerType'                    
    , L4.ManagingStyle                   AS 'L4_ManagingStyle'                    
    , L4.PSPAssetClassAllocationCode     AS 'L4_PSPAssetClassAllocationCode'    
    , L4.AssetClassAllocationDescription AS 'L4_AssetClassAllocationDescription'
    , L4.PortfolioStyle                  AS 'L4_PortfolioStyle'                    
    , L4.OwnerDepartment                 AS 'L4_OwnerDepartment'                
    , L4.PSPInvestmentTeamCode           AS 'L4_PSPInvestmentTeamCode'            
    , L4.InvestmentTeamName              AS 'L4_InvestmentTeamName'  
    
    ,case 
            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') AND L4.PSPInvestmentTeamCode in ('PFI') 
                                                            AND COALESCE(L1.PortfolioStyle,L4.PortfolioStyle) Not In ('Legacy','Internal Borrowings','Subsidiary') 
                                                            AND COALESCE(L1.ManagingStyle,L4.ManagingStyle) in ('Active')     
                                                            AND COALESCE(L1.ManagerType,L4.ManagerType) in ('External') 
                  Then 'Public Fixed Income - Active - External'

            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') AND L4.PSPInvestmentTeamCode in ('PFI') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle ) Not In ('Legacy','Internal Borrowings','Subsidiary') 
                                                            AND COALESCE(L1.ManagingStyle, L4.ManagingStyle) in ('Active')    
                                                            AND COALESCE(L1.ManagerType, L4.ManagerType) in ('Internal') 
                  Then 'Public Fixed Income - Active - Internal'         
                                                     
            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') AND L4.PSPInvestmentTeamCode in ('PFI') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle ) Not In ('Legacy','Internal Borrowings','Subsidiary') 
                                                            AND COALESCE(L1.ManagingStyle, L4.ManagingStyle) in ('Passive')   
                                                            AND COALESCE(L1.ManagerType, L4.ManagerType) in ('External') 
                  Then 'Public Fixed Income - Passive - External'

            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') AND L4.PSPInvestmentTeamCode in ('PFI') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle) Not In ('Legacy','Internal Borrowings','Subsidiary') 
                                                            AND COALESCE(L1.ManagingStyle, L4.ManagingStyle) in ('Passive')   
                                                            AND COALESCE(L1.ManagerType, L4.ManagerType ) in ('Internal') 
                  Then 'Public Fixed Income - Passive - Internal'

            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') AND L4.PSPInvestmentTeamCode in ('PEQ') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle)  Not In ('Legacy','Internal Borrowings','Subsidiary') 
                                                            AND COALESCE(L1.ManagingStyle, L4.ManagingStyle) in ('Passive')   
                                                            AND COALESCE(L1.ManagerType, L4.ManagerType) in ('External') 
                  Then 'Public Equity - Passive - External'

            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') AND L4.PSPInvestmentTeamCode in ('PEQ') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle)  Not In ('Legacy','Internal Borrowings','Subsidiary') 
                                                            AND COALESCE(L1.ManagingStyle, L4.ManagingStyle) in ('Passive')   
                                                            AND COALESCE(L1.ManagerType, L4.ManagerType) in ('Internal') 
                  Then 'Public Equity - Passive - Internal' 
                                                            
            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') AND L4.PSPInvestmentTeamCode in ('PEQ') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle)  Not In ('Legacy','Internal Borrowings','Subsidiary') 
                                                            AND COALESCE(L1.ManagingStyle, L4.ManagingStyle) in ('Active')    
                                                            AND COALESCE(L1.ManagerType, L4.ManagerType) in ('External') 
                  Then 'Public Equity - Active - External'

            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') AND L4.PSPInvestmentTeamCode in ('PEQ') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle)  Not In ('Legacy','Internal Borrowings','Subsidiary') 
                                                            AND COALESCE(L1.ManagingStyle, L4.ManagingStyle) in ('Active')    
                                                            AND COALESCE(L1.ManagerType, L4.ManagerType) in ('Internal') 
                  Then 'Public Equity - Active - Internal'


            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') AND L4.PSPInvestmentTeamCode in ('ALT') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle) Not In ('Legacy','Internal Borrowings','Subsidiary') 
                                                            AND COALESCE(L1.ManagerType, L4.ManagerType) in ('External') 
                  Then 'Alternatives - External'

            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') AND L4.PSPInvestmentTeamCode in ('ALT') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle) Not In ('Legacy','Internal Borrowings','Subsidiary') 
                                                            AND COALESCE(L1.ManagerType,L4.ManagerType) in ('Internal') 
                  Then 'Alternatives - Internal'                                              
--- 
            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') AND L4.PSPInvestmentTeamCode in ('PS') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle) Not In ('Legacy','Internal Borrowings','Subsidiary')
                  Then 'Portfolio Strategy'

            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle) In ('Legacy')
                  Then 'Legacy'

            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle) In ('Internal Borrowings')
                  Then 'Internal Borrowings'

            when  L4.OwnerDepartment in ('PMARS','Public Markets','CM', 'Capital Markets') AND L4.ManagingDepartment Not In ('CIO Group') 
                                                            AND COALESCE(L1.PortfolioStyle, L4.PortfolioStyle) In ('Subsidiary')
                  Then 'Subsidiary'

            when  L4.OwnerDepartment in ('CIO Group') AND L4.ManagingDepartment In ('PMARS','Public Markets','CM', 'Capital Markets') 
                  Then 'Mechanical Rebalancing'

            Else  'Other'
     end AS InvestmentStrategyCalc
    
FROM [PSPDW2].[PSPDW].[cvPSPPortfoliosHierarchy]
INNER JOIN [PSPDW2].[PSPDW].[cvPortfolio] L1 ON L1.PSPPortfolioCode = L1_PSPPortfolioCode
INNER JOIN [PSPDW2].[PSPDW].[cvPortfolio] L2 ON L2.PSPPortfolioCode = L2_PSPPortfolioCode
INNER JOIN [PSPDW2].[PSPDW].[cvPortfolio] L3 ON L3.PSPPortfolioCode = L3_PSPPortfolioCode
INNER JOIN [PSPDW2].[PSPDW].[cvPortfolio] L4 ON L4.PSPPortfolioCode = L4_PSPPortfolioCode
WHERE
      L4_PSPPortfolioID IN (__psp_portfolio_ids__)