WITH portfolio_date_batch (PORTFOLIO_KEY, PORTFOLIO_ID, MostRecent_CalendarKey, MostRecent_Batch_key)
AS  (
    SELECT 
          P.PORTFOLIO_KEY
        , P.PORTFOLIO_ID
        , MBD.MostRecent_CalendarKey
        , MBK.MostRecent_Batch_key
    FROM  __database_warehouse__WAREHOUSE.DATE_V1 as datetable
    INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_PORTFOLIO P ON P.PORTFOLIO_ID IN (__psp_portfolio_ids__) AND CAST(P.DATE_WINDOW_FROM AS DATE) <= datetable.CALENDAR_DATE AND datetable.CALENDAR_DATE < CAST(P.DATE_WINDOW_TO AS DATE)
    INNER join lateral(
                        SELECT
                              MAX(PS.CALENDAR_KEY) AS "MostRecent_CalendarKey"
                        FROM __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_BATCH B
                        INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_PORTFOLIO_STATS PS ON PS.PORTFOLIO_KEY = P.PORTFOLIO_KEY AND PS.BATCH_KEY = B.BATCH_KEY AND PS.CALENDAR_KEY BETWEEN DATEADD(MONTH,-1,datetable.CALENDAR_DATE) AND datetable.CALENDAR_DATE
                        WHERE
                            B.IS_PROD = 'Prod'
                      ) MBD
    INNER join lateral(
                        SELECT
                              MAX(PS.BATCH_KEY) AS "MostRecent_Batch_key"
                        FROM __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_BATCH B
                        INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_PORTFOLIO_STATS PS ON PS.PORTFOLIO_KEY = P.PORTFOLIO_KEY AND PS.BATCH_KEY = B.BATCH_KEY AND PS.CALENDAR_KEY = MBD.MostRecent_CalendarKey
                        WHERE
                            B.IS_PROD = 'Prod'
                 ) MBK
    WHERE
            datetable.CALENDAR_DATE IN (__final_position_dates__)
        AND MBD.MostRecent_CalendarKey IS NOT NULL
        AND MBK.MostRecent_Batch_key IS NOT NULL
    GROUP BY
          P.PORTFOLIO_KEY
        , P.PORTFOLIO_ID
        , MBD.MostRecent_CalendarKey
        , MBK.MostRecent_Batch_key
    )
SELECT
      PDB.PORTFOLIO_KEY
    , PDB.PORTFOLIO_ID
    , B.BENCHMARK_KEY
    , B.BENCHMARK_CODE
    , I.INSTRUMENT_KEY
    , I.INSTRUMENT_ID
    , I.RISK_METRICS_POSITION_TYPE
    , PS.CALENDAR_KEY
    , PS.BATCH_KEY
    , C.CURRENCY_KEY
    , C.CURRENCY_CODE
    , PS.PORTFOLIO_PRESENT_VALUE
    , PS.PORTFOLIO_KRD
    , PS.PORTFOLIO_CURRENCY_DOLLAR_DELTA
    , PS.BENCHMARK_PRESENT_VALUE
    , PS.BENCHMARK_KRD
    , PS.BENCHMARK_CURRENCY_DOLLAR_DELTA
FROM portfolio_date_batch PDB
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_POSITION_STATS_BY_CURRENCY PS  ON PS.BATCH_KEY = PDB.MostRecent_Batch_key AND PS.PORTFOLIO_KEY = PDB.PORTFOLIO_KEY AND PS.CALENDAR_KEY = PDB.MostRecent_CalendarKey
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_Instrument  I ON I.INSTRUMENT_KEY = PS.Instrument_Key
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_Benchmark B  ON B.BENCHMARK_KEY = PS.Benchmark_Key
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_Currency C  ON C.CURRENCY_KEY = PS.Currency_Key;