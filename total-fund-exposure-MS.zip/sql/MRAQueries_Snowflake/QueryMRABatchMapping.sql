SELECT 
      P.PORTFOLIO_KEY
    , P.PORTFOLIO_ID
    , datetable.CALENDAR_DATE
    , MBD.MostRecent_CalendarKey
    , MBK.MostRecent_Batch_key
FROM  __database_warehouse__WAREHOUSE.DATE_V1 as datetable
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_PORTFOLIO P ON P.PORTFOLIO_ID IN (__psp_portfolio_ids__) AND CAST(P.DATE_WINDOW_FROM AS DATE) <= datetable.CALENDAR_DATE AND datetable.CALENDAR_DATE < CAST(P.DATE_WINDOW_TO AS DATE)
INNER join lateral(
                    SELECT
                          MAX(PS.CALENDAR_KEY) AS "MostRecent_CalendarKey"
                    FROM __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_BATCH B
                    INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_PORTFOLIO_STATS PS ON PS.PORTFOLIO_KEY = P.PORTFOLIO_KEY AND PS.BATCH_KEY = B.BATCH_KEY AND PS.CALENDAR_KEY BETWEEN DATEADD(MONTH,-1,datetable.CALENDAR_DATE) AND datetable.CALENDAR_DATE
                    WHERE
                        B.IS_PROD = 'Prod'
                  ) MBD
INNER join lateral(
                    SELECT
                          MAX(PS.BATCH_KEY) AS "MostRecent_Batch_key"
                    FROM __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_BATCH B
                    INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_PORTFOLIO_STATS PS ON PS.PORTFOLIO_KEY = P.PORTFOLIO_KEY AND PS.BATCH_KEY = B.BATCH_KEY AND PS.CALENDAR_KEY = MBD.MostRecent_CalendarKey
                    WHERE
                        B.IS_PROD = 'Prod'
             ) MBK
WHERE
        datetable.CALENDAR_DATE IN (__final_position_dates__)
    AND MBD.MostRecent_CalendarKey IS NOT NULL
    AND MBK.MostRecent_Batch_key IS NOT NULL
GROUP BY
      P.PORTFOLIO_KEY
    , P.PORTFOLIO_ID
    , datetable.CALENDAR_DATE
    , MBD.MostRecent_CalendarKey
    , MBK.MostRecent_Batch_key