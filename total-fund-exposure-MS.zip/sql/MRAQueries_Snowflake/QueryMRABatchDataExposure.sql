WITH portfolio_date_batch (PORTFOLIO_KEY, PORTFOLIO_ID, MostRecent_CalendarKey, MostRecent_Batch_key)
AS  (
    SELECT 
          P.PORTFOLIO_KEY
        , P.PORTFOLIO_ID
        , MBD.MostRecent_CalendarKey
        , MBK.MostRecent_Batch_key
    FROM  __database_warehouse__WAREHOUSE.DATE_V1 as datetable
    INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_PORTFOLIO P ON P.PORTFOLIO_ID IN (__psp_portfolio_ids__) AND CAST(P.DATE_WINDOW_FROM AS DATE) <= datetable.CALENDAR_DATE AND datetable.CALENDAR_DATE < CAST(P.DATE_WINDOW_TO AS DATE)
    INNER join lateral(
                        SELECT
                              MAX(PS.CALENDAR_KEY) AS "MostRecent_CalendarKey"
                        FROM __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_BATCH B
                        INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_PORTFOLIO_STATS PS ON PS.PORTFOLIO_KEY = P.PORTFOLIO_KEY AND PS.BATCH_KEY = B.BATCH_KEY AND PS.CALENDAR_KEY BETWEEN DATEADD(MONTH,-1,datetable.CALENDAR_DATE) AND datetable.CALENDAR_DATE
                        WHERE
                            B.IS_PROD = 'Prod'
                      ) MBD
    INNER join lateral(
                        SELECT
                              MAX(PS.BATCH_KEY) AS "MostRecent_Batch_key"
                        FROM __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_BATCH B
                        INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_PORTFOLIO_STATS PS ON PS.PORTFOLIO_KEY = P.PORTFOLIO_KEY AND PS.BATCH_KEY = B.BATCH_KEY AND PS.CALENDAR_KEY = MBD.MostRecent_CalendarKey
                        WHERE
                            B.IS_PROD = 'Prod'
                 ) MBK
    WHERE
            datetable.CALENDAR_DATE IN (__final_position_dates__)
        AND MBD.MostRecent_CalendarKey IS NOT NULL
        AND MBK.MostRecent_Batch_key IS NOT NULL
    GROUP BY
          P.PORTFOLIO_KEY
        , P.PORTFOLIO_ID
        , MBD.MostRecent_CalendarKey
        , MBK.MostRecent_Batch_key
    )
SELECT 
      PDB.PORTFOLIO_KEY                           
    , PDB.PORTFOLIO_ID 
    , 'Portfolio'                       AS OBJECT_TYPE
    , B.BENCHMARK_KEY                  
    , B.BENCHMARK_CODE                 
    , I.INSTRUMENT_KEY                
    , I.INSTRUMENT_ID                
    , I.RISK_METRICS_POSITION_TYPE               
    , I.INSTRUMENT_CATEGORIZATION_ID                         
    , I.INSTRUMENT_CATEGORIZATION_CODE                         
    , I2.INSTRUMENT_KEY                 AS I2_InstrumentKey         
    , I2.INSTRUMENT_ID                  AS I2_InstrumentID
    , I2.RISK_METRICS_POSITION_TYPE     AS I2_RiskMetricsPositionType      
    , I2.INSTRUMENT_CATEGORIZATION_ID   AS I2_InstrumentCategorizationID         
    , I2.INSTRUMENT_CATEGORIZATION_CODE AS I2_InstrumentCategorizationCode           
    , PS.CALENDAR_KEY                   
    , PS.BATCH_KEY
    , PS.PORTFOLIO_COMMODITY_EXPOSURE   AS Exposure_Commodity     
    , PS.PORTFOLIO_EQUITY_EXPOSURE      AS Exposure_Equity
    , PS.PORTFOLIO_ISSUER_EXPOSURE      AS Exposure_Issuer
FROM portfolio_date_batch PDB
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_EXPOSURE PS  ON PS.BATCH_KEY = PDB.MostRecent_Batch_key AND PS.PORTFOLIO_KEY = PDB.PORTFOLIO_KEY AND PS.CALENDAR_KEY = PDB.MostRecent_CalendarKey
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_INSTRUMENT I  ON I.INSTRUMENT_KEY = PS.INSTRUMENT_KEY
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_INSTRUMENT I2 ON I2.INSTRUMENT_KEY = PS.CONSTITUENT_INSTRUMENT_KEY
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_BENCHMARK B   ON B.BENCHMARK_KEY = PS.BENCHMARK_KEY
WHERE
       PS.PORTFOLIO_COMMODITY_EXPOSURE <> 0
    OR PS.PORTFOLIO_EQUITY_EXPOSURE <> 0
    OR PS.PORTFOLIO_ISSUER_EXPOSURE <> 0
UNION
SELECT 
      PDB.PORTFOLIO_KEY                                    
    , PDB.PORTFOLIO_ID                  
    , 'Benchmark'                       AS OBJECT_TYPE                 
    , B.BENCHMARK_KEY                  
    , B.BENCHMARK_CODE                 
    , I.INSTRUMENT_KEY                
    , I.INSTRUMENT_ID                
    , I.RISK_METRICS_POSITION_TYPE               
    , I.INSTRUMENT_CATEGORIZATION_ID                         
    , I.INSTRUMENT_CATEGORIZATION_CODE                         
    , I2.INSTRUMENT_KEY                 AS I2_InstrumentKey         
    , I2.INSTRUMENT_ID                  AS I2_InstrumentID
    , I2.RISK_METRICS_POSITION_TYPE     AS I2_RiskMetricsPositionType      
    , I2.INSTRUMENT_CATEGORIZATION_ID   AS I2_InstrumentCategorizationID         
    , I2.INSTRUMENT_CATEGORIZATION_CODE AS I2_InstrumentCategorizationCode                 
    , PS.CALENDAR_KEY                   
    , PS.BATCH_KEY                      
    , PS.BENCHMARK_COMMODITY_EXPOSURE   AS Exposure_Commodity     
    , PS.BENCHMARK_EQUITY_EXPOSURE      AS Exposure_Equity
    , PS.BENCHMARK_ISSUER_EXPOSURE      AS Exposure_Issuer
FROM portfolio_date_batch PDB
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_EXPOSURE PS  ON PS.BATCH_KEY = PDB.MostRecent_Batch_key AND PS.PORTFOLIO_KEY = PDB.PORTFOLIO_KEY AND PS.CALENDAR_KEY = PDB.MostRecent_CalendarKey
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_INSTRUMENT I  ON I.INSTRUMENT_KEY = PS.INSTRUMENT_KEY
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_INSTRUMENT I2 ON I2.INSTRUMENT_KEY = PS.CONSTITUENT_INSTRUMENT_KEY
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_BENCHMARK B   ON B.BENCHMARK_KEY = PS.BENCHMARK_KEY
WHERE
       PS.BENCHMARK_COMMODITY_EXPOSURE <> 0
    OR PS.BENCHMARK_EQUITY_EXPOSURE <> 0
    OR PS.BENCHMARK_ISSUER_EXPOSURE <> 0