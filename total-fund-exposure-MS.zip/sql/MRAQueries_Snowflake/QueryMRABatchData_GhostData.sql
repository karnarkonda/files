WITH portfolio_date_batch (PORTFOLIO_KEY, PORTFOLIO_ID, MostRecent_CalendarKey, MostRecent_Batch_key)
AS  (
    SELECT 
          P.PORTFOLIO_KEY
        , P.PORTFOLIO_ID
        , MBD.MostRecent_CalendarKey
        , MBK.MostRecent_Batch_key
    FROM  __database_warehouse__WAREHOUSE.DATE_V1 as datetable
    INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_PORTFOLIO P ON P.PORTFOLIO_ID IN (__pooled_fund_ghost_psp_portfolio_ids__) AND CAST(P.DATE_WINDOW_FROM AS DATE) <= datetable.CALENDAR_DATE AND datetable.CALENDAR_DATE < CAST(P.DATE_WINDOW_TO AS DATE)
    INNER join lateral(
                        SELECT
                              MAX(PS.CALENDAR_KEY) AS "MostRecent_CalendarKey"
                        FROM __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_BATCH B
                        INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_PORTFOLIO_STATS PS ON PS.PORTFOLIO_KEY = P.PORTFOLIO_KEY AND PS.BATCH_KEY = B.BATCH_KEY AND PS.CALENDAR_KEY BETWEEN DATEADD(MONTH,-1,datetable.CALENDAR_DATE) AND datetable.CALENDAR_DATE
                        WHERE
                            B.IS_PROD = 'Prod'
                      ) MBD
    INNER join lateral(
                        SELECT
                              MAX(PS.BATCH_KEY) AS "MostRecent_Batch_key"
                        FROM __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_BATCH B
                        INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_PORTFOLIO_STATS PS ON PS.PORTFOLIO_KEY = P.PORTFOLIO_KEY AND PS.BATCH_KEY = B.BATCH_KEY AND PS.CALENDAR_KEY = MBD.MostRecent_CalendarKey
                        WHERE
                            B.IS_PROD = 'Prod'
                 ) MBK
    WHERE
            datetable.CALENDAR_DATE IN (__final_position_dates__)
        AND MBD.MostRecent_CalendarKey IS NOT NULL
        AND MBK.MostRecent_Batch_key IS NOT NULL
    GROUP BY
          P.PORTFOLIO_KEY
        , P.PORTFOLIO_ID
        , MBD.MostRecent_CalendarKey
        , MBK.MostRecent_Batch_key
    )
SELECT 
      PDB.PORTFOLIO_KEY
    , PDB.PORTFOLIO_ID
    , I.INSTRUMENTKEY
    , I.INSTRUMENTID                                                                
    , I.RISKMETRICSPOSITIONTYPE
    , PS.CALENDAR_KEY
    , PS.BATCH_KEY
    
    , I.INSTRUMENTFAMILY                                                             
    , I.INSTRUMENTCATEGORIZATIONID                                                   
    , COALESCE(I.INSTRUMENTCATEGORIZATIONCODE, I.INSTRUMENTCATEGORIZATIONCODERISK)    AS   INSTRUMENTCATEGORIZATIONCODE
    , I.INSTRUMENTDESCRIPTION                                                        
    , I.INSTRUMENTMARKET                                                             
    , I.INSTRUMENTTYPE                                                             
    , I.ISSUERCODE                                                               
    
    , I.ULTIMATEUNDERLYINGINSTRUMENTID                                               
    , UUI.INSTRUMENTFAMILY                                                              AS UUI_INSTRUMENTFAMILY
    , UUI.INSTRUMENTCATEGORIZATIONID                                                    AS UUI_INSTRUMENTCATEGORIZATIONID
    , COALESCE(UUI.INSTRUMENTCATEGORIZATIONCODE, UUI.INSTRUMENTCATEGORIZATIONCODERISK)  AS UUI_INSTRUMENTCATEGORIZATIONCODE
    , UUI.INSTRUMENTDESCRIPTION                                                         AS UUI_INSTRUMENTDESCRIPTION     
    , UUI.INSTRUMENTMARKET                                                              AS UUI_INSTRUMENTMARKET
    , UUI.INSTRUMENTTYPE                                                                AS UUI_INSTRUMENTTYPE   
    , UUI.ISSUERCODE                                                                    AS UUI_ISSUERCODE 
    , COALESCE(INDEXPROXY.INSTRUMENT_ID, UUI.INSTRUMENTID)                              AS UUI_INDEXPROXYID
            
    --Sector Data
    , COALESCE(UUI.GICSSECTORCODERISK,        UUI.GICSSECTORCODE)                       AS GICSSECTORCODE                
    , COALESCE(UUI.GICSSECTORNAMERISK,        UUI.GICSSECTORNAME)                       AS GICSSECTORNAME      
    , COALESCE(UUI.GICSINDUSTRYGROUPNAMERISK, UUI.GICSINDUSTRYGROUPNAME)                AS GICSINDUSTRYGROUPNAME      
    , COALESCE(UUI.GICSINDUSTRYCODERISK,      UUI.GICSINDUSTRYCODE)                     AS GICSINDUSTRYCODE        
    , COALESCE(UUI.GICSINDUSTRYNAMERISK,      UUI.GICSINDUSTRYNAME)                     AS GICSINDUSTRYNAME        
    , COALESCE(UUI.GICSSUBINDUSTRYNAMERISK,   UUI.GICSSUBINDUSTRYNAME)                  AS GICSSUBINDUSTRYNAME       
    
    , UUI.BLOOMBERGSECTORDESCRIPTION                       
    , UUI.BLOOMBERGINDUSTRYDESCRIPTION            
    , UUI.BLOOMBERGSUBINDUSTRYDESCRIPTION            
    
    --Issuer Data
    , ISSUER.ISSUER_CODE
    , ISSUER.ISSUER_NAME
    , ISSUER.ISSUER_LEGAL_NAME
    , ISSUER.RISK_LOCATION_COUNTRY_CODE
    , ISSUER.RISK_LOCATION_COUNTRY_NAME
    
    --Legal Entity Data
    , LE.PSP_LEGAL_ENTITY_ID
    , LE.LEGAL_NAME
FROM portfolio_date_batch PDB
INNER JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_POSITION_STATS PS  ON PS.BATCH_KEY = PDB.MostRecent_Batch_key AND PS.PORTFOLIO_KEY = PDB.PORTFOLIO_KEY AND PS.CALENDAR_KEY = PDB.MostRecent_CalendarKey
INNER JOIN __database_mra__DATAPRODUCT_RISK_CORE.INSTRUMENT I ON I.INSTRUMENTKEY = PS.INSTRUMENT_KEY
INNER JOIN __database_mra__DATAPRODUCT_RISK_CORE.INSTRUMENT UUI ON UUI.INSTRUMENTKEY = I.ULTIMATEUNDERLYINGINSTRUMENTKEY
LEFT JOIN __database_mra__DATAPRODUCT_RISK.VW_FACT_INDEX_PROXY FIP ON FIP.CALENDAR_KEY = PDB.MostRecent_CalendarKey AND FIP.INDEX_INSTRUMENT_KEY = UUI.ULTIMATEUNDERLYINGINSTRUMENTKEY
LEFT JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_INSTRUMENT INDEXPROXY ON INDEXPROXY.INSTRUMENT_KEY = FIP.INDEX_PROXY_INSTRUMENT_KEY
LEFT JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_ISSUER ISSUER ON ISSUER.ISSUER_KEY = UUI.ISSUERKEY
LEFT JOIN __database_mra__DATAPRODUCT_RISK.VW_DIMENSION_LEGAL_ENTITY LE ON LE.PSP_LEGAL_ENTITY_ID = ISSUER.LEGAL_ENTITY_ID AND LE.DATE_WINDOW_FROM <= PS.CALENDAR_KEY AND PS.CALENDAR_KEY < LE.DATE_WINDOW_TO
WHERE
      I.INSTRUMENTID < 0;