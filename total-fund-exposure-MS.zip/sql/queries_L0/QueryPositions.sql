select
      P.ValuationDate                   AS 'PositionDate'
    , P.PSPPortfolioCode                AS 'Portfolio_PSPPortfolioCode'
    , P.PSPPortfolioID                  AS 'Portfolio_PSPPortfolioID'
    , pf.PortfolioName                  AS 'Portfolio_Name'
    , AC.MarketType                     AS 'Portfolio_MarketType'
    , AC.AssetClassName                 AS 'Portfolio_AssetClass'
    , pbh.InvestmentTeamName            AS 'Portfolio_InvestmentTeam'
    , pbh.ManagerType                   AS 'Portfolio_ManagerType'
    , pbh.ManagingStyle                 AS 'Portfolio_ManagingStyle'
    , pbh.ManagingDepartment            AS 'Portfolio_ManagingDepartment'
    , pbh.OwnerDepartment               AS 'Portfolio_OwnerDepartment'
    , P.PSPInstrumentID                 AS 'Instrument_PSPInstrumentID'
    , P.PositionCurrencyCode            AS 'Instrument_CurrencyCode'
    , P.PSPInstrumentLegID				      AS 'Leg_PSPInstrumentLegID' --, CASE SL.LegType WHEN 'CreditFee' THEN -1 WHEN 'CreditProtection' THEN 1 ELSE (CASE P.PositionLevel WHEN 'PaidLeg' THEN -1 WHEN 'ReceivedLeg' THEN 1 ELSE 0 END) END AS 'Leg_PSPInstrumentLegID'
    , P.PositionLevel                   AS 'Leg_PositionLevel'
    , P.TotalQuantity                   AS 'Position_Quantity'
    , P.TotalQuantityNominalAmount      AS 'Position_NominalAmount'
    , P.MarketValueInCAD                AS 'Position_MarketValue_CAD'
    , P.AccruedInterestValueInCAD       AS 'Position_AccruedInterestValue_CAD'
    , P.TaxReclaimAmountInCAD           AS 'Position_TaxReclaimValue_CAD'
    , P.NetAssetValueInCAD              AS 'Position_NetAssetValue_CAD'
FROM PSPDW2.PSPDW.PositionsPerLeg P
INNER JOIN PSPDW2.PSPDW.cvPortfolio Pf 
  ON P.PSPPortfolioCode = Pf.PSPPortfolioCode
    AND Pf.PortfolioType = 'Investment'
LEFT JOIN PSPDW2.PSPDW.cvPortfoliosBusinessHistory pbh 
  ON P.ValuationDate >= pbh.EffectiveBusinessDateFrom
    AND P.ValuationDate < isnull(pbh.EffectiveBusinessDateTo, '2199-12-31')
    AND P.PSPPortfolioCode = pbh.PSPPortfolioCode
LEFT JOIN PSPDW2.PSPDW.cvAssetClass AC 
  ON pbh.PSPAssetClassID = AC.PSPAssetClassID
where 
        P.ValuationDate in (__position_dates__)
    AND P.DateWindowFrom <= __evaluation_date__
    AND isnull(P.DateWindowTo,'2100-01-01') > __evaluation_date__
    __exclusions_psp_instrument_ids__
    __psp_portfolio_ids__
    __exclusions_psp_fund_codes__