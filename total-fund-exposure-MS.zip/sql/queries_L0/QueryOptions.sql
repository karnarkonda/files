SELECT
      o.PSPInstrumentID                                        AS 'Instrument_PSPInstrumentID'
    , COALESCE(fut.UnderlyingPSPID, o.UnderlyingPSPInstrumentID) AS 'Underlying_PSPInstrumentID'
    , o.OptionStyle                                            AS 'Option_Style'
    , o.ContractSize                                           AS 'Option_ContractSize'
    , o.ConversionRatio                                        AS 'Option_ConversionRatio'
    , o.UnderlyingPSPInstrumentID                              AS 'Option_UnderlyingPSPInstrumentID'
    , fut.ContractSymbol                                       AS 'OptionFuture_ContractSymbol'
FROM PSPDW2.PSPDW.cvOptions o
LEFT JOIN PSPDW2.PSPDW.cvFinancialInstrumentIdentifiers fi 
  ON o.PSPInstrumentID= fi.PSPInstrumentID
LEFT JOIN PSPDW2.PSPDW.cvFutures fut 
  ON o.UnderlyingPSPInstrumentID = fut.PSPInstrumentID
WHERE 
    o.UnderlyingPSPInstrumentID is not null