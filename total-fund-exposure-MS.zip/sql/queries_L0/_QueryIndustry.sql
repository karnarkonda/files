SELECT
      PSPIndustryClassificationID
    , SectorName
    , IndustryGroupName
    , IndustryName
    , SubIndustryName
    , ActivityName
    , SubActivityName
    , SegmentName
    , SectorStructure
FROM PSPDW2.PSPDW.cvIndustryClassification_AllLevels