--SELECT
--      Leg.PSPInstrumentID              AS 'Instrument_PSPInstrumentID'
--    , PSPInstrumentLegID               AS 'Leg_PSPInstrumentLegID'
--    , convert(date,Leg.FirstResetDate) AS 'Leg_FirstResetDate'
--    , convert(date,Leg.LastResetDate)  AS 'Leg_LastResetDate'
--    , Leg.LegType                      AS 'Leg_Type'
--    , PSPLegDirection                  AS 'Leg_Direction'
--    , UnderlyingPSPInstrumentID        AS 'Underlying_PSPInstrumentID'
--FROM PSPDW2.PSPDW.cvSwapLegs Leg
--OUTER APPLY(SELECT MIN(ResetDate) FROM PSPDW2.PSPDW.InstrumentResets IR ON IR.PSPInstrumentID = Leg.PSPInstrumentID AND IR.PSPLegDirection = Leg.PSPLegDirection AND isActiveReset = 1
SELECT
      Leg.PSPInstrumentID              AS 'Instrument_PSPInstrumentID'
    , CASE Leg.LegType WHEN 'CreditFee' THEN -1 WHEN 'CreditProtection' THEN 1 ELSE CASE LOWER(Leg.PSPLegDirection) WHEN 'paid' THEN -1 WHEN 'received' THEN 1 ELSE 0 END END AS 'Leg_PSPInstrumentLegID' --Leg.PSPInstrumentLegID		       AS 'Leg_PSPInstrumentLegID'
    , convert(date,IR.FirstResetDate)  AS 'Leg_FirstResetDate'
    , convert(date,CF.LastResetDate)   AS 'Leg_LastResetDate'
    , Leg.LegType                      AS 'Leg_Type'
    , Leg.PSPLegDirection              AS 'Leg_Direction'
    , Leg.UnderlyingPSPInstrumentID    AS 'Underlying_PSPInstrumentID'
FROM PSPDW2.PSPDW.cvSwapLegs Leg
OUTER APPLY(
  SELECT MIN(i.ResetDate)                AS 'FirstResetDate' 
  FROM PSPDW2.PSPDW.InstrumentResets i   
  WHERE i.PSPInstrumentID = Leg.PSPInstrumentID 
  AND i.PSPLegDirection = Leg.PSPLegDirection 
  AND i.isActiveReset = 1 AND i.ResetType = 'Nominal Scaling'
  ) IR
OUTER APPLY(
  SELECT MAX(ic.ResetDate)                AS 'LastResetDate' 
  FROM PSPDW2.PSPDW.InstrumentCashflows ic
  WHERE ic.PSPInstrumentID = Leg.PSPInstrumentID 
  AND ic.PSPLegDirection = Leg.PSPLegDirection AND ic.IsActiveCashflow = 1
  ) CF 