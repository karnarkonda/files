SELECT
      o.PSPInstrumentID                                        AS 'Instrument_PSPInstrumentID'
    , coalesce(fut.UnderlyingPSPID, o.UnderlyingPSPInstrumentID) as 'Underlying_PSPInstrumentID'
    , o.OptionStyle                                            AS 'Option_Style'
FROM [PSPDW2].[PSPDW].[cvPooledFundOTCConstituentOptions] o
LEFT JOIN PSPDW2.PSPDW.cvFinancialInstrumentIdentifiers fi 
  ON o.PSPInstrumentID= fi.PSPInstrumentID
LEFT JOIN PSPDW2.PSPDW.cvFutures fut 
  ON o.UnderlyingPSPInstrumentID = fut.PSPInstrumentID
WHERE 
     o.UnderlyingPSPInstrumentID is not null