SELECT
      PSPInstrumentID                                    AS 'Instrument_PSPInstrumentID'
    , isnull(IndexProxyPSPInstrumentID, PSPInstrumentID) as 'Instrument_IndexProxyPSPInstrumentID'
FROM PSPDW2.PSPDW.PSPIndex
where
        PSPInstrumentID<>0
    AND DateWindowFrom <= __index_date__ 
    AND isnull(DateWindowTo,'2100-01-01') > __index_date__