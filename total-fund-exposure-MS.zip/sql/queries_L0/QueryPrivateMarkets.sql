SELECT 
      W.CalendarDate                                AS 'PositionDate'
    , W.effectiveDate                               AS 'SourceDate'
    , pf.PSPPortfolioCode                           AS 'Portfolio_PSPPortfolioCode'
    , pf.PSPPortfolioID                             AS 'Portfolio_PSPPortfolioID'
    , pf.PortfolioName                              AS 'Portfolio_Name'
    , MarketType                                    AS 'Portfolio_MarketType'
    , AC.AssetClassName                             AS 'Portfolio_AssetClass'
    , pbh.InvestmentTeamName                        AS 'Portfolio_InvestmentTeam'
    , pbh.ManagerType                               AS 'Portfolio_ManagerType'
    , pbh.ManagingStyle                             AS 'Portfolio_ManagingStyle'
    , pbh.ManagingDepartment                        AS 'Portfolio_ManagingDepartment'
    , pbh.OwnerDepartment                           AS 'Portfolio_OwnerDepartment'
    , W.PSPInstrumentID                             AS 'Instrument_PSPInstrumentID'   
    , W.CurrencyCode                                AS 'Instrument_CurrencyCode'
    , 0                                             AS 'Leg_PSPInstrumentLegID'
    , ISNULL(W.Weight*AUM.NetAssetValueInCAD, 0)    AS 'Position_Quantity'
    , ISNULL(W.Weight*AUM.NetAssetValueInCAD, 0)    AS 'Position_NominalAmount'
    , ISNULL(W.Weight*AUM.NetAssetValueInCAD, 0)    AS 'Position_MarketValue_CAD'
    , 0                                             AS 'Position_AccruedInterestValue_CAD'
    , 0                                             AS 'Position_TaxReclaimValue_CAD'
    , ISNULL(W.Weight*AUM.NetAssetValueInCAD, 0)    AS 'Position_NetAssetValue_CAD'
    , ISNULL(W.Weight*AUM.NetAssetValueInCAD, 0)    AS 'Position_ExposureValue_CAD'
    , W.CountryCode                                 AS 'Instrument_RiskLocationCountryCode'
    , W.CountryCode                                 AS 'Instrument_NormalizedCountryCode'
    , W.GeographyName                               AS 'Instrument_GeographyName'
    , W.PSPIndustryClassificationID                 AS 'Instrument_BICSBETAClassificationID'
    , ICAL.SectorCode                               AS 'Instrument_BICSBETASectorCode'
    , ICAL.SectorName                               AS 'Instrument_BICSBETASectorName'
    , ICAL.IndustryGroupCode                        AS 'Instrument_BICSBETAIndustryGroupCode'
    , ICAL.IndustryGroupName                        AS 'Instrument_BICSBETAIndustryGroupName'
    , ICAL.IndustryCode                             AS 'Instrument_BICSBETAIndustryCode'
    , ICAL.IndustryName                             AS 'Instrument_BICSBETAIndustryName'
    , ICAL.SubIndustryCode                          AS 'Instrument_BICSBETASubIndustryCode'
    , ICAL.SubIndustryName                          AS 'Instrument_BICSBETASubIndustryName'
    , ICAL.ActivityCode                             AS 'Instrument_BICSBETAActivityCode'
    , ICAL.ActivityName                             AS 'Instrument_BICSBETAActivityName'
    , ICAL.SubActivityCode                          AS 'Instrument_BICSBETASubActivityCode'
    , ICAL.SubActivityName                          AS 'Instrument_BICSBETASubActivityName'
    , ICAL.SegmentCode                              AS 'Instrument_BICSBETASegmentCode'
    , ICAL.SegmentName                              AS 'Instrument_BICSBETASegmentName'
FROM
    (
        SELECT 
              a.CalendarDate
            , a.effectiveDate
            , b.PSPPortfolioCode
            , ISNULL(b.PSPInstrumentID,0)                       AS 'PSPInstrumentID' 
            , ISNULL(b.CurrencyCode, 'None')                    AS 'CurrencyCode'
            , b.CountryCode
            , NULL                                              AS GeographyName
            , b.PSPIndustryClassificationID
            , convert(float,sum(b.NetAssetValueInCAD)) / nullif(sum(sum(b.NetAssetValueInCAD)) OVER (PARTITION by a.CalendarDate, b.PSPPortfolioCode) ,0) as Weight
            , convert(float,sum(b.NetAssetValueInCAD)) AS NetAssetValueInCAD
        FROM
        (
            SELECT 
                  d.CalendarDate
                , c.PSPPortfolioID
                , MAX(c.effectiveDate) as effectiveDate
            FROM DataAnalyticsDM.Analytics.dimDate d
            inner join PSPDW2.PSPDW.cvPositionExposure c on d.CalendarDate >= c.effectiveDate
            where 
                    d.CalendarDate in (__final_position_dates__) 
                and c.IsActivePSPDW =1
            group by 
                  d.CalendarDate
                , c.PSPPortfolioID
        ) a
        inner join PSPDW2.PSPDW.cvPositionExposure b on a.effectiveDate = b.effectiveDate and b.IsActivePSPDW =1 and a.PSPPortfolioID = b.PSPPortfolioID
        group by 
              a.CalendarDate
            , a.effectiveDate
            , b.PSPPortfolioCode
            , ISNULL(b.PSPInstrumentID,0)
            , ISNULL(b.CurrencyCode, 'None')
            , b.CountryCode
            , b.PSPIndustryClassificationID
    ) W
INNER JOIN
        (
        SELECT 
              ValuationDate
            , PSPPortfolioCode
            , SUM(NetAssetValueInCAD) as NetAssetValueInCAD
        FROM PSPDW2.PSPDW.PositionsPerInstrument P
        where 
                ValuationDate in (__final_position_dates__)
            AND P.DateWindowFrom <= __evaluation_date__
            AND isnull(P.DateWindowTo,'2100-01-01') > __evaluation_date__
        group by 
              ValuationDate
            , PSPPortfolioCode
        ) AUM on W.CalendarDate = AUM.ValuationDate and W.PSPPortfolioCode = AUM.PSPPortfolioCode
LEFT JOIN PSPDW2.PSPDW.cvPortfolio pf on W.PSPPortfolioCode = pf.PSPPortfolioCode
LEFT JOIN PSPDW2.PSPDW.cvPortfoliosBusinessHistory pbh on AUM.ValuationDate >= pbh.EffectiveBusinessDateFrom AND AUM.ValuationDate < isnull(pbh.EffectiveBusinessDateTo, '2199-12-31') AND pf.PSPPortfolioCode = pbh.PSPPortfolioCode
LEFT JOIN PSPDW2.PSPDW.cvAssetClass AC on pbh.PSPAssetClassID = AC.PSPAssetClassID 
LEFT JOIN [PSPDW2].[PSPDW].[IndustryClassification_AllLevels] ICAL ON ICAL.PSPIndustryClassificationID = W.PSPIndustryClassificationID AND ICAL.ClassificationScheme = 'BICSBETA' AND ICAL.DateWindowFrom <= __issuer_date__ AND isnull(ICAL.DateWindowTo,'2100-01-01') > __issuer_date__
where 
        pf.PSPPortfolioCode not like 'HE1013%'
    AND pf.PSPPortfolioCode not like 'PP%[a-zA-Z]' -- temporary fix for GIPP Portfolio