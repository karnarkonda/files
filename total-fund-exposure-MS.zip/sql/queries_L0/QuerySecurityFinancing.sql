SELECT
      PSPInstrumentID           AS 'Instrument_PSPInstrumentID'
    , PSPUnderlyingInstrumentID as 'Underlying_PSPInstrumentID'
FROM PSPDW2.PSPDW.cvSecurityFinancing sf