SELECT
      PSPInstrumentID           AS 'Instrument_PSPInstrumentID'
    , UnderlyingPSPInstrumentID AS 'Underlying_PSPInstrumentID'
FROM [PSPDW2].[PSPDW].[cvPooledFundOTCConstituentForwards]
where 
        UnderlyingPSPInstrumentID is not null