SELECT
      CountryCode
    , rtrim(CountryName) as CountryName
    , FinanceContinentName
FROM DataAnalyticsDM.Analytics.dimCountry
where
        PSPCountryID <> 0