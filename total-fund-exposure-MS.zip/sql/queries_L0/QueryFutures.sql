SELECT
      PSPInstrumentID AS 'Instrument_PSPInstrumentID'
    , UnderlyingPSPID AS 'Underlying_PSPInstrumentID'
    , ValueOfOnePoint AS 'Future_ValueOfOnePoint'
    , IsVariableTick  AS 'Future_IsVariableTick'
    , ContractSize    AS 'Future_ContractSize'
    , TickSize        AS 'Future_TickSize'
    , TickValue       AS 'Future_TickValue'
    , ContractSymbol  AS 'Future_ContractSymbol'
    , UnderlyingPSPID AS 'Future_UnderlyingPSPInstrumentID'
FROM PSPDW2.PSPDW.cvFutures