SELECT
      PSPInstrumentID   AS 'Instrument_PSPInstrumentID'
    , UnderlierPSPID    AS 'Underlying_PSPInstrumentID'
    , UnderlierPSPID    AS 'Forward_PSPInstrumentID'
    , ForwardPrice      AS 'Forward_Price'
FROM PSPDW2.PSPDW.cvForwards