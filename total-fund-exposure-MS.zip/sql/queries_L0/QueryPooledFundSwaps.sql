SELECT
      sl.PSPInstrumentID                                     AS 'Instrument_PSPInstrumentID'
    , COALESCE(F.UnderlyingPSPID, sl.UnderlyingPSPInstrumentID) AS 'Underlying_PSPInstrumentID'
FROM [PSPDW2].[PSPDW].[cvPooledFundOTCConstituentSwapLegs] sl
LEFT JOIN PSPDW2.PSPDW.cvFutures F 
  ON sl.UnderlyingPSPInstrumentID = F.PSPInstrumentID
where 
        sl.LegType = 'TotalReturn' 
    and sl.UnderlyingPSPInstrumentID is not null