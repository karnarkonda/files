SELECT
      BC.EffectiveDate                                       AS 'PositionDate'
    , AC.AssetClassName                                      AS 'AssetClass_Name'
    , ACB.PSPBenchmarkCode                                   AS 'AssetClass_PSPBenchmarkCode'
    , ACB.BenchmarkAssignationDescription                    AS 'AssetClass_BenchmarkAssignationDescription'                           
    , B.BenchmarkName                                        AS 'Benchmark_Name'       
    , B.BenchmarkCurrencyCode                                AS 'Benchmark_CurrencyCode'               
    , BC.PSPInstrumentID                                     AS 'Benchmark_PSPInstrumentID'          
    , BC.Weight                                              AS 'Benchmark_Weight' 
    , ISNULL(I.IndexProxyPSPInstrumentID, I.PSPInstrumentID) AS 'Benchmark_FinalPSPInstrumentID'
FROM [PSPDW2].[PSPDW].[cvAssetClass] AC
INNER JOIN PSPDW2.PSPDW.cvAssetClassBenchmark ACB ON ACB.PSPAssetClassID = AC.PSPAssetClassID
INNER JOIN PSPDW2.PSPDW.cvBenchmark B ON B.PSPBenchmarkCode = ACB.PSPBenchmarkCode
INNER JOIN PSPDW2.PSPDW.cvBenchmarkConstituent BC ON B.PSPBenchmarkCode = BC.PSPBenchmarkCode 
INNER JOIN PSPDW2.PSPDW.cvPSPIndex I ON I.PSPInstrumentID = BC.PSPInstrumentID
WHERE
        BC.EffectiveDate IN (__final_position_dates__)
    AND AC.AssetClassName IN (__psp_asset_class_names__)