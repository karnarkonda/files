SELECT
      PSPInstrumentID           AS 'Instrument_PSPInstrumentID'
    , PSPUnderlyingInstrumentID as 'Underlying_PSPInstrumentID'
    , FundLeverageFactor        AS 'Share_FundLeverageFactor'
    , FundLeverageType          AS 'Share_FundLeverageType'
    , IsFundLeveraged           AS 'Share_FundIsLeveraged'
FROM PSPDW2.PSPDW.cvShares
