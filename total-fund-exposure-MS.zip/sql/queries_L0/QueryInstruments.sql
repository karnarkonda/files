SELECT 
      fii.PSPInstrumentID                               AS 'Instrument_PSPInstrumentID'
    , P.InstrumentFamily                                AS 'Instrument_Family'
    , P.PSPInstrumentCategorizationID                   AS 'Instrument_PSPInstrumentCategorizationID'
    , P.PSPInstrumentCategorizationCode                 AS 'Instrument_PSPInstrumentCategorizationCode'
    , fii.InstrumentDescription                         AS 'Instrument_Description'
    , P.InstrumentMarket                                AS 'Instrument_Market'
    , P.InstrumentType                                  AS 'Instrument_Type'
    , fii.IssuerCode                                    AS 'Instrument_IssuerCode'
    , MAX(SL.PenultimatePaymentDate)                    AS 'Instrument_PenultimatePaymentDate'
    , ISNULL(FIC.CurrencyISOCode, PI.IndexCurrencyCode) AS 'Instrument_CurrencyCode'
FROM [PSPDW2].[PSPDW].cvFinancialInstrumentIdentifiers fii
LEFT JOIN PSPDW2.PSPDW.cvPooledFundOTCConstituent pfc 
  ON fii.PSPInstrumentID = pfc.PSPInstrumentID
INNER JOIN PSPDW2.PSPDW.cvPSPFinancialInstrumentClassification P 
  ON COALESCE(pfc.OriginalPSPInstrumentCategorizationID, fii.PSPInstrumentCategorizationID) = P.PSPInstrumentCategorizationID
LEFT JOIN PSPDW2.PSPDW.cvFinancialInstrumentCategorization FIC ON FIC.PSPInstrumentID = fii.PSPInstrumentID
LEFT JOIN PSPDW2.PSPDW.cvSwapLegs SL 
  ON SL.[PSPInstrumentID] = fii.PSPInstrumentID
LEFT JOIN PSPDW2.PSPDW.cvPSPIndex PI ON PI.PSPInstrumentId = fii.PSPInstrumentID
GROUP BY
      fii.PSPInstrumentID               
    , P.InstrumentFamily                
    , P.PSPInstrumentCategorizationID   
    , P.PSPInstrumentCategorizationCode 
    , fii.InstrumentDescription         
    , P.InstrumentMarket                
    , P.InstrumentType                  
    , fii.IssuerCode   
    , FIC.CurrencyISOCode          
    , PI.IndexCurrencyCode  