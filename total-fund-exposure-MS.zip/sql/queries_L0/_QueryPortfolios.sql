select
      ValuationDate                   AS 'PositionDate'
    , P.PSPPortfolioCode              AS 'Portfolio_PSPPortfolioCode'
    , P.PSPPortfolioID                AS 'Portfolio_PSPPortfolioID'
    , SUM(NetAssetValueInCAD)         AS 'Position_NetAssetValue_CAD'
    , SUM(ExposureValueinCAD)         AS 'Position_ExposureValue_CAD'
FROM PSPDW2.PSPDW.PositionsPerLeg P

CROSS APPLY(SELECT 
where 
        P.ValuationDate in (__position_dates__)
    AND P.DateWindowFrom <= __evaluation_date__
    AND isnull(P.DateWindowTo,'2100-01-01') > __evaluation_date__
    __exclusions_psp_instrument_ids__
    __specific_portfolio_ids__