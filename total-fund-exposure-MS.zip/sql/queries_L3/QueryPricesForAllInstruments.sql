SELECT
      EffectiveDate            AS 'PositionDate'
    , PSPInstrumentID          AS 'Instrument_PSPInstrumentID'
    , MeasureValueCurrencyCode AS 'Price_CurrencyCode'
    , MeasureValue             AS 'Price_Local'
    , MeasureValueinCAD        AS 'Price_CAD'
FROM PSPDW2.PSPDW.cvPricesForAllInstruments_v4
WHERE
        EffectiveDate in (__final_position_dates__)
    AND PSPInstrumentID IN (__price_psp_instrument_ids__)