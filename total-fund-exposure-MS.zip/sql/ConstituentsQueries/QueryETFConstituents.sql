WITH Core as
            (
            SELECT 
                  D.ISODate
                , E.EvaluationDate
                , E.ETFPSPInstrumentID
                , E.PSPInstrumentID
                , E.OpeningWeight
                , E.ClosingWeight
                , E.OpeningWeightWithCash
                , E.ClosingWeightWithCash
                , CreateTimeStamp AS DateWindowFrom
                , LAG(CreateTimeStamp, 1, '2100-01-01') OVER (PARTITION BY D.ISODate, E.EvaluationDate, E.ETFPSPInstrumentID, E.PSPInstrumentID ORDER BY CreateTimeStamp desc) AS DateWindowTo
                , IsActiveETFConstituentEvaluations
                , ROW_NUMBER() OVER (PARTITION BY D.ISODate, E.EvaluationDate, E.ETFPSPInstrumentID, E.PSPInstrumentID ORDER BY CreateTimeStamp desc) as HistoricalRow
                , PriceCurrencyCode
            FROM PSPDW2.PSPDW.DimDate D
            inner join PSPDW2.PSPDW.ETFConstituentEvaluations E on EvaluationDate <= D.ISODate and DATEDIFF(day,EvaluationDate, D.ISODate) < 7
            WHERE 
                    D.ISODate in (__final_position_dates__)
            ),
            ETFs as
            (
            SELECT
                  ISODate
                , EvaluationDate
                , ETFPSPInstrumentID
                , sum(ISNULL(OpeningWeightWithCash,0)) as OpeningWeightWithCash
                , sum(isnull(ClosingWeightWithCash,0)) as ClosingWeightWithCash
                , sum(ISNULL(OpeningWeight,0)) as OpeningWeight
                , sum(isnull(ClosingWeight,0)) as ClosingWeight
                , ROW_NUMBER() over (PARTITION BY ISODate, ETFPSPInstrumentID order by EvaluationDate desc) as rowid
            FROM Core
            WHERE 
                    DateWindowFrom <= __etf_date__ 
                AND DateWindowTo > __etf_date__
                AND case when HistoricalRow = 1 then IsActiveETFConstituentEvaluations else 1 end = 1
            group by
                  ISODate
                , EvaluationDate
                , ETFPSPInstrumentID
            )
SELECT 
      Core.ISODate                                                                                                 AS 'PositionDate'
    , Core.EvaluationDate                                                                                          AS 'SourceDate'
    , Core.ETFPSPInstrumentID                                                                                      AS 'ETF_PSPInstrumentID'
    , Core.PSPInstrumentID                                                                                         AS 'Constituent_PSPInstrumentID'
    , COALESCE(FIC.CurrencyISOCode, Core.PriceCurrencyCode)                                                         AS 'Constituent_CurrencyCode'
    , isnull(case when ETFs.ClosingWeight=0 then Core.OpeningWeightWithCash else Core.ClosingWeightWithCash end,0) AS 'Constituent_WeightWithCash'
    , isnull(case when ETFs.ClosingWeight=0 then Core.OpeningWeight else Core.ClosingWeight end,0)                 AS 'Constituent_Weight'
--ETFs.*,  case when ETFs.ClosingWeight=0 then convert(bit, 0) else convert(bit,1) end as IsClosing
FROM ETFs
inner join Core on ETFs.ISODate = Core.ISODate and ETFs.EvaluationDate = Core.EvaluationDate and ETFs.ETFPSPInstrumentID = Core.ETFPSPInstrumentID
LEFT JOIN PSPDW2.PSPDW.cvFinancialInstrumentCategorization FIC ON FIC.PSPInstrumentID = Core.PSPInstrumentID
where 
        rowid = 1
    and Core.DateWindowFrom <= __etf_date__ 
    AND Core.DateWindowTo > __etf_date__
    AND case when HistoricalRow = 1 then Core.IsActiveETFConstituentEvaluations else 1 end = 1