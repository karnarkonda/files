WITH MaxEffectiveDates AS
	(
  SELECT 
		  C.ISODate 
		, CIC.IndexPSPInstrumentID
		, MAX(EffectiveDate) AS MaxEffectiveDate
	FROM PSPDW2.PSPDW.DimDate C
	INNER JOIN PSPDW2.PSPDW.cvCreditIndexConstituents CIC ON CIC.EffectiveDate BETWEEN DATEADD(MONTH, -6, C.ISODate) AND C.ISODate
	WHERE
			 ISODate IN (__final_position_dates__)
		 --AND CIC.IndexPSPInstrumentID IN (__credit_index_instrument_ids__)
	GROUP BY 
		  C.ISODate
		, CIC.IndexPSPInstrumentID
	)
SELECT
	    MED.ISODate			         AS 'PositionDate'
    , CIC.EffectiveDate        AS 'SourceDate'
    , CIC.IndexPSPInstrumentID AS 'CreditIndex_PSPInstrumentID'
    , CIC.IssuerName           AS 'Constituent_IssuerName'
    , CIC.DebtTierDescription  AS 'Constituent_DebtTierDescription'
    , CIC.PSPIssuerCode        AS 'Constituent_IssuerCode'
    , CIC.IssuerCurrencyCode   AS 'Constituent_CurrencyCode'
    , CIC.IndexWeight          AS 'Constituent_Weight'
FROM MaxEffectiveDates MED
INNER JOIN PSPDW2.PSPDW.cvCreditIndexConstituents CIC ON CIC.IndexPSPInstrumentID = MED.IndexPSPInstrumentID AND CIC.EffectiveDate = MED.MaxEffectiveDate
