WITH MaxEvaluationDates AS
(
  SELECT 
      C.ISODate 
    , ICE.PSPIndexInstrumentID
    , MAX(EvaluationDate) AS MaxEvaluationDate
  FROM PSPDW2.PSPDW.DimDate C
  INNER JOIN PSPDW2.PSPDW.IndexConstituentEvaluations ICE ON ICE.EvaluationDate BETWEEN DATEADD(DAY, -7, C.ISODate) AND C.ISODate
  WHERE
        ISODate IN (__final_position_dates__)
    AND ICE.IsActive = 1
    AND ICE.EvaluationType = 'Closing'
    AND ICE.IndexWeight is not null
  GROUP BY 
      C.ISODate 
    , ICE.PSPIndexInstrumentID
)
SELECT
      CONVERT(date,MED.ISODate)        AS 'PositionDate'
    , CONVERT(date,ICE.EvaluationDate) AS 'SourceDate'
    , ICE.PSPIndexInstrumentID         AS 'Index_PSPInstrumentID'
    , ICE.PSPInstrumentID              AS 'Constituent_PSPInstrumentID'
    , COALESCE(FIC.CurrencyISOCode, ICE.CleanPriceCurrencyCode, ICE.NotionalAmountOutstandingCurrencyCode)              AS 'Constituent_CurrencyCode'
    , ICE.IndexWeight                  AS 'Constituent_Weight'
FROM MaxEvaluationDates MED
INNER JOIN PSPDW2.PSPDW.IndexConstituentEvaluations ICE ON ICE.EvaluationDate = MED.MaxEvaluationDate AND ICE.PSPIndexInstrumentID = MED.PSPIndexInstrumentID
LEFT JOIN PSPDW2.PSPDW.cvFinancialInstrumentCategorization FIC ON FIC.PSPInstrumentID = ICE.PSPInstrumentID
WHERE
        ICE.IsActive = 1
    AND ICE.IsActive = 1
    AND ICE.EvaluationType = 'Closing'
    AND ICE.IndexWeight is not null