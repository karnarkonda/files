WITH MaxEvaluationDate AS
	(
  SELECT 
		  C.ISODate 
		, BCE.BasketPSPInstrumentID
		, MAX(BCE.EvaluationDate) AS MaxEvaluationDate
	FROM PSPDW2.PSPDW.DimDate C
	INNER JOIN PSPDW2.PSPDW.BasketConstituentEvaluations BCE ON BCE.EvaluationDate BETWEEN DATEADD(DAY, -7, C.ISODate) AND C.ISODate
	WHERE
			 ISODate IN (__final_position_dates__)
		AND IsActiveBasketConstituentEvaluations = 1
	GROUP BY 
		  C.ISODate 
		, BCE.BasketPSPInstrumentID
	)
SELECT
	  MED.ISODate               AS 'PositionDate'
	, BCE.EvaluationDate        AS 'SourceDate'
    , BCE.BasketPSPInstrumentID AS 'Basket_PSPInstrumentID'
    , BCE.PSPInstrumentID       AS 'Constituent_PSPInstrumentID'
    , COALESCE(FIC.CurrencyISOCode, BCE.PriceCurrencyCode)  AS 'Constituent_CurrencyCode'
    , BCE.Weight                							AS 'Constituent_Weight'
FROM MaxEvaluationDate MED
INNER JOIN PSPDW2.PSPDW.BasketConstituentEvaluations BCE ON BCE.EvaluationDate = MED.MaxEvaluationDate AND BCE.BasketPSPInstrumentID = MED.BasketPSPInstrumentID
LEFT JOIN PSPDW2.PSPDW.cvFinancialInstrumentCategorization FIC ON FIC.PSPInstrumentID = BCE.PSPInstrumentID
WHERE 
        IsActiveBasketConstituentEvaluations = 1