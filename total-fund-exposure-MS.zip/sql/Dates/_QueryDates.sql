SELECT CalendarDate
FROM DataAnalyticsDM.Analytics.dimDate
where 
        CalendarDate BETWEEN DATEADD(DAY,-14, CONVERT(date,GETDATE())) AND DATEADD(DAY,-1, CONVERT(date,GETDATE()))
    and CalendarDate >='2021-08-31'