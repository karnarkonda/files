SELECT 
      S.PSPInstrumentID
    , ICAL.SectorCode
    , ICAL.SectorName
    , ICAL.IndustryGroupCode
    , ICAL.IndustryGroupName
    , ICAL.IndustryCode
    , ICAL.IndustryName
    , ICAL.SubIndustryCode
    , ICAL.SubIndustryName
FROM PSPDW2.PSPDW.cvShares S
INNER JOIN [PSPDW2].[PSPDW].[cvIndustryClassification_AllLevels] ICAL 
  ON ICAL.SubIndustryCode = S.GICSSubInsdustryCode 
    AND ICAL.ClassificationScheme = 'GICS' 
    AND ICAL.Source = 'Bloomberg'
WHERE 
        S.GICSSubInsdustryCode IS NOT NULL