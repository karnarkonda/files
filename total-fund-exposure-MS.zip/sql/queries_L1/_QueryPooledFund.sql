WITH pooled_fund_constituent_dates( ValuationDate, EvaluationDate, PSPPortfolioID, PSPInstrumentID)
AS  (
    SELECT 
          P.ValuationDate         
        , MAX(PFCE.EvaluationDate)
        , P.PSPPortfolioID        
        , P.PSPInstrumentID       
    FROM PSPDW2.PSPDW.PositionsPerInstrument P
    INNER JOIN PSPDW2.CORE.PooledFundConstituentEvaluations PFCE ON PFCE.FundPSPInstrumentID = P.PSPInstrumentID AND PFCE.IsActivePooledFundConstituentEvaluations = 1 AND PFCE.CreateTimeStamp <= P.ValuationDate
    WHERE
            P.ValuationDate in (__final_position_dates__)
        __pooled_fund_psp_portfolio_ids__
        __pooled_fund_psp_instrument_ids__
    GROUP BY
          P.ValuationDate         
        , P.PSPPortfolioID        
        , P.PSPInstrumentID      
    )
SELECT
      PFCD.ValuationDate                  AS 'PositionDate'
    , PFCD.EvaluationDate                 AS 'PooledFundDate'
    , PFCD.PSPPortfolioID                 AS 'Portfolio_PSPPortfolioID'
    , PFCD.PSPInstrumentID                AS 'Instrument_PSPInstrumentID'
    , b.PSPInstrumentID                   AS 'PooledFund_PSPInstrumentID'
    , b.Quantity                          AS 'PooledFund_Quantity'
    , b.NominalAmount                     AS 'PooledFund_NominalAmount'
    , b.NominalAmountCurrencyCode         AS 'PooledFund_NominalAmountCurrencyCode'
    , b.MarketValue                       AS 'PooledFund_MarketValue'
    , b.MarketValueInCAD                  AS 'PooledFund_MarketValueInCAD'
    , b.MarketValueCurrencyCode           AS 'PooledFund_MarketValueCurrencyCode'
    , b.Price                             AS 'PooledFund_Price'
    , b.PriceCurrencyCode                 AS 'PooledFund_PriceCurrencyCode'
    , b.AccruedInterestAmount             AS 'PooledFund_AccruedInterestAmount'
    , c.PSPLegDirection                   AS 'PooledFund_Leg_Direction'
    , c.NominalAmount                     AS 'PooledFund_Leg_NominalAmount'
    , c.NominalAmountCurrencyCode         AS 'PooledFund_Leg_NominalAmountCurrencyCode'
    , c.LegType                           AS 'PooledFund_Leg_Type'
    , b.CreateTimeStamp                   AS 'CreateTimeStamp'
FROM pooled_fund_constituent_dates PFCD
INNER JOIN PSPDW2.PSPDW.PooledFundConstituentEvaluations b       on PFCD.PSPInstrumentID = b.FundPSPInstrumentID and PFCD.EvaluationDate = b.EvaluationDate and b.IsActivePooledFundConstituentEvaluations=1 AND b.CreateTimeStamp <= PFCD.ValuationDate
LEFT JOIN  PSPDW2.PSPDW.PooledFundConstituentEvaluationsPerLeg c on b.EvaluationDate = c.EvaluationDate and b.FundPSPInstrumentID = c.FundPSPInstrumentID and b.PSPInstrumentID = c.PSPInstrumentID and c.IsActivePSPDW=1 and c.LegType = 'TotalReturn' 