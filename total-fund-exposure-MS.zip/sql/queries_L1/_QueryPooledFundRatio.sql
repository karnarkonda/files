SELECT
      CalendarDate                                                                                                   AS 'PositionDate'
    , P.ValuationDate                                                                                                AS 'PooledFundDate'
    , P.PSPPortfolioID                                                                                               AS 'Portfolio_PSPPortfolioID'
    , c.FundPSPInstrumentID                                                                                          AS 'Instrument_PSPInstrumentID'
    , P.NetAssetValueInCAD                                                                                           AS 'PooledFund_NetAssetValue_CAD'
    , c.MV                                                                                                           AS 'PooledFund_Constituents_MarketValue_CAD'
    , P2.MarketValueInPositionCurrency                                                                               AS 'PooledFund_PositionDate_MarketValue_Local'
    , P.MarketValueInPositionCurrency                                                                                as 'PooledFund_PooledFundDate_MarketValue_Local'
    , P2.NetAssetValueInCAD                                                                                          AS 'PooledFund_PositionDate_NetAssetValue_CAD'
    , P.MarketValueInPositionCurrency                                                                                as 'PooledFund_PooledFundDate_NetAssetValue_CAD'
    , convert(float, P.NetAssetValueInCAD)/c.MV*P2.MarketValueInPositionCurrency/P.MarketValueInPositionCurrency     AS 'PooledFund_MarketValueRatio'
    , convert(float, P.NetAssetValueInCAD)/c.MV*P2.NetAssetValueInPositionCurrency/P.NetAssetValueInPositionCurrency AS 'PooledFund_NetAssetValueRatio'
FROM
(
    SELECT 
          CalendarDate
        , a.valdate
        , a.FundPSPInstrumentID
        , sum(MarketValueInCAD) as MV
    FROM
    (
        SELECT 
              D.CalendarDate
            , FD.FundPSPInstrumentID
            , max(FD.EvaluationDate) as valdate
        FROM DataAnalyticsDM.Analytics.dimDate D
        inner join 
        (
            SELECT 
                  FundPSPInstrumentID
                , EvaluationDate
            FROM PSPDW2.PSPDW.PooledFundConstituentEvaluations
            where
                    CreateTimeStamp <= __pooled_fund_date__
                and IsActivePooledFundConstituentEvaluations=1
               __pooled_fund_psp_instrument_ids__
            group by 
                  FundPSPInstrumentID
                , EvaluationDate
        ) FD on D.CalendarDate >= FD.EvaluationDate
        where 
                D.CalendarDate in (__final_position_dates__)
        group by 
              D.CalendarDate
            , FD.FundPSPInstrumentID
    ) a
    inner join PSPDW2.PSPDW.PooledFundConstituentEvaluations b on a.FundPSPInstrumentID = b.FundPSPInstrumentID and a.valdate = b.EvaluationDate and b.IsActivePooledFundConstituentEvaluations=1
    group by 
          CalendarDate
        ,a.valdate
        ,a.FundPSPInstrumentID
) c
INNER join PSPDW2.PSPDW.PositionsPerInstrument P on c.valdate = P.ValuationDate and P.PSPInstrumentID = c.FundPSPInstrumentID and P.IsActivePSPDW = 1
INNER join PSPDW2.PSPDW.PositionsPerInstrument P2 on c.CalendarDate = P2.ValuationDate and P2.PSPInstrumentID = c.FundPSPInstrumentID and P2.IsActivePSPDW = 1
where 
        P2.MarketValueInPositionCurrency is not null