SELECT 
	 ValuationDate
	,Source
	,PSPPortfolioCode
	,PSPInstrumentCategorizationCode
	,ConstituentPSPInstrumentCategorizationCode
	,Coverage
	,AssetClassName_Grouping
	,SUM(Exposure) AS Exposure
FROM CreditRiskDM.CFRO.Concentration
WHERE ValuationDate IN (__position_dates__)
AND ISNULL(SectorName,'None') NOT IN ('ReversalPSPPortfolioCode','ReversalPSPInstrumentID')
GROUP BY 
	 ValuationDate
	,Source
	,PSPPortfolioCode
	,PSPInstrumentCategorizationCode
	,ConstituentPSPInstrumentCategorizationCode
	,Coverage
	,AssetClassName_Grouping