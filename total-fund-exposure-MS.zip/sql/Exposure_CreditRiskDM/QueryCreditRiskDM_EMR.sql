WITH Exposure_EMR AS(
SELECT
	CASE     
		WHEN CountryName IN ('Canada')                                                              THEN CountryName  
		WHEN CountryName IN ('United-States','United States','United States of America')            THEN 'United States'      
		WHEN CountryRegion IN ('Americas')                                                          THEN 'Central and South America'  
	 -- WHEN [Sub-regionName] in ('Western Asia')                                                   THEN 'Middle East'
		WHEN CountryRegion IS NOT NULL                                                              THEN CountryRegion
		ELSE 'Missing Mapping' END AS EMRGrouping
		,ValuationDate
		,Exposure
		,SectorName
		,CountryName
        ,AssetClassName
	FROM CreditRiskDM.CFRO.Concentration 
	WHERE ValuationDate IN (__position_dates__)
	AND IssuerCode NOT IN (-4, -14)
	AND PSPPortfolioCode <> 'TR01CAP'
	AND ISNULL(SectorName,'None') NOT IN ('ReversalPSPPortfolioCode','ReversalPSPInstrumentID')
	AND Source = 'PSP'
)
SELECT 
	 ValuationDate  as valuation_date
	,SectorName     as sector_name
	,CountryName 	as country_name
	,EMRGrouping 	as region_name
	,AssetClassName	as l5_asset_class_name
	,SUM(Exposure)  AS issuer_exposure
FROM Exposure_EMR
GROUP BY 
	 ValuationDate
	,SectorName
	,CountryName
	,EMRGrouping
	,AssetClassName

