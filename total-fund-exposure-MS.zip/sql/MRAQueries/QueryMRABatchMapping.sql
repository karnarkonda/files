SELECT 
      P.PortfolioKey
    , P.PortfolioID
    , DO.CalendarDate
    , MBD.MostRecent_CalendarKey
    , MBK.MostRecent_Batch_key
FROM DataAnalyticsDM.Core.dimDate DO
INNER JOIN MarketRiskAnalytics.Dimension.Portfolio P ON P.PortfolioID IN (__psp_portfolio_ids__) AND CONVERT(DATE,P.DateWindowFrom) <= DO.CalendarDate AND DO.CalendarDate < CONVERT(DATE,P.DateWindowTo)
CROSS APPLY(SELECT 
                  MAX(PS.CalendarKey) AS 'MostRecent_CalendarKey'
            FROM MarketRiskAnalytics.Dimension.Batch B
            INNER JOIN MarketRiskAnalytics.Fact.PortfolioStats PS ON PS.PortfolioKey = P.PortfolioKey AND PS.BatchKey = B.BatchKey AND PS.CalendarKey BETWEEN DATEADD(MONTH,-1,DO.CalendarDate) AND DO.CalendarDate
            WHERE
                B.IsProd = 'Prod'
            ) MBD
CROSS APPLY(SELECT 
                  MAX(PS.BatchKey) AS 'MostRecent_Batch_key'
            FROM MarketRiskAnalytics.Dimension.Batch B
            INNER JOIN MarketRiskAnalytics.Fact.PortfolioStats PS ON PS.PortfolioKey = P.PortfolioKey AND PS.BatchKey = B.BatchKey AND PS.CalendarKey = MBD.MostRecent_CalendarKey
            WHERE
                B.IsProd = 'Prod'
            ) MBK
WHERE
        DO.CalendarDate IN (__final_position_dates__)
    AND MBD.MostRecent_CalendarKey IS NOT NULL
    AND MBK.MostRecent_Batch_key IS NOT NULL;