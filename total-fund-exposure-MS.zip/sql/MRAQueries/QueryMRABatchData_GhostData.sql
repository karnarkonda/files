WITH portfolio_date_batch (PortfolioKey, PortfolioID, MostRecent_CalendarKey, MostRecent_Batch_key)
        AS  (
            SELECT 
                  P.PortfolioKey
                , P.PortfolioID
                , MBD.MostRecent_CalendarKey
                , MBK.MostRecent_Batch_key
            FROM DataAnalyticsDM.Core.dimDate DO
            INNER JOIN MarketRiskAnalytics.Dimension.Portfolio P ON P.PortfolioID IN (__pooled_fund_ghost_psp_portfolio_ids__) AND CONVERT(DATE,P.DateWindowFrom) <= DO.CalendarDate AND DO.CalendarDate < CONVERT(DATE,P.DateWindowTo)
            CROSS APPLY(SELECT 
                              MAX(PS.CalendarKey) AS 'MostRecent_CalendarKey'
                        FROM MarketRiskAnalytics.Dimension.Batch B
                        INNER JOIN MarketRiskAnalytics.Fact.PortfolioStats PS ON PS.PortfolioKey = P.PortfolioKey AND PS.BatchKey = B.BatchKey AND PS.CalendarKey BETWEEN DATEADD(MONTH,-1,DO.CalendarDate) AND DO.CalendarDate
                        WHERE
                            B.IsProd = 'Prod'
                        ) MBD
            CROSS APPLY(SELECT 
                              MAX(PS.BatchKey) AS 'MostRecent_Batch_key'
                        FROM MarketRiskAnalytics.Dimension.Batch B
                        INNER JOIN MarketRiskAnalytics.Fact.PortfolioStats PS ON PS.PortfolioKey = P.PortfolioKey AND PS.BatchKey = B.BatchKey AND PS.CalendarKey = MBD.MostRecent_CalendarKey
                        WHERE
                            B.IsProd = 'Prod'
                        ) MBK
            WHERE
                  DO.CalendarDate IN (__final_position_dates__)
                AND MBD.MostRecent_CalendarKey IS NOT NULL
                AND MBK.MostRecent_Batch_key IS NOT NULL
            GROUP BY 
                  P.PortfolioKey
                , P.PortfolioID
                , MBD.MostRecent_CalendarKey
                , MBK.MostRecent_Batch_key
            )
SELECT 
      PDB.PortfolioKey
    , PDB.PortfolioID
    , I.InstrumentKey
    , I.InstrumentID                                                                 AS 'Instrument_PSPInstrumentID'
    , I.RiskMetricsPositionType
    , PS.CalendarKey
    , PS.BatchKey
    
    , I.InstrumentFamily                                                             AS 'Instrument_Family'
    , I.InstrumentCategorizationID                                                   AS 'Instrument_PSPInstrumentCategorizationID'
    , ISNULL(I.InstrumentCategorizationCode, I.InstrumentCategorizationCodeRisk)     AS 'Instrument_PSPInstrumentCategorizationCode'
    , I.InstrumentDescription                                                        AS 'Instrument_Description'
    , I.InstrumentMarket                                                             AS 'Instrument_Market'
    , I.InstrumentType                                                               AS 'Instrument_Type'
    , I.IssuerCode                                                                   AS 'Instrument_IssuerCode'
    
    , I.UltimateUnderlyingInstrumentID                                               AS 'UltimateUnderlying_PSPInstrumentID'
    , UUI.InstrumentFamily                                                           AS 'UltimateUnderlying_Family'
    , UUI.InstrumentCategorizationID                                                 AS 'UltimateUnderlying_PSPInstrumentCategorizationID'
    , ISNULL(UUI.InstrumentCategorizationCode, UUI.InstrumentCategorizationCodeRisk) AS 'UltimateUnderlying_PSPInstrumentCategorizationCode'
    , UUI.InstrumentDescription                                                      AS 'UltimateUnderlying_Description'
    , UUI.InstrumentMarket                                                           AS 'UltimateUnderlying_Market'
    , UUI.InstrumentType                                                             AS 'UltimateUnderlying_Type'
    , UUI.IssuerCode                                                                 AS 'UltimateUnderlying_IssuerCode'
    
    --Sector Data
    , UUI.GICSSectorCode
    , UUI.GICSSectorName
    , UUI.GICSIndustryGroupName
    , UUI.GICSIndustryCode
    , UUI.GICSIndustryName
    , UUI.GICSSubIndustryName
    
    --Risk Sector Data
    , UUI.GICSSectorCodeRisk
    , UUI.GICSSectorNameRisk
    , UUI.GICSIndustryGroupNameRisk
    , UUI.GICSIndustryCodeRisk
    , UUI.GICSIndustryNameRisk
    , UUI.GICSSubIndustryNameRisk
    
    --Issuer Data
    , ISSUER.IssuerCode
    , ISSUER.IssuerName
    , ISSUER.IssuerLegalName
    , ISSUER.RiskLocationCountryCode
    , ISSUER.RiskLocationCountryName
    
    --Legal Entity Data
    , LE.LegalEntityID
    , LE.LegalName
FROM portfolio_date_batch PDB
INNER JOIN MarketRiskAnalytics.Fact.PositionStats PS  ON PS.BatchKey = PDB.MostRecent_Batch_key AND PS.PortfolioKey = PDB.PortfolioKey AND PS.CalendarKey = PDB.MostRecent_CalendarKey
INNER JOIN MarketRiskAnalytics.Dimension.Instrument I ON I.InstrumentKey = PS.InstrumentKey
INNER JOIN MarketRiskAnalytics.Dimension.Instrument UUI ON UUI.InstrumentKey = I.UltimateUnderlyingInstrumentKey
LEFT JOIN MarketRiskAnalytics.Dimension.Issuer ISSUER ON ISSUER.IssuerKey = UUI.IssuerKey
LEFT JOIN MarketRiskAnalytics.Dimension.LegalEntity LE ON LE.LegalEntityID = ISSUER.LegalEntityID AND LE.DateWindowFrom <= PS.CalendarKey AND PS.CalendarKey < LE.DateWindowTo
WHERE
      I.InstrumentID < 0;