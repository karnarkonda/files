WITH portfolio_date_batch (PortfolioKey, PortfolioID, MostRecent_CalendarKey, MostRecent_Batch_key)
        AS  (
            SELECT 
                  P.PortfolioKey
                , P.PortfolioID
                , MBD.MostRecent_CalendarKey
                , MBK.MostRecent_Batch_key
            FROM DataAnalyticsDM.Core.dimDate DO
            INNER JOIN MarketRiskAnalytics.Dimension.Portfolio P ON P.PortfolioID IN (__psp_portfolio_ids__) AND CONVERT(DATE,P.DateWindowFrom) <= DO.CalendarDate AND DO.CalendarDate < CONVERT(DATE,P.DateWindowTo)
            CROSS APPLY(SELECT 
                              MAX(PS.CalendarKey) AS 'MostRecent_CalendarKey'
                        FROM MarketRiskAnalytics.Dimension.Batch B
                        INNER JOIN MarketRiskAnalytics.Fact.PortfolioStats PS ON PS.PortfolioKey = P.PortfolioKey AND PS.BatchKey = B.BatchKey AND PS.CalendarKey BETWEEN DATEADD(MONTH,-1,DO.CalendarDate) AND DO.CalendarDate
                        WHERE
                            B.IsProd = 'Prod'
                        ) MBD
            CROSS APPLY(SELECT 
                              MAX(PS.BatchKey) AS 'MostRecent_Batch_key'
                        FROM MarketRiskAnalytics.Dimension.Batch B
                        INNER JOIN MarketRiskAnalytics.Fact.PortfolioStats PS ON PS.PortfolioKey = P.PortfolioKey AND PS.BatchKey = B.BatchKey AND PS.CalendarKey = MBD.MostRecent_CalendarKey
                        WHERE
                            B.IsProd = 'Prod'
                        ) MBK
            WHERE
                  DO.CalendarDate IN (__final_position_dates__)
                AND MBD.MostRecent_CalendarKey IS NOT NULL
                AND MBK.MostRecent_Batch_key IS NOT NULL
            GROUP BY 
                  P.PortfolioKey
                , P.PortfolioID
                , MBD.MostRecent_CalendarKey
                , MBK.MostRecent_Batch_key
            )
SELECT 
      PDB.PortfolioKey
    , PDB.PortfolioID
    , B.BenchmarkKey
    , B.BenchmarkCode
    , I.InstrumentKey
    , I.InstrumentID
    , I.RiskMetricsPositionType
    , I.PrimaryCurrencyName
    , PS.CalendarKey
    , PS.BatchKey
    , PS.Delta
    , PS.Portfolio_NotionalInBaseCurrency
    , PS.Portfolio_CommodityDollarDelta
    , PS.Portfolio_EquityDollarDelta
    , PS.Benchmark_NotionalInBaseCurrency
    , PS.Benchmark_CommodityDollarDelta
    , PS.Benchmark_EquityDollarDelta
FROM portfolio_date_batch PDB
INNER JOIN MarketRiskAnalytics.Fact.PositionStats PS  ON PS.BatchKey = PDB.MostRecent_Batch_key AND PS.PortfolioKey = PDB.PortfolioKey AND PS.CalendarKey = PDB.MostRecent_CalendarKey
INNER JOIN MarketRiskAnalytics.Dimension.Instrument I ON I.InstrumentKey = PS.InstrumentKey
INNER JOIN MarketRiskAnalytics.Dimension.Benchmark B  ON B.BenchmarkKey = PS.BenchmarkKey;