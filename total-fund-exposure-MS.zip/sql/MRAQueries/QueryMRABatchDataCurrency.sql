WITH portfolio_date_batch (PortfolioKey, PortfolioID, MostRecent_CalendarKey, MostRecent_Batch_key)
        AS  (
            SELECT 
                  P.PortfolioKey
                , P.PortfolioID
                , MBD.MostRecent_CalendarKey
                , MBK.MostRecent_Batch_key
            FROM DataAnalyticsDM.Core.dimDate DO
            INNER JOIN MarketRiskAnalytics.Dimension.Portfolio P ON P.PortfolioID IN (__psp_portfolio_ids__) AND CONVERT(DATE,P.DateWindowFrom) <= DO.CalendarDate AND DO.CalendarDate < CONVERT(DATE,P.DateWindowTo)
            CROSS APPLY(SELECT 
                              MAX(PS.CalendarKey) AS 'MostRecent_CalendarKey'
                        FROM MarketRiskAnalytics.Dimension.Batch B
                        INNER JOIN MarketRiskAnalytics.Fact.PortfolioStats PS ON PS.PortfolioKey = P.PortfolioKey AND PS.BatchKey = B.BatchKey AND PS.CalendarKey BETWEEN DATEADD(MONTH,-1,DO.CalendarDate) AND DO.CalendarDate
                        WHERE
                            B.IsProd = 'Prod'
                        ) MBD
            CROSS APPLY(SELECT 
                              MAX(PS.BatchKey) AS 'MostRecent_Batch_key'
                        FROM MarketRiskAnalytics.Dimension.Batch B
                        INNER JOIN MarketRiskAnalytics.Fact.PortfolioStats PS ON PS.PortfolioKey = P.PortfolioKey AND PS.BatchKey = B.BatchKey AND PS.CalendarKey = MBD.MostRecent_CalendarKey
                        WHERE
                            B.IsProd = 'Prod'
                        ) MBK
            WHERE
                  DO.CalendarDate IN (__final_position_dates__)
                AND MBD.MostRecent_CalendarKey IS NOT NULL
                AND MBK.MostRecent_Batch_key IS NOT NULL
            GROUP BY 
                  P.PortfolioKey
                , P.PortfolioID
                , MBD.MostRecent_CalendarKey
                , MBK.MostRecent_Batch_key
            )
SELECT 
      PDB.PortfolioKey
    , PDB.PortfolioID
    , B.BenchmarkKey
    , B.BenchmarkCode
    , I.InstrumentKey
    , I.InstrumentID
    , I.RiskMetricsPositionType
    , PS.CalendarKey
    , PS.BatchKey
    , C.CurrencyKey
    , C.CurrencyCode
    , PS.Portfolio_PresentValue
    , PS.Portfolio_KRD
    , PS.Portfolio_CurrencyDollarDelta
    --, PS.Portfolio_CurrencyDollarGamma
    --, PS.Portfolio_FX_m30prct
    --, PS.Portfolio_FX_m25prct
    --, PS.Portfolio_FX_m20prct
    --, PS.Portfolio_FX_m15prct
    --, PS.Portfolio_FX_m10prct
    --, PS.Portfolio_FX_m5prct
    --, PS.Portfolio_FX_p5prct
    --, PS.Portfolio_FX_p10prct
    --, PS.Portfolio_FX_p15prct
    --, PS.Portfolio_FX_p20prct
    --, PS.Portfolio_FX_p25prct
    --, PS.Portfolio_FX_p30prct
    , PS.Benchmark_PresentValue
    , PS.Benchmark_KRD
    , PS.Benchmark_CurrencyDollarDelta
    --, PS.Benchmark_CurrencyDollarGamma
    --, PS.Benchmark_FX_m30prct
    --, PS.Benchmark_FX_m25prct
    --, PS.Benchmark_FX_m20prct
    --, PS.Benchmark_FX_m15prct
    --, PS.Benchmark_FX_m10prct
    --, PS.Benchmark_FX_m5prct
    --, PS.Benchmark_FX_p5prct
    --, PS.Benchmark_FX_p10prct
    --, PS.Benchmark_FX_p15prct
    --, PS.Benchmark_FX_p20prct
    --, PS.Benchmark_FX_p25prct
    --, PS.Benchmark_FX_p30prct
    --, PS.Active_PresentValue
    --, PS.Active_KRD
    --, PS.Active_CurrencyDollarDelta
    --, PS.Active_CurrencyDollarGamma
    --, PS.Active_FX_m30prct
    --, PS.Active_FX_m25prct
    --, PS.Active_FX_m20prct
    --, PS.Active_FX_m15prct
    --, PS.Active_FX_m10prct
    --, PS.Active_FX_m5prct
    --, PS.Active_FX_p5prct
    --, PS.Active_FX_p10prct
    --, PS.Active_FX_p15prct
    --, PS.Active_FX_p20prct
    --, PS.Active_FX_p25prct
    --, PS.Active_FX_p30prct
FROM portfolio_date_batch PDB
INNER JOIN MarketRiskAnalytics.Fact.PositionStatsByCurrency PS  ON PS.BatchKey = PDB.MostRecent_Batch_key AND PS.PortfolioKey = PDB.PortfolioKey AND PS.CalendarKey = PDB.MostRecent_CalendarKey
INNER JOIN MarketRiskAnalytics.Dimension.Instrument I ON I.InstrumentKey = PS.InstrumentKey
INNER JOIN MarketRiskAnalytics.Dimension.Benchmark B  ON B.BenchmarkKey = PS.BenchmarkKey
INNER JOIN MarketRiskAnalytics.Dimension.Currency C  ON C.CurrencyKey = PS.CurrencyKey;