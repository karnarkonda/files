"""Retroactive Exposure Run Module."""
import logging
import argparse
import json
import os

from app.process_triggers import (trigger_retro_exposure_compute,
                                  trigger_data_migration)

parser = argparse.ArgumentParser()
parser.add_argument("--retro_date", type=str,
                    help="A set of evaluation dates in retrospect")
args = parser.parse_args()


def _read_dates() -> dict:
    retro_dates: dict = {}
    try:
        retro_date_file: str = os.path.join(
            os.path.dirname(__file__), "retro_dates.json"
        )
        retro_dates = json.load(open(retro_date_file))

    except Exception:
        logging.exception("!!Error loading retro-dates")

    return retro_dates


if __name__ == "__main__":
    logging.info(f">>>> PARAMETERS: {args}")
    payload: dict = {}

    try:
        payload = json.loads(args.retro_date)
        logging.info(f"PAYLOAD: {payload}")

    except Exception:
        logging.exception("== Error Parsing cmd args")
        payload = _read_dates()

    try:
        # Step 1
        trigger_retro_exposure_compute(payload)
        # Step 2
        trigger_data_migration()

    except Exception:
        logging.exception("*** Exception thrown during daily benchmarking ***")
