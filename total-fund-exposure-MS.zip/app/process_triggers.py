"""Process triggers Module"""

import logging
from datetime import datetime

from config.general import Config

from .process_marshal import PAMParameter, PAMProcessMarshal
from .services.messaging.msteams import MSTeams


def trigger_exposure_compute():
    """Trigger daily benchmarking process."""
    current_time: str = datetime.now().strftime("%I:%M:%S %p")
    logging.info(f">>>> Starting Daily Run @ {current_time} <<<<<")
    MSTeams().post_info(
        "Daily Exposure Processor", f"Starting Daily Run @ {current_time}"
    )

    # Use default parameter values
    cfg: Config = Config()
    def_params: PAMParameter = PAMParameter()
    marshal: PAMProcessMarshal = PAMProcessMarshal(cfg)
    MSTeams().post_info(
        "Daily Exposure Processor",
        f"""Computing Exposure with Parameters:
                        {def_params.dict()}""",
    )
    marshal.run_exposure_benchmark(**def_params.dict())


def trigger_retro_exposure_compute(retro_dates: dict = {}):
    """Trigger retro execution process."""
    current_time: str = datetime.now().strftime("%I:%M:%S %p")
    logging.info(f">>>> Starting Retro-Execution Run @ {current_time} <<<<<")
    MSTeams().post_warning(
        "Daily Exposure Processor",
        f"Started Historical Exposure Run @ {current_time}",
    )

    # Use default parameter values
    cfg: Config = Config()
    marshal: PAMProcessMarshal = PAMProcessMarshal(cfg)
    MSTeams().post_warning(
        "Daily Exposure Processor",
        f"""Computing Historical Exposure for date(s):
                        {retro_dates}""",
    )
    marshal.retro_run_exposure_benchmark(**retro_dates)


def trigger_data_migration():
    """Migrate staging data to live."""
    current_time: str = datetime.now().strftime("%I:%M:%S %p")
    logging.info(">>>>> Executing Data Migration Stage <<<<<")
    MSTeams().post_info(
        "Daily Exposure Processor",
        f"Executing Data Migration Stage @ {current_time}",
    )

    cfg: Config = Config()
    marshal: PAMProcessMarshal = PAMProcessMarshal(cfg)
    marshal.migrate_data_from_staging()


def trigger_quality_validation():
    """Run MRA Business Validation Rules"""
    current_time: str = datetime.now().strftime("%I:%M:%S %p")
    logging.info(">>>>> Executing Business Rule Validation <<<<<")
    MSTeams().post_info(
        "Daily Exposure Processor",
        f"Executing Business Rule Validation @ {current_time}",
    )

    cfg: Config = Config()
    marshal: PAMProcessMarshal = PAMProcessMarshal(cfg)
    marshal.run_quality_validation()


def trigger_adhoc_executions():
    """Execute Adhoc SP-Executions"""
    current_time: str = datetime.now().strftime("%I:%M:%S %p")
    logging.info(">>>>> Executing Adhoc SP-Executions <<<<<")
    MSTeams().post_info(
        "Daily Exposure Processor",
        f"Executing Adhoc Procedures @ {current_time}",
    )

    cfg: Config = Config()
    marshal: PAMProcessMarshal = PAMProcessMarshal(cfg)
    marshal.run_adhoc_procs()
