"""Application log forwarding module"""

from logging import ERROR, WARN, Handler, LogRecord

from .msteams import MSTeams
from .pager_duty import PagerDuty


class CustomWarnHandler(Handler):
    """Custom Warn-logrecord proxy handler class"""

    _severity_level = WARN
    queue_id = "cwlogque"
    _datastore = None

    def __init__(self):
        """Initialize CustomWarnHandler class."""
        Handler.__init__(self)

    def get_severity_level(self) -> int:
        return self._severity_level

    def emit(self, record: LogRecord) -> None:
        # Dispatch an Alert
        MSTeams().post_log_message(record)


class CustomErrorHandler(Handler):
    """Custom Error-logrecord proxy handler class"""

    _severity_level = ERROR
    queue_id = "celogque"

    def __init__(self):
        """Initialize CustomErrorHandler class."""
        Handler.__init__(self)

    def get_severity_level(self) -> int:
        return self._severity_level

    def emit(self, record: LogRecord) -> None:
        # Notify Pagerduty
        PagerDuty().trigger_incident(
            f"{record.levelname} #{record.created}",
            record.levelname,
            __name__,
            record.message,
            f"{record.levelname}:{record.created}",
        )
