"""Microsoft Teams messaging module"""
import json
from datetime import datetime
from logging import LogRecord
from typing import Dict, List

from adaptivecards.adaptivecard import AdaptiveCard
from adaptivecards.containers import Column, ColumnSet, Fact, FactSet
from adaptivecards.elements import Image, TextBlock
from requests import Response, post


class MSTeams:
    """MsTeams Integration class abstraction"""

    message_pyld = {}
    cfg = None
    info_badge: str = "https://i.ibb.co/dL66PWv/Info.png"
    error_badge: str = "https://i.ibb.co/64hq0Yp/red-error.png"
    warning_badge: str = "https://i.ibb.co/zGMTMH1/Warning.png"
    critical_badge: str = "https://i.ibb.co/64hq0Yp/red-error.png"

    def __init__(self):
        """Initialize message wrapper"""
        from config.general import Config

        self.message_pyld["type"] = "message"
        self.message_pyld["attachments"] = []
        self.cfg = Config()

    # Private functions
    def _get_message_header(self, title: str = "", type: str = "info") -> List:
        body = []
        # Create title
        body.append(
            TextBlock(text=title, size="Medium", weight="Bolder").render()
        )
        # Create header badge by type.
        match type.lower():
            case "info":
                body.append(
                    self._get_header_badge(
                        self.info_badge,
                        "Info. Alert",
                        "accent",
                        "*No follow-up action required.*",
                    )
                )
            case "error":
                body.append(
                    self._get_header_badge(
                        self.error_badge,
                        "Error Alert",
                        "attention",
                        "*Attention required, bring in the firemen.*",
                    )
                )
            case "critical":
                body.append(
                    self._get_header_badge(
                        self.critical_badge,
                        "Critical Error Alert",
                        "attention",
                        "*Now there's trouble, expedite solution.*",
                    )
                )
            case "warning":
                body.append(
                    self._get_header_badge(
                        self.warning_badge,
                        "Warning Alert",
                        "warning",
                        "*Not critical but follow-up recommended.*",
                    )
                )
            case _:
                body.append(
                    self._get_header_badge(
                        self.info_badge,
                        "Info. Alert",
                        "accent",
                        "*No follow-up action required.*",
                    )
                )
        return body

    def _get_header_badge(
        self,
        badge_url: str = "",
        badge_title: str = "",
        color: str = "accent",
        footnote: str = "",
    ) -> Dict:
        # Define badge layout
        return ColumnSet(
            columns=[
                Column(
                    width="auto",
                    items=[Image(size="Medium", url=badge_url).render()],
                ).render(),  # set badge image
                Column(
                    width="stretch",
                    items=[
                        TextBlock(
                            text=badge_title, wrap=True, weight="Bolder"
                        ).render(),
                        TextBlock(
                            text=footnote,
                            wrap=True,
                            spacing="None",
                            color=color,
                        ).render(),
                    ],
                ).render(),  # set badge title & timestamp
            ]
        ).render()

    def _set_message_body(
        self, msg_body: List = [], details: Dict = {}
    ) -> List:
        _env = details.get("_env", "-")
        _date = (
            datetime.now().strftime("")
            if details.get("_date", None) is None
            else details.get("_date", None)
        )
        mssg = details.get("message", "")
        # Set Event info body section
        msg_body.append(
            FactSet(
                spacing="Medium",
                facts=[
                    Fact(title="Date & Time:", value=_date).render(),
                    Fact(title="Environment:", value=_env).render(),
                ],
            ).render()
        )
        # Set event details
        msg_body.append(
            TextBlock(
                weight="Bolder",
                wrap=True,
                spacing="Medium",
                text="Message | Details :",
            ).render()
        )
        msg_body.append(
            TextBlock(
                isSubtle=True, wrap=True, spacing="Small", text=f"*{mssg}*"
            ).render()
        )

        return msg_body

    def _build_message(
        self, title: str = "", type: str = "info", details: Dict = {}
    ) -> None:
        # Build header & detail body
        body_content = self._set_message_body(
            self._get_message_header(title, type), details
        )

        # Create message card
        card = AdaptiveCard()
        card.body = body_content
        self.message_pyld["attachments"] = [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": None,
                "content": card.render(),
            }
        ]

    def _dispatch_alert(self) -> None:
        if self.cfg.MSTEAMS["URL"] is not None:
            headers: dict = {
                "Accept": "application/json",
                "Content-Type": "application/json",
            }

        response: Response = post(
            self.cfg.MSTEAMS["URL"],
            data=json.dumps(self.message_pyld),
            headers=headers,
        )
        return response

    # Public functions
    def post_log_message(self, log: LogRecord):
        if self.cfg.MSTEAMS["ALERTING"]:
            # Build message
            details = {
                "_env": self.cfg.ENV,
                "message": log.getMessage(),
                "_date": datetime.fromtimestamp(log.created).strftime(
                    "%a. %d %b., %Y @ %I.%M%p"
                ),
            }
            self._build_message(
                "Daily Exposure Processor", log.levelname, details
            )
            # dispatch alert.
            self._dispatch_alert()

    def post_info(self, sender_title: str = "None", message: str = "None"):
        if self.cfg.MSTEAMS["ALERTING"]:
            # Build message
            details = {
                "_env": self.cfg.ENV,
                "message": message,
                "_date": datetime.now().strftime("%a. %d, %Y @ %I.%M%p"),
            }
            self._build_message(sender_title, "INFO", details)
            # dispatch alert.
            self._dispatch_alert()

    def post_warning(self, sender_title: str = "None", message: str = "None"):
        if self.cfg.MSTEAMS["ALERTING"]:
            # Build message
            details = {
                "_env": self.cfg.ENV,
                "message": message,
                "_date": datetime.now().strftime("%a. %d, %Y @ %I.%M%p"),
            }
            self._build_message(sender_title, "WARNING", details)
            # dispatch alert.
            self._dispatch_alert()

    def post_error(self, sender_title: str = "None", message: str = "None"):
        if self.cfg.MSTEAMS["ALERTING"]:
            # Build message
            details = {
                "_env": self.cfg.ENV,
                "message": message,
                "_date": datetime.now().strftime("%a. %d, %Y @ %I.%M%p"),
            }
            self._build_message(sender_title, "ERROR", details)
            # dispatch alert.
            self._dispatch_alert()

    def post_critical(self, sender_title: str = "None", message: str = "None"):
        if self.cfg.MSTEAMS["ALERTING"]:
            # Build message
            details = {
                "_env": self.cfg.ENV,
                "message": message,
                "_date": datetime.now().strftime("%a. %d, %Y @ %I.%M%p"),
            }
            self._build_message(sender_title, "CRITICAL", details)
            # dispatch alert.
            self._dispatch_alert()
