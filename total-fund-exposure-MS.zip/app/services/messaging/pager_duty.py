"""Incidents (Team: Total Fund Solutions and Analytics Enablement)
- PagerDuty (https://pspib.pagerduty.com/incidents)

Documentation
- Send an event to PagerDuty
https://developer.pagerduty.com/api-reference/368ae3d938c9e-send-an-event-to-pager-duty

- Supporting your application
https://dev.azure.com/investpsp/Cloud%20Competency%20Center/_wiki/wikis/Cloud-Competency-Center.wiki/189/Supporting-your-application
"""

from enum import Enum

from requests import Response, post


class PagerDuty:
    """API client to create, update, take ownership and close PagerDuty
    incidents.
    """

    class EventAction(Enum):
        """EventAction types in PagerDuty."""

        TRIGGER = "trigger"
        ACKNOWLEDGE = "acknowledge"
        RESOLVE = "resolve"

    url: str
    routing_key: str

    def __init__(self, url: str = None, routing_key: str = None):
        """Initialize class with required PagerDuty configuration."""
        from config.general import Config

        self.url = Config().PAGER_DUTY["URL"] if url is None else url
        self.routing_key = (
            Config().PAGER_DUTY["ROUTING_KEY"]
            if routing_key is None
            else routing_key
        )

    def trigger_incident(
        self,
        incident_title: str,
        severity: str,
        source: str,
        incident_details: str = None,
        dedup_key: str = None,
    ) -> None:
        json: dict = {
            "payload": {
                "summary": incident_title,
                "severity": severity.lower(),
                "source": source,
                "custom_details": incident_details,
            },
            "routing_key": self.routing_key,
            "dedup_key": dedup_key,
            "event_action": self.EventAction.TRIGGER.value,
        }
        self.post_request(json)

    def acknowledge_incident(self, dedup_key: str) -> None:
        json: dict = {
            "routing_key": self.routing_key,
            "dedup_key": dedup_key,
            "event_action": self.EventAction.ACKNOWLEDGE.value,
        }
        self.post_request(json)

    def resolve_incident(self, dedup_key: str) -> None:
        json: dict = {
            "routing_key": self.routing_key,
            "dedup_key": dedup_key,
            "event_action": self.EventAction.RESOLVE.value,
        }
        self.post_request(json)

    def post_request(self, json: dict) -> Response:
        headers: dict = {
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

        response: Response = post(self.url, json=json, headers=headers)

        if not str(response.status_code).startswith("2"):
            raise Exception(response.status_code, response.reason)

        return response
