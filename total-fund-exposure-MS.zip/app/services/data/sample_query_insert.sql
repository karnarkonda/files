INSERT INTO "STAGING_DIM_ISSUER"
    ("Issuer_Code", "Issuer_Name", "Issuer_PSPLegalEntityID", "Issuer_UltimateParentCode", "Issuer_RiskLocationCountryCode", "Issuer_NormalizedCountryCode", "Issuer_BICSBETAClassificationID", "Issuer_BICSBETASectorCode", "Issuer_BICSBETASectorName", "Issuer_BICSBETAIndustryGroupCode", "Issuer_BICSBETAIndustryGroupName", "Issuer_BICSBETAIndustryCode", "Issuer_BICSBETAIndustryName", "Issuer_BICSBETASubIndustryCode", "Issuer_BICSBETASubIndustryName", "Issuer_BICSBETAActivityCode", "Issuer_BICSBETAActivityName", "Issuer_BICSBETASubActivityCode", "Issuer_BICSBETASubActivityName", "Issuer_BICSBETASegmentCode", "Issuer_BICSBETASegmentName", "Issuer_LongTerm_LowestNormalizedRating", "Issuer_LongTerm_HighestNormalizedRating", "Issuer_ShortTerm_LowestNormalizedRating", "Issuer_ShortTerm_HighestNormalizedRating", "Issuer_Name_UltimateParent", "Issuer_UltimateParentPSPLegalEntityID", "Issuer_UltimateParentRiskLocationCountryCode", "Issuer_UltimateParentNormalizedCountryCode", "Issuer_UltimateParentBICSBETAClassificationID", "Issuer_UltimateParentBICSBETASectorCode", "Issuer_UltimateParentBICSBETASectorName", "Issuer_UltimateParentBICSBETAIndustryGroupCode", "Issuer_UltimateParentBICSBETAIndustryGroupName", "Issuer_UltimateParentBICSBETAIndustryCode", "Issuer_UltimateParentBICSBETAIndustryName", "Issuer_UltimateParentBICSBETASubIndustryCode", "Issuer_UltimateParentBICSBETASubIndustryName", "Issuer_UltimateParentBICSBETAActivityCode", "Issuer_UltimateParentBICSBETAIndustryName.1", "Issuer_UltimateParentBICSBETASubActivityCode", "Issuer_UltimateParentBICSBETASubActivityName", "Issuer_UltimateParentBICSBETASegmentCode", "Issuer_UltimateParentBICSBETASegmentName", "Issuer_LongTerm_LowestNormalizedRating_UltimateParent", "Issuer_LongTerm_HighestNormalizedRating_UltimateParent", "Issuer_ShortTerm_LowestNormalizedRating_UltimateParent", "Issuer_ShortTerm_HighestNormalizedRating_UltimateParent", "Issuer_EquityExposureFactor", "Issuer_IssuerExposureFactor", "Issuer_FxExposureFactor", "Issuer_CommodityExposureFactor", "Issuer_FIExposureFactor", "Issuer_CRExposureFactor")
VALUES
    (%
(Issuer_Code)s, %
(Issuer_Name)s, %
(Issuer_PSPLegalEntityID)s, %
(Issuer_UltimateParentCode)s, %
(Issuer_RiskLocationCountryCode)s, %
(Issuer_NormalizedCountryCode)s, %
(Issuer_BICSBETAClassificationID)s, %
(Issuer_BICSBETASectorCode)s, %
(Issuer_BICSBETASectorName)s, %
(Issuer_BICSBETAIndustryGroupCode)s, %
(Issuer_BICSBETAIndustryGroupName)s, %
(Issuer_BICSBETAIndustryCode)s, %
(Issuer_BICSBETAIndustryName)s, %
(Issuer_BICSBETASubIndustryCode)s, %
(Issuer_BICSBETASubIndustryName)s, %
(Issuer_BICSBETAActivityCode)s, %
(Issuer_BICSBETAActivityName)s, %
(Issuer_BICSBETASubActivityCode)s, %
(Issuer_BICSBETASubActivityName)s, %
(Issuer_BICSBETASegmentCode)s, %
(Issuer_BICSBETASegmentName)s, %
(Issuer_LongTerm_LowestNormalizedRating)s, %
(Issuer_LongTerm_HighestNormalizedRating)s, %
(Issuer_ShortTerm_LowestNormalizedRating)s, %
(Issuer_ShortTerm_HighestNormalizedRating)s, %
(Issuer_Name_UltimateParent)s, %
(Issuer_UltimateParentPSPLegalEntityID)s, %
(Issuer_UltimateParentRiskLocationCountryCode)s, %
(Issuer_UltimateParentNormalizedCountryCode)s, %
(Issuer_UltimateParentBICSBETAClassificationID)s, %
(Issuer_UltimateParentBICSBETASectorCode)s, %
(Issuer_UltimateParentBICSBETASectorName)s, %
(Issuer_UltimateParentBICSBETAIndustryGroupCode)s, %
(Issuer_UltimateParentBICSBETAIndustryGroupName)s, %
(Issuer_UltimateParentBICSBETAIndustryCode)s, %
(Issuer_UltimateParentBICSBETAIndustryName)s, %
(Issuer_UltimateParentBICSBETASubIndustryCode)s, %
(Issuer_UltimateParentBICSBETASubIndustryName)s, %
(Issuer_UltimateParentBICSBETAActivityCode)s, %
(Issuer_UltimateParentBICSBETAIndustryName.1)s, %
(Issuer_UltimateParentBICSBETASubActivityCode)s, %
(Issuer_UltimateParentBICSBETASubActivityName)s, %
(Issuer_UltimateParentBICSBETASegmentCode)s, %
(Issuer_UltimateParentBICSBETASegmentName)s, %
(Issuer_LongTerm_LowestNormalizedRating_UltimateParent)s, %
(Issuer_LongTerm_HighestNormalizedRating_UltimateParent)s, %
(Issuer_ShortTerm_LowestNormalizedRating_UltimateParent)s, %
(Issuer_ShortTerm_HighestNormalizedRating_UltimateParent)s, %
(Issuer_EquityExposureFactor)s, %
(Issuer_IssuerExposureFactor)s, %
(Issuer_FxExposureFactor)s, %
(Issuer_CommodityExposureFactor)s, %
(Issuer_FIExposureFactor)s, %
(Issuer_CRExposureFactor)s)