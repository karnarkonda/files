"""Datasource module."""
import datetime
import json
import logging
import os
import time
from itertools import islice

import snowflake.connector as sc
from azure.identity import CertificateCredential
from pandas import DataFrame
from snowflake.connector.connection import SnowflakeConnection
from snowflake.connector.pandas_tools import write_pandas
from snowflake.sqlalchemy import URL
from sqlalchemy import Column, MetaData, String, Table, create_engine, exc
from sqlalchemy.engine import Connection, Engine


class DataSource:
    """Datasource class that abstracts access to multiple datasources."""

    _mappings: dict = {}
    _connection: Connection = None
    _override_creds: dict = None
    _sf_engine: Engine = None
    _direct_sf_conn: SnowflakeConnection = None
    _expiry: datetime = None

    # Constructor
    def __init__(self, cfg, creds: dict = None) -> None:
        """Initialize datasource."""
        self._CONFIG = cfg
        self._override_creds = creds
        self._compose_mappings()
        self._initiate_engine()  # create sqlalchemy engine on init.

    # Private Functions
    def _compose_mappings(self) -> None:
        try:
            map_file: str = os.path.join(
                os.path.dirname(__file__), "mappings.json"
            )
            self._mappings = json.load(open(map_file))

        except Exception:
            logging.exception("!!Error loading datasource mappings")

    def _initiate_engine(self) -> Engine:
        """Initiate a snowflake engine with the appropriate credentials."""
        if not self._sf_engine:
            try:
                creds: dict = self._get_credentials()
                self._sf_engine = create_engine(URL(**creds))

            except exc.SQLAlchemyError:
                logging.exception(
                    ">>> Exception raised in Snowflake connection"
                )

            except Exception:
                logging.exception("!Error getting snowflake engine")

        return self._sf_engine

    def _get_credentials(self) -> dict:
        creds: dict = {
            "account": self._CONFIG.SNOWFLAKE.get("ACCOUNT"),
            "warehouse": self._CONFIG.SNOWFLAKE.get("WAREHOUSE")
            if not self._override_creds
            else self._CONFIG.MRA.get("WAREHOUSE"),
            "database": self._CONFIG.SNOWFLAKE.get("DATABASE")
            if not self._override_creds
            else self._CONFIG.MRA.get("DATABASE"),
            "schema": self._CONFIG.SNOWFLAKE.get("SCHEMA")
            if not self._override_creds
            else self._CONFIG.MRA.get("SCHEMA"),
            "role": self._CONFIG.SNOWFLAKE.get("ROLE"),
        }
        if self._CONFIG.SNOWFLAKE.get("USER", None):
            # Use User cred connect.
            creds["user"] = self._CONFIG.SNOWFLAKE.get("USER")
            creds["authenticator"] = "externalbrowser"

        else:
            # Use token connect.
            creds["token"] = self._get_app_token()
            creds["authenticator"] = "oauth"
        return creds

    def _get_app_token(self) -> str:
        token: str = None
        if self._CONFIG.AZURE["TENANT_ID"] and self._CONFIG.AZURE["CLIENT_ID"]:
            try:
                app: CertificateCredential = CertificateCredential(
                    self._CONFIG.AZURE.get("TENANT_ID"),
                    self._CONFIG.AZURE.get("CLIENT_ID"),
                    self._CONFIG.AZURE.get("CERT_PATH"),
                )

                scope_str: str = (
                    f"api://{self._CONFIG.AZURE.get('APP_ID')}/.default"
                )
                response = app.get_token(scope_str)
                self._expiry = datetime.datetime.fromtimestamp(
                    response.expires_on
                )
                token: str = response.token
            except Exception:
                logging.exception(">>> Error Fetching AppReg Token..<<<")
        return token

    def _is_token_expired(self) -> bool:
        expired: bool = False
        if self._expiry:
            expired = self._expiry < datetime.datetime.now()
        else:
            expired = True
        return expired

    # Public Functions
    def getenv_snowflake_connection(self) -> Connection:
        """Initiate a snowflake connection with the appropriate credentials."""
        if self._is_token_expired():
            try:
                creds: dict = self._get_credentials()
                self._sf_engine: Engine = create_engine(URL(**creds))
                self._connection = self._sf_engine.connect()

            except exc.SQLAlchemyError:
                logging.exception(
                    ">>> Exception raised in Snowflake connection"
                )

            except Exception:
                logging.exception("!Error getting snowflake connection")
        else:
            self._connection = self._sf_engine.connect()

        return self._connection

    def getenv_raw_snowflake_connection(self) -> Connection:
        """
        Initiate a raw snowflake connection with the appropriate
        credentials.
        """
        raw_conn = None
        if self._is_token_expired():
            try:
                creds: dict = self._get_credentials()
                self._sf_engine: Engine = create_engine(URL(**creds))
                raw_conn = self._sf_engine.raw_connection()

            except exc.SQLAlchemyError:
                logging.exception(
                    ">>> Exception raised in Snowflake connection"
                )

            except Exception:
                logging.exception("!Error getting snowflake connection")
        else:
            raw_conn = self._sf_engine.raw_connection()

        return raw_conn

    def close_connection(self) -> None:
        if self._connection:
            self._connection.close()

    # Utility Fuctions

    def get_table_name(self, df_name: str) -> str:
        tbl_name: str = None
        if df_name:
            return self._mappings["entities"].get(df_name, None)
        return tbl_name

    def flush_tables(self, df_name: str) -> bool:
        _status = False

        db_tbl: str = self.get_table_name(df_name)
        if not db_tbl:
            logging.warning(
                f"!! Database table mapping unavailable for {df_name}"
            )
            return None

        try:
            with self.getenv_snowflake_connection() as conn:
                logging.info(f">>>>> FLUSHING {df_name.upper()} TABLE.")
                result = conn.execute(f"DELETE FROM {db_tbl}")
                logging.info(
                    f"Successfully flushed {result.rowcount} row(s) \
    from {db_tbl.upper()} table"
                )

        except Exception:
            logging.exception(f"!Error flushing table {db_tbl.upper()}")

        return _status

    def sql_sanitize(self, df: DataFrame, df_name: str) -> None:
        """Prepare dataframe for sql insert."""
        # Columns
        att_dict = self._mappings["attributes"].get(df_name, {})
        df.columns = [
            x.upper() if not att_dict.get(x, None) else att_dict.get(x)
            for x in df.columns
        ]

        # Convert all data to string
        df_str = df.astype(str)

        # Replace None & nan
        df_final = df_str.replace(
            ["None", "nan", "NONE", "nat", "Nat", "NaN", "NaT", "none"], None
        )

        return df_final

    def set_sql_nulls(self, val):
        val_lst = list(val)
        new_lst = [x if x != "" else None for x in val_lst]
        return tuple(new_lst)

    def execute_table_insert(self, df: DataFrame, tbl_name: str) -> any:
        """Create sqlalchemy table insert statement."""
        chunk_size = 16000
        result = False

        def get_chunks(_iterator, size):
            return iter(lambda: tuple(islice(_iterator, size)), ())

        if not df.empty and tbl_name:
            # define table
            columns = df.columns.tolist()
            meta = MetaData(bind=self._sf_engine)
            tbl = Table(
                tbl_name,
                meta,
                *(
                    Column(col, String(200), nullable=True, default=None)
                    for col in columns
                ),
            )

            # set insert records into chunks.
            records: list = list(
                get_chunks(df.itertuples(index=False, name=None), chunk_size)
            )

            # records: tuple = tuple(get_chunks(df.itertuples(index=False,
            # name=None), chunk_size))

            logging.info(
                f">>> {tbl_name.upper()} Table Insert records chunked:\
                    {len(records)} chunks"
            )

            # insert records into table by chunk/batch.
            try:
                with self._sf_engine.connect() as conn:
                    counter = 0
                    while records:
                        rec_batch = records.pop(0)
                        counter += 1
                        values_lst = [self.set_sql_nulls(x) for x in rec_batch]
                        stmt = tbl.insert().values(tuple(values_lst))

                        tic = time.perf_counter()
                        result = conn.execute(stmt)
                        toc = time.perf_counter()
                        logging.info(
                            f">>> Successfully inserted {result.rowcount}\
                                row(s) in {tbl_name.upper()} in\
                                    {toc - tic:0.4f} seconds"
                        )
                        logging.info(f">>> {counter} chunk(s) inserted.")
                result = True

            except Exception:
                logging.exception(
                    f"!! Error inserting {tbl_name.upper()} records to Db."
                )

            return result

    def load_dataframe(
        self, df_name: str = None, df: DataFrame = None, flush: bool = True
    ) -> bool:
        published = False
        if df_name.upper() == "VALIDATION_NAV":
            return published

        try:
            if df_name and not df.empty:
                # prepare dataframe for sql.
                df_clean = self.sql_sanitize(df, df_name)

                # flush destination tables.
                if flush:
                    self.flush_tables(df_name)

                # execute table inserts.
                tbl_name = self.get_table_name(df_name)

                creds: dict = self._get_credentials()
                with sc.connect(**creds) as conn:
                    tic = time.perf_counter()
                    result = write_pandas(conn, df_clean, tbl_name)
                    toc = time.perf_counter()

                    if result and result[0]:
                        logging.info("=======================================")
                        logging.info(
                            f">>> Loaded {result[2]} row(s)-{tbl_name.upper()}"
                        )
                        logging.info(f">>> TIME: {toc - tic:0.4f} seconds")
                        logging.info("=======================================")

                if result:
                    published = True

        except Exception:
            logging.exception(f"!! Error writing {df_name.upper()} to Db.")

        return published
