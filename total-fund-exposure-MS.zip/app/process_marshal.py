"""ProcessMarshal Module."""
import logging
import sys
from datetime import date

from pydantic import BaseModel

from config.general import Config
from core.position_analytics_machine import positions_analytics_machine
from utils import sql_dictionary, utils

from .exceptions import BenchmarkComputationError
from .services.data.datasources import DataSource


class PAMParameter(BaseModel):
    """API requets payload abstraction."""

    evaluation_date: str | None = date.today().strftime("%Y-%m-%d")
    position_dates: list | None = []
    retro_position_dates: dict | None = {}
    index_date: str | None = None
    etf_date: str | None = None
    issuer_date: str | None = None
    pooled_fund_date: str | None = None
    psp_portfolio_ids: list | None = None
    production_mode: bool = True
    run_unitary_indices: bool = True
    force_refresh: bool = False
    country_to_use: str | None = None
    file_path: str | None = "output/"


class PAMProcessMarshal:
    """Class orchestrator for the exposure computation."""

    def __init__(self, cfg: Config):
        """Initialize Process Marshal."""
        self._pam: positions_analytics_machine = None
        self._config = cfg

    def run_exposure_benchmark(self, **kwargs):
        """Query & Process data from warehouse."""
        try:
            _engines = self._config.get_engines()

            # Initiate
            self._pam = positions_analytics_machine(
                evaluation_date=kwargs.get("evaluation_date", None),
                position_dates=kwargs.get("position_dates", []),
                psp_portfolio_ids=kwargs.get("psp_portfolio_ids", None),
                force_refresh=kwargs.get("force_refresh", False),
                country_to_use=kwargs.get("country_to_use", None),
                run_unitary_indices=kwargs.get("run_unitary_indices", False),
                sql_dictionary=sql_dictionary.sql_dictionary,
                initialized_adaconnect=_engines,
                file_path=kwargs.get("file_path", None),
                production_mode=kwargs.get("production_mode", True),
            )

            # Commence data query & exposure computation
            wh: DataSource = DataSource(self._config)
            self._pam.generate_csv_files(wh)
            wh.close_connection()

        except Exception as _e:
            logging.exception(
                "*** Exception thrown during benchmark endpoint Invocation ***"
            )
            err_info = sys.exc_info()[2]
            raise BenchmarkComputationError(_e, err_info)

    def migrate_data_from_staging(self):
        logging.info(">>>> Moving data to Live tables <<<<<")

        try:
            wh: DataSource = DataSource(self._config)
            with wh.getenv_snowflake_connection() as conn:
                procs: list = wh._mappings.get("migration")
                for proc in procs:
                    logging.info(f"====> EXECUTING STORED PROC: {proc}")
                    result = conn.execute(f"call {proc}()")
                    logging.info(
                        f"RESULT: {result.rowcount} record(s) migrated."
                    )

        except Exception:
            logging.exception(">> Issue raised executing Stored Proc")

    def retro_run_exposure_benchmark(self, **kwargs):
        """Run exposure computation for a specific date in the past."""
        try:
            _engines = self._config.get_engines()
            wh: DataSource = DataSource(self._config)

            retro_dates: dict = kwargs.get("retro_position_dates", {})
            if not retro_dates:
                logging.warning(">>>>>>>>>>> No retro dates provided!")
                return

            for _pstn_dates in retro_dates:
                logging.info(
                    f">> Processing POSITION DATES: {retro_dates[_pstn_dates]}"
                )

                # Initiatlize PAM
                self._pam = positions_analytics_machine(
                    evaluation_date=kwargs.get(
                        "evaluation_date", date.today().strftime("%Y-%m-%d")
                    ),
                    position_dates=retro_dates[_pstn_dates],
                    psp_portfolio_ids=kwargs.get("psp_portfolio_ids", None),
                    force_refresh=kwargs.get("force_refresh", False),
                    country_to_use=kwargs.get("country_to_use", None),
                    sql_dictionary=sql_dictionary.sql_dictionary,
                    initialized_adaconnect=_engines,
                    run_standard=kwargs.get("run_standard", True),
                    run_unitary_indices=kwargs.get(
                        "run_unitary_indices", False
                    ),
                    file_path=kwargs.get("file_path", "output/"),
                    production_mode=False,
                )

                # Commence data query & exposure computation
                self._pam.generate_csv_files(wh)
                self.migrate_data_from_staging()

            wh.close_connection()

        except Exception as _e:
            logging.exception(
                "*** Exception thrown during benchmark endpoint Invocation ***"
            )
            err_info = sys.exc_info()[2]
            raise BenchmarkComputationError(_e, err_info)

    def run_quality_validation(self):
        # Fetch last business date.
        lbd = utils.get_last_businessday()
        rundate = str(lbd.strftime("%Y-%m-%d"))
        # Execute business quality validation.
        logging.info(">>>> Executing Business Validation Rule <<<<<")

        try:
            wh: DataSource = DataSource(self._config)
            conn = wh.getenv_raw_snowflake_connection()
            if conn:
                procs: list = wh._mappings.get("quality")
                for proc in procs:
                    logging.info(
                        f"====> Executing Business Rule: {proc} for \
                                 Value date: {rundate}"
                    )
                    crsr = conn.cursor()
                    crsr.callproc(f"{proc}", [rundate])
                    result = list(crsr.fetchall())
                    crsr.close()
                    logging.info(f"RESULT: {result[0]}")

        except Exception:
            logging.exception(">> Issue raised executing Stored Proc")

    def run_adhoc_procs(self):
        # Fetch last business date.
        lbd = utils.get_last_businessday()
        rundate = str(lbd.strftime("%Y-%m-%d"))
        # Execute business quality validation.
        logging.info(">>>> Executing Adhoc Procedures <<<<<")

        try:
            wh: DataSource = DataSource(self._config)
            conn = wh.getenv_raw_snowflake_connection()
            if conn:
                procs: list = wh._mappings.get("adhoc")
                for proc in procs:
                    logging.info(f"====> Executing Adhoc Procedure: {proc}")
                    crsr = conn.cursor()
                    crsr.callproc(f"{proc['name']}", [rundate]) if proc[
                        "injectDate"
                    ] else crsr.callproc(f"{proc['name']}")
                    result = list(crsr.fetchall())
                    crsr.close()
                    logging.info(f"RESULT: {result[0]}")

        except Exception:
            logging.exception(">> Issue raised executing Stored Proc")
