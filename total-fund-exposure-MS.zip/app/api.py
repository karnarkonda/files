"""RestFul Api module."""
import logging

from fastapi import FastAPI
from fastapi.responses import FileResponse

from config import Config, get_project_root

from .exceptions import BenchmarkComputationError
from .process_marshal import PAMParameter, PAMProcessMarshal

app = FastAPI()
app_config: Config


@app.get("/status")
def get_status():
    """Return PAM status."""
    logging.info("Checked Status")
    return {"status": "Running!"}


@app.get("/readConfig")
def read_config():
    """Return App Config status."""
    return vars(app_config)


@app.get("/readLog")
async def read_logs():
    """Return App Log file content inline"""
    log_path = get_project_root() + "\\logs\\tfe.log"
    return FileResponse(log_path, media_type="text/plain")


@app.get("/getLog")
async def get_logs():
    """Download App Log file"""
    log_path = get_project_root() + "\\logs\\tfe.log"
    return FileResponse(
        log_path, media_type="application/octet-stream", filename="TFE_LOG.log"
    )


@app.post("/execute/")
def execute_exposure_benchmarks(payload: PAMParameter = None):
    """Initiate exposure benchmarking."""
    if payload:
        params: dict = payload.dict()
        logging.debug("Payload Received: %s", params)

        try:
            marshal: PAMProcessMarshal = PAMProcessMarshal(app_config)
            marshal.run_exposure_benchmark(**params)
            return {"message": "Complete!"}

        except BenchmarkComputationError as _e:
            logging.error(_e)
            return {"message": _e.__str__()}

    else:
        return {"message": "Missing required parameters!"}


@app.post("/retro_execute/")
def retro_execute_exposure_benchmarks(payload: PAMParameter = None):
    """Initiate retro exposure computation."""
    if payload:
        params: dict = payload.dict()
        logging.debug("Payload Received: %s", params)

        try:
            marshal: PAMProcessMarshal = PAMProcessMarshal(app_config)
            marshal.retro_run_exposure_benchmark(**params)
            return {"message": "Complete!"}

        except BenchmarkComputationError as _e:
            logging.error(_e)
            return {"message": _e.__str__()}

    else:
        return {"message": "Missing required parameters!"}


@app.post("/migrate")
def migrate_data():
    """Migrate stage data to live tables"""
    try:
        marshal: PAMProcessMarshal = PAMProcessMarshal(app_config)
        marshal.migrate_data_from_staging()
        return {"message": "Complete!"}

    except BenchmarkComputationError as _e:
        logging.error(_e)
        return {"message": _e.__str__()}


def get_api(cfg: Config):
    """Return an instance of FastAPI."""
    global app_config
    app_config = cfg
    return app
