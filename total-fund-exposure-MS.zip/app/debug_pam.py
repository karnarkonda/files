"""Position Analytics Logic debug Module."""
import logging
import os
from getpass import getuser

import pandas as pd
from psp.ada_connect import AdaConnect
from services.data.datasources import DataSource

from config import Config
from core.position_analytics_machine import positions_analytics_machine as pam
from utils import sql_dictionary


def test_run(db_settings_path: str = None):
    """Dummys."""
    initialized_adaconnect: AdaConnect = AdaConnect(
        file=db_settings_path, username=f"{getuser()}@investpsp.ca"
    )

    # Stage 2
    cfg = Config()
    d_src = DataSource(cfg)

    pam_calculator = pam(
        evaluation_date="2023-06-08",
        position_dates=[],
        psp_portfolio_ids=None,
        exclusions_psp_instrument_ids=["138514"],
        force_refresh=False,
        country_to_use=None,
        sql_dictionary=sql_dictionary.sql_dictionary,
        initialized_adaconnect=initialized_adaconnect,
        file_path="output/",
        production_mode=True,
    )

    pam_calculator.generate_csv_files(d_src)

    # Stage 3
    # pam_calculator.generate_exposure_v1()


def test_datasource_flow():
    cfg = Config()
    src = DataSource(cfg)
    tbls = [
        "dim_issuers",
    ]

    for csv_fl in tbls:
        try:
            df = pd.read_csv(
                f"./output/20230712_145903__2023-07-12__2023-03-31_\
                2023-04-30_2023-05-31_2023-06-30_2023-07-07/{csv_fl}.csv",
                sep=";",
            )

            src.load_dataframe(csv_fl, df)

        except Exception as err:
            logging.exception(err)


def test_table_flush():
    cfg = Config()
    src = DataSource(cfg)
    tbls = [
        "dim_countries",
        "dim_gics",
        "dim_issuers",
        "dim_portfolios",
        "fact_all_constituents",
        "fact_exposure",
        "fact_portfolios",
    ]
    # tbls = ["dim_issuers"]

    try:
        for tbl in tbls:
            src.flush_tables(tbl)

    except Exception:
        logging.exception("!Error")


if __name__ == "__main__":
    root = os.path.abspath(os.curdir)
    db_settings_path: str = os.path.join(root + "\config\conn_props.json")
    # Run tests
    # test_run(db_settings_path)
    # test_table_flush()
    test_datasource_flow()
