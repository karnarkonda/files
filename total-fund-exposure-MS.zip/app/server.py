"""Server Module."""
import atexit
import os

from config import Config

from .api import get_api


class Server:
    """Server Context Abstraction."""

    def __init__(self):
        """Initialize instance variables."""
        self._api = None

    def start(self, cfg: Config):
        """Get an instance of the FastAPI asgi app"""
        self._api = get_api(cfg)
        return self._api


def on_app_exit():
    """Clean up resources after server shuts down."""
    print("Application shutdown complete!")


# Commence Server start-up flow.
config = Config()

server = Server()

api = server.start(config)

atexit.register(on_app_exit)

mode: bool = bool(os.environ.get("VSCODE_DEBUG_MODE", None))


if config.DEBUG:
    print(
        f"\n \033[1;33m >>>>>> DEBUG MODE: {config.ENV} config <<<< \n",
    )
elif mode:
    print(
        f"\n \033[1;33m >>>>>> DEVELOPMENT MODE: {config.ENV} config <<<< \n",
    )
else:
    print(
        f"\n \033[1;31m >>>>>> PRODUCTION MODE : {config.ENV} config <<<< \n"
    )
