"""Application Configuration Module."""

import logging
import os
import queue
from logging.handlers import QueueHandler, QueueListener

from dotenv import load_dotenv
from psp.ada_connect import AdaConnect

from app.services.data.datasources import DataSource
from app.services.messaging import CustomErrorHandler, CustomWarnHandler


def get_project_root():
    """Fetch project root value."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Config:
    """Application configuration class."""

    log_hndlers: list = []
    _init_singleton: bool = False
    _self = None

    def __new__(cls):
        if cls._self is None:
            cls._self = super().__new__(cls)
        return cls._self

    def __init__(self, int_log: bool = True):
        """Initialize config instance."""
        # Check if singleton object exists.
        if self._init_singleton:
            return

        self._setup_app_logging(int_log)

        try:
            default_env = os.environ.get("ENV", os.getenv("ENV", "dev"))

            if default_env != "":
                load_dotenv("config/.env.tfe-" + str.lower(default_env))

            self.TESTING = False

            # environment
            self.APP_NAME = os.getenv("APP_NAME", "total_fund_exposure_ms")
            self.ENV = os.getenv("ENV", "dev")
            self.DEBUG = os.getenv("DEBUG", "1") == "1"

            # App configuration
            self.HOST = os.getenv("HOST", "0.0.0.0")
            self.PORT = int(os.getenv("PORT", "8080"))
            self.USERNAME = os.getenv("USER", os.getlogin() + "@investpsp.ca")
            self.CONNECTION_FILE_PATH = os.getenv("CONNECTION_FILE_PATH", "")

            # Azure AppReg Settings
            path = os.getenv("AZURE_CERTIFICATE_PATH", None)
            if path:
                path = os.path.join(os.getcwd(), "config", path)
            self.AZURE: dict = {
                "TENANT_ID": os.getenv("AZURE_TENANT_ID", None),
                "CLIENT_ID": os.getenv("AZURE_CLIENT_ID", None),
                "APP_ID": os.getenv("SCOPE_APP_ID", None),
                "CERT_PATH": path,
            }

            # Set Log level
            self.LOG_LEVEL = os.getenv("LOG_LEVEL", "debug")
            logger = logging.getLogger()
            match str(self.LOG_LEVEL).upper():
                case "DEBUG":
                    logger.setLevel(logging.DEBUG)
                case "WARNING":
                    logger.setLevel(logging.WARNING)
                case "ERROR":
                    logger.setLevel(logging.ERROR)
                case "CRITICAL":
                    logger.setLevel(logging.CRITICAL)
                case _:
                    logger.setLevel(logging.INFO)

            # Snowflake configs
            self.SNOWFLAKE: dict = {
                "ACCOUNT": os.getenv("SNOWFLAKE_ACCOUNT", None),
                "USER": os.getenv("SNOWFLAKE_USER", None),
                "WAREHOUSE": os.getenv("SNOWFLAKE_WAREHOUSE", None),
                "DATABASE": os.getenv("SNOWFLAKE_DATABASE", None),
                "SCHEMA": os.getenv("SNOWFLAKE_SCHEMA", None),
                "ROLE": os.getenv("SNOWFLAKE_ROLE", None),
            }

            # MRA configs
            self.MRA: dict = {
                "WAREHOUSE": os.getenv("MRA_WAREHOUSE", None),
                "DATABASE": os.getenv("MRA_DATABASE", None),
                "SCHEMA": os.getenv("MRA_SCHEMA", None),
            }

            # PagerDuty
            self.PAGER_DUTY: dict = {
                "URL": os.getenv("URL", None),
                "ROUTING_KEY": os.getenv("ROUTING_KEY", None),
            }

            # Alerting switch
            self.MSTEAMS: dict = {
                "ALERTING": os.getenv("ENABLE_ALERTS", False),
                "URL": os.getenv("MS_CHANNEL_WEBHOOK", None)
            }

            self._init_singleton = True
            logging.info(f"TFE Configuration Complete! - {self.ENV}")

        except OSError as _e:
            logging.exception(
                f"Unable to load environment variables : {_e.strerror}"
            )

    def get_engines(self):
        """Initilize an Adaconnect Connection-like object."""
        adapted_ada: dict = {}
        ada_inst: AdaConnect = AdaConnect(
            file=get_project_root() + self.CONNECTION_FILE_PATH,
            username=self.USERNAME,
        )
        adapted_ada["sqlserver"] = ada_inst.get("sqlserver")
        adapted_ada["mraserver"] = ada_inst.get("mraserver")

        if self.ENV != "dev":
            # provide a service principal connection for snowflake.
            sp_snow = DataSource(self, self.MRA)

            # make anonymous wrapper object.
            def snowflaker(**kwargs):
                return type("snowflaker", (), kwargs)

            adapted_ada["snowflake"] = snowflaker(
                connection=sp_snow.getenv_snowflake_connection()
            )

        else:
            adapted_ada["snowflake"] = ada_inst.get("snowflake")

        return adapted_ada

    def _setup_app_logging(self, log_switch: bool):
        # Setup Logger
        logging.basicConfig(
            level=logging.INFO,
            filename="logs\\tfe.log",
            format="%(asctime)s [%(levelname)s] - %(message)s",
            datefmt="%b %d,%Y | %I:%M:%S %p |",
        )
        logging.captureWarnings(True)

        if log_switch:
            logger = logging.getLogger()

            # Setup message queues for custom handlers.

            # Warn
            dblog_que = queue.Queue(-1)
            dblog_hndlr = CustomWarnHandler()

            q_hndlr = QueueHandler(dblog_que)
            q_hndlr.setLevel(dblog_hndlr.get_severity_level())
            dblog_lstnr = QueueListener(dblog_que, dblog_hndlr)

            logger.addHandler(q_hndlr)
            dblog_lstnr.start()
            self.log_hndlers.append(dblog_lstnr)

            # Error
            pd_que = queue.Queue(-1)
            pd_hndlr = CustomErrorHandler()

            q_hndlr_2 = QueueHandler(pd_que)
            q_hndlr_2.setLevel(pd_hndlr.get_severity_level())
            pd_lstnr = QueueListener(pd_que, pd_hndlr)

            logger.addHandler(q_hndlr_2)
            pd_lstnr.start()
            self.log_hndlers.append(pd_lstnr)
