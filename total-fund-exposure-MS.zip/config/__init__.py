"""Configuration Package."""
from .general import Config, get_project_root

__all__ = [Config, get_project_root]
