import pandas as pd
from typing import List
import os
from constants import position_analytics_constants as PAC
from utils import data_acquisition
from utils.sql_dictionary import sql_dictionary
from app.services.data.datasources import DataSource
import numpy as np
import logging

from datetime import datetime, timedelta
import csv
level_tracker = 0

### Index
    ### 0 Auxiliary functions
        ### A show_duplicate_df
        ### B function_compare
        ### C function_bond_future_price
        ### D function_check_first_reset_date
        ### E function_check_last_reset_date
        ### F track_execution
        
    ### 1 Main Class
    ### 2 Acquisition Functions
    ### 3 Class Initialisation
    ### 4 Positions Facts
    ### 5 Exposure Calculations
    ### 6 Exposure Structure Output

####################################################################################################
### 0 Auxiliary functions ##########################################################################
####################################################################################################

def flag_non_significant_error(  absolute_error
                               , relative_error
                               , min_absolute_error
                               , min_relative_error
                              ):
    if abs(absolute_error) >= min_absolute_error and abs(relative_error) >= min_relative_error:
        return 0
    else:
        return 1

def adjusted_absolute_error(old_value, new_value):
    #Si old_value est un nan
    if old_value != old_value:
        #Si new_value est un nan, on renvoit 0 car il n'y a pas de difference
        if new_value != new_value:
            return 0
        #Si new_value n'est pas un nan, renvoie new_value, comme si old_value serait 0
        else:
            return new_value
    #Si old_value n'est pas un nan
    else:
        #Si new_value est un nan, on renvoit -old_value, comme si new_value serait 0 
        if new_value != new_value:
            return -1.0 * old_value
        #Si new_value est egale a old_value, on renvoit 0 afin de repliquer la structure de la fonction adjusted_relative_error
        elif new_value == old_value:
            return 0
        #Si old_value == 0 != new_value, on renvoit new value afin de repliquer la structure de la fonction adjusted_relative_error
        elif old_value == 0:
            return new_value
        #Sinon, on renvoit l'erreur absolue standard
        else: 
            return new_value - old_value
    
def adjusted_relative_error(old_value, new_value):
    #Si old_value est un nan
    if old_value != old_value:
        #Si new_value est un nan, on renvoit 0 car il n'y a pas de difference
        if new_value != new_value:
            return 0
        #Si new_value n'est pas un nan, renvoie inf, comme si old_value serait 0
        else: 
            return float('inf')
    #Si old_value n'est pas un nan
    else:
        #Si new_value est un nan, on renvoit -100%, comme si new_value serait 0 
        if new_value != new_value:
            return -1
        #Si new_value est egale a old_value, on renvoit 0 afin de traiter adequatement les cas ou old_value = new_value = 0
        elif new_value == old_value:
            return 0
        #Si old_value = 0 != new_value, on renvoit l'infini
        elif old_value == 0:
            return float('inf')
        #Sinon, on renvoit l'erreur relative standard
        else: 
            return new_value / old_value - 1.0   

def show_duplicate_df(df, columns):
    return df[df.duplicated(subset = columns, keep = False)].sort_values(by = columns)

def function_compare( x, y):
    if x == y:
        return 1
    else:
        return y/x

def function_bond_future_price(  data_vector):
    contract_symbol       = data_vector.iloc[0]
    measure_value_local   = data_vector.iloc[1]
    measure_value_CAD     = data_vector.iloc[2]
    future_contract_size  = data_vector.iloc[3]
    fx_rates_local_to_CAD = data_vector.iloc[4]
    
    if contract_symbol == 'XM':
        return round((600*(1-((1/(1+(100-measure_value_local)/200))**20))/(100-measure_value_local)+100*((1/(1+(100-measure_value_local)/200))**20))*1000,1) * fx_rates_local_to_CAD
    
    if contract_symbol == 'YM':
        return round((600*(1-((1/(1+(100-measure_value_local)/200))**6))/(100-measure_value_local)+100*((1/(1+(100-measure_value_local)/200))**6))*1000,2) * fx_rates_local_to_CAD
    
    else:
        return future_contract_size * measure_value_CAD /100

def function_check_first_reset_date( data_vector):
    try:
        position_date    = datetime.strptime(str(data_vector.iloc[0])[:10], '%Y-%m-%d')
        first_reset_date = datetime.strptime(str(data_vector.iloc[1]), '%Y-%m-%d')
        if (position_date - first_reset_date).days >=0:
            return 1
        else:
            return 0
    except Exception as error:
        return 0

def function_check_last_reset_date( data_vector):
    try:
        position_date    = datetime.strptime(str(data_vector.iloc[0])[:10], '%Y-%m-%d')
        last_reset_date  = datetime.strptime(str(data_vector.iloc[1]), '%Y-%m-%d')
        if (last_reset_date - position_date).days > 0:
            return 1
        else:
            return 0
    except Exception as error:
        return 0

def track_execution(function):
    def inner(*args, **kwargs):
        global level_tracker
        start_time = datetime.now()
        print('  '*level_tracker, '-')
        print('  '*level_tracker, '|', '### START ##########################################################################')
        print('  '*level_tracker, '|', 'Executing ' + function.__name__, ', started at ' + start_time.strftime('%H:%M:%S'))
        level_tracker = level_tracker + 1
        function_result = function(*args, **kwargs)
        level_tracker = level_tracker - 1
        end_time = datetime.now()
        print('  '*level_tracker, '|', 'Done', ', finished at ' + end_time.strftime('%H:%M:%S'), ', done in ' +str(end_time-start_time))
        print('  '*level_tracker, '|', '### END   ##########################################################################')
        print('  '*level_tracker, '-')
        return function_result
    return inner
  

####################################################################################################
### 1 Main Class ###################################################################################
####################################################################################################
class positions_analytics_machine:
    
    ####################################################################################################
    ### 2 Acquisition Functions ########################################################################
    ####################################################################################################
    
    #@#track_execution
    def unique_benchmarks(self):
        if self._unique_benchmarks is None:
            if self.verbose == True:
               logging.info('Acquiring unique_benchmarks_snowflake data...')
            self._unique_benchmarks = data_acquisition.function_get_sql_data('unique_benchmarks_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._unique_benchmarks

    #@#track_execution
    def gics(self):
        if self._gics is None:
            if self.verbose == True:
               logging.info('Acquiring gics data...')
            self._gics = data_acquisition.function_get_sql_data('gics', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._gics
    
    #@#track_execution
    def portfolios(self):
        if self._portfolios is None:
            if self.verbose == True:
               logging.info('Acquiring portfolios data...')
            self.psp_portfolio_ids()
            #self._portfolios = data_acquisition.function_get_sql_data('portfolios', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
            self._portfolios = data_acquisition.function_get_sql_data('portfolios_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._portfolios
    
    #@#track_execution
    def positions(self):
        if self._positions is None:
            if self.verbose == True:
               logging.info('Acquiring positions data...')
            self._positions = data_acquisition.function_get_sql_data('positions_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._positions
    
    #@#track_execution
    def private_markets(self):
        if self._private_markets is None:
            if self.verbose == True:
               logging.info('Acquiring private_markets data...')
            self.final_position_dates()
            self._private_markets = data_acquisition.function_get_sql_data('private_markets_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._private_markets
    
    #@#track_execution
    def instruments(self):
        if self._instruments is None:
            if self.verbose == True:
               logging.info('Acquiring instruments data...')
            self._instruments = data_acquisition.function_get_sql_data('instruments_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._instruments
    
    def swap_legs(self):
        if self._swap_legs is None:
            if self.verbose == True:
               logging.info('Acquiring swap_legs data...')
            self._swap_legs = data_acquisition.function_get_sql_data('swap_legs_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._swap_legs
    
    '''
    # queries for on prem services
    #@#track_execution
    def options(self):
        if self._options is None:
            if self.verbose == True:
               logging.info('Acquiring options data...')
            self._options = data_acquisition.function_get_sql_data('options', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._options    
    
    #@#track_execution
    def futures(self):
        if self._futures is None:
            if self.verbose == True:
               logging.info('Acquiring futures data...')
            self._futures = data_acquisition.function_get_sql_data('futures', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._futures    
    
    #@#track_execution
    def forwards(self):
        if self._forwards is None:
            if self.verbose == True:
               logging.info('Acquiring forwards data...')
            self._forwards = data_acquisition.function_get_sql_data('forwards', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._forwards   
    
    #@#track_execution
    def security_financing(self):
        if self._security_financing is None:
            if self.verbose == True:
               logging.info('Acquiring security_financing data...')
            self._security_financing = data_acquisition.function_get_sql_data('security_financing', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._security_financing   
    
    #@#track_execution
    def swap_legs(self):
        if self._swap_legs is None:
            if self.verbose == True:
               logging.info('Acquiring swap_legs data...')
            self._swap_legs = data_acquisition.function_get_sql_data('swap_legs', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._swap_legs
       
    #@#track_execution
    def index(self):
        if self._index is None:
            if self.verbose == True:
               logging.info('Acquiring index data...')
            self._index = data_acquisition.function_get_sql_data('index', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._index
    
    #@#track_execution
    def shares(self):
        if self._shares is None:
            if self.verbose == True:
               logging.info('Acquiring shares data...')
            self._shares = data_acquisition.function_get_sql_data('shares', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._shares
    
    #@#track_execution
    def pooled_funds_options(self):
        if self._pooled_funds_options is None:
            if self.verbose == True:
               logging.info('Acquiring pooled_funds_options data...')
            self._pooled_funds_options = data_acquisition.function_get_sql_data('pooled_funds_options', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._pooled_funds_options
    
    #@#track_execution
    def pooled_funds_forwards(self):
        if self._pooled_funds_forwards is None:
            if self.verbose == True:
               logging.info('Acquiring pooled_funds_forwards data...')
            self._pooled_funds_forwards = data_acquisition.function_get_sql_data('pooled_funds_forwards', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._pooled_funds_forwards
    
    #@#track_execution
    def pooled_funds_swaps(self):
        if self._pooled_funds_swaps is None:
            if self.verbose == True:
               logging.info('Acquiring pooled_funds_swaps data...')
            self._pooled_funds_swaps = data_acquisition.function_get_sql_data('pooled_funds_swaps', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._pooled_funds_swaps
    
    #@#track_execution
    def pooled_funds_credit_derivatives(self):
        if self._pooled_funds_credit_derivatives is None:
            if self.verbose == True:
               logging.info('Acquiring pooled_funds_credit_derivatives data...')
            self._pooled_funds_credit_derivatives = data_acquisition.function_get_sql_data('pooled_funds_credit_derivatives', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._pooled_funds_credit_derivatives
    
    #@#track_execution
    def pooled_funds(self):
        if self._pooled_funds is None:
            if self.verbose == True:
               logging.info('Acquiring pooled_funds data...')
            self.pooled_fund_psp_portfolio_ids()
            self.final_position_dates()
            self._pooled_funds = data_acquisition.function_get_sql_data('pooled_funds', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._pooled_funds
    
    #@#track_execution
    def pooled_funds_ratio(self):
        if self._pooled_funds_ratio is None:
            if self.verbose == True:
               logging.info('Acquiring pooled_funds_ratio data...')
            self.pooled_fund_psp_instrument_ids()
            self.final_position_dates()
            self._pooled_funds_ratio = data_acquisition.function_get_sql_data('pooled_funds_ratio', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._pooled_funds_ratio
    '''
    #Query to extract all index constituents
    #@#track_execution
    def index_constituents(self):
        if self._index_constituents is None:
            if self.verbose == True:
               logging.info('Acquiring index_constituents data...')
            self.final_position_dates()
            self._index_constituents = data_acquisition.function_get_sql_data('index_constituents', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._index_constituents
    
    #Query to extract all basket constituents
    #@#track_execution
    def basket_constituents(self):
        if self._basket_constituents is None:
            if self.verbose == True:
               logging.info('Acquiring basket_constituents data...')
            self.final_position_dates()
            self._basket_constituents = data_acquisition.function_get_sql_data('basket_constituents', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._basket_constituents
    
    #Query to extract all index constituents
    #@#track_execution
    def etf_constituents(self):
        if self._etf_constituents is None:
            if self.verbose == True:
               logging.info('Acquiring etf_constituents data...')
            self.final_position_dates()
            self._etf_constituents = data_acquisition.function_get_sql_data('etf_constituents', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._etf_constituents
    
    
    #@#track_execution
    def fx_rates(self):
        if self._fx_rates is None:
            if self.verbose == True:
               logging.info('Acquiring fx_rates data...')
            self.final_position_dates()
            self._fx_rates = data_acquisition.function_get_sql_data('fx_rates_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
            #the inverse is computed in python as in snowflake, it only keeps 6 decimals
            self._fx_rates['Position_FXRates_CurrencyCode_to_CAD'] = 1/self._fx_rates['Position_FXRates_CurrencyCode_to_CAD']
        return self._fx_rates

    #@#track_execution
    def prices(self):
        if self._prices is None:
            if self.verbose == True:
               logging.info('Acquiring prices data...')
            self.final_position_dates()
            self.price_psp_instrument_ids()
            self._prices = data_acquisition.function_get_sql_data('prices_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._prices
    
    #@#track_execution
    def benchmarks(self):
        if self._benchmarks is None:
            if self.verbose == True:
               logging.info('Acquiring benchmarks data...')
            self.psp_asset_class_names()
            self.final_position_dates()
            self._benchmarks = data_acquisition.function_get_sql_data('benchmarks_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._benchmarks

    #Query to extract all index constituents
    #@#track_execution
    def credit_constituents(self):
        if self._credit_constituents is None:
            if self.verbose == True:
               logging.info('Acquiring credit_constituents data...')
            self.final_position_dates()
            #self.credit_index_instrument_ids()
            self._credit_constituents = data_acquisition.function_get_sql_data('credit_constituents_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._credit_constituents
    

    #Query to extract all etf, basket & index constituents from snowflake
    #@#track_execution
    def constituents(self):
        if self._constituents is None:
            if self.verbose == True:
               logging.info('Acquiring constituents data...')
            self.final_position_dates()
            self._constituents = data_acquisition.function_get_sql_data('constituents', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._constituents
    
    #Query to extract all mra batch mapping
    #@#track_execution
    def mra_batch_mapping(self):
        if self._mra_batch_mapping is None:
            if self.verbose == True:
               logging.info('Acquiring mra_batch_mapping_snowflake data...')
            self.final_position_dates()
            self.psp_portfolio_ids()
            self._mra_batch_mapping = data_acquisition.function_get_sql_data(  'mra_batch_mapping_snowflake'
                                                                             , self.sql_dictionary, self.initialized_adaconnect
                                                                             , self.parameters, force_refresh = self.force_refresh).rename(columns = {  'PortfolioKey':'Portfolio_Key'
                                                                                                                  , 'InstrumentKey':'Instrument_Key'
                                                                                                                 }
                                                                                                      )
            
        return self._mra_batch_mapping
    
    #Query to extract all mra batch data
    #@#track_execution
    def mra_batch_data(self):
        if self._mra_batch_data is None:
            if self.verbose == True:
               logging.info('Acquiring mra_batch_data_snowflake data...')
            self.mra_batch_mapping()
            self._mra_batch_data = data_acquisition.function_get_sql_data(  'mra_batch_data_snowflake'
                                                                          , self.sql_dictionary, self.initialized_adaconnect
                                                                          , self.parameters, force_refresh = self.force_refresh).rename(columns = {  'PortfolioKey':'Portfolio_Key'
                                                                                                               , 'InstrumentKey':'Instrument_Key'
                                                                                                               , 'primary_currency_code':'Instrument_CurrencyCode'
                                                                                                              }
                                                                                                   )
            self._mra_batch_data['Instrument_CurrencyCode'] = self._mra_batch_data['Instrument_CurrencyCode'].astype(str).str.upper() #fix for incorrect currency code in DP Risk
        return self._mra_batch_data
    
    #Query to extract all mra batch data by currency
    #@#track_execution
    def mra_batch_data_currency(self):
        if self._mra_batch_data_currency is None:
            if self.verbose == True:
               logging.info('Acquiring mra_batch_data_currency_snowflake data...')
            self.mra_batch_mapping()
            self._mra_batch_data_currency = data_acquisition.function_get_sql_data(  'mra_batch_data_currency_snowflake'
                                                                                   , self.sql_dictionary, self.initialized_adaconnect
                                                                                   , self.parameters, force_refresh = self.force_refresh).rename(columns = {  'PortfolioKey':'Portfolio_Key' 
                                                                                                                        , 'InstrumentKey':'Instrument_Key'
                                                                                                                       }
                                                                                                            )
            
        return self._mra_batch_data_currency
    
    #Query to extract all mra ghost instrument
    #@#track_execution
    def mra_ghost_instruments(self):
        if self._mra_ghost_instruments is None:
            if self.verbose == True:
               logging.info('Acquiring mra_ghost_instruments_snowflake data...')
            self.mra_batch_mapping()
            self.pooled_fund_ghost_psp_portfolio_ids()
            self._mra_ghost_instruments = data_acquisition.function_get_sql_data(  'mra_ghost_instruments_snowflake'
                                                                                 , self.sql_dictionary, self.initialized_adaconnect
                                                                                 , self.parameters, force_refresh = self.force_refresh).rename(columns = {  'PortfolioKey':'Portfolio_Key' 
                                                                                                                      , 'InstrumentKey':'Instrument_Key'
                                                                                                                     }
                                                                                                          )
        return self._mra_ghost_instruments
    
    def mra_exposure(self):
        if self._mra_exposure is None:
            if self.verbose == True:
               logging.info('Acquiring mra_exposure_snowflake data...')
            self.mra_batch_mapping()
            self._mra_exposure = data_acquisition.function_get_sql_data(  'mra_exposure_snowflake'
                                                                         , self.sql_dictionary, self.initialized_adaconnect
                                                                         , self.parameters, force_refresh = self.force_refresh).rename(columns = {  'PortfolioKey':'Portfolio_Key' 
                                                                                                              , 'InstrumentKey':'Instrument_Key'
                                                                                                             }
                                                                                                  )
        return self._mra_exposure
    
    def mra_exposure_fx(self):
        if self._mra_exposure_fx is None:
            if self.verbose == True:
               logging.info('Acquiring mra_exposure_fx_snowflake data...')
            self.mra_batch_mapping()
            self._mra_exposure_fx = data_acquisition.function_get_sql_data(  'mra_exposure_fx_snowflake'
                                                                           , self.sql_dictionary, self.initialized_adaconnect
                                                                           , self.parameters, force_refresh = self.force_refresh).rename(columns = {  'PortfolioKey':'Portfolio_Key' 
                                                                                                                , 'InstrumentKey':'Instrument_Key'
                                                                                                               }
                                                                                                   )
        return self._mra_exposure_fx

    def mra_index_mapping(self):
        if self._mra_index_mapping is None:
            if self.verbose == True:
               logging.info('Acquiring mra_index_mapping data...')
            self.final_position_dates()
            self.benchmark_index_psp_instrument_ids()
            self._mra_index_mapping = data_acquisition.function_get_sql_data('mra_index_mapping', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._mra_index_mapping

    def mra_index_data(self):
        if self._mra_index_data is None:
            if self.verbose == True:
               logging.info('Acquiring mra_index_data data...')
            self.final_position_dates()
            self.benchmark_index_psp_instrument_ids()
            self._mra_index_data = data_acquisition.function_get_sql_data('mra_index_data', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._mra_index_data
    
    #Query to extract Portfolio IDs from a certain batch key
    def mra_batch_portfolios(self):
        if self._mra_batch_portfolios is None:
            if self.verbose == True:
               logging.info('Acquiring mra_batch_portfolios data...')
            self._mra_batch_portfolios = data_acquisition.function_get_sql_data(  'mra_batch_portfolios_snowflake'
                                                                                   , self.sql_dictionary
                                                                                   , self.initialized_adaconnect
                                                                                   , self.parameters
                                                                                   , force_refresh = self.force_refresh)
            self._mra_batch_portfolios = list(self._mra_batch_portfolios['PortfolioID'])
            if not self._mra_batch_portfolios:
                logging.info("No portfolio for this batch key")
        
        return self._mra_batch_portfolios

    #@#track_execution
    def issuers(self):
        if self._issuers is None:
            if self.verbose == True:
               logging.info('Acquiring issuers data...')
            self.psp_issuers_codes()
            self._issuers = data_acquisition.function_get_sql_data('issuers', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._issuers
    
    #@#track_execution
    def issuer_sectors(self):
        if self._issuer_sectors is None:
            if self.verbose == True:
               logging.info('Acquiring issuer_sectors data...')
            self.psp_all_issuer_codes()
            self._issuer_sectors = data_acquisition.function_get_sql_data('issuer_sectors', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
            self._issuer_sectors = self._issuer_sectors.drop_duplicates('Issuer_Code')
        return self._issuer_sectors
    
    #@#track_execution
    def issuer_ratings(self):
        if self._issuer_ratings is None:
            if self.verbose == True:
               logging.info('Acquiring issuer_ratings data...')
            self.psp_all_issuer_codes()
            self._issuer_ratings = data_acquisition.function_get_sql_data('issuer_ratings', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
            self._issuer_ratings = self._issuer_ratings.drop_duplicates('Issuer_Code')
        return self._issuer_ratings
    
    #@#track_execution
    def maturity_dates(self):
        if self._maturity_dates is None:
            if self.verbose == True:
               logging.info('Acquiring maturity_dates_snowflake data...')
            self._maturity_dates = data_acquisition.function_get_sql_data('maturity_dates_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._maturity_dates
        
    #@#track_execution
    def exposure_extended_snowflake(self):
        if self._exposure_extended_snowflake is None:
            if self.verbose == True:
               logging.info('Acquiring exposure_extended_snowflake data...')
            self.final_position_dates()
            self._exposure_extended_snowflake = data_acquisition.function_get_sql_data('exposure_extended_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._exposure_extended_snowflake
    
    #@#track_execution
    def exposure_non_extended_snowflake(self):
        if self._exposure_non_extended_snowflake is None:
            if self.verbose == True:
               logging.info('Acquiring exposure_non_extended_snowflake data...')
            self.final_position_dates()
            self._exposure_non_extended_snowflake = data_acquisition.function_get_sql_data('exposure_non_extended_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._exposure_non_extended_snowflake
    
    def exposure_tfe_snowflake(self):
        if self._exposure_tfe_snowflake is None:
            if self.verbose == True:
               logging.info('Acquiring exposure_TFE_snowflake data...')
            self._exposure_tfe_snowflake = data_acquisition.function_get_sql_data('exposure_tfe_snowflake', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._exposure_tfe_snowflake
    
    def exposure_tfe_snowflake_emr(self):
        if self._exposure_tfe_snowflake_emr is None:
            if self.verbose == True:
               logging.info('Acquiring exposure_tfe_snowflake_emr data...')
            self._exposure_tfe_snowflake_emr = data_acquisition.function_get_sql_data('exposure_tfe_snowflake_emr', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._exposure_tfe_snowflake_emr

    def exposure_creditrisk_dm(self):
        if self._exposure_creditrisk_dm is None:
            if self.verbose == True:
               logging.info('Acquiring exposure_creditrisk_dm data...')
            self._exposure_creditrisk_dm = data_acquisition.function_get_sql_data('exposure_creditrisk_dm', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._exposure_creditrisk_dm
    
    def exposure_creditrisk_dm_emr(self):
        if self._exposure_creditrisk_dm_emr is None:
            if self.verbose == True:
               logging.info('Acquiring exposure_creditrisk_dm_emr data...')
            self._exposure_creditrisk_dm_emr = data_acquisition.function_get_sql_data('exposure_creditrisk_dm_emr', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
        return self._exposure_creditrisk_dm_emr

    def position_dates_production(self):
        if self._position_dates_production is None:
            if self.verbose == True:
               logging.info('Acquiring position_dates_production data...')
            self._position_dates_production = data_acquisition.function_get_sql_data('position_dates_production', self.sql_dictionary, self.initialized_adaconnect, self.parameters, force_refresh = self.force_refresh)
            self._position_dates_production = [date.strftime('%Y-%m-%d') for date in self._position_dates_production['PositionDate']]
        return self._position_dates_production


    ####################################################################################################
    ### 3 Class Initialisation #########################################################################
    ####################################################################################################    
    def __init__( self
                , evaluation_date
                , position_dates
                , index_date = None
                , etf_date = None
                , issuer_date = None
                , pooled_fund_date = None
                , psp_portfolio_ids: List[int] = None
                , exclusions_psp_instrument_ids: List[int] = None
                , exclusions_psp_fund_codes: List[str] = ['CGF001C']
                , force_refresh:     str = False
                , country_to_use: str = None
                , sql_dictionary = None
                , initialized_adaconnect = None
                , file_path = ''
                , production_mode        = False #calculates exposure for specific dates
                , database_warehouse     = None
                , database_mra           = None
                , database_tfe           = None
                , verbose                = False
                , output_path            = None
                , run_standard           = True
                , run_unitary_benchmarks = False
                , run_unitary_indices    = False
                , batch_key : List[int]  = None
                , run_private            = False
                ):
                
        if production_mode and batch_key is not None:
            logging.exception("cannot run production mode and by batch at the same time")
        if batch_key is not None and psp_portfolio_ids is not None:
            logging.exception("cannot run by batch and also specify a portfolio ids list")
        if not run_standard and run_private:
            logging.exception("if run_private is True, run_standard must be True")

        self.original_evaluation_date  = evaluation_date
        self.original_position_dates   = position_dates
        self.original_index_date       = index_date
        self.original_etf_date         = etf_date
        self.original_issuer_date      = issuer_date
        self.original_pooled_fund_date = pooled_fund_date
        self.original_country_to_use   = country_to_use
        self.file_path                 = file_path
        self.database_warehouse        = database_warehouse
        self.database_mra              = database_mra
        self.database_tfe              = database_tfe
        self.execution_timestamp       = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.force_refresh             = force_refresh
        self.verbose                   = verbose
        self.output_path               = output_path
        self.run_standard              = run_standard
        self.run_unitary_benchmarks    = run_unitary_benchmarks
        self.run_unitary_indices       = run_unitary_indices
        self.batch_key                 = batch_key
        self.run_private               = run_private
        
        
        self.original_psp_portfolio_ids             = psp_portfolio_ids
        self.original_exclusions_psp_instrument_ids = exclusions_psp_instrument_ids
        self.sql_dictionary = sql_dictionary
        self.initialized_adaconnect = initialized_adaconnect
        
        self._portfolios = None
        self._positions = None
        self._instruments = None
        self._exposure_mapping = None
        self._exposure_mapping_pooled_funds = None
        self._position_dates_production = None
        self._unique_benchmarks = None
        
        self._fact_portfolios_private_markets = None
        self._fact_portfolios_pooled_funds_with_constituents = None
        self._fact_portfolios_pooled_funds_without_constituents = None
        self._fact_portfolios_internal = None
        self._fact_portfolios_V2 = None

        #DA Properties
        self._has_pooled_funds = None
        self._pooled_fund_psp_portfolio_ids = None
        self._pooled_fund_ghost_psp_portfolio_ids = None
        self._pooled_fund_psp_instrument_ids = None
        self._pooled_fund_mra_psp_portfolio_ids = None
        self._pooled_fund_position_dates = None
        self._final_position_dates = None
        self._all_position_dates = None
        self._trs_underlyings_psp_instrument_ids = None
        self._future_psp_instrument_ids = None
        self._option_underlyings_psp_instrument_ids = None
        self._price_psp_instrument_ids = None
        self._psp_portfolio_ids = None
        self._psp_asset_class_names = None
        self._psp_issuer_codes = None
        self._psp_all_issuer_codes = None
        self._psp_instrument_classification_ids = None
        self._credit_index_instrument_ids = None
        self._benchmark_index_psp_instrument_ids = None
        
        #PSP Other data
        self._gics = None
        self._fx_rates = None
        self._prices = None
        self._issuers = None
        self._issuer_sectors = None
        self._issuer_ratings = None
        self._maturity_dates = None
        self._exposure_extended_snowflake = None
        self._exposure_non_extended_snowflake = None
        self._exposure_tfe_snowflake = None
        self._exposure_tfe_snowflake_emr = None
        self._exposure_creditrisk_dm = None
        self._exposure_creditrisk_dm_emr = None
        
        #PSP instrument data
        self._options = None
        self._futures = None
        self._forwards = None
        self._swap_legs = None
        self._security_financing = None
        self._index = None
        self._shares = None
        self._benchmarks = None
        self._index_constituents = None
        self._basket_constituents = None
        self._etf_constituents = None
        self._credit_constituents = None
        self._constituents = None
        
        #MRA data
        self._mra_batch_mapping = None
        self._mra_exposure_with_calendardate = None
        self._mra_batch_data = None
        self._mra_batch_data_currency = None
        self._mra_ghost_instruments = None
        self._mra_exposure = None
        self._mra_exposure_fx = None
        self._fact_mra_data = None
        self._fact_mra_data_currency = None
        self._fact_mra_ghost_instruments = None
        self._fact_positions_mra_ghost = None
        self._mra_index_data = None
        self._mra_index_mapping = None
        #self._mra_batch_data_sensitivity = None
        self._mra_batch_portfolios = None
        
        #Pooled Funds instrument data
        self._pooled_funds_options = None
        self._pooled_funds_forwards = None
        self._pooled_funds_swaps = None
        self._pooled_funds_credit_derivatives = None
        self._pooled_funds = None
        self._pooled_funds_ratio = None
        
        #private market data
        self._private_markets = None
        
        #derived structure
        self._dim_countries = None
        self._dim_gics = None
        self._dim_portfolios = None
        self._dim_instruments = None
        self._dim_issuers = None
        self._fact_portfolios = None
        self._fact_portfolio_aums = None
        self._fact_benchmarks = None
        self._fact_pooled_funds = None
        self._fact_private_markets_sector_country = None
        self._fact_validation = None
        self._fact_portfolios_detailed = None
        self._fact_portfolios_scaling = None
        self._fact_unitary_benchmark_indices = None
        self._fact_unitary_benchmark_indices_with_mra = None
        self._fact_unitary_benchmark_with_mra = None
        self._fact_unitary_indices = None
        self._fact_unitary_indices_with_mra = None
        
        #Constituents Structure
        self._fact_index_constituents = None
        self._fact_etf_constituents = None
        self._fact_basket_constituents = None
        self._fact_credit_constituents = None
        self._fact_constituents = None
        
        #All Positions Structures
        self._fact_positions = None
        self._fact_positions_pooled_funds = None
        self._fact_positions_pooled_funds_with_constituents = None
        self._fact_positions_pooled_funds_without_constituents = None
        self._fact_positions_private_markets = None
        self._fact_positions_internal = None
        self._fact_positions_all = None
        self._fact_positions_all_with_mra = None
        self._fact_positions_internal_with_mra = None
        self._fact_positions_pooled_funds_with_constituents_with_mra = None
        self._fact_exposure_non_extended = None
        self._fact_exposure_extended = None
        self._fact_positions_benchmark = None
        self.output_dictionary = None
        self._fact_exposure_extended_v1 = None
        
        #validation data
        self._agg_by_portfolio = None
        self._agg_by_categorization_id = None
        
        self.parameters = {}
        self.parameters['evaluation_date']               = evaluation_date
        self.parameters['position_dates']                = sorted(self.position_dates_production()) if production_mode else sorted(position_dates)
        self.parameters['index_date']                    = index_date if index_date is not None else evaluation_date
        self.parameters['etf_date']                      = etf_date if etf_date is not None else evaluation_date
        self.parameters['issuer_date']                   = issuer_date if issuer_date is not None else evaluation_date
        self.parameters['pooled_fund_date']              = pooled_fund_date if pooled_fund_date is not None else evaluation_date
        self.parameters['batch_key']                     = batch_key
        self.parameters['original_psp_portfolio_ids']    = sorted(psp_portfolio_ids)  if psp_portfolio_ids is not None else psp_portfolio_ids
        self.parameters['psp_portfolio_ids']             = sorted(psp_portfolio_ids)  if psp_portfolio_ids is not None else psp_portfolio_ids 
        self.parameters['exclusions_psp_instrument_ids'] = sorted(exclusions_psp_instrument_ids) if exclusions_psp_instrument_ids is not None  else exclusions_psp_instrument_ids
        self.parameters['exclusions_psp_fund_codes']     = sorted(exclusions_psp_fund_codes) if exclusions_psp_fund_codes is not None  else exclusions_psp_fund_codes
        self.parameters['country_to_use']                = country_to_use if country_to_use is not None  else 'RiskLocationCountryCode'
        self.parameters['database_warehouse']            = database_warehouse
        self.parameters['database_mra']                  = database_mra
        self.parameters['database_tfe']                  = database_tfe
        self.parameters['delta_statistic_id']            = PAC.delta_statistic_id
        self.parameters['pv_statistic_id']               = PAC.pv_statistic_id
        self.parameters['krd_statistic_ids']             = PAC.krd_statistic_ids
        self.parameters['benchmark_total_nav']           = PAC.benchmark_total_nav
        self.parameters['index_total_nav']               = PAC.index_total_nav
        
        
    ####################################################################
    ## Define all calculated properties ################################
    ####################################################################
    
    #Properties identifying if pooled funds are in current fact_positions
    def has_pooled_funds(self):
        if self._has_pooled_funds is None:
            self._has_pooled_funds = True if len(self.pooled_fund_psp_instrument_ids()) > 0 else False
        return self._has_pooled_funds
    
    #Properties identifying all pooled funds psp portfolio ids in fact_positions
    def pooled_fund_ghost_psp_portfolio_ids(self):
        if self._pooled_fund_ghost_psp_portfolio_ids is None:
            self._pooled_fund_ghost_psp_portfolio_ids = sorted(list(set(self.mra_batch_data()[(self.mra_batch_data()['InstrumentID']<0)&( (self.mra_batch_data()['PortfolioID'].isin(self.pooled_fund_psp_portfolio_ids())))]['PortfolioID'].unique())))
            self.parameters['pooled_fund_ghost_psp_portfolio_ids'] = self._pooled_fund_ghost_psp_portfolio_ids
        return self._pooled_fund_ghost_psp_portfolio_ids

    #Properties identifying all pooled funds psp portfolio ids in fact_positions
    def pooled_fund_psp_portfolio_ids(self):
        if self._pooled_fund_psp_portfolio_ids is None:
            self._pooled_fund_psp_portfolio_ids = sorted(list(set(self.fact_positions()[self.fact_positions()['Position_Type'].isin(['Pooled Fund','Pooled Fund with Data','Pooled Fund without Data'])]['Portfolio_PSPPortfolioID'].unique())))
            self.parameters['pooled_fund_psp_portfolio_ids'] = self._pooled_fund_psp_portfolio_ids
        return self._pooled_fund_psp_portfolio_ids
    
    #Properties identifying all pooled funds psp portfolio ids in mra_batch_data
    ### not used anymore
    def pooled_fund_mra_psp_portfolio_ids(self):
        if self._pooled_fund_mra_psp_portfolio_ids is None:
            self._pooled_fund_mra_psp_portfolio_ids = sorted(list(
                (set(self.fact_pooled_funds()['Portfolio_PSPPortfolioID']) & set(self.fact_positions_pooled_funds()['Portfolio_PSPPortfolioID']))\
                                                                  | set(self.fact_positions_mra_ghost()['Portfolio_PSPPortfolioID'])))
        return self._pooled_fund_mra_psp_portfolio_ids
    
    #Properties identifying all pooled funds instruments ids in current fact_positions
    def pooled_fund_psp_instrument_ids(self):
        if self._pooled_fund_psp_instrument_ids is None:
            self._pooled_fund_psp_instrument_ids = sorted(list(set(self.fact_positions()[self.fact_positions()['Position_Type'].isin(['Pooled Fund','Pooled Fund with Data','Pooled Fund without Data'])]['Instrument_PSPInstrumentID'].unique())))
            self.parameters['pooled_fund_psp_instrument_ids'] = self._pooled_fund_psp_instrument_ids
        return self._pooled_fund_psp_instrument_ids
    
    #Properties identifying all pooled funds position dates
    def pooled_fund_position_dates(self):
        if self._pooled_fund_position_dates is None:
            self._pooled_fund_position_dates = sorted([date for date in map(lambda x: str(x)[:10],set(self.fact_pooled_funds()['PositionDate'].unique()))])
            self.parameters['pooled_fund_position_dates'] = self._pooled_fund_position_dates
        return self._pooled_fund_position_dates
    
    #Properties identifying final position dates for normal positions
    def final_position_dates(self):
        if self._final_position_dates is None:
            self._final_position_dates = sorted([date for date in map(lambda x: str(x)[:10],set(self.positions()['PositionDate'].unique()))])
            self.parameters['final_position_dates'] = self._final_position_dates
        return self._final_position_dates
   
    #Properties identifying final position dates for normal positions
    def benchmark_index_psp_instrument_ids(self):
        if self._benchmark_index_psp_instrument_ids is None:
            self._benchmark_index_psp_instrument_ids = sorted(list(set(self.unique_benchmarks()['Index_PSPInstrumentID'].unique())))
            self.parameters['benchmark_index_psp_instrument_ids'] = self._benchmark_index_psp_instrument_ids
        return self._benchmark_index_psp_instrument_ids

    #Properties identifying all position dates, botrh for normal positions and pooled funds positions
    def all_position_dates(self):
        if self._all_position_dates is None:
            self._all_position_dates = sorted(list(set(self.final_position_dates() + self.pooled_fund_position_dates())))
            self.parameters['all_position_dates'] = self._all_position_dates
        return self._all_position_dates
    
    #Properties identifying all underlying psp instrument ids for total return swaps
    def trs_underlyings_psp_instrument_ids(self):
        if self._trs_underlyings_psp_instrument_ids is None:
            self._trs_underlyings_psp_instrument_ids = sorted(list(set(self.fact_positions().loc[(self.fact_positions()['Leg_Type']=='TotalReturn'),'UltimateUnderlying_PSPInstrumentID'].dropna().unique())))
        return self._trs_underlyings_psp_instrument_ids
    
    #Properties identifying all futures psp instrument ids
    def future_psp_instrument_ids(self):
        if self._future_psp_instrument_ids is None:
            future_underlying_list = list(set(self.fact_positions().loc[(self.fact_positions()['Instrument_Family']=='Futures'),'Instrument_PSPInstrumentID'].unique()))
            future_underlying_list = future_underlying_list + list(set(self.fact_positions().loc[~(self.fact_positions()['Future_UnderlyingPSPInstrumentID'].isnull()),'Future_UnderlyingPSPInstrumentID'].unique()))
            self._future_psp_instrument_ids = sorted(list(set(future_underlying_list)))
            self.parameters['future_psp_instrument_ids'] = self._future_psp_instrument_ids
        return self._future_psp_instrument_ids
    
    #Properties identifying all options psp instrument ids
    def option_underlyings_psp_instrument_ids(self):
        if self._option_underlyings_psp_instrument_ids is None:
            option_underlying_ids_list = list(set(self.fact_positions().loc[(self.fact_positions()['Instrument_Family']=='Option'),'UltimateUnderlying_PSPInstrumentID'].unique()))
            option_underlying_ids_list = option_underlying_ids_list + list(set(self.fact_positions().loc[~(self.fact_positions()['Option_UnderlyingPSPInstrumentID'].isnull()),'Option_UnderlyingPSPInstrumentID'].unique()))
            self._option_underlyings_psp_instrument_ids = sorted(list(set(option_underlying_ids_list)))
            self.parameters['option_underlyings_psp_instrument_ids'] = self._option_underlyings_psp_instrument_ids
        return self._option_underlyings_psp_instrument_ids

    #Properties identifying all psp instrument ids that requires price extractions
    def price_psp_instrument_ids(self):
        if self._price_psp_instrument_ids is None:
            self._price_psp_instrument_ids = sorted(self.trs_underlyings_psp_instrument_ids() + self.future_psp_instrument_ids() + self.option_underlyings_psp_instrument_ids())
            self.parameters['price_psp_instrument_ids'] = self._price_psp_instrument_ids
        return self._price_psp_instrument_ids
    
    #Properties identifying all psp portfolio ids
    def psp_portfolio_ids(self):
        if self._psp_portfolio_ids is None:
            self._psp_portfolio_ids = sorted(list(set(self.fact_portfolios()['Portfolio_PSPPortfolioID'].unique())))
            self.parameters['psp_portfolio_ids'] = self._psp_portfolio_ids
        return self._psp_portfolio_ids
    
    #Properties identifying psp asset class names
    def psp_asset_class_names(self):
        if self._psp_asset_class_names is None:
            self._psp_asset_class_names = sorted(list(set(self.fact_portfolios()['Portfolio_AssetClass'].unique())))
            self.parameters['psp_asset_class_names'] = self._psp_asset_class_names
        return self._psp_asset_class_names
    
    #Properties identifying psp asset class names
    def psp_issuers_codes(self):
        if self._psp_issuer_codes is None:
            self._psp_issuer_codes= sorted(list(set(self.fact_positions_all_with_mra()['UltimateUnderlying_IssuerCode'].dropna().astype('int'))
                                                | set(self.fact_all_constituents()['Constituent_IssuerCode'].dropna().astype('int'))))
            self.parameters['psp_issuer_codes'] = self._psp_issuer_codes
        return self._psp_issuer_codes
    
    #Properties identifying psp asset class names
    def psp_all_issuer_codes(self):
        if self._psp_all_issuer_codes is None:
            self._psp_all_issuer_codes = sorted(list(set(self.issuers()['Issuer_Code'].unique())))
            self.parameters['psp_all_issuer_codes'] = self._psp_all_issuer_codes
        return self._psp_all_issuer_codes
    
    #Properties identifying psp asset class names
    def psp_instrument_classification_ids(self):
        if self._psp_instrument_classification_ids is None:
            self._psp_instrument_classification_ids= sorted(list(set(self.fact_all_positions()['Instrument_PSPInstrumentCategorizationID'].unique())))
        return self._psp_instrument_classification_ids

    #Properties identifying all different credit index psp instrument ids
    ### not used anymore
    def credit_index_instrument_ids(self):
        if self._credit_index_instrument_ids is None:
            self._credit_index_instrument_ids = sorted(list(set(self.fact_positions_all()[self.fact_positions_all()['UltimateUnderlying_Type'] == 'Credit Index']['UltimateUnderlying_IndexProxyPSPInstrumentID'])))
            self.parameters['credit_index_instrument_ids'] = self._credit_index_instrument_ids
        return self._credit_index_instrument_ids

    ##Properties identifying all benchmark ids
    #def psp_asset_class_names(self):
    #    if self._psp_asset_class_names is None:
    #        self._psp_asset_class_names = sorted(list(set(self.fact_portfolios()['Portfolio_AssetClass'].unique())))
    #        self.parameters['psp_asset_class_names'] = self._psp_asset_class_names
    #    return self._psp_asset_class_names
    
    ####################################################################
    ## Define all derived fact structures ##############################
    ####################################################################
    #@#track_execution
    def dim_gics(self):
        if self._dim_gics is None:
            self._dim_gics = self.gics().copy(deep = True)
            
        return self._dim_gics
    
    #@#track_execution
    def dim_countries(self):
        if self._dim_countries is None:
            self._dim_countries = pd.DataFrame(PAC.region_mapping, columns = ['Country_ISOCode','Country_Name','Country_CurrencyCode','Country_IntermediateRegion','Country_SubRegion','Country_Region'])
            
        return self._dim_countries
    
    #@#track_execution
    def dim_portfolios(self):
        if self._dim_portfolios is None:
            self._dim_portfolios = self.portfolios().copy(deep = True)
            
        return self._dim_portfolios
    
    '''
    def dim_instruments(self):
        if self._dim_instruments is None:
            dim_instruments =  self.instruments().copy(deep = True)
            #print(len(dim_instruments.index))
            
            dim_instruments = dim_instruments.merge(  self.maturity_dates()
                                                    , on = ['Instrument_PSPInstrumentID']
                                                    , how = 'left'
                                                    , validate = '1:1'
                                                   )
            
            #Generate financial maturity date mapping
            maturity_mapping = {'Instrument_MaturityDate':['Bond',
                                                           'Bond Futures',
                                                           'Credit Default Swap on Index',
                                                           'Inflation-linked Bond',
                                                           'Credit Default Swap',
                                                           'Floating Rate Note',
                                                           'Option on Bond Futures',
                                                           'Total Return Swap on Inflation Bond',
                                                           'Total Return Swap on Bond',
                                                           'Treasury Bill',
                                                           'Bankers'' Acceptance',
                                                           'Bond Forward',
                                                           'Commercial Paper',
                                                           'Promissory Note',
                                                           'Term Deposit'
                                                          ], 
                                'Instrument_TerminationDate':['Interest Rate Swap',
                                                              'Interest Rate Cap / Floor',
                                                              'Overnight Index Swap',
                                                              'CMS Spread Option',
                                                              'Cross Currency Swap',
                                                              'Inflation Swap'
                                                             ], 
                                'Instrument_FirstDeliveryDate':['Money Market Futures'], 
                                'Instrument_ExpirationDate':['Option on Money Market Futures'], 
                                'Instrument_PenultimatePaymentDate':['Swaption']}
            
            for key in maturity_mapping.keys():
                current_filter_value = maturity_mapping[key]
                #print(key, current_filter_value)
                current_filter = dim_instruments['Instrument_PSPInstrumentCategorizationCode'].isin(current_filter_value)
                dim_instruments.loc[current_filter, 'Instrument_FinancialMaturityDate'] = dim_instruments.loc[current_filter, key]
                
            dim_instruments = dim_instruments.drop(columns = maturity_mapping.keys())
            
            #Includes Options underlying and style
            dim_instruments = dim_instruments.merge(self.options(), 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    validate = '1:1'
                                                   )
            dim_instruments = dim_instruments.rename({'Underlying_PSPInstrumentID':'UltimateUnderlying_PSPInstrumentID'}, axis=1)
            
            #Include Forward underlying
            dim_instruments = dim_instruments.merge(self.forwards(), 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    validate = '1:1'
                                                   )
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Underlying_PSPInstrumentID'])
            dim_instruments = dim_instruments.drop(['Underlying_PSPInstrumentID'], axis=1)
            
            #Includes PF Options underlying and style
            dim_instruments = dim_instruments.merge(self.pooled_funds_options(), 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    suffixes=('', '_temp'), 
                                                    validate = '1:1'
                                                   )
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Underlying_PSPInstrumentID'])
            dim_instruments['Option_Style'] = dim_instruments['Option_Style'].fillna(dim_instruments['Option_Style_temp'])
            dim_instruments = dim_instruments.drop(['Underlying_PSPInstrumentID','Option_Style_temp'], axis=1)
            
            #Include PF Forwards underlying
            dim_instruments = dim_instruments.merge(self.pooled_funds_forwards(), 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    validate = '1:1'
                                                   )
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Underlying_PSPInstrumentID'])
            dim_instruments = dim_instruments.drop(['Underlying_PSPInstrumentID'], axis=1)
            
            #Include PF Credit Derivatives underlying
            dim_instruments = dim_instruments.merge(self.pooled_funds_credit_derivatives(), 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    validate = '1:1'
                                                   )
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Underlying_PSPInstrumentID'])
            dim_instruments = dim_instruments.drop(['Underlying_PSPInstrumentID'], axis=1)
            
            #Include PF Swaps underlying
            dim_instruments = dim_instruments.merge(self.pooled_funds_swaps(), 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    validate = '1:1'
                                                   )
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Underlying_PSPInstrumentID'])
            dim_instruments = dim_instruments.drop(['Underlying_PSPInstrumentID'], axis=1)
            
            #Include Futures underlying
            dim_instruments = dim_instruments.merge(self.futures(), 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    validate = '1:1'
                                                   )
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Underlying_PSPInstrumentID'])
            dim_instruments = dim_instruments.drop(['Underlying_PSPInstrumentID'], axis=1)
            
            #Includes Security Financing underlying
            dim_instruments = dim_instruments.merge(self.security_financing(), 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    validate = '1:1'
                                                   )
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Underlying_PSPInstrumentID'])
            dim_instruments = dim_instruments.drop(['Underlying_PSPInstrumentID'], axis=1)
            
            #Includes Swaps Legs underlying for total return and credit protection type legs
            temp_swap_legs = self.swap_legs().copy(deep = True)
            temp_swap_legs = temp_swap_legs.loc[temp_swap_legs['Leg_Type'].isin(['TotalReturn','CreditProtection']), ['Instrument_PSPInstrumentID','Underlying_PSPInstrumentID']]
            
            dim_instruments = dim_instruments.merge(temp_swap_legs, 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    validate = '1:1'
                                                   )
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Underlying_PSPInstrumentID'])
            dim_instruments = dim_instruments.drop(['Underlying_PSPInstrumentID'], axis=1)
            
            #Includes shares underlying for ADR/GDR and other weird corned case
            dim_instruments = dim_instruments.merge(self.shares(), 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    validate = '1:1'
                                                   )
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Underlying_PSPInstrumentID'])
            dim_instruments = dim_instruments.drop(['Underlying_PSPInstrumentID'], axis=1) 
            
            #Includes Index proxy if applicable.  If none, will use index id
            dim_instruments = dim_instruments.merge(self.index(), 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    validate = '1:1'
                                                   )
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Instrument_PSPInstrumentID'])
            
            #Initiate first loop of iterative underlying identification
            dim_instruments = dim_instruments.merge(dim_instruments[['Instrument_PSPInstrumentID','UltimateUnderlying_PSPInstrumentID']], 
                                                    left_on=['UltimateUnderlying_PSPInstrumentID'], 
                                                    right_on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    suffixes=('', '_temp'), 
                                                    validate = 'm:1'
                                                   )
            dim_instruments = dim_instruments.drop(['Instrument_PSPInstrumentID_temp'], axis=1)
            
            #Launch loops of iterative underlying identification
            while not(dim_instruments['UltimateUnderlying_PSPInstrumentID'].equals(dim_instruments['UltimateUnderlying_PSPInstrumentID_temp'])):
                dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID_temp']
                dim_instruments = dim_instruments.drop(['UltimateUnderlying_PSPInstrumentID_temp'], axis=1)
                dim_instruments = dim_instruments.merge(dim_instruments[['Instrument_PSPInstrumentID','UltimateUnderlying_PSPInstrumentID']], 
                                                        left_on=['UltimateUnderlying_PSPInstrumentID'], 
                                                        right_on=['Instrument_PSPInstrumentID'], 
                                                        how='left', 
                                                        suffixes=('', '_temp'), 
                                                        validate = 'm:1'
                                                       )
                dim_instruments = dim_instruments.drop(['Instrument_PSPInstrumentID_temp'], axis=1)
            
            dim_instruments = dim_instruments.drop(['UltimateUnderlying_PSPInstrumentID_temp'], axis=1)   
            #dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].astype(int)
            
            temp_dim_columns = ['Instrument_PSPInstrumentID',
                                'Instrument_Family',
                                'Instrument_PSPInstrumentCategorizationID',
                                'Instrument_PSPInstrumentCategorizationCode',
                                'Instrument_Description',
                                'Instrument_Market',
                                'Instrument_Type',
                                'Instrument_IssuerCode', 
                                'Instrument_IndexProxyPSPInstrumentID', 
                                #'Instrument_MaturityDate', 
                                #'Instrument_TerminationDate', 
                                #'Instrument_FirstDeliveryDate', 
                                #'Instrument_ExpirationDate', 
                                #'Instrument_PenultimatePaymentDate',
                                'Instrument_FinancialMaturityDate',
                                'Instrument_CurrencyCode'
                               ]
            
            temp_dim_instruments = dim_instruments[temp_dim_columns].copy(deep = True)
            temp_dim_instruments = temp_dim_instruments.rename(columns = lambda column_name: str(column_name).replace('Instrument_','UltimateUnderlying_'))
            
            #dim_instruments
            dim_instruments = dim_instruments.merge(temp_dim_instruments, 
                                                    on = ['UltimateUnderlying_PSPInstrumentID'], 
                                                    how = 'left', 
                                                    validate = 'm:1'
                                                   )
            
            dim_instruments['UltimateUnderlying_IndexProxyPSPInstrumentID'] = dim_instruments['UltimateUnderlying_IndexProxyPSPInstrumentID'].fillna(dim_instruments['UltimateUnderlying_PSPInstrumentID']).astype(int)
            dim_instruments['Instrument_IndexProxyPSPInstrumentID'] = dim_instruments['Instrument_IndexProxyPSPInstrumentID'].fillna(0).astype(int)
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].astype(int)
            
            self._dim_instruments = dim_instruments
         
        return self._dim_instruments
    '''
    def dim_instruments(self):
        if self._dim_instruments is None:
            dim_instruments =  self.instruments().copy(deep = True)

            #manually add a row for instrument with no dimensions (private positions)
            new_row = {col: 'NONE' if dim_instruments[col].dtype == 'object' else 0 for col in dim_instruments.columns}
            dim_instruments = pd.concat([dim_instruments, pd.DataFrame([new_row])], ignore_index=True)
            
            dim_instruments = dim_instruments.merge(  self.maturity_dates()
                                                    , on = ['Instrument_PSPInstrumentID']
                                                    , how = 'left'
                                                    , validate = '1:1'
                                                   )
            
            #Generate financial maturity date mapping
            maturity_mapping = {'Instrument_MaturityDate':['Bond',
                                                           'Bond Futures',
                                                           'Credit Default Swap on Index',
                                                           'Inflation-linked Bond',
                                                           'Credit Default Swap',
                                                           'Floating Rate Note',
                                                           'Option on Bond Futures',
                                                           'Total Return Swap on Inflation Bond',
                                                           'Total Return Swap on Bond',
                                                           'Treasury Bill',
                                                           'Bankers'' Acceptance',
                                                           'Bond Forward',
                                                           'Commercial Paper',
                                                           'Promissory Note',
                                                           'Term Deposit'
                                                          ], 
                                'Instrument_TerminationDate':['Interest Rate Swap',
                                                              'Interest Rate Cap / Floor',
                                                              'Overnight Index Swap',
                                                              'CMS Spread Option',
                                                              'Cross Currency Swap',
                                                              'Inflation Swap'
                                                             ], 
                                'Instrument_FirstDeliveryDate':['Money Market Futures'], 
                                'Instrument_ExpirationDate':['Option on Money Market Futures'], 
                                'Instrument_PenultimatePaymentDate':['Swaption']
                                }
            
            for key in maturity_mapping.keys():
                current_filter_value = maturity_mapping[key]
                #print(key, current_filter_value)
                current_filter = dim_instruments['Instrument_PSPInstrumentCategorizationCode'].isin(current_filter_value)
                dim_instruments.loc[current_filter, 'Instrument_FinancialMaturityDate'] = dim_instruments.loc[current_filter, key]
                
            dim_instruments = dim_instruments.drop(columns = maturity_mapping.keys())

            dim_instruments['Option_UnderlyingPSPInstrumentID'] = dim_instruments[dim_instruments['Instrument_Family'] == 'Option']['Underlying_PSPInstrumentID']
            dim_instruments['Future_UnderlyingPSPInstrumentID'] = dim_instruments[dim_instruments['Instrument_Family'] == 'Futures']['Underlying_PSPInstrumentID']
            dim_instruments = dim_instruments.drop(['Underlying_PSPInstrumentID'], axis=1)

            dim_instruments['Option_ContractSize']              = dim_instruments[dim_instruments['Instrument_Family'] == 'Option']['ContractSize']
            dim_instruments['Future_ContractSize']              = dim_instruments[dim_instruments['Instrument_Family'] == 'Futures']['ContractSize']
            dim_instruments = dim_instruments.drop(['ContractSize'], axis=1)

            dim_instruments = dim_instruments.rename({'Coal_Underlying_PSPInstrumentID':'UltimateUnderlying_PSPInstrumentID'}, axis=1)            

            #Includes Swaps Legs underlying for total return, credit protection, cap and floor type legs
            temp_swap_legs = self.swap_legs().copy(deep = True)
            temp_swap_legs = temp_swap_legs.loc[temp_swap_legs['Leg_Type'].isin(['TotalReturn','CreditProtection','Cap','Floor']), ['Instrument_PSPInstrumentID','Underlying_PSPInstrumentID']]
            temp_swap_legs = temp_swap_legs[~temp_swap_legs['Underlying_PSPInstrumentID'].isna()]

            dim_instruments = dim_instruments.merge(temp_swap_legs, 
                                                    on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    validate = '1:1'
                                                   )
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Underlying_PSPInstrumentID'])
            dim_instruments = dim_instruments.drop(['Underlying_PSPInstrumentID'], axis=1)
            
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].fillna(dim_instruments['Instrument_PSPInstrumentID'])

            #Initiate first loop of iterative underlying identification
            dim_instruments = dim_instruments.merge(dim_instruments[['Instrument_PSPInstrumentID','UltimateUnderlying_PSPInstrumentID']], 
                                                    left_on=['UltimateUnderlying_PSPInstrumentID'], 
                                                    right_on=['Instrument_PSPInstrumentID'], 
                                                    how='left', 
                                                    suffixes=('', '_temp'), 
                                                    validate = 'm:1'
                                                   )
            dim_instruments = dim_instruments.drop(['Instrument_PSPInstrumentID_temp'], axis=1)
            
            #Launch loops of iterative underlying identification
            while not(dim_instruments['UltimateUnderlying_PSPInstrumentID'].equals(dim_instruments['UltimateUnderlying_PSPInstrumentID_temp'])):
                dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID_temp']
                dim_instruments = dim_instruments.drop(['UltimateUnderlying_PSPInstrumentID_temp'], axis=1)
                dim_instruments = dim_instruments.merge(dim_instruments[['Instrument_PSPInstrumentID','UltimateUnderlying_PSPInstrumentID']], 
                                                        left_on=['UltimateUnderlying_PSPInstrumentID'], 
                                                        right_on=['Instrument_PSPInstrumentID'], 
                                                        how='left', 
                                                        suffixes=('', '_temp'), 
                                                        validate = 'm:1'
                                                       )
                dim_instruments = dim_instruments.drop(['Instrument_PSPInstrumentID_temp'], axis=1)
            
            dim_instruments = dim_instruments.drop(['UltimateUnderlying_PSPInstrumentID_temp'], axis=1)
            
            temp_dim_columns = ['Instrument_PSPInstrumentID',
                                'Instrument_Family',
                                'Instrument_PSPInstrumentCategorizationID',
                                'Instrument_PSPInstrumentCategorizationCode',
                                'Instrument_Description',
                                'Instrument_Market',
                                'Instrument_Type',
                                'Instrument_IssuerCode', 
                                'Instrument_IndexProxyPSPInstrumentID', 
                                #'Instrument_MaturityDate', 
                                #'Instrument_TerminationDate', 
                                #'Instrument_FirstDeliveryDate', 
                                #'Instrument_ExpirationDate', 
                                #'Instrument_PenultimatePaymentDate',
                                'Instrument_FinancialMaturityDate',
                                'Instrument_CurrencyCode'
                               ]
            
            temp_dim_instruments = dim_instruments[temp_dim_columns].copy(deep = True)
            temp_dim_instruments = temp_dim_instruments.rename(columns = lambda column_name: str(column_name).replace('Instrument_','UltimateUnderlying_'))
            
            #dim_instruments
            dim_instruments = dim_instruments.merge(temp_dim_instruments, 
                                                    on = ['UltimateUnderlying_PSPInstrumentID'], 
                                                    how = 'left', 
                                                    validate = 'm:1'
                                                   )
            
            dim_instruments['UltimateUnderlying_IndexProxyPSPInstrumentID'] = dim_instruments['UltimateUnderlying_IndexProxyPSPInstrumentID'].fillna(dim_instruments['UltimateUnderlying_PSPInstrumentID']).astype(int)
            dim_instruments['Instrument_IndexProxyPSPInstrumentID'] = dim_instruments['Instrument_IndexProxyPSPInstrumentID'].fillna(0).astype(int)
            dim_instruments['UltimateUnderlying_PSPInstrumentID'] = dim_instruments['UltimateUnderlying_PSPInstrumentID'].astype(int)
            
            self._dim_instruments = dim_instruments
         
        return self._dim_instruments

    #@#track_execution
    def dim_issuers(self):
        if self._dim_issuers is None:
            self._dim_issuers = self.issuers()
            self._dim_issuers = self._dim_issuers.merge(  self.issuer_sectors()
                                                        , on = ['Issuer_Code']
                                                        , how = 'left'
                                                        , validate = 'one_to_one'
                                                       )   
            
            self._dim_issuers = self._dim_issuers.merge(  self.issuer_ratings()
                                                        , on = ['Issuer_Code']
                                                        , how = 'left'
                                                        , validate = 'one_to_one'
                                                       ) 
            
            self._dim_issuers = self._dim_issuers.merge(  self._dim_issuers
                                                        , left_on = ['Issuer_UltimateParentCode']
                                                        , right_on = ['Issuer_Code']
                                                        , how = 'left'
                                                        , validate = 'many_to_one'
                                                        , suffixes = ['','_UltimateParent']
                                                       ).rename(columns = {  'Issuer_PSPLegalEntityID_UltimateParent':          'Issuer_UltimateParentPSPLegalEntityID'
                                                                           , 'Issuer_RiskLocationCountryCode_UltimateParent':   'Issuer_UltimateParentRiskLocationCountryCode'
                                                                           , 'Issuer_NormalizedCountryCode_UltimateParent':     'Issuer_UltimateParentNormalizedCountryCode'
                                                                           , 'Issuer_BICSBETAClassificationID_UltimateParent':  'Issuer_UltimateParentBICSBETAClassificationID'
                                                                           
                                                                           , 'Issuer_BICSBETASectorCode_UltimateParent':        'Issuer_UltimateParentBICSBETASectorCode'
                                                                           , 'Issuer_BICSBETASectorName_UltimateParent':        'Issuer_UltimateParentBICSBETASectorName'
                                                                           , 'Issuer_BICSBETAIndustryGroupCode_UltimateParent': 'Issuer_UltimateParentBICSBETAIndustryGroupCode'
                                                                           , 'Issuer_BICSBETAIndustryGroupName_UltimateParent': 'Issuer_UltimateParentBICSBETAIndustryGroupName'  
                                                                           , 'Issuer_BICSBETAIndustryCode_UltimateParent':      'Issuer_UltimateParentBICSBETAIndustryCode'
                                                                           , 'Issuer_BICSBETAIndustryName_UltimateParent':      'Issuer_UltimateParentBICSBETAIndustryName'  
                                                                           , 'Issuer_BICSBETASubIndustryCode_UltimateParent':   'Issuer_UltimateParentBICSBETASubIndustryCode'
                                                                           , 'Issuer_BICSBETASubIndustryName_UltimateParent':   'Issuer_UltimateParentBICSBETASubIndustryName'  
                                                                           , 'Issuer_BICSBETAActivityCode_UltimateParent':      'Issuer_UltimateParentBICSBETAActivityCode'  
                                                                           , 'Issuer_BICSBETAActivityName_UltimateParent':      'Issuer_UltimateParentBICSBETAActivityName'  
                                                                           , 'Issuer_BICSBETASubActivityCode_UltimateParent':   'Issuer_UltimateParentBICSBETASubActivityCode'  
                                                                           , 'Issuer_BICSBETASubActivityName_UltimateParent':   'Issuer_UltimateParentBICSBETASubActivityName'  
                                                                           , 'Issuer_BICSBETASegmentCode_UltimateParent':       'Issuer_UltimateParentBICSBETASegmentCode'  
                                                                           , 'Issuer_BICSBETASegmentName_UltimateParent':       'Issuer_UltimateParentBICSBETASegmentName'  
                                                                          }).drop(columns = [  'Issuer_Code_UltimateParent'
                                                                                             , 'Issuer_UltimateParentCode_UltimateParent'
                                                                                            ])
            
            self._dim_issuers['Issuer_EquityExposureFactor']    = 1.0
            self._dim_issuers['Issuer_IssuerExposureFactor']    = 1.0
            self._dim_issuers['Issuer_FxExposureFactor']        = 1.0
            self._dim_issuers['Issuer_CommodityExposureFactor'] = 1.0
            self._dim_issuers['Issuer_FIExposureFactor']        = 1.0
            self._dim_issuers['Issuer_CRExposureFactor']        = 1.0
            
            #self._dim_issuers = self._dim_issuers[PAC.issuer_columns]
            
        return self._dim_issuers
    
    #@#track_execution
    def fact_positions(self):
        if self._fact_positions is None:
            self._fact_positions = self.positions().copy(deep = True)
            self._fact_positions = self._fact_positions.merge(  self.dim_instruments().drop(columns = 'Instrument_CurrencyCode')
                                                              , on=['Instrument_PSPInstrumentID']
                                                              , how='left'
                                                              , validate = 'many_to_one'
                                                             )
            
            self._fact_positions['Position_Type'] = self._fact_positions['Instrument_PSPInstrumentCategorizationID'].map(lambda x: 'Pooled Fund' if x in PAC.pooled_fund_psp_instrument_categorization_codes else 'Normal')
        
            self._fact_positions = self._fact_positions.merge(  self.swap_legs()[[  'Instrument_PSPInstrumentID'
                                                                                  , 'Leg_PSPInstrumentLegID'
                                                                                  , 'Leg_Type'
                                                                                  , 'Leg_FirstResetDate'
                                                                                  , 'Leg_LastResetDate'
                                                                                  , 'Leg_Direction'
                                                                                 ]]
                                                              , on = ['Instrument_PSPInstrumentID','Leg_PSPInstrumentLegID']
                                                              , how = 'left'
                                                              , validate = 'many_to_one'
                                                             )
            
        return self._fact_positions
              
    #@#track_execution               
    def fact_index_constituents(self):
        if self._fact_index_constituents is None:
            columns_dim_instruments = [  'Instrument_PSPInstrumentID'
                                       , 'Instrument_PSPInstrumentCategorizationID'
                                       , 'Instrument_PSPInstrumentCategorizationCode'
                                       , 'Instrument_CurrencyCode'
                                       , 'UltimateUnderlying_Family'
                                       , 'UltimateUnderlying_PSPInstrumentID'
                                       , 'UltimateUnderlying_PSPInstrumentCategorizationID'
                                       , 'UltimateUnderlying_PSPInstrumentCategorizationCode'
                                       , 'UltimateUnderlying_Description'
                                       , 'UltimateUnderlying_Market'
                                       , 'UltimateUnderlying_Type'
                                       , 'UltimateUnderlying_IssuerCode'
                                       , 'UltimateUnderlying_IndexProxyPSPInstrumentID'
                                       , 'UltimateUnderlying_FinancialMaturityDate'
                                       , 'UltimateUnderlying_CurrencyCode'
                                      ]
            
            self._fact_index_constituents = self.index_constituents().merge( self.dim_instruments()[columns_dim_instruments]
                                                                           , left_on = ['Constituent_PSPInstrumentID']
                                                                           , right_on = ['Instrument_PSPInstrumentID']
                                                                           , how = 'left'
                                                                           , validate = 'many_to_one'
                                                                           )
            
            self._fact_index_constituents['Constituent_Family']                          = self._fact_index_constituents['UltimateUnderlying_Family']                         
            self._fact_index_constituents['Constituent_PSPInstrumentCategorizationID']   = self._fact_index_constituents['UltimateUnderlying_PSPInstrumentCategorizationID']        
            self._fact_index_constituents['Constituent_PSPInstrumentCategorizationCode'] = self._fact_index_constituents['UltimateUnderlying_PSPInstrumentCategorizationCode']  
            self._fact_index_constituents['Constituent_Description']                     = self._fact_index_constituents['UltimateUnderlying_Description']                       
            self._fact_index_constituents['Constituent_Market']                          = self._fact_index_constituents['UltimateUnderlying_Market']                                 
            self._fact_index_constituents['Constituent_Type']                            = self._fact_index_constituents['UltimateUnderlying_Type']                          
            self._fact_index_constituents['Constituent_IssuerCode']                      = self._fact_index_constituents['UltimateUnderlying_IssuerCode']                  
            self._fact_index_constituents['Constituent_FinancialMaturityDate']           = self._fact_index_constituents['UltimateUnderlying_FinancialMaturityDate']
            self._fact_index_constituents['Constituee_PSPInstrumentID']                  = self._fact_index_constituents['Index_PSPInstrumentID']
            
            self._fact_index_constituents['Constituent_CurrencyCode']                    = self._fact_index_constituents['UltimateUnderlying_CurrencyCode'].fillna( self._fact_index_constituents['Constituent_CurrencyCode'])
            #self._fact_index_constituents['Constituent_AccountingCurrencyCode']          = self._fact_index_constituents['Instrument_CurrencyCode'].fillna(         self._fact_index_constituents['Constituent_CurrencyCode'])
            #self._fact_index_constituents['Constituent_EconomicCurrencyCode']            = self._fact_index_constituents['UltimateUnderlying_CurrencyCode'].fillna( self._fact_index_constituents['Constituent_CurrencyCode'])
            
            self._fact_index_constituents['Constituee_Type']                             = 'Index'
            
            self._fact_index_constituents.loc[(self._fact_index_constituents['Constituent_Family'] == 'Cash'), 'Constituent_IssuerExposureFactor'] = 0.0
            self._fact_index_constituents.loc[(self._fact_index_constituents['Constituent_Family'] != 'Cash'), 'Constituent_IssuerExposureFactor'] = 1.0
            
            self._fact_index_constituents.loc[(self._fact_index_constituents['Constituent_Market'] != 'Equity'), 'Constituent_EquityExposureFactor'] = 0.0
            self._fact_index_constituents.loc[(self._fact_index_constituents['Constituent_Market'] == 'Equity'), 'Constituent_EquityExposureFactor'] = 1.0
            
            self._fact_index_constituents = self._fact_index_constituents[PAC.constituee_columns]
            
        return self._fact_index_constituents
            
    #@#track_execution
    def fact_etf_constituents(self):
        if self._fact_etf_constituents is None:
            columns_dim_instruments = [  'Instrument_PSPInstrumentID'
                                       , 'Instrument_PSPInstrumentCategorizationID'
                                       , 'Instrument_PSPInstrumentCategorizationCode'
                                       , 'Instrument_CurrencyCode'
                                       , 'UltimateUnderlying_Family'
                                       , 'UltimateUnderlying_PSPInstrumentID'
                                       , 'UltimateUnderlying_PSPInstrumentCategorizationID'
                                       , 'UltimateUnderlying_PSPInstrumentCategorizationCode'
                                       , 'UltimateUnderlying_Description'
                                       , 'UltimateUnderlying_Market'
                                       , 'UltimateUnderlying_Type'
                                       , 'UltimateUnderlying_IssuerCode'
                                       , 'UltimateUnderlying_IndexProxyPSPInstrumentID'
                                       , 'UltimateUnderlying_FinancialMaturityDate'
                                       , 'UltimateUnderlying_CurrencyCode'
                                      ]
            
            self._fact_etf_constituents = self.etf_constituents().merge( self.dim_instruments()[columns_dim_instruments]
                                                                       , left_on = ['Constituent_PSPInstrumentID']
                                                                       , right_on = ['Instrument_PSPInstrumentID']
                                                                       , how = 'left'
                                                                       , validate = 'many_to_one'
                                                                       )
            
            self._fact_etf_constituents['Constituent_Family']                          = self._fact_etf_constituents['UltimateUnderlying_Family']             
            self._fact_etf_constituents['Constituent_PSPInstrumentCategorizationID']   = self._fact_etf_constituents['UltimateUnderlying_PSPInstrumentCategorizationID']       
            self._fact_etf_constituents['Constituent_PSPInstrumentCategorizationCode'] = self._fact_etf_constituents['UltimateUnderlying_PSPInstrumentCategorizationCode']  
            self._fact_etf_constituents['Constituent_Description']                     = self._fact_etf_constituents['UltimateUnderlying_Description']                       
            self._fact_etf_constituents['Constituent_Market']                          = self._fact_etf_constituents['UltimateUnderlying_Market']                        
            self._fact_etf_constituents['Constituent_Type']                            = self._fact_etf_constituents['UltimateUnderlying_Type']                              
            self._fact_etf_constituents['Constituent_IssuerCode']                      = self._fact_etf_constituents['UltimateUnderlying_IssuerCode']    
            self._fact_etf_constituents['Constituent_FinancialMaturityDate']           = self._fact_etf_constituents['UltimateUnderlying_FinancialMaturityDate']
            self._fact_etf_constituents['Constituee_PSPInstrumentID']                  = self._fact_etf_constituents['ETF_PSPInstrumentID']
            
            self._fact_etf_constituents['Constituent_CurrencyCode']                    = self._fact_etf_constituents['UltimateUnderlying_CurrencyCode'].fillna(self._fact_etf_constituents['Constituent_CurrencyCode'])
            #self._fact_etf_constituents['Constituent_AccountingCurrencyCode']          = self._fact_etf_constituents['Instrument_CurrencyCode'].fillna(        self._fact_etf_constituents['Constituent_CurrencyCode'])
            #self._fact_etf_constituents['Constituent_EconomicCurrencyCode']            = self._fact_etf_constituents['UltimateUnderlying_CurrencyCode'].fillna(self._fact_etf_constituents['Constituent_CurrencyCode'])
            
            self._fact_etf_constituents['Constituee_Type']                             = 'ETF'
            self._fact_etf_constituents['Constituent_Weight']                          = self._fact_etf_constituents['Constituent_WeightWithCash']
            
            self._fact_etf_constituents = self._fact_etf_constituents.merge(  self.fact_index_constituents()
                                                                           , left_on = ['PositionDate',  'UltimateUnderlying_IndexProxyPSPInstrumentID']
                                                                           , right_on = ['PositionDate', 'Constituee_PSPInstrumentID']
                                                                           , how = 'left'
                                                                           , suffixes = ['','_subIndex']
                                                                           )
            
            self._fact_etf_constituents = self._fact_etf_constituents.merge( self.dim_instruments()[columns_dim_instruments]
                                                                           , left_on = ['Constituent_PSPInstrumentID_subIndex']
                                                                           , right_on = ['Instrument_PSPInstrumentID']
                                                                           , how = 'left'
                                                                           , suffixes = ['','_subIndex']
                                                                           , validate = 'many_to_one'
                                                                           )
            
            self._fact_etf_constituents['Constituent_PSPInstrumentID']                 = self._fact_etf_constituents['UltimateUnderlying_PSPInstrumentID_subIndex'].fillna(                self._fact_etf_constituents['Constituent_PSPInstrumentID'])         
            self._fact_etf_constituents['Constituent_Family']                          = self._fact_etf_constituents['UltimateUnderlying_Family_subIndex'].fillna(                         self._fact_etf_constituents['Constituent_Family'])
            self._fact_etf_constituents['Constituent_PSPInstrumentCategorizationID']   = self._fact_etf_constituents['UltimateUnderlying_PSPInstrumentCategorizationID_subIndex'].fillna(  self._fact_etf_constituents['Constituent_PSPInstrumentCategorizationID'])  
            self._fact_etf_constituents['Constituent_PSPInstrumentCategorizationCode'] = self._fact_etf_constituents['UltimateUnderlying_PSPInstrumentCategorizationCode_subIndex'].fillna(self._fact_etf_constituents['Constituent_PSPInstrumentCategorizationCode'])
            self._fact_etf_constituents['Constituent_Description']                     = self._fact_etf_constituents['UltimateUnderlying_Description_subIndex'].fillna(                    self._fact_etf_constituents['Constituent_Description'])  
            self._fact_etf_constituents['Constituent_Market']                          = self._fact_etf_constituents['UltimateUnderlying_Market_subIndex'].fillna(                         self._fact_etf_constituents['Constituent_Market'])    
            self._fact_etf_constituents['Constituent_Type']                            = self._fact_etf_constituents['UltimateUnderlying_Type_subIndex'].fillna(                           self._fact_etf_constituents['Constituent_Type'])  
            self._fact_etf_constituents['Constituent_IssuerCode']                      = self._fact_etf_constituents['UltimateUnderlying_IssuerCode_subIndex'].fillna(                     self._fact_etf_constituents['Constituent_IssuerCode'])
            self._fact_etf_constituents['Constituent_FinancialMaturityDate']           = self._fact_etf_constituents['UltimateUnderlying_FinancialMaturityDate_subIndex'].fillna(          self._fact_etf_constituents['Constituent_FinancialMaturityDate'])
             
            self._fact_etf_constituents['Constituent_CurrencyCode']                    = self._fact_etf_constituents['UltimateUnderlying_CurrencyCode_subIndex'].fillna(self._fact_etf_constituents['Constituent_CurrencyCode'])
            #self._fact_etf_constituents['Constituent_AccountingCurrencyCode']          = self._fact_etf_constituents['Instrument_CurrencyCode_subIndex'].fillna(        self._fact_etf_constituents['Constituent_AccountingCurrencyCode'])
            #self._fact_etf_constituents['Constituent_EconomicCurrencyCode']            = self._fact_etf_constituents['UltimateUnderlying_CurrencyCode_subIndex'].fillna(self._fact_etf_constituents['Constituent_EconomicCurrencyCode'])
            
            self._fact_etf_constituents['Constituent_Weight']                          = self._fact_etf_constituents['Constituent_Weight'] * self._fact_etf_constituents['Constituent_Weight_subIndex'].fillna(1.0)
            
            self._fact_etf_constituents.loc[(self._fact_etf_constituents['Constituent_Family'] == 'Cash'), 'Constituent_IssuerExposureFactor'] = 0.0
            self._fact_etf_constituents.loc[(self._fact_etf_constituents['Constituent_Family'] != 'Cash'), 'Constituent_IssuerExposureFactor'] = 1.0
            
            self._fact_etf_constituents.loc[(self._fact_etf_constituents['Constituent_Market'] != 'Equity'), 'Constituent_EquityExposureFactor'] = 0.0
            self._fact_etf_constituents.loc[(self._fact_etf_constituents['Constituent_Market'] == 'Equity'), 'Constituent_EquityExposureFactor'] = 1.0
            
            agg_columns = [row for row in PAC.constituee_columns if row != 'Constituent_Weight']
            self._fact_etf_constituents = self._fact_etf_constituents[PAC.constituee_columns].groupby(agg_columns, dropna = False).sum(numeric_only = True).reset_index()
            
            self._fact_etf_constituents = self._fact_etf_constituents[PAC.constituee_columns]
                
        return self._fact_etf_constituents
            

    #@#track_execution        
    def fact_basket_constituents(self):
        if self._fact_basket_constituents is None:
            columns_dim_instruments = [  'Instrument_PSPInstrumentID'
                                       , 'Instrument_PSPInstrumentCategorizationID'
                                       , 'Instrument_PSPInstrumentCategorizationCode'
                                       , 'Instrument_CurrencyCode'
                                       , 'UltimateUnderlying_Family'
                                       , 'UltimateUnderlying_PSPInstrumentID'
                                       , 'UltimateUnderlying_PSPInstrumentCategorizationID'
                                       , 'UltimateUnderlying_PSPInstrumentCategorizationCode'
                                       , 'UltimateUnderlying_Description'
                                       , 'UltimateUnderlying_Market'
                                       , 'UltimateUnderlying_Type'
                                       , 'UltimateUnderlying_IssuerCode'
                                       , 'UltimateUnderlying_IndexProxyPSPInstrumentID'
                                       , 'UltimateUnderlying_FinancialMaturityDate'
                                       , 'UltimateUnderlying_CurrencyCode'
                                      ]
            self._fact_basket_constituents = self.basket_constituents().merge( self.dim_instruments()[columns_dim_instruments]
                                                                             , left_on = ['Constituent_PSPInstrumentID']
                                                                             , right_on = ['Instrument_PSPInstrumentID']
                                                                             , how = 'left'
                                                                             , validate = 'many_to_one'
                                                                             )
            
            self._fact_basket_constituents['Constituent_Family']                          = self._fact_basket_constituents['UltimateUnderlying_Family']             
            self._fact_basket_constituents['Constituent_PSPInstrumentCategorizationID']   = self._fact_basket_constituents['UltimateUnderlying_PSPInstrumentCategorizationID']       
            self._fact_basket_constituents['Constituent_PSPInstrumentCategorizationCode'] = self._fact_basket_constituents['UltimateUnderlying_PSPInstrumentCategorizationCode']  
            self._fact_basket_constituents['Constituent_Description']                     = self._fact_basket_constituents['UltimateUnderlying_Description']                       
            self._fact_basket_constituents['Constituent_Market']                          = self._fact_basket_constituents['UltimateUnderlying_Market']                        
            self._fact_basket_constituents['Constituent_Type']                            = self._fact_basket_constituents['UltimateUnderlying_Type']                              
            self._fact_basket_constituents['Constituent_IssuerCode']                      = self._fact_basket_constituents['UltimateUnderlying_IssuerCode']    
            self._fact_basket_constituents['Constituent_FinancialMaturityDate']           = self._fact_basket_constituents['UltimateUnderlying_FinancialMaturityDate']
            self._fact_basket_constituents['Constituee_PSPInstrumentID']                  = self._fact_basket_constituents['Basket_PSPInstrumentID']
            
            self._fact_basket_constituents['Constituent_CurrencyCode']                    = self._fact_basket_constituents['UltimateUnderlying_CurrencyCode'].fillna(self._fact_basket_constituents['Constituent_CurrencyCode'])
            #self._fact_basket_constituents['Constituent_AccountingCurrencyCode']          = self._fact_basket_constituents['Instrument_CurrencyCode'].fillna(        self._fact_basket_constituents['Constituent_CurrencyCode'])
            #self._fact_basket_constituents['Constituent_EconomicCurrencyCode']            = self._fact_basket_constituents['UltimateUnderlying_CurrencyCode'].fillna(self._fact_basket_constituents['Constituent_CurrencyCode'])
            
            self._fact_basket_constituents['Constituee_Type']                             = 'Basket'
            self._fact_basket_constituents['Constituent_Weight']                          = self._fact_basket_constituents['Constituent_Weight']
            
            self._fact_basket_constituents = self._fact_basket_constituents.merge(  self.fact_index_constituents()
                                                                                  , left_on = ['PositionDate',  'UltimateUnderlying_IndexProxyPSPInstrumentID']
                                                                                  , right_on = ['PositionDate', 'Constituee_PSPInstrumentID']
                                                                                  , how = 'left'
                                                                                  , suffixes = ['','_subIndex']
                                                                                 )
            
            self._fact_basket_constituents = self._fact_basket_constituents.merge( self.dim_instruments()[columns_dim_instruments]
                                                                           , left_on = ['Constituent_PSPInstrumentID_subIndex']
                                                                           , right_on = ['Instrument_PSPInstrumentID']
                                                                           , how = 'left'
                                                                           , suffixes = ['','_subIndex']
                                                                           , validate = 'many_to_one'
                                                                           )
            
            self._fact_basket_constituents['Constituent_PSPInstrumentID']                 = self._fact_basket_constituents['UltimateUnderlying_PSPInstrumentID_subIndex'].fillna(                self._fact_basket_constituents['Constituent_PSPInstrumentID'])         
            self._fact_basket_constituents['Constituent_Family']                          = self._fact_basket_constituents['UltimateUnderlying_Family_subIndex'].fillna(                         self._fact_basket_constituents['Constituent_Family'])
            self._fact_basket_constituents['Constituent_PSPInstrumentCategorizationID']   = self._fact_basket_constituents['UltimateUnderlying_PSPInstrumentCategorizationID_subIndex'].fillna(  self._fact_basket_constituents['Constituent_PSPInstrumentCategorizationID'])  
            self._fact_basket_constituents['Constituent_PSPInstrumentCategorizationCode'] = self._fact_basket_constituents['UltimateUnderlying_PSPInstrumentCategorizationCode_subIndex'].fillna(self._fact_basket_constituents['Constituent_PSPInstrumentCategorizationCode'])
            self._fact_basket_constituents['Constituent_Description']                     = self._fact_basket_constituents['UltimateUnderlying_Description_subIndex'].fillna(                    self._fact_basket_constituents['Constituent_Description'])  
            self._fact_basket_constituents['Constituent_Market']                          = self._fact_basket_constituents['UltimateUnderlying_Market_subIndex'].fillna(                         self._fact_basket_constituents['Constituent_Market'])    
            self._fact_basket_constituents['Constituent_Type']                            = self._fact_basket_constituents['UltimateUnderlying_Type_subIndex'].fillna(                           self._fact_basket_constituents['Constituent_Type'])  
            self._fact_basket_constituents['Constituent_IssuerCode']                      = self._fact_basket_constituents['UltimateUnderlying_IssuerCode_subIndex'].fillna(                     self._fact_basket_constituents['Constituent_IssuerCode'])
            self._fact_basket_constituents['Constituent_FinancialMaturityDate']           = self._fact_basket_constituents['UltimateUnderlying_FinancialMaturityDate_subIndex'].fillna(          self._fact_basket_constituents['Constituent_FinancialMaturityDate'])
            
            self._fact_basket_constituents['Constituent_CurrencyCode']                    = self._fact_basket_constituents['UltimateUnderlying_CurrencyCode_subIndex'].fillna( self._fact_basket_constituents['Constituent_CurrencyCode'])
            #self._fact_basket_constituents['Constituent_AccountingCurrencyCode']          = self._fact_basket_constituents['Instrument_CurrencyCode_subIndex'].fillna(         self._fact_basket_constituents['Constituent_AccountingCurrencyCode'])
            #self._fact_basket_constituents['Constituent_EconomicCurrencyCode']            = self._fact_basket_constituents['UltimateUnderlying_CurrencyCode_subIndex'].fillna( self._fact_basket_constituents['Constituent_EconomicCurrencyCode'])
            
            self._fact_basket_constituents['Constituent_Weight']                          = self._fact_basket_constituents['Constituent_Weight'] * self._fact_basket_constituents['Constituent_Weight_subIndex'].fillna(1.0)
            
            self._fact_basket_constituents.loc[(self._fact_basket_constituents['Constituent_Family'] == 'Cash'), 'Constituent_IssuerExposureFactor'] = 0.0
            self._fact_basket_constituents.loc[(self._fact_basket_constituents['Constituent_Family'] != 'Cash'), 'Constituent_IssuerExposureFactor'] = 1.0
            
            self._fact_basket_constituents.loc[(self._fact_basket_constituents['Constituent_Market'] != 'Equity'), 'Constituent_EquityExposureFactor'] = 0.0
            self._fact_basket_constituents.loc[(self._fact_basket_constituents['Constituent_Market'] == 'Equity'), 'Constituent_EquityExposureFactor'] = 1.0
            
            agg_columns = [row for row in PAC.constituee_columns if row != 'Constituent_Weight']
            self._fact_basket_constituents = self._fact_basket_constituents[PAC.constituee_columns].groupby(agg_columns, dropna = False).sum(numeric_only = True).reset_index()
            
            self._fact_basket_constituents = self._fact_basket_constituents[PAC.constituee_columns]
        
        return self._fact_basket_constituents

    def fact_constituents(self):
        if self._fact_constituents is None:
            columns_dim_instruments = [  'Instrument_PSPInstrumentID'
                                       , 'Instrument_PSPInstrumentCategorizationID'
                                       , 'Instrument_PSPInstrumentCategorizationCode'
                                       , 'Instrument_CurrencyCode'
                                       , 'UltimateUnderlying_Family'
                                       , 'UltimateUnderlying_PSPInstrumentID'
                                       , 'UltimateUnderlying_PSPInstrumentCategorizationID'
                                       , 'UltimateUnderlying_PSPInstrumentCategorizationCode'
                                       , 'UltimateUnderlying_Description'
                                       , 'UltimateUnderlying_Market'
                                       , 'UltimateUnderlying_Type'
                                       , 'UltimateUnderlying_IssuerCode'
                                       , 'UltimateUnderlying_IndexProxyPSPInstrumentID'
                                       , 'UltimateUnderlying_FinancialMaturityDate'
                                       , 'UltimateUnderlying_CurrencyCode'
                                      ]
            self._fact_constituents = self.constituents().merge( self.dim_instruments()[columns_dim_instruments]
                                                                             , left_on = ['Constituent_PSPInstrumentID']
                                                                             , right_on = ['Instrument_PSPInstrumentID']
                                                                             , how = 'left'
                                                                             , validate = 'many_to_one'
                                                                             )
            
            self._fact_constituents['Constituent_Family']                          = self._fact_constituents['UltimateUnderlying_Family']             
            self._fact_constituents['Constituent_PSPInstrumentCategorizationID']   = self._fact_constituents['UltimateUnderlying_PSPInstrumentCategorizationID']       
            self._fact_constituents['Constituent_PSPInstrumentCategorizationCode'] = self._fact_constituents['UltimateUnderlying_PSPInstrumentCategorizationCode']  
            self._fact_constituents['Constituent_Description']                     = self._fact_constituents['UltimateUnderlying_Description']                       
            self._fact_constituents['Constituent_Market']                          = self._fact_constituents['UltimateUnderlying_Market']                        
            self._fact_constituents['Constituent_Type']                            = self._fact_constituents['UltimateUnderlying_Type']                              
            self._fact_constituents['Constituent_IssuerCode']                      = self._fact_constituents['UltimateUnderlying_IssuerCode']    
            self._fact_constituents['Constituent_FinancialMaturityDate']           = self._fact_constituents['UltimateUnderlying_FinancialMaturityDate']
            #self._fact_constituents['Constituee_PSPInstrumentID']                  = self._fact_constituents['Basket_PSPInstrumentID']
            self._fact_constituents['Constituent_CurrencyCode']                    = self._fact_constituents['UltimateUnderlying_CurrencyCode'].fillna(self._fact_constituents['Constituent_CurrencyCode'])
        
            self._fact_constituents = self._fact_constituents.merge(  self.constituents()
                                                                    , left_on = ['PositionDate',  'UltimateUnderlying_IndexProxyPSPInstrumentID']
                                                                    , right_on = ['PositionDate', 'Constituee_PSPInstrumentID']
                                                                    , how = 'left'
                                                                    , suffixes = ['','_subIndex']
                                                                    )
            
            self._fact_constituents = self._fact_constituents.merge( self.dim_instruments()[columns_dim_instruments]
                                                                    , left_on = ['Constituent_PSPInstrumentID_subIndex']
                                                                    , right_on = ['Instrument_PSPInstrumentID']
                                                                    , how = 'left'
                                                                    , suffixes = ['','_subIndex']
                                                                    , validate = 'many_to_one'
                                                                    )
            
            self._fact_constituents['Constituent_PSPInstrumentID']                 = self._fact_constituents['UltimateUnderlying_PSPInstrumentID_subIndex'].fillna(                self._fact_constituents['Constituent_PSPInstrumentID'])         
            self._fact_constituents['Constituent_Family']                          = self._fact_constituents['UltimateUnderlying_Family_subIndex'].fillna(                         self._fact_constituents['Constituent_Family'])
            self._fact_constituents['Constituent_PSPInstrumentCategorizationID']   = self._fact_constituents['UltimateUnderlying_PSPInstrumentCategorizationID_subIndex'].fillna(  self._fact_constituents['Constituent_PSPInstrumentCategorizationID'])  
            self._fact_constituents['Constituent_PSPInstrumentCategorizationCode'] = self._fact_constituents['UltimateUnderlying_PSPInstrumentCategorizationCode_subIndex'].fillna(self._fact_constituents['Constituent_PSPInstrumentCategorizationCode'])
            self._fact_constituents['Constituent_Description']                     = self._fact_constituents['UltimateUnderlying_Description_subIndex'].fillna(                    self._fact_constituents['Constituent_Description'])  
            self._fact_constituents['Constituent_Market']                          = self._fact_constituents['UltimateUnderlying_Market_subIndex'].fillna(                         self._fact_constituents['Constituent_Market'])    
            self._fact_constituents['Constituent_Type']                            = self._fact_constituents['UltimateUnderlying_Type_subIndex'].fillna(                           self._fact_constituents['Constituent_Type'])  
            self._fact_constituents['Constituent_IssuerCode']                      = self._fact_constituents['UltimateUnderlying_IssuerCode_subIndex'].fillna(                     self._fact_constituents['Constituent_IssuerCode'])
            self._fact_constituents['Constituent_FinancialMaturityDate']           = self._fact_constituents['UltimateUnderlying_FinancialMaturityDate_subIndex'].fillna(          self._fact_constituents['Constituent_FinancialMaturityDate'])
            
            self._fact_constituents['Constituent_CurrencyCode']                    = self._fact_constituents['UltimateUnderlying_CurrencyCode_subIndex'].fillna( self._fact_constituents['Constituent_CurrencyCode'])

            self._fact_constituents['Constituent_Weight']                          = self._fact_constituents['Constituent_Weight'] * self._fact_constituents['Constituent_Weight_subIndex'].fillna(1.0)
            
            self._fact_constituents.loc[(self._fact_constituents['Constituent_Family'] == 'Cash'), 'Constituent_IssuerExposureFactor'] = 0.0
            self._fact_constituents.loc[(self._fact_constituents['Constituent_Family'] != 'Cash'), 'Constituent_IssuerExposureFactor'] = 1.0
            
            self._fact_constituents.loc[(self._fact_constituents['Constituent_Market'] != 'Equity'), 'Constituent_EquityExposureFactor'] = 0.0
            self._fact_constituents.loc[(self._fact_constituents['Constituent_Market'] == 'Equity'), 'Constituent_EquityExposureFactor'] = 1.0
            
            agg_columns = [row for row in PAC.constituee_columns if row != 'Constituent_Weight']
            self._fact_constituents = self._fact_constituents[PAC.constituee_columns].groupby(agg_columns, dropna = False).sum(numeric_only = True).reset_index()
            
            self._fact_constituents = self._fact_constituents[PAC.constituee_columns]
        
        return self._fact_constituents


            
    #@#track_execution       
    def fact_credit_constituents(self):
        if self._fact_credit_constituents is None:
            self._fact_credit_constituents = self.credit_constituents()
            
            self._fact_credit_constituents['Constituent_Family']                          = 'Credit'                           
            self._fact_credit_constituents['Constituent_PSPInstrumentID']                 = 0                        
            self._fact_credit_constituents['Constituent_PSPInstrumentCategorizationID']   = 0
            self._fact_credit_constituents['Constituent_PSPInstrumentCategorizationCode'] = 'None'
            self._fact_credit_constituents['Constituent_Description']                     = self._fact_credit_constituents['Constituent_IssuerName'] + '-' + self._fact_credit_constituents['Constituent_DebtTierDescription']                
            self._fact_credit_constituents['Constituent_Market']                          = 'Credit'                              
            self._fact_credit_constituents['Constituent_Type']                            = self._fact_credit_constituents['Constituent_DebtTierDescription']                                  
            self._fact_credit_constituents['Constituee_PSPInstrumentID']                  = self._fact_credit_constituents['CreditIndex_PSPInstrumentID']
            
            #self._fact_credit_constituents['Constituent_AccountingCurrencyCode']          = self._fact_credit_constituents['Constituent_CurrencyCode']
            #self._fact_credit_constituents['Constituent_EconomicCurrencyCode']            = self._fact_credit_constituents['Constituent_CurrencyCode']
            
            self._fact_credit_constituents['Constituee_Type']                             = 'Credit Index'
            
            self._fact_credit_constituents['Constituent_IssuerExposureFactor'] = 1.0
            self._fact_credit_constituents['Constituent_EquityExposureFactor'] = 0.0
            
            self._fact_credit_constituents = self._fact_credit_constituents#[PAC.constituee_columns]
            self._fact_credit_constituents = self._fact_credit_constituents.drop(columns = ['CreditIndex_PSPInstrumentID','Constituent_DebtTierDescription'])
            
        return self._fact_credit_constituents

    def fact_all_constituents(self):
        return pd.concat([ self.fact_credit_constituents()
                         #, self.fact_basket_constituents()
                         #, self.fact_etf_constituents()
                         #, self.fact_index_constituents()
                         , self.fact_constituents()]
                         ).dropna(subset = ['Constituent_CurrencyCode'])

    #@#track_execution
    def fact_benchmarks(self):
        if self._fact_benchmarks is None:
            self._fact_benchmarks = self.benchmarks().copy(deep = True)
            #self._fact_benchmarks = self._fact_benchmarks.merge(self.index_constituents(), left_on = [], right_on = [], how = 'left', suffixes = ['','_'])
            
            #self._fact_positions['is_pooled_fund'] = self._fact_positions['Instrument_PSPInstrumentCategorizationID'].map(lambda x: 1 if x in PAC.pooled_fund_psp_instrument_categorization_codes else 0)
        
            #fact_positions_nopf = fact_positions[fact_positions['is_pooled_fund'] == 0]
            #fact_positions_ispf = fact_positions[fact_positions['is_pooled_fund'] == 1]
        
            #Treat non-pooled funds
            #self._fact_positions = self._fact_positions.merge(self.swap_legs()[['Instrument_PSPInstrumentID','Leg_PSPInstrumentLegID','Leg_Type', 'Leg_LastResetDate', 'Leg_Direction']], on = ['Instrument_PSPInstrumentID','Leg_PSPInstrumentLegID'], how = 'left')
        
        return self._fact_benchmarks

    #@#track_execution
    def fact_portfolios(self):
        if self._fact_portfolios is None:
            temp_columns = [  'PositionDate'
                            , 'Portfolio_PSPPortfolioCode'
                            , 'Portfolio_PSPPortfolioID'
                            , 'Portfolio_Name'
                            , 'Portfolio_MarketType'
                            , 'Portfolio_AssetClass'
                            , 'Portfolio_InvestmentTeam'
                            , 'Portfolio_ManagerType'
                            , 'Portfolio_ManagingStyle'
                            , 'Portfolio_ManagingDepartment'
                            , 'Portfolio_OwnerDepartment'
                            , 'Position_MarketValue_CAD'
                            , 'Position_NetAssetValue_CAD'
                            , 'Instrument_PSPInstrumentCategorizationID'
                           ]
            
            temp_positions = self.fact_positions()[temp_columns].copy(deep = True)
            
            temp_positions['is_position']    = 1
            temp_positions['is_pooled_fund'] = temp_positions['Instrument_PSPInstrumentCategorizationID'].map(lambda x: 1 if x in PAC.pooled_fund_psp_instrument_categorization_codes else 0)
            temp_positions['PooledFund_MarketValue_CAD']   = temp_positions['is_pooled_fund'] * temp_positions['Position_MarketValue_CAD']
            temp_positions['PooledFund_NetAssetValue_CAD'] = temp_positions['is_pooled_fund'] * temp_positions['Position_NetAssetValue_CAD']
            
            self._fact_portfolios = temp_positions[[ 'PositionDate'
                                                   , 'Portfolio_PSPPortfolioCode'
                                                   , 'Portfolio_PSPPortfolioID'
                                                   , 'Portfolio_Name'
                                                   , 'Portfolio_MarketType'
                                                   , 'Portfolio_AssetClass'
                                                   , 'Portfolio_InvestmentTeam'
                                                   , 'Portfolio_ManagerType'
                                                   , 'Portfolio_ManagingStyle'
                                                   , 'Portfolio_ManagingDepartment'
                                                   , 'Portfolio_OwnerDepartment'
                                                   , 'is_position'
                                                   , 'Position_MarketValue_CAD'
                                                   , 'Position_NetAssetValue_CAD'
                                                   , 'is_pooled_fund'
                                                   , 'PooledFund_MarketValue_CAD'
                                                   , 'PooledFund_NetAssetValue_CAD'
                                                  ]].groupby( by = [  'PositionDate'
                                                                    , 'Portfolio_PSPPortfolioCode'
                                                                    , 'Portfolio_PSPPortfolioID'
                                                                    , 'Portfolio_Name'
                                                                    , 'Portfolio_MarketType'
                                                                    , 'Portfolio_AssetClass'
                                                                    , 'Portfolio_InvestmentTeam'
                                                                    , 'Portfolio_ManagerType'
                                                                    , 'Portfolio_ManagingStyle'
                                                                    , 'Portfolio_ManagingDepartment'
                                                                    , 'Portfolio_OwnerDepartment'
                                                                   ]
                                                             , dropna = False
                                                            ).agg(  Portfolio_Position_Count               = pd.NamedAgg( column = 'is_position',                  aggfunc='sum')
                                                                  , Portfolio_Position_MarketValue_CAD     = pd.NamedAgg( column = 'Position_MarketValue_CAD',     aggfunc='sum')
                                                                  , Portfolio_Position_NetAssetValue_CAD   = pd.NamedAgg( column = 'Position_NetAssetValue_CAD',   aggfunc='sum')
                                                                  , Portfolio_PooledFund_Count             = pd.NamedAgg( column = 'is_pooled_fund',               aggfunc='sum')
                                                                  , Portfolio_PooledFund_MarketValue_CAD   = pd.NamedAgg( column = 'PooledFund_MarketValue_CAD',   aggfunc='sum')
                                                                  , Portfolio_PooledFund_NetAssetValue_CAD = pd.NamedAgg( column = 'PooledFund_NetAssetValue_CAD', aggfunc='sum')
                                                                 ).reset_index()
            
            self._fact_portfolios['Portfolio_Internal_Count']             = self._fact_portfolios['Portfolio_Position_Count']             - self._fact_portfolios['Portfolio_PooledFund_Count']              
            self._fact_portfolios['Portfolio_Internal_MarketValue_CAD']   = self._fact_portfolios['Portfolio_Position_MarketValue_CAD']   - self._fact_portfolios['Portfolio_PooledFund_MarketValue_CAD']    
            self._fact_portfolios['Portfolio_Internal_NetAssetValue_CAD'] = self._fact_portfolios['Portfolio_Position_NetAssetValue_CAD'] - self._fact_portfolios['Portfolio_PooledFund_NetAssetValue_CAD']  
            
            self._fact_portfolios['Portfolio_Type'] = self._fact_portfolios['Portfolio_PooledFund_Count'].map(lambda x: 'Pooled Fund' if x > 0 else 'Internal')
            self._fact_portfolios = self._fact_portfolios[[  'PositionDate'
                                                           , 'Portfolio_PSPPortfolioCode'
                                                           , 'Portfolio_PSPPortfolioID'
                                                           , 'Portfolio_Name'
                                                           , 'Portfolio_Type'
                                                           , 'Portfolio_MarketType'
                                                           , 'Portfolio_AssetClass'
                                                           , 'Portfolio_InvestmentTeam'
                                                           , 'Portfolio_ManagerType'
                                                           , 'Portfolio_ManagingStyle'
                                                           , 'Portfolio_ManagingDepartment'
                                                           , 'Portfolio_OwnerDepartment'
                                                           , 'Portfolio_Position_Count'
                                                           , 'Portfolio_Position_MarketValue_CAD'
                                                           , 'Portfolio_Position_NetAssetValue_CAD'
                                                           , 'Portfolio_Internal_Count'
                                                           , 'Portfolio_Internal_MarketValue_CAD'
                                                           , 'Portfolio_Internal_NetAssetValue_CAD'
                                                           , 'Portfolio_PooledFund_Count'
                                                           , 'Portfolio_PooledFund_MarketValue_CAD'
                                                           , 'Portfolio_PooledFund_NetAssetValue_CAD'
                                                          ]]

        return self._fact_portfolios
    
    def fact_portfolios_scaling(self):
        if self._fact_portfolios_scaling is None:
            
            # NEW MODIF
            portfolio_mra_batch_mapping = self.fact_portfolios().copy()
            portfolio_mra_batch_mapping = portfolio_mra_batch_mapping.merge(  self.mra_batch_mapping()
                                                                        , left_on = ['PositionDate','Portfolio_PSPPortfolioID']
                                                                        , right_on = ['CalendarDate','PortfolioID']
                                                                        , how = 'left'
                                                                        , validate = 'one_to_one'
                                                                        )[[  'PositionDate'
                                                                            ,'Portfolio_PSPPortfolioID'
                                                                            ,'Portfolio_PSPPortfolioCode'
                                                                            ,'Portfolio_Key'
                                                                            ,'MostRecent_CalendarKey'
                                                                            ,'MostRecent_Batch_key'
                                                                            ,'Portfolio_Position_NetAssetValue_CAD'
                                                                        ]]

            portfolio_data_no_scale                 = self.fact_portfolios_V2()[self.fact_portfolios_V2()['Portfolio_Type'] != 'Pooled Fund with Constituents'].copy(deep = True)
            portfolio_data_no_scale['do_not_scale'] = 1

            fact_positions_all_with_mra = self.fact_positions_all_with_mra().copy()
            fact_positions_all_with_mra = fact_positions_all_with_mra[fact_positions_all_with_mra['Object_Type'] == 'Portfolio']

            fact_positions_all_with_mra = fact_positions_all_with_mra.groupby(['PositionDate','Portfolio_PSPPortfolioCode'], dropna = False, as_index = False)\
                                                .agg(Portfolio_PresentValue = pd.NamedAgg('Position_NetAssetValue_CAD', aggfunc = 'sum'))

            self._fact_portfolios_scaling = portfolio_mra_batch_mapping.merge(  fact_positions_all_with_mra
                                                                              , on = ['PositionDate','Portfolio_PSPPortfolioCode']
                                                                              , validate = 'one_to_one'
                                                                              , how = 'left'
                                                                              )

            self._fact_portfolios_scaling = self._fact_portfolios_scaling.merge(  portfolio_data_no_scale
                                                                                , on = ['PositionDate','Portfolio_PSPPortfolioCode']
                                                                                , how = 'left'
                                                                                , validate = 'one_to_one'
                                                                                )
            self._fact_portfolios_scaling['do_not_scale'] = self._fact_portfolios_scaling['do_not_scale'].fillna(0)
            
            self._fact_portfolios_scaling['Ratio_NAV_PresentValue'] = self._fact_portfolios_scaling['Portfolio_Position_NetAssetValue_CAD'] / self._fact_portfolios_scaling['Portfolio_PresentValue'].fillna(1.0).replace([np.inf, -np.inf], 1.0)

            no_scale_filter = (self._fact_portfolios_scaling['do_not_scale'] == 1)
            self._fact_portfolios_scaling.loc[no_scale_filter, 'Final_Ratio_NAV_PresentValue']  = 1.0
            self._fact_portfolios_scaling.loc[~no_scale_filter, 'Final_Ratio_NAV_PresentValue'] = self._fact_portfolios_scaling.loc[~no_scale_filter, 'Ratio_NAV_PresentValue']
           
            # BEFORE
            # portfolio_mra_batch_mapping = self.fact_portfolios().copy()
            # portfolio_mra_batch_mapping = portfolio_mra_batch_mapping.merge(  self.mra_batch_mapping()
            #                                                             , left_on = ['PositionDate','Portfolio_PSPPortfolioID']
            #                                                             , right_on = ['CalendarDate','PortfolioID']
            #                                                             , how = 'left'
            #                                                             , validate = 'one_to_one'
            #                                                             )[[  'PositionDate'
            #                                                                 ,'Portfolio_PSPPortfolioID'
            #                                                                 ,'Portfolio_Key'
            #                                                                 ,'MostRecent_CalendarKey'
            #                                                                 ,'MostRecent_Batch_key'
            #                                                                 ,'Portfolio_Position_NetAssetValue_CAD'
            #                                                             ]]


            # fact_mra_data_currency = self.fact_mra_data_currency().copy()
            # fact_mra_data_currency = fact_mra_data_currency[fact_mra_data_currency['Object_Type'] == 'Portfolio']

            # fact_mra_data_currency = fact_mra_data_currency.groupby(['PositionDate','PortfolioID'], dropna = False, as_index = False)\
            #                                     .agg(Portfolio_PresentValue = pd.NamedAgg('Position_PresentValue', aggfunc = 'sum'))
            # fact_mra_data_currency['has_MRA_data'] = 1

            # self._fact_portfolios_scaling = portfolio_mra_batch_mapping.merge(fact_mra_data_currency
            #                             ,left_on = ['PositionDate','Portfolio_PSPPortfolioID']
            #                             ,right_on = ['PositionDate','PortfolioID']
            #                             ,validate = 'one_to_one'
            #                             ,how = 'left'
            #                             ).drop(columns = 'PortfolioID')

            # self._fact_portfolios_scaling['has_MRA_data'].fillna(0, inplace = True)
            # self._fact_portfolios_scaling['Ratio_NAV_PresentValue'] = self._fact_portfolios_scaling['Portfolio_Position_NetAssetValue_CAD'] / self._fact_portfolios_scaling['Portfolio_PresentValue']

            # #scale only for portfolio for which we have data in MRA
            # self._fact_portfolios_scaling['Final_Ratio_NAV_PresentValue'] = self._fact_portfolios_scaling.apply(lambda x: x['Ratio_NAV_PresentValue'] if x['has_MRA_data'] == 1 else 1, axis = 1)

            # #scale only for pooled funds
            # #pooled_funds_ids_MRA = self.fact_pooled_funds()['Portfolio_PSPPortfolioID'].unique()
            # self._fact_portfolios_scaling['Final_Ratio_NAV_PresentValue'] = self._fact_portfolios_scaling\
            #     .apply(lambda x: x['Final_Ratio_NAV_PresentValue'] if x['Portfolio_PSPPortfolioID'] in self.pooled_fund_mra_psp_portfolio_ids() else 1, axis = 1)

        return self._fact_portfolios_scaling
        
    #@#track_execution
    def fact_portfolios_detailed(self):
        if self._fact_portfolios_detailed is None:
            self._fact_portfolios_detailed = self.fact_portfolios()

            key = ['PositionDate','Portfolio_PSPPortfolioCode']
            data = ['Position_NetAssetValue_CAD','Exposure_FI','Exposure_CR','Exposure_Issuer','Exposure_Equity','Exposure_FX','Exposure_Commodity']

            temp_exposure_non_extended_agg = self.fact_exposure_non_extended()[key + data].groupby(by = key, dropna = False).sum(numeric_only = True).reset_index()
            self._fact_portfolios_detailed = self._fact_portfolios_detailed.merge(temp_exposure_non_extended_agg
                                                                                 , on = key
                                                                                 , how = 'left')
            
        return self._fact_portfolios_detailed
                                                                                                                            
    #@#track_execution
    def fact_pooled_funds(self):
        if self._fact_pooled_funds is None:
            if self.has_pooled_funds():
                
                fact_pooled_funds = self.fact_mra_data()[(self.fact_mra_data()['Instrument_PSPInstrumentID']>0)&(self.fact_mra_data()['Object_Type'] == 'Portfolio')]
                fact_pooled_funds = fact_pooled_funds.copy()[fact_pooled_funds['PortfolioID'].isin(self.pooled_fund_psp_portfolio_ids())]\
                                                    .rename({'CalendarDate': 'PositionDate'
                                                            ,'MostRecent_CalendarKey': 'PooledFundDate'
                                                            ,'PortfolioID': 'Portfolio_PSPPortfolioID'}, axis=1)\
                                                            [['PositionDate','PooledFundDate','Portfolio_PSPPortfolioID','Instrument_PSPInstrumentID','Instrument_CurrencyCode']]
                fact_pooled_funds = fact_pooled_funds.groupby(['PositionDate','PooledFundDate','Portfolio_PSPPortfolioID','Instrument_PSPInstrumentID','Instrument_CurrencyCode'],dropna = False, as_index=False).sum(numeric_only = True)
                fact_pooled_funds = fact_pooled_funds.merge(  self.dim_instruments().drop(columns = 'Instrument_CurrencyCode')
                                                            , on = 'Instrument_PSPInstrumentID'
                                                            , how = 'left'
                                                            , suffixes = ['','_y']
                                                            , validate = 'many_to_one'
                                                        )

                fact_pooled_funds['Position_AccruedInterestAmount'] = 0
                #self._fact_pooled_funds['PooledFund_NetAssetValue_CAD'] = self._fact_pooled_funds['PooledFund_MarketValueInCAD']
                fact_pooled_funds['Position_TaxReclaimValue_CAD'] = 0
                fact_pooled_funds['Position_ExposureValue_CAD'] = 0

                self._fact_pooled_funds = fact_pooled_funds

            else:
                self._fact_pooled_funds = pd.DataFrame(columns = PAC.pooled_funds_ratio_columns)   

                      
        return self._fact_pooled_funds

    ####################################################################################################
    ### 4 Positions Facts ##############################################################################
    ####################################################################################################
    
    #@#track_execution
    def fact_positions_pooled_funds_with_constituents(self):
        if self._fact_positions_pooled_funds_with_constituents is None:
            
            self.fact_positions_pooled_funds()
            self._fact_positions_pooled_funds_with_constituents = self.fact_positions_pooled_funds()[self.fact_positions_pooled_funds()['Position_Type'] == 'Pooled Fund/Private Membership with Data'].copy(deep = True)
            
        return self._fact_positions_pooled_funds_with_constituents
    
    ##@#track_execution
    #def fact_positions_pooled_funds_without_constituents(self):
    #    if self._fact_positions_pooled_funds_without_constituents is None:
    #        
    #        self._fact_positions_pooled_funds_without_constituents = self.fact_positions_pooled_funds()[self.fact_positions_pooled_funds()['Position_Type'] == 'Pooled Fund/Private Membership without Data'].copy(deep = True)
    #    
    #        ###########################################################################################################################################################
    #        #Start Fix 2023-03-09: Delete all pooled_funds_without_constituents elements for which, for a date and a PSPortfolioCode, we have some ghost associated
    #        mra_ghost_coverage = self.fact_positions_mra_ghost()[['Portfolio_PSPPortfolioCode','PositionDate']].drop_duplicates()
    #        mra_ghost_coverage['has_ghost'] = 1
    #        
    #        self._fact_positions_pooled_funds_without_constituents = self._fact_positions_pooled_funds_without_constituents.merge(  mra_ghost_coverage
    #                                                                                                                              , on = ['Portfolio_PSPPortfolioCode','PositionDate']
    #                                                                                                                              , how = 'left'
    #                                                                                                                              )
    #        self._fact_positions_pooled_funds_without_constituents['has_ghost'] = self._fact_positions_pooled_funds_without_constituents['has_ghost'].fillna(0)
    #        
    #        self._fact_positions_pooled_funds_without_constituents = self._fact_positions_pooled_funds_without_constituents[self._fact_positions_pooled_funds_without_constituents['has_ghost'] == 0].drop(columns = ['has_ghost']).copy(deep = True)
    #        #End Fix 2023-03-09: Delete all pooled_funds_without_constituents elements for which, for a date and a PSPortfolioCode, we have some ghost associated
    #        ###########################################################################################################################################################
    #        
    #    return self._fact_positions_pooled_funds_without_constituents
        
    #@#track_execution
    def fact_positions_pooled_funds(self):
        if self._fact_positions_pooled_funds is None:
            if self.has_pooled_funds():
                
                private_portfolios = self.fact_positions_private_markets()[['PositionDate','Portfolio_PSPPortfolioCode']].drop_duplicates()
                private_portfolios['is_private'] = 1

                self._fact_positions_pooled_funds = self.fact_positions().merge(private_portfolios, on = ['PositionDate','Portfolio_PSPPortfolioCode'], how = 'left')
                self._fact_positions_pooled_funds.loc[self._fact_positions_pooled_funds['is_private'] == 1, ['Position_Type']] = 'Private Market'
                self._fact_positions_pooled_funds = self._fact_positions_pooled_funds.drop(columns = ['is_private'])

                self._fact_positions_pooled_funds = self._fact_positions_pooled_funds[self._fact_positions_pooled_funds['Position_Type'] == 'Pooled Fund'].copy()

                #ensure one to many merge
                self._fact_positions_pooled_funds = self._fact_positions_pooled_funds.drop_duplicates(['PositionDate','Portfolio_PSPPortfolioID']).drop(columns = ['Instrument_PSPInstrumentID'])

                self._fact_positions_pooled_funds = self._fact_positions_pooled_funds.merge(  self.fact_pooled_funds()
                                                                                            , on = [  'PositionDate'
                                                                                                    , 'Portfolio_PSPPortfolioID']
                                                                                            , how = 'left'
                                                                                            , suffixes = ['','_pf']
                                                                                            , validate = 'one_to_many'
                                                                                           )

                fact_positions_pooled_funds_with_constituents    = self._fact_positions_pooled_funds[~self._fact_positions_pooled_funds['Instrument_PSPInstrumentID'].isnull()].copy(deep = True)
                fact_positions_pooled_funds_without_constituents = self._fact_positions_pooled_funds[self._fact_positions_pooled_funds['Instrument_PSPInstrumentID'].isnull()].copy(deep = True)

                fact_positions_pooled_funds_with_constituents['Position_Type']   = 'Pooled Fund/Private Membership with Data'
                fact_positions_pooled_funds_with_constituents['Position_Source'] = 'Market Risk Analytics Positions'  #modified
                fact_positions_pooled_funds_with_constituents['Object_Type']     = 'Portfolio'
                
                fact_positions_pooled_funds_without_constituents['Position_Type']   = 'Pooled Fund/Private Membership without Data'
                fact_positions_pooled_funds_without_constituents['Position_Source'] = 'Position Per Leg'
                fact_positions_pooled_funds_without_constituents['Object_Type']     = 'Portfolio'

                pf_data_column_mapping = {  'PositionDate'                                          : 'PositionDate'
                                          , 'PooledFundDate'                                        : 'SourceDate'
                                          , 'Object_Type'                                           : 'Object_Type'
                                          , 'Portfolio_PSPPortfolioCode'                            : 'Portfolio_PSPPortfolioCode'
                                          , 'Portfolio_PSPPortfolioID'                              : 'Portfolio_PSPPortfolioID'
                                          , 'Portfolio_Name'                                        : 'Portfolio_Name'
                                          , 'Instrument_PSPInstrumentID'                            : 'Instrument_PSPInstrumentID' #modified
                                          , 'Instrument_CurrencyCode_pf'                            : 'Instrument_CurrencyCode'    #modified
                                          , 'Leg_PSPInstrumentLegID'                                : 'Leg_PSPInstrumentLegID'
                                          , 'Position_Type'                                         : 'Position_Type'
                                          , 'Position_Source'                                       : 'Position_Source'
                                          , 'Position_Quantity'                                     : 'Position_Quantity' #modified
                                          , 'Position_NominalAmount'                                : 'Position_NominalAmount' #modified
                                          , 'Position_MarketValue_CAD'                              : 'Position_MarketValue_CAD' #modified
                                          , 'Position_AccruedInterestValue_CAD'                     : 'Position_AccruedInterestValue_CAD'
                                          , 'Position_TaxReclaimValue_CAD'                          : 'Position_TaxReclaimValue_CAD'
                                          , 'Position_NetAssetValue_CAD'                            : 'Position_NetAssetValue_CAD'
                                          , 'Position_ExposureValue_CAD'                            : 'Position_ExposureValue_CAD'
                                          , 'Instrument_Family_pf'                                  : 'Instrument_Family'
                                          , 'Instrument_PSPInstrumentCategorizationID_pf'           : 'Instrument_PSPInstrumentCategorizationID'
                                          , 'Instrument_PSPInstrumentCategorizationCode_pf'         : 'Instrument_PSPInstrumentCategorizationCode'
                                          , 'Instrument_Description_pf'                             : 'Instrument_Description'
                                          , 'Instrument_Market_pf'                                  : 'Instrument_Market'
                                          , 'Instrument_Type_pf'                                    : 'Instrument_Type'
                                          , 'Instrument_IssuerCode_pf'                              : 'Instrument_IssuerCode'
                                          , 'Instrument_FinancialMaturityDate_pf'                   : 'Instrument_FinancialMaturityDate' 
                                          , 'UltimateUnderlying_PSPInstrumentID_pf'                 : 'UltimateUnderlying_PSPInstrumentID'
                                          , 'Option_Style_pf'                                       : 'Option_Style'
                                          , 'Option_ContractSize_pf'                                : 'Option_ContractSize'
                                          , 'Option_ConversionRatio_pf'                             : 'Option_ConversionRatio'
                                          , 'Option_UnderlyingPSPInstrumentID_pf'                   : 'Option_UnderlyingPSPInstrumentID'
                                          , 'Future_ContractSize_pf'                                : 'Future_ContractSize'
                                          , 'Future_TickSize_pf'                                    : 'Future_TickSize'
                                          , 'Future_TickValue_pf'                                   : 'Future_TickValue'
                                          , 'Future_UnderlyingPSPInstrumentID_pf'                   : 'Future_UnderlyingPSPInstrumentID'
                                          , 'Instrument_IndexProxyPSPInstrumentID_pf'               : 'Instrument_IndexProxyPSPInstrumentID'
                                          , 'UltimateUnderlying_Family_pf'                          : 'UltimateUnderlying_Family'
                                          , 'UltimateUnderlying_PSPInstrumentCategorizationID_pf'   : 'UltimateUnderlying_PSPInstrumentCategorizationID'
                                          , 'UltimateUnderlying_PSPInstrumentCategorizationCode_pf' : 'UltimateUnderlying_PSPInstrumentCategorizationCode'
                                          , 'UltimateUnderlying_Description_pf'                     : 'UltimateUnderlying_Description'
                                          , 'UltimateUnderlying_Market_pf'                          : 'UltimateUnderlying_Market'
                                          , 'UltimateUnderlying_Type_pf'                            : 'UltimateUnderlying_Type'
                                          , 'UltimateUnderlying_IssuerCode_pf'                      : 'UltimateUnderlying_IssuerCode'
                                          , 'UltimateUnderlying_FinancialMaturityDate'              : 'UltimateUnderlying_FinancialMaturityDate' 
                                          , 'UltimateUnderlying_IndexProxyPSPInstrumentID_pf'       : 'UltimateUnderlying_IndexProxyPSPInstrumentID'
                                          , 'Leg_Type'                                              : 'Leg_Type'
                                          , 'Leg_LastResetDate'                                     : 'Leg_LastResetDate'
                                          , 'Leg_Direction'                                         : 'Leg_Direction'
                                          , 'Leg_PositionLevel'                                     : 'Leg_PositionLevel'
                                         }    

                numeric_columns = [   'Position_Quantity'
                                    , 'Position_NominalAmount'
                                    , 'Position_MarketValue_CAD'
                                    , 'Position_AccruedInterestValue_CAD'
                                    , 'Position_TaxReclaimValue_CAD'
                                    , 'Position_NetAssetValue_CAD'
                                    , 'Position_ExposureValue_CAD'
                                  ]
                
                primary_columns = [col for col in pf_data_column_mapping.values() if col not in numeric_columns]
                    
                fact_positions_pooled_funds_with_constituents = fact_positions_pooled_funds_with_constituents[pf_data_column_mapping.keys()].rename(columns = pf_data_column_mapping).groupby(primary_columns, dropna = False).sum(numeric_only = True).reset_index()
                fact_positions_pooled_funds_with_constituents['SourceDate'] = pd.to_datetime(fact_positions_pooled_funds_with_constituents['SourceDate'], format = '%Y-%m-%d')
                
                #Set SourceDate to source data: 
                #    will use PooledFundDate for fact_positions_pooled_funds_with_constituents
                #    will use PositionDate for fact_positions_pooled_funds_without_constituents
                fact_positions_pooled_funds_without_constituents['SourceDate'] = fact_positions_pooled_funds_without_constituents['PositionDate']
                fact_positions_pooled_funds_without_constituents['SourceDate'] = pd.to_datetime(fact_positions_pooled_funds_without_constituents['SourceDate'], format = '%Y-%m-%d')
                fact_positions_pooled_funds_without_constituents = fact_positions_pooled_funds_without_constituents[pf_data_column_mapping.values()]
                
                self._fact_positions_pooled_funds = pd.concat([fact_positions_pooled_funds_with_constituents, fact_positions_pooled_funds_without_constituents])
                #self._fact_positions_pooled_funds = self._fact_positions_pooled_funds[pf_data_column_mapping.keys()].rename(columns = pf_data_column_mapping)
                
        return self._fact_positions_pooled_funds
    
    #@#track_execution
    def fact_positions_pooled_funds_with_constituents_with_mra(self):
        if self._fact_positions_pooled_funds_with_constituents_with_mra is None:
            
            self._fact_positions_pooled_funds_with_constituents_with_mra = self.fact_positions_pooled_funds_with_constituents()
            
            self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_ReportingCurrencyCode'] = self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode']

            ##Merge for internal positions
            ##PA FIX: ADjusted for addition of 'Instrument_CurrencyCode_mra' in fact_mra_data
            self._fact_positions_pooled_funds_with_constituents_with_mra = self._fact_positions_pooled_funds_with_constituents_with_mra.merge(  self.fact_mra_data()
                                                                                                                                              , on = [  'PositionDate'
                                                                                                                                                      , 'Portfolio_PSPPortfolioCode'
                                                                                                                                                      , 'Instrument_PSPInstrumentID'
                                                                                                                                                      , 'Object_Type'
                                                                                                                                                     ]
                                                                                                                                              , how = 'left'
                                                                                                                                              , suffixes = ['','_mra']
                                                                                                                                              , validate = 'many_to_many'
                                                                                                                                             ).drop(columns = ['Instrument_CurrencyCode_mra'])

            self._fact_positions_pooled_funds_with_constituents_with_mra = self._fact_positions_pooled_funds_with_constituents_with_mra.merge(  self.fact_mra_data_currency(keep_zero = False)
                                                                                                  , on = [  'PositionDate'
                                                                                                          , 'Portfolio_PSPPortfolioCode'
                                                                                                          , 'Instrument_PSPInstrumentID'
                                                                                                          , 'Object_Type'
                                                                                                         ]
                                                                                                  , how = 'left'
                                                                                                  , suffixes = ['','_mra_currency']
                                                                                                  , validate = 'many_to_many'
                                                                                                 ).reset_index(drop=True)
            
            self._fact_positions_pooled_funds_with_constituents_with_mra['to_delete'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra['adjusted'] = ''
            self._fact_positions_pooled_funds_with_constituents_with_mra['adjusted_variant'] = ''
           #self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_ReportingCurrencyCode'] = self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode']
            self._fact_positions_pooled_funds_with_constituents_with_mra['entry_type'] = 'primary'
            self._fact_positions_pooled_funds_with_constituents_with_mra['to_delete'] = 0
            
            positions_agg = self._fact_positions_pooled_funds_with_constituents_with_mra.groupby(  by = [  'Instrument_PSPInstrumentCategorizationID'
                                                                                                         , 'PositionDate'
                                                                                                         , 'Portfolio_PSPPortfolioCode'
                                                                                                         , 'Instrument_PSPInstrumentID'
                                                                                                         , 'Leg_PSPInstrumentLegID'
                                                                                                         , 'Instrument_CurrencyCode'
                                                                                                        ]
                                                                                                 , dropna = False
                                                                                                ).agg( position_count = pd.NamedAgg(column = 'entry_type', aggfunc = 'count')
                                                                                                     ).reset_index()
            
            self._fact_positions_pooled_funds_with_constituents_with_mra = self._fact_positions_pooled_funds_with_constituents_with_mra.merge(  positions_agg
                                                                                                                                              , on = [  'Instrument_PSPInstrumentCategorizationID'
                                                                                                                                                      , 'PositionDate'
                                                                                                                                                      , 'Portfolio_PSPPortfolioCode'
                                                                                                                                                      , 'Instrument_PSPInstrumentID'
                                                                                                                                                      , 'Leg_PSPInstrumentLegID'
                                                                                                                                                      , 'Instrument_CurrencyCode'
                                                                                                                                                     ]
                                                                                                                                              , how = 'left'
                                                                                                                                             )

            #NEW, use value from MRA
            self._fact_positions_pooled_funds_with_constituents_with_mra['Position_Quantity'] = self._fact_positions_pooled_funds_with_constituents_with_mra['Position_NotionalInBaseCurrency']
            self._fact_positions_pooled_funds_with_constituents_with_mra['Position_NominalAmount'] = self._fact_positions_pooled_funds_with_constituents_with_mra['Position_NotionalInBaseCurrency']
            self._fact_positions_pooled_funds_with_constituents_with_mra['Position_MarketValue_CAD'] = self._fact_positions_pooled_funds_with_constituents_with_mra['Position_PresentValue']
            self._fact_positions_pooled_funds_with_constituents_with_mra['Position_NetAssetValue_CAD'] = self._fact_positions_pooled_funds_with_constituents_with_mra['Position_PresentValue']
            
            # Rule Prime for Currency
            # Adjust N/D currency to mra currency
            condition_rule_P_0 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode'] == 'N/D')
            condition_rule_P_1 = (~self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode_mra_currency'].isnull())

            condition_rule_P = condition_rule_P_0 & condition_rule_P_1

            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_P, 'Instrument_ReportingCurrencyCode'] = self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_P, 'Instrument_CurrencyCode_mra_currency']
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_P, 'Instrument_CurrencyCode']          = self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_P, 'Instrument_CurrencyCode_mra_currency']
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_P, 'adjusted']                         = self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_P, 'adjusted'] + '/ Rule Prime'
            
            #We only adjust if there is a match with MRA and if there is actually more than one line per unique position combination
            condition_rule_prime = (~self._fact_positions_pooled_funds_with_constituents_with_mra['BatchKey'].isnull())&(self._fact_positions_pooled_funds_with_constituents_with_mra['position_count']>1)
            
            # Rule 0
            # kill clause for position without notional, quantity or net asset value
            condition_rule_0_1 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Position_Quantity']==0)
            condition_rule_0_2 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Position_NominalAmount']==0)
            condition_rule_0_3 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Position_MarketValue_CAD']==0)
            condition_rule_0_4 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Position_AccruedInterestValue_CAD']==0)
            condition_rule_0_5 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Position_TaxReclaimValue_CAD']==0)
            condition_rule_0_6 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Position_NetAssetValue_CAD']==0)

            condition_rule_0 = condition_rule_prime & condition_rule_0_1 & condition_rule_0_2 & condition_rule_0_3 & condition_rule_0_4 & condition_rule_0_5 & condition_rule_0_6

            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_0, 'to_delete'] = 1
            
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_0, 'adjusted'] = self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_0, 'adjusted'] + '/ Rule 0'
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_0,].to_excel('rule_0.xlsx')
            
            #no need for the rule since we are using mra data for pooled funds
            '''
            # Rule 1
            # Neutralise nav for product in following list when currency esb is not currency mra and adjust currency to mra currency
            condition_rule_1_1 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode'] != self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode_mra_currency'])
            condition_rule_1_2 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode_mra_currency'].isnull())
            condition_rule_1 = condition_rule_prime & (~condition_rule_0) & condition_rule_1_1 & (~condition_rule_1_2)

            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_1, 'Position_NetAssetValue_CAD'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_1, 'Position_MarketValue_CAD'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_1, 'Position_AccruedInterestValue_CAD'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_1, 'Position_TaxReclaimValue_CAD'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_1, 'Instrument_ReportingCurrencyCode'] = self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_1, 'Instrument_CurrencyCode_mra_currency']
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_1, 'entry_type'] = 'secondary'

            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_1, 'adjusted'] = self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_1, 'adjusted'] + '/ Rule 2'
            '''
            
            # Rule 2
            # remove positions for which mra_data_currency has two rows for the same positions
            rule_2_id_list = [  
                               1031 #Commodity Futures
                             ]

            condition_rule_2_0 = (~self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_PSPInstrumentCategorizationID'].isin(rule_2_id_list))
            condition_rule_2_1 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode'] != self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode_mra_currency'])
            condition_rule_2_2 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode_mra_currency'].isnull())

            condition_rule_2 = condition_rule_prime & (~condition_rule_0) & condition_rule_2_0 & condition_rule_2_1 & (~condition_rule_2_2)
            
            #self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2, 'Position_NetAssetValue_CAD'] = 0
            #self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2, 'Position_MarketValue_CAD'] = 0
            #self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2, 'Position_AccruedInterestValue_CAD'] = 0
            #self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2, 'Position_TaxReclaimValue_CAD'] = 0
            
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2, 'Position_CommodityDollarDelta'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2, 'Position_EquityDollarDelta'] = 0
            #self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2, 'Position_CurrencyDollarDelta'] = 0
            #self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2, 'Position_NotionalInBaseCurrency'] = 0
            
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2, 'Instrument_ReportingCurrencyCode'] = self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2, 'Instrument_CurrencyCode_mra_currency']
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2, 'entry_type'] = 'secondary'

            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2_1, 'adjusted'] = self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_2_1, 'adjusted'] + '/ Rule 2'

            # Rule 8
            # Adjust commodity futures to match with MRA data currency
            rule_8_id_list = [  
                               1031 #Commodity Futures
                             ]

            condition_rule_8_0 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_PSPInstrumentCategorizationID'].isin(rule_8_id_list))
            condition_rule_8_1 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode'] == self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode_mra_currency'])
            condition_rule_8_2 = (self._fact_positions_pooled_funds_with_constituents_with_mra['Instrument_CurrencyCode_mra_currency'].isnull())

            condition_rule_8  = condition_rule_prime & (~condition_rule_0) & condition_rule_8_0  & (~condition_rule_8_2)
            condition_rule_8a = condition_rule_prime & (~condition_rule_0) & condition_rule_8_0  & (~condition_rule_8_2) & condition_rule_8_1
            condition_rule_8b = condition_rule_prime & (~condition_rule_0) & condition_rule_8_0  & (~condition_rule_8_2) & ~condition_rule_8_1

            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8a, 'Position_NetAssetValue_CAD'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8a, 'Position_MarketValue_CAD'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8a, 'Position_AccruedInterestValue_CAD'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8a, 'Position_TaxReclaimValue_CAD'] = 0
            
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8a, 'Position_CommodityDollarDelta'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8a, 'Position_EquityDollarDelta'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8a, 'Position_CurrencyDollarDelta'] = 0
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8a, 'Position_NotionalInBaseCurrency'] = 0
            
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8, 'Instrument_ReportingCurrencyCode'] = self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8, 'Instrument_CurrencyCode_mra_currency']
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8a, 'entry_type'] = 'secondary'
            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8b, 'entry_type'] = 'primary'

            self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8, 'adjusted'] = self._fact_positions_pooled_funds_with_constituents_with_mra.loc[condition_rule_8, 'adjusted'] + '/ Rule 8'
            
        return self._fact_positions_pooled_funds_with_constituents_with_mra
    
    #@#track_execution
    def fact_positions_private_markets(self):
        if self._fact_positions_private_markets is None:
            self._fact_positions_private_markets = self.private_markets().copy(deep = True)
            
            self._fact_positions_private_markets = self._fact_positions_private_markets.merge(  self.dim_instruments().drop(columns = 'Instrument_CurrencyCode')
                                                                                              , on = ['Instrument_PSPInstrumentID']
                                                                                              , how = 'left'
                                                                                              , validate = 'many_to_one'
                                                                                              , suffixes = ['','_y']
                                                                                             )
            self._fact_positions_private_markets = self._fact_positions_private_markets[self._fact_positions_private_markets['Portfolio_PSPPortfolioID'].isin(self.psp_portfolio_ids())]

            # manually assign the correct Categorization ID and Code to GIPP portfolio in the table PositionExposure
            # this manual treatment is not perfect, as some portfolios for which the managing department is 'Capital Markets' or 'Global Alpha' are not GIPP portfolios 
            # (they contains common share and bonds). The total issuer exposure is still good.
            gipp_managing_department = ['Capital Markets','Global Alpha']
            self._fact_positions_private_markets.loc[self._fact_positions_private_markets['Portfolio_ManagingDepartment'].isin(gipp_managing_department), 'Instrument_PSPInstrumentCategorizationID'] = 1125
            self._fact_positions_private_markets.loc[self._fact_positions_private_markets['Portfolio_ManagingDepartment'].isin(gipp_managing_department), 'Instrument_PSPInstrumentCategorizationCode'] = 'Private Membership Interest'

            #Fix to remove internal leverage from private positions. These portoflios are also in PositionPerLeg with the correct attributes
            cond_1 = (self._fact_positions_private_markets['Portfolio_ManagingDepartment'] == 'Treasury')
            cond_2 = (self._fact_positions_private_markets['Portfolio_MarketType'] == 'Private Market')
            cond_rule = cond_1 & cond_2
            self._fact_positions_private_markets =  self._fact_positions_private_markets[~cond_rule]

            self._fact_positions_private_markets['Instrument_ReportingCurrencyCode'] = self._fact_positions_private_markets['Instrument_CurrencyCode']
                
            self._fact_positions_private_markets['Position_Type']   = 'Private Market'
            self._fact_positions_private_markets['Position_Source'] = 'Private Market'
            self._fact_positions_private_markets['Object_Type']     = 'Portfolio'
            self._fact_positions_private_markets['SourceDate'] = pd.to_datetime(self._fact_positions_private_markets['SourceDate'], format = '%Y-%m-%d')
            
        return self._fact_positions_private_markets

    #@#track_execution
    def fact_positions_mra_ghost(self):
        if self._fact_positions_mra_ghost is None:
            if len(self.pooled_fund_ghost_psp_portfolio_ids())>0:
                #print('Ghost protocol activated')
                ghost_portfolio = self.fact_portfolios()[[  'PositionDate'
                                                          , 'Portfolio_PSPPortfolioCode'
                                                          , 'Portfolio_PSPPortfolioID'
                                                          , 'Portfolio_Type']][self.fact_portfolios()['Portfolio_PSPPortfolioID'].isin(self.pooled_fund_ghost_psp_portfolio_ids())]
                
                #remove ghost positions fro which we have data from private markets
                private_port_mapping = self.fact_positions_private_markets()[['PositionDate','Portfolio_PSPPortfolioID']].drop_duplicates()
                private_port_mapping['has_private_data'] = 1
                ghost_portfolio = ghost_portfolio.merge(private_port_mapping, on = ['PositionDate','Portfolio_PSPPortfolioID'], how = 'left')
                
                ghost_portfolio = ghost_portfolio.loc[ghost_portfolio['has_private_data'] != 1]
                ghost_portfolio = ghost_portfolio.drop(columns = ['has_private_data'])

                ##PA FIX: No adjustment required for addition of 'Instrument_CurrencyCode_mra' in fact_mra_data

                filter_mra_data_currency = (self.fact_mra_data_currency(keep_zero = True)['Instrument_PSPInstrumentID']<0)&(self.fact_mra_data_currency(keep_zero = True)['Object_Type'] == 'Portfolio')

                self._fact_positions_mra_ghost = ghost_portfolio.merge(  self.fact_mra_data_currency(keep_zero = True)[filter_mra_data_currency][[  'PositionDate'
                                                                                                                                                  , 'Portfolio_PSPPortfolioCode'
                                                                                                                                                  , 'Portfolio_Key'
                                                                                                                                                  , 'Instrument_Key'
                                                                                                                                                  , 'Instrument_PSPInstrumentID'
                                                                                                                                                  , 'Instrument_CurrencyCode'
                                                                                                                                                  , 'MostRecent_CalendarKey'
                                                                                                                                                  , 'BatchKey'
                                                                                                                                                  , 'Position_PresentValue'
                                                                                                                                                  , 'Position_KRD'
                                                                                                                                                  , 'Position_CurrencyDollarDelta'
                                                                                                                                                 ]]
                                                                       , on = ['PositionDate', 'Portfolio_PSPPortfolioCode']
                                                                       , how = 'inner'
                                                                       , validate = 'one_to_many'
                                                                      ).merge(  self.fact_mra_data()[self.fact_mra_data()['Instrument_PSPInstrumentID']<0][[  'PositionDate'
                                                                                                                                                            , 'Portfolio_Key'
                                                                                                                                                            , 'Instrument_Key'
                                                                                                                                                            , 'Position_Delta'
                                                                                                                                                            , 'Position_NotionalInBaseCurrency'
                                                                                                                                                            , 'Position_CommodityDollarDelta'
                                                                                                                                                            , 'Position_EquityDollarDelta'
                                                                                                                                                           ]]
                                                                              , on = [ 'PositionDate'
                                                                                     , 'Portfolio_Key'
                                                                                     , 'Instrument_Key']
                                                                              , how = 'left'
                                                                              #, validate = 'one_to_many'
                                                                             )
                
                self._fact_positions_mra_ghost = self._fact_positions_mra_ghost.merge(  self.fact_mra_ghost_instruments()
                                                                                      , on = ['Portfolio_Key', 'Instrument_Key', 'BatchKey']
                                                                                      , how = 'left'
                                                                                      , validate = 'many_to_one'
                                                                                      , suffixes = ['', '_y']
                                                                                     ).drop(columns = [  'Instrument_PSPInstrumentID_y'])
                
                self._fact_positions_mra_ghost['SourceDate'] = pd.to_datetime(self._fact_positions_mra_ghost['CalendarKey'], format = '%Y-%m-%d')
                
                #self._fact_mra_ghost_instruments_sector_country = self._fact_positions_mra_ghost[[ 'PositionDate'
                #                                                                                 , 'Portfolio_PSPPortfolioCode'
                #                                                                                 , 'Instrument_PSPInstrumentID'
                #                                                                                 , 'GICSSectorCode'
                #                                                                                 , 'GICSSectorName'
                #                                                                                 , 'GICSIndustryGroupName'
                #                                                                                 , 'GICSIndustryCode'
                #                                                                                 , 'GICSIndustryName'
                #                                                                                 , 'GICSSubIndustryName'
                #                                                                                 , 'GICSSectorCodeRisk'
                #                                                                                 , 'GICSSectorNameRisk'
                #                                                                                 , 'GICSIndustryGroupNameRisk'
                #                                                                                 , 'GICSIndustryCodeRisk'
                #                                                                                 , 'GICSIndustryNameRisk'
                #                                                                                 , 'GICSSubIndustryNameRisk'
                #                                                                                ]].copy(deep = True).drop_duplicates()
                #                                              

                self._fact_positions_mra_ghost['Instrument_ReportingCurrencyCode'] = self._fact_positions_mra_ghost['Instrument_CurrencyCode']
                
                self._fact_positions_mra_ghost['Position_Quantity']                 = self._fact_positions_mra_ghost['Position_NotionalInBaseCurrency']           
                self._fact_positions_mra_ghost['Position_NominalAmount']            = self._fact_positions_mra_ghost['Position_NotionalInBaseCurrency']           
                self._fact_positions_mra_ghost['Position_MarketValue_CAD']          = self._fact_positions_mra_ghost['Position_PresentValue']
                self._fact_positions_mra_ghost['Position_AccruedInterestValue_CAD'] = 0    
                self._fact_positions_mra_ghost['Position_TaxReclaimValue_CAD']      = 0          
                self._fact_positions_mra_ghost['Position_NetAssetValue_CAD']        = self._fact_positions_mra_ghost['Position_PresentValue']           
                self._fact_positions_mra_ghost['Position_ExposureValue_CAD']        = 0 
                
                self._fact_positions_mra_ghost['Position_Source'] = 'Ghost'
                self._fact_positions_mra_ghost['Position_Type']   = 'Pooled Fund/Private Membership with Data'
                self._fact_positions_mra_ghost['Object_Type']     = 'Portfolio'
                
                self._fact_positions_mra_ghost = self._fact_positions_mra_ghost.rename(columns = {  'UltimateUnderlying_GICSSectorCode'        : 'Instrument_GICSSectorCode'
                                                                                                  , 'UltimateUnderlying_GICSSectorName'        : 'Instrument_GICSSectorName'
                                                                                                  , 'UltimateUnderlying_GICSIndustryGroupName' : 'Instrument_GICSIndustryGroupName'
                                                                                                  , 'UltimateUnderlying_GICSIndustryCode'      : 'Instrument_GICSIndustryCode'
                                                                                                  , 'UltimateUnderlying_GICSIndustryName'      : 'Instrument_GICSIndustryName'
                                                                                                  , 'UltimateUnderlying_GICSSubIndustryName'   : 'Instrument_GICSSubIndustryName'
                                                                                                  , 'Instrument_BICSBETASectorName'            : 'Instrument_BICSBETASectorName'
                                                                                                  , 'Instrument_BICSBETAIndustryName'          : 'Instrument_BICSBETAIndustryName'
                                                                                                  , 'Instrument_BICSBETASubIndustryDescription': 'Instrument_BICSBETASubIndustryDescription'
                                                                                                  , 'RiskLocationCountryCode'                  : 'Instrument_RiskLocationCountryCode'
                                                                                                  , 'RiskLocationCountryName'                  : 'Instrument_RiskLocationCountryName'                
                                                                                                 }
                                                                                      )
                
        return self._fact_positions_mra_ghost

    #@#track_execution
    def fact_positions_benchmark(self):
        if self._fact_positions_benchmark is None:

            self._fact_positions_benchmark = self.benchmarks().copy(deep = True)[[  'PositionDate'
                                                                                 , 'AssetClass_Name'
                                                                                 , 'AssetClass_PSPBenchmarkCode'
                                                                                 , 'Benchmark_Name' 
                                                                                 , 'AssetClass_BenchmarkAssignationDescription'
                                                                                 , 'Benchmark_CurrencyCode'
                                                                                 , 'Benchmark_FinalPSPInstrumentID'
                                                                                 , 'Benchmark_Weight'
                                                                                ]]

            agg_portfolio_aum = self.fact_portfolios().copy(deep = True)
            #fix following Capital Markets restructure
            portfolio_ownerdepartment =['Global Alpha','CIO Group','Capital Markets']
            cond_1 = (agg_portfolio_aum['Portfolio_InvestmentTeam'] == 'CIO Group')
            cond_2 = (agg_portfolio_aum['Portfolio_OwnerDepartment'].isin(portfolio_ownerdepartment))
            cond_3 = (agg_portfolio_aum['Portfolio_Position_NetAssetValue_CAD']!=0)
            cond_rule = ~cond_1 & cond_2 & cond_3

            agg_portfolio_aum = agg_portfolio_aum[cond_rule]
            #agg_portfolio_aum = agg_portfolio_aum[(agg_portfolio_aum['Portfolio_OwnerDepartment'].isin(['Capital Markets']))&(agg_portfolio_aum['Portfolio_Position_NetAssetValue_CAD']!=0)]

            self._fact_positions_benchmark = self._fact_positions_benchmark[self._fact_positions_benchmark['AssetClass_BenchmarkAssignationDescription'] == 'Total Fund Benchmark'].copy(deep = True)

            self._fact_positions_benchmark = agg_portfolio_aum.merge(self._fact_positions_benchmark, left_on = ['PositionDate','Portfolio_AssetClass'], right_on = ['PositionDate','AssetClass_Name'], how = 'inner')

            self._fact_positions_benchmark = self._fact_positions_benchmark.merge(  self.fact_all_constituents()
                                                                                  , left_on = ['PositionDate','Benchmark_FinalPSPInstrumentID']
                                                                                  , right_on = ['PositionDate','Constituee_PSPInstrumentID']
                                                                                  , how = 'left'
                                                                                 ).rename(columns = lambda x: x.replace('Constituent','Instrument'))
            
            self._fact_positions_benchmark['Instrument_PSPInstrumentID'] = self._fact_positions_benchmark['Instrument_PSPInstrumentID'].fillna(self._fact_positions_benchmark['Benchmark_FinalPSPInstrumentID'])
            self._fact_positions_benchmark['Instrument_CurrencyCode']    = self._fact_positions_benchmark['Instrument_CurrencyCode'].fillna(self._fact_positions_benchmark['Benchmark_CurrencyCode'])
            #self._fact_positions_benchmark['Leg_PositionLevel']          = 'Instrument'
            self._fact_positions_benchmark['Instrument_Weight']          = self._fact_positions_benchmark['Instrument_Weight'].fillna(1.0)

            self._fact_positions_benchmark = self._fact_positions_benchmark.drop(columns = ['Instrument_IssuerName','Constituee_Type','Instrument_IssuerExposureFactor','Instrument_EquityExposureFactor'])
            self._fact_positions_benchmark = self._fact_positions_benchmark.rename(columns = {'Constituee_PSPInstrumentID':'Index_PSPInstrumentID'})

            self._fact_positions_benchmark = self._fact_positions_benchmark.merge(  self.dim_instruments().drop(columns = 'Instrument_CurrencyCode')
                                                                                 , on =['Instrument_PSPInstrumentID']
                                                                                 , how = 'left'
                                                                                 , suffixes = ['_drop','']
                                                                                 )
            
            keep_columns = [col for col in self._fact_positions_benchmark.columns if col[len(col)-5:] != '_drop']
            self._fact_positions_benchmark = self._fact_positions_benchmark[keep_columns]

            self._fact_positions_benchmark['Position_MarketValue_CAD']   = -1.0 * self._fact_positions_benchmark['Portfolio_Position_NetAssetValue_CAD'] * self._fact_positions_benchmark['Benchmark_Weight'] * self._fact_positions_benchmark['Instrument_Weight']
            self._fact_positions_benchmark['Position_NetAssetValue_CAD'] = -1.0 * self._fact_positions_benchmark['Portfolio_Position_NetAssetValue_CAD'] * self._fact_positions_benchmark['Benchmark_Weight'] * self._fact_positions_benchmark['Instrument_Weight']
            self._fact_positions_benchmark['Position_AccruedInterestValue_CAD']   = 0
            #self._fact_positions_benchmark['Position_MarketValue_CAD']   = -1.0 * self._fact_positions_benchmark['Portfolio_Position_NetAssetValue_CAD'] * self._fact_positions_benchmark['Benchmark_Weight'] * self._fact_positions_benchmark['Instrument_Weight']
            #self._fact_positions_benchmark['Position_NetAssetValue_CAD'] = -1.0 * self._fact_positions_benchmark['Portfolio_Position_NetAssetValue_CAD'] * self._fact_positions_benchmark['Benchmark_Weight'] * self._fact_positions_benchmark['Instrument_Weight']
            self._fact_positions_benchmark['Portfolio_Type'] = 'Total Fund Benchmarks'
            #self._fact_positions_benchmark['Instrument_CurrencyCode'] = self._fact_positions_benchmark['Constituent_CurrencyCode']

            #Separate private markets, pooled funds and standard positions
            self._fact_positions_benchmark['Position_Source'] = 'Index Constituent Evaluations'
            self._fact_positions_benchmark['Position_Type']   = 'Internal'
            self._fact_positions_benchmark['Object_Type']     = 'Benchmark'
            
        return self._fact_positions_benchmark
 
    #@#track_execution
    def fact_unitary_benchmark_indices(self):
        if self._fact_unitary_benchmark_indices is None:
            self._fact_unitary_benchmark_indices = self.unique_benchmarks()[[  'PositionDate'
                                                                             , 'Benchmark_PSPBenchmarkCode'
                                                                             , 'Benchmark_PSPBenchmarkID'
                                                                             , 'Index_PSPInstrumentID' 
                                                                             , 'Index_Weight'
                                                                            ]]

            self._fact_unitary_benchmark_indices = self._fact_unitary_benchmark_indices.merge(  self.dim_instruments()[[  'Instrument_PSPInstrumentID'
                                                                                                        , 'Instrument_IndexProxyPSPInstrumentID']]
                                                                                                        , left_on = ['Index_PSPInstrumentID']
                                                                                                        , right_on = ['Instrument_PSPInstrumentID']
                                                                                                        , how = 'left'
                                                                                                        , validate = 'many_to_one'
                                                                                                    ).drop(columns = 'Instrument_PSPInstrumentID').rename(columns = {'Instrument_IndexProxyPSPInstrumentID':'Index_ProxyPSPInstrumentID'})

            self._fact_unitary_benchmark_indices = self._fact_unitary_benchmark_indices.merge(  self.fact_all_constituents()[['PositionDate','SourceDate','Constituee_PSPInstrumentID','Constituent_PSPInstrumentID','Constituent_Weight']]
                                                                                , left_on = ['PositionDate','Index_ProxyPSPInstrumentID']
                                                                                , right_on = ['PositionDate','Constituee_PSPInstrumentID']
                                                                                , how = 'left'
                                                                                , validate = 'many_to_many'
                                                                            )

            filter_sin_constituent = self._fact_unitary_benchmark_indices['Constituee_PSPInstrumentID'].isnull()

            self._fact_unitary_benchmark_indices.loc[ filter_sin_constituent,'Instrument_PSPInstrumentID'] = self._fact_unitary_benchmark_indices.loc[ filter_sin_constituent,'Index_PSPInstrumentID']
            self._fact_unitary_benchmark_indices.loc[~filter_sin_constituent,'Instrument_PSPInstrumentID'] = self._fact_unitary_benchmark_indices.loc[~filter_sin_constituent,'Constituent_PSPInstrumentID']

            self._fact_unitary_benchmark_indices.loc[ filter_sin_constituent,'Instrument_Weight'] = 1.0
            self._fact_unitary_benchmark_indices.loc[~filter_sin_constituent,'Instrument_Weight'] = self._fact_unitary_benchmark_indices.loc[~filter_sin_constituent,'Constituent_Weight']

            self._fact_unitary_benchmark_indices.loc[ filter_sin_constituent,'SourceDate'] = self._fact_unitary_benchmark_indices.loc[ filter_sin_constituent,'PositionDate']
            self._fact_unitary_benchmark_indices.loc[~filter_sin_constituent,'SourceDate'] = self._fact_unitary_benchmark_indices.loc[~filter_sin_constituent,'SourceDate']

            self._fact_unitary_benchmark_indices['Final_Weight'] = self._fact_unitary_benchmark_indices['Instrument_Weight'] * self._fact_unitary_benchmark_indices['Index_Weight']

            self._fact_unitary_benchmark_indices =  self._fact_unitary_benchmark_indices.drop(columns = ['Constituee_PSPInstrumentID', 'Constituent_PSPInstrumentID', 'Constituent_Weight'])

            #group_by_Columns = [  'PositionDate'
            #                    , 'Benchmark_Code'
            #                    , 'Benchmark_ID'
            #                    , 'Benchmark_Name'
            #                    , 'SourceDate'
            #                    , 'Instrument_PSPInstrumentID'
            #                   ]

            #sum_Columns = [  'Final_Weight']

            #self._fact_unitary_benchmarks = self._fact_unitary_benchmarks[group_by_Columns + sum_Columns].groupby(group_by_Columns, dropna = False, as_index = False).sum(numeric_only = True)

            self._fact_unitary_benchmark_indices['Instrument_PSPInstrumentID'] = self._fact_unitary_benchmark_indices['Instrument_PSPInstrumentID'].astype('int')

            self._fact_unitary_benchmark_indices = self._fact_unitary_benchmark_indices.merge(  self.dim_instruments()
                                                                                                 , on = ['Instrument_PSPInstrumentID']
                                                                                                 , how = 'left'
                                                                                                 , validate = 'many_to_one'
                                                                                             ).drop(columns = ['UltimateUnderlying_CurrencyCode'])

            self._fact_unitary_benchmark_indices[['Instrument_PSPInstrumentID','Instrument_PSPInstrumentCategorizationID']] = self._fact_unitary_benchmark_indices[['Instrument_PSPInstrumentID','Instrument_PSPInstrumentCategorizationID']].astype('int')

            self._fact_unitary_benchmark_indices['Position_Quantity']                 = self._fact_unitary_benchmark_indices['Final_Weight'] * PAC.index_total_nav
            self._fact_unitary_benchmark_indices['Position_NominalAmount']            = self._fact_unitary_benchmark_indices['Final_Weight'] * PAC.index_total_nav
            self._fact_unitary_benchmark_indices['Position_MarketValue_CAD']          = self._fact_unitary_benchmark_indices['Final_Weight'] * PAC.index_total_nav     
            self._fact_unitary_benchmark_indices['Position_AccruedInterestValue_CAD'] = 0
            self._fact_unitary_benchmark_indices['Position_TaxReclaimValue_CAD']      = 0
            self._fact_unitary_benchmark_indices['Position_NetAssetValue_CAD']        = self._fact_unitary_benchmark_indices['Final_Weight'] * PAC.index_total_nav      
            self._fact_unitary_benchmark_indices['Position_ExposureValue_CAD']        = 0

            self._fact_unitary_benchmark_indices = self._fact_unitary_benchmark_indices.drop(columns = ['Instrument_Weight', 'UltimateUnderlying_IndexProxyPSPInstrumentID'])

            self._fact_unitary_benchmark_indices['Instrument_ReportingCurrencyCode'] = self._fact_unitary_benchmark_indices['Instrument_CurrencyCode']
            self._fact_unitary_benchmark_indices['Portfolio_Type'] = 'PSP Benchmarks'
            self._fact_unitary_benchmark_indices['Position_Source'] = 'Index Constituent Evaluations'
            self._fact_unitary_benchmark_indices['Position_Type']   = 'Unitary'
            self._fact_unitary_benchmark_indices['Object_Type']     = 'Unitary Benchmark'

        return self._fact_unitary_benchmark_indices

    #@#track_execution
    def fact_unitary_benchmark_indices_with_mra(self):
        if self._fact_unitary_benchmark_indices_with_mra is None:

            self._fact_unitary_benchmark_indices_with_mra = self.fact_unitary_benchmark_indices().merge(  self.mra_index_mapping()
                                                                                                        , left_on = [  'PositionDate'
                                                                                                                     , 'Index_PSPInstrumentID'
                                                                                                                    ]
                                                                                                        , right_on = [ 'PositionDate'
                                                                                                                     , 'Index_PSPInstrumentID'
                                                                                                                    ]
                                                                                                        , how = 'left'
                                                                                                        , validate = 'many_to_one'
                                                                                                        )
            
            self._fact_unitary_benchmark_indices_with_mra = self._fact_unitary_benchmark_indices_with_mra.merge(  self.mra_index_data()
                                                                                                                , left_on = [  'Index_Key'
                                                                                                                             , 'MostRecent_CalendarKey'
                                                                                                                             , 'BatchKey'
                                                                                                                             , 'Instrument_PSPInstrumentID'
                                                                                                                            ]
                                                                                                                , right_on = [ 'Index_Key'
                                                                                                                             , 'MostRecent_CalendarKey'
                                                                                                                             , 'BatchKey'
                                                                                                                             , 'Instrument_PSPInstrumentID'
                                                                                                                            ]
                                                                                                                , how = 'left'
                                                                                                                , validate = 'many_to_many'
                                                                                                                , suffixes = ['','_mra_currency']
                                                                                                               )

            unique_columns = [  'PositionDate'
                              , 'Benchmark_PSPBenchmarkCode'
                              , 'Index_PSPInstrumentID'
                              , 'Instrument_PSPInstrumentID'
                              , 'Instrument_CurrencyCode'
                              ]
            
            self.fact_unitary_benchmark_indices_with_mra_count = self._fact_unitary_benchmark_indices_with_mra[unique_columns + ['Object_Type', 'PresentValue']].groupby(  unique_columns
                                                                                                                                                         , dropna = False
                                                                                                                                                         , as_index = False
                                                                                                                                                         ).agg(  position_count = pd.NamedAgg(column = 'Object_Type', aggfunc = 'count')
                                                                                                                                                               , TotalPresentValue = pd.NamedAgg(column = 'PresentValue', aggfunc = 'sum'))
            
            self._fact_unitary_benchmark_indices_with_mra = self._fact_unitary_benchmark_indices_with_mra.merge(  self.fact_unitary_benchmark_indices_with_mra_count
                                                                                                                , on = unique_columns
                                                                                                                , how = 'left'
                                                                                                                , validate = 'many_to_one'
                                                                                                               )
            
            self._fact_unitary_benchmark_indices_with_mra['Krd'] = self._fact_unitary_benchmark_indices_with_mra['Krd'] * self._fact_unitary_benchmark_indices_with_mra['Index_Weight']

            self._fact_unitary_benchmark_indices_with_mra['entry_type'] = 'primary'
            self._fact_unitary_benchmark_indices_with_mra['adjusted'] = ''

            total_present_value_0_filter = self._fact_unitary_benchmark_indices_with_mra['TotalPresentValue'] != 0
            self._fact_unitary_benchmark_indices_with_mra.loc[ total_present_value_0_filter, 'TotalPresentValue_Ratio'] = self._fact_unitary_benchmark_indices_with_mra.loc[total_present_value_0_filter, 'PresentValue'] / self._fact_unitary_benchmark_indices_with_mra.loc[total_present_value_0_filter, 'TotalPresentValue']
            self._fact_unitary_benchmark_indices_with_mra.loc[~total_present_value_0_filter, 'TotalPresentValue_Ratio'] = 1.0

            #We only adjust if there is a match with MRA and if there is actually more than one line per unique position combination
            condition_rule_prime = (~self._fact_unitary_benchmark_indices_with_mra['BatchKey'].isnull())&(self._fact_unitary_benchmark_indices_with_mra['position_count'] > 1)
            self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'Position_Quantity']          = self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'Position_Quantity']          * self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'TotalPresentValue_Ratio']
            self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'Position_NominalAmount']     = self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'Position_NominalAmount']     * self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'TotalPresentValue_Ratio']
            self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'Position_NetAssetValue_CAD'] = self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'Position_NetAssetValue_CAD'] * self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'TotalPresentValue_Ratio']
            self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'Position_MarketValue_CAD']   = self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'Position_MarketValue_CAD']   * self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_prime, 'TotalPresentValue_Ratio']

            #Rule to adjust currency for positions with krd in different currencies
            condition_rule_2_1 = (self._fact_unitary_benchmark_indices_with_mra['Instrument_CurrencyCode'] != self._fact_unitary_benchmark_indices_with_mra['Instrument_CurrencyCode_mra_currency'])
            condition_rule_2_2 = (self._fact_unitary_benchmark_indices_with_mra['Instrument_CurrencyCode_mra_currency'].isnull())
            condition_rule_2 = condition_rule_prime & condition_rule_2_1 & (~condition_rule_2_2)

            self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_2, 'Instrument_ReportingCurrencyCode'] = self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_2, 'Instrument_CurrencyCode_mra_currency']
            self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_2, 'entry_type'] = 'secondary'

            self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_2_1, 'adjusted'] = self._fact_unitary_benchmark_indices_with_mra.loc[condition_rule_2_1, 'adjusted'] + '/ Rule 2'

            #Drop position with 0 Position_NetAssetValue_CAD, 0 KRD and 0 Present Value
            filter = (self._fact_unitary_benchmark_indices_with_mra['Position_NetAssetValue_CAD'] == 0) & (self._fact_unitary_benchmark_indices_with_mra['Krd'] == 0)
            self._fact_unitary_benchmark_indices_with_mra = self._fact_unitary_benchmark_indices_with_mra[~filter].copy(deep = True)

        return self._fact_unitary_benchmark_indices_with_mra
    
#@#track_execution
    def fact_unitary_benchmark_with_mra(self):
        if self._fact_unitary_benchmark_with_mra is None:

            groupby_columns = [  'PositionDate'
                               , 'Benchmark_PSPBenchmarkCode'
                               , 'Benchmark_PSPBenchmarkID'  
                               , 'SourceDate'
                               , 'Instrument_PSPInstrumentID'
                               , 'Final_Weight'
                               , 'Instrument_Family'
                               , 'Instrument_PSPInstrumentCategorizationID'
                               , 'Instrument_PSPInstrumentCategorizationCode'
                               , 'Instrument_Description'
                               , 'Instrument_Market'
                               , 'Instrument_Type'
                               , 'Instrument_IssuerCode'
                               , 'Instrument_CurrencyCode'
                               , 'Instrument_FinancialMaturityDate'
                               , 'UltimateUnderlying_PSPInstrumentID'
                               , 'Option_Style'
                               , 'Option_ContractSize'
                               , 'Option_ConversionRatio'
                               , 'Option_UnderlyingPSPInstrumentID'
                               , 'OptionFuture_ContractSymbol'
                               , 'Forward_Price'
                               , 'Future_ContractSize'
                               , 'Future_TickSize'
                               , 'Future_TickValue'
                               , 'Future_ContractSymbol'
                               , 'Future_UnderlyingPSPInstrumentID'
                               , 'Instrument_IndexProxyPSPInstrumentID'
                               , 'UltimateUnderlying_Family'
                               , 'UltimateUnderlying_PSPInstrumentCategorizationID'
                               , 'UltimateUnderlying_PSPInstrumentCategorizationCode'
                               , 'UltimateUnderlying_Description'
                               , 'UltimateUnderlying_Market'
                               , 'UltimateUnderlying_Type'
                               , 'UltimateUnderlying_IssuerCode'
                               , 'UltimateUnderlying_FinancialMaturityDate'
                               , 'Instrument_ReportingCurrencyCode'
                               , 'Portfolio_Type'
                               , 'Position_Source'
                               , 'Position_Type'
                               , 'Object_Type'
                              ]
            
            data_columns = [  'Position_Quantity'
                            , 'Position_NominalAmount'
                            , 'Position_MarketValue_CAD'
                            , 'Position_AccruedInterestValue_CAD'
                            , 'Position_TaxReclaimValue_CAD'
                            , 'Position_NetAssetValue_CAD'
                            , 'Position_ExposureValue_CAD'
                            , 'Krd'
                           ]
            
            self._fact_unitary_benchmark_with_mra = self.fact_unitary_benchmark_indices_with_mra()[groupby_columns + data_columns].copy(deep = True).groupby(groupby_columns
                                                                                                                                                              , dropna = False
                                                                                                                                                              , as_index=False
                                                                                                                                                              ).agg(  Position_Quantity                 = pd.NamedAgg(column = 'Position_Quantity',                 aggfunc = 'count')
                                                                                                                                                                    , Position_NominalAmount            = pd.NamedAgg(column = 'Position_NominalAmount',            aggfunc = 'sum')
                                                                                                                                                                    , Position_MarketValue_CAD          = pd.NamedAgg(column = 'Position_MarketValue_CAD',          aggfunc = 'sum')
                                                                                                                                                                    , Position_AccruedInterestValue_CAD = pd.NamedAgg(column = 'Position_AccruedInterestValue_CAD', aggfunc = 'sum')
                                                                                                                                                                    , Position_TaxReclaimValue_CAD      = pd.NamedAgg(column = 'Position_TaxReclaimValue_CAD',      aggfunc = 'sum')
                                                                                                                                                                    , Position_NetAssetValue_CAD        = pd.NamedAgg(column = 'Position_NetAssetValue_CAD',        aggfunc = 'sum')
                                                                                                                                                                    , Position_ExposureValue_CAD        = pd.NamedAgg(column = 'Position_ExposureValue_CAD',        aggfunc = 'sum')
                                                                                                                                                                    , Position_KRD                      = pd.NamedAgg(column = 'Krd',                               aggfunc = 'sum')
                                                                                                                                                                    )
            
        return self._fact_unitary_benchmark_with_mra
    
    #@#track_execution
    def fact_unitary_indices(self):
        if self._fact_unitary_indices is None:
            self._fact_unitary_indices = self.unique_benchmarks()[[  'PositionDate'
                                                                   , 'Index_PSPInstrumentID' 
                                                                  ]].drop_duplicates()

            self._fact_unitary_indices = self._fact_unitary_indices.merge(  self.dim_instruments()[[  'Instrument_PSPInstrumentID'
                                                                                                    , 'Instrument_IndexProxyPSPInstrumentID']]
                                                                          , left_on = ['Index_PSPInstrumentID']
                                                                          , right_on = ['Instrument_PSPInstrumentID']
                                                                          , how = 'left'
                                                                          , validate = 'many_to_one'
                                                                         ).drop(columns = 'Instrument_PSPInstrumentID').rename(columns = {'Instrument_IndexProxyPSPInstrumentID':'Index_ProxyPSPInstrumentID'})

            self._fact_unitary_indices = self._fact_unitary_indices.merge(  self.fact_all_constituents()[['PositionDate','SourceDate','Constituee_PSPInstrumentID','Constituent_PSPInstrumentID','Constituent_Weight']]
                                                                          , left_on = ['PositionDate','Index_ProxyPSPInstrumentID']
                                                                          , right_on = ['PositionDate','Constituee_PSPInstrumentID']
                                                                          , how = 'left'
                                                                          , validate = 'many_to_many'
                                                                         )

            filter_sin_constituent = self._fact_unitary_indices['Constituee_PSPInstrumentID'].isnull()

            self._fact_unitary_indices.loc[ filter_sin_constituent,'Instrument_PSPInstrumentID'] = self._fact_unitary_indices.loc[ filter_sin_constituent,'Index_PSPInstrumentID']
            self._fact_unitary_indices.loc[~filter_sin_constituent,'Instrument_PSPInstrumentID'] = self._fact_unitary_indices.loc[~filter_sin_constituent,'Constituent_PSPInstrumentID']

            self._fact_unitary_indices.loc[ filter_sin_constituent,'Final_Weight'] = 1.0
            self._fact_unitary_indices.loc[~filter_sin_constituent,'Final_Weight'] = self._fact_unitary_indices.loc[~filter_sin_constituent,'Constituent_Weight']

            self._fact_unitary_indices.loc[ filter_sin_constituent,'SourceDate'] = self._fact_unitary_indices.loc[ filter_sin_constituent,'PositionDate']
            self._fact_unitary_indices.loc[~filter_sin_constituent,'SourceDate'] = self._fact_unitary_indices.loc[~filter_sin_constituent,'SourceDate']

            self._fact_unitary_indices =  self._fact_unitary_indices.drop(columns = ['Constituee_PSPInstrumentID', 'Constituent_PSPInstrumentID', 'Constituent_Weight'])

            #group_by_Columns = [  'PositionDate'
            #                    , 'Benchmark_Code'
            #                    , 'Benchmark_ID'
            #                    , 'Benchmark_Name'
            #                    , 'SourceDate'
            #                    , 'Instrument_PSPInstrumentID'
            #                   ]

            #sum_Columns = [  'Final_Weight']

            #self._fact_unitary_benchmarks = self._fact_unitary_benchmarks[group_by_Columns + sum_Columns].groupby(group_by_Columns, dropna = False, as_index = False).sum(numeric_only = True)

            self._fact_unitary_indices['Instrument_PSPInstrumentID'] = self._fact_unitary_indices['Instrument_PSPInstrumentID'].astype('int')

            self._fact_unitary_indices = self._fact_unitary_indices.merge(  self.dim_instruments()
                                                                           , on = ['Instrument_PSPInstrumentID']
                                                                           , how = 'left'
                                                                           , validate = 'many_to_one'
                                                                         ).drop(columns = ['UltimateUnderlying_CurrencyCode'])

            self._fact_unitary_indices[['Instrument_PSPInstrumentID','Instrument_PSPInstrumentCategorizationID']] = self._fact_unitary_indices[['Instrument_PSPInstrumentID','Instrument_PSPInstrumentCategorizationID']].astype('int')

            self._fact_unitary_indices['Position_Quantity']                 = self._fact_unitary_indices['Final_Weight'] * PAC.index_total_nav
            self._fact_unitary_indices['Position_NominalAmount']            = self._fact_unitary_indices['Final_Weight'] * PAC.index_total_nav
            self._fact_unitary_indices['Position_MarketValue_CAD']          = self._fact_unitary_indices['Final_Weight'] * PAC.index_total_nav     
            self._fact_unitary_indices['Position_AccruedInterestValue_CAD'] = 0
            self._fact_unitary_indices['Position_TaxReclaimValue_CAD']      = 0
            self._fact_unitary_indices['Position_NetAssetValue_CAD']        = self._fact_unitary_indices['Final_Weight'] * PAC.index_total_nav      
            self._fact_unitary_indices['Position_ExposureValue_CAD']        = 0

            self._fact_unitary_indices = self._fact_unitary_indices.drop(columns = ['UltimateUnderlying_IndexProxyPSPInstrumentID'])

            self._fact_unitary_indices['Instrument_ReportingCurrencyCode'] = self._fact_unitary_indices['Instrument_CurrencyCode']
            self._fact_unitary_indices['Portfolio_Type']  = 'PSP Benchmark Indices'
            self._fact_unitary_indices['Position_Source'] = 'Index Constituent Evaluations'
            self._fact_unitary_indices['Position_Type']   = 'Unitary'
            self._fact_unitary_indices['Object_Type']     = 'Unitary Index'

        return self._fact_unitary_indices

    #@#track_execution
    def fact_unitary_indices_with_mra(self):
        if self._fact_unitary_indices_with_mra is None:

            self._fact_unitary_indices_with_mra = self.fact_unitary_indices().merge(  self.mra_index_mapping()
                                                                                    , left_on = [  'PositionDate'
                                                                                                 , 'Index_PSPInstrumentID'
                                                                                                ]
                                                                                    , right_on = [ 'PositionDate'
                                                                                                 , 'Index_PSPInstrumentID'
                                                                                                ]
                                                                                    , how = 'left'
                                                                                    , validate = 'many_to_one'
                                                                                   )
            
            self._fact_unitary_indices_with_mra = self._fact_unitary_indices_with_mra.merge(  self.mra_index_data()
                                                                                            , left_on = [  'Index_Key'
                                                                                                         , 'MostRecent_CalendarKey'
                                                                                                         , 'BatchKey'
                                                                                                         , 'Instrument_PSPInstrumentID'
                                                                                                        ]
                                                                                            , right_on = [ 'Index_Key'
                                                                                                         , 'MostRecent_CalendarKey'
                                                                                                         , 'BatchKey'
                                                                                                         , 'Instrument_PSPInstrumentID'
                                                                                                        ]
                                                                                            , how = 'left'
                                                                                            , validate = 'many_to_many'
                                                                                            , suffixes = ['','_mra_currency']
                                                                                            )

            unique_columns = [  'PositionDate'
                              , 'Index_PSPInstrumentID'
                              , 'Instrument_PSPInstrumentID'
                              , 'Instrument_CurrencyCode'
                              ]
            
            self.fact_unitary_indices_with_mra_count = self._fact_unitary_indices_with_mra[unique_columns + ['Object_Type', 'PresentValue']].groupby(  unique_columns
                                                                                                                                                    , dropna = False
                                                                                                                                                    , as_index = False
                                                                                                                                                    ).agg(  position_count = pd.NamedAgg(column = 'Object_Type', aggfunc = 'count')
                                                                                                                                                          , TotalPresentValue = pd.NamedAgg(column = 'PresentValue', aggfunc = 'sum')
                                                                                                                                                          )
            
            self._fact_unitary_indices_with_mra = self._fact_unitary_indices_with_mra.merge(  self.fact_unitary_indices_with_mra_count
                                                                                            , on = unique_columns
                                                                                            , how = 'left'
                                                                                            , validate = 'many_to_one'
                                                                                           )

            self._fact_unitary_indices_with_mra['entry_type'] = 'primary'
            self._fact_unitary_indices_with_mra['adjusted'] = ''

            total_present_value_0_filter = self._fact_unitary_indices_with_mra['TotalPresentValue'] != 0
            self._fact_unitary_indices_with_mra.loc[ total_present_value_0_filter, 'TotalPresentValue_Ratio'] = self._fact_unitary_indices_with_mra.loc[total_present_value_0_filter, 'PresentValue'] / self._fact_unitary_indices_with_mra.loc[total_present_value_0_filter, 'TotalPresentValue']
            self._fact_unitary_indices_with_mra.loc[~total_present_value_0_filter, 'TotalPresentValue_Ratio'] = 1.0

            #We only adjust if there is a match with MRA and if there is actually more than one line per unique position combination
            condition_rule_prime = (~self._fact_unitary_indices_with_mra['BatchKey'].isnull())&(self._fact_unitary_indices_with_mra['position_count'] > 1)
            self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'Position_Quantity']          = self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'Position_Quantity']          * self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'TotalPresentValue_Ratio']
            self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'Position_NominalAmount']     = self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'Position_NominalAmount']     * self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'TotalPresentValue_Ratio']
            self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'Position_NetAssetValue_CAD'] = self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'Position_NetAssetValue_CAD'] * self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'TotalPresentValue_Ratio']
            self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'Position_MarketValue_CAD']   = self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'Position_MarketValue_CAD']   * self._fact_unitary_indices_with_mra.loc[condition_rule_prime, 'TotalPresentValue_Ratio']

            #Rule to adjust currency for positions with krd in different currencies
            condition_rule_2_1 = (self._fact_unitary_indices_with_mra['Instrument_CurrencyCode'] != self._fact_unitary_indices_with_mra['Instrument_CurrencyCode_mra_currency'])
            condition_rule_2_2 = (self._fact_unitary_indices_with_mra['Instrument_CurrencyCode_mra_currency'].isnull())
            condition_rule_2 = condition_rule_prime & condition_rule_2_1 & (~condition_rule_2_2)

            self._fact_unitary_indices_with_mra.loc[condition_rule_2, 'Instrument_ReportingCurrencyCode'] = self._fact_unitary_indices_with_mra.loc[condition_rule_2, 'Instrument_CurrencyCode_mra_currency']
            self._fact_unitary_indices_with_mra.loc[condition_rule_2, 'entry_type'] = 'secondary'

            self._fact_unitary_indices_with_mra.loc[condition_rule_2_1, 'adjusted'] = self._fact_unitary_indices_with_mra.loc[condition_rule_2_1, 'adjusted'] + '/ Rule 2'

            #Drop position with 0 Position_NetAssetValue_CAD, 0 KRD and 0 Present Value
            filter = (self._fact_unitary_indices_with_mra['Position_NetAssetValue_CAD'] == 0) & (self._fact_unitary_indices_with_mra['Krd'] == 0)

            self._fact_unitary_indices_with_mra = self._fact_unitary_indices_with_mra[~filter].copy(deep = True)

            groupby_columns = [  'PositionDate'
                               , 'Index_PSPInstrumentID'
                               , 'SourceDate'
                               , 'Instrument_PSPInstrumentID'
                               , 'Final_Weight'
                               , 'Instrument_Family'
                               , 'Instrument_PSPInstrumentCategorizationID'
                               , 'Instrument_PSPInstrumentCategorizationCode'
                               , 'Instrument_Description'
                               , 'Instrument_Market'
                               , 'Instrument_Type'
                               , 'Instrument_IssuerCode'
                               , 'Instrument_CurrencyCode'
                               , 'Instrument_FinancialMaturityDate'
                               , 'UltimateUnderlying_PSPInstrumentID'
                               , 'Option_Style'
                               , 'Option_ContractSize'
                               , 'Option_ConversionRatio'
                               , 'Option_UnderlyingPSPInstrumentID'
                               , 'OptionFuture_ContractSymbol'
                              # , 'Forward_PSPInstrumentID'
                               , 'Forward_Price'
                               , 'Future_ContractSize'
                               , 'Future_TickSize'
                               , 'Future_TickValue'
                               , 'Future_ContractSymbol'
                               , 'Future_UnderlyingPSPInstrumentID'
                               , 'Instrument_IndexProxyPSPInstrumentID'
                               , 'UltimateUnderlying_Family'
                               , 'UltimateUnderlying_PSPInstrumentCategorizationID'
                               , 'UltimateUnderlying_PSPInstrumentCategorizationCode'
                               , 'UltimateUnderlying_Description'
                               , 'UltimateUnderlying_Market'
                               , 'UltimateUnderlying_Type'
                               , 'UltimateUnderlying_IssuerCode'
                               , 'UltimateUnderlying_FinancialMaturityDate'
                               , 'Instrument_ReportingCurrencyCode'
                               , 'Portfolio_Type'
                               , 'Position_Source'
                               , 'Position_Type'
                               , 'Object_Type'
                               , 'Index_Key'
                               , 'MostRecent_CalendarKey'
                               , 'BatchKey'
                               , 'Instrument_Key'
                              ]
            
            data_columns = [  'Position_Quantity'
                            , 'Position_NominalAmount'
                            , 'Position_MarketValue_CAD'
                            , 'Position_AccruedInterestValue_CAD'
                            , 'Position_TaxReclaimValue_CAD'
                            , 'Position_NetAssetValue_CAD'
                            , 'Position_ExposureValue_CAD'
                            , 'Krd'
                           ]
            
            self._fact_unitary_indices_with_mra = self._fact_unitary_indices_with_mra[groupby_columns + data_columns].copy(deep = True).groupby(  groupby_columns
                                                                                                                                                , dropna = False
                                                                                                                                                , as_index=False
                                                                                                                                                ).agg(   Position_Quantity                 = pd.NamedAgg(column = 'Position_Quantity',                 aggfunc = 'count')
                                                                                                                                                       , Position_NominalAmount            = pd.NamedAgg(column = 'Position_NominalAmount',            aggfunc = 'sum')
                                                                                                                                                       , Position_MarketValue_CAD          = pd.NamedAgg(column = 'Position_MarketValue_CAD',          aggfunc = 'sum')
                                                                                                                                                       , Position_AccruedInterestValue_CAD = pd.NamedAgg(column = 'Position_AccruedInterestValue_CAD', aggfunc = 'sum')
                                                                                                                                                       , Position_TaxReclaimValue_CAD      = pd.NamedAgg(column = 'Position_TaxReclaimValue_CAD',      aggfunc = 'sum')
                                                                                                                                                       , Position_NetAssetValue_CAD        = pd.NamedAgg(column = 'Position_NetAssetValue_CAD',        aggfunc = 'sum')
                                                                                                                                                       , Position_ExposureValue_CAD        = pd.NamedAgg(column = 'Position_ExposureValue_CAD',        aggfunc = 'sum')
                                                                                                                                                       , Position_KRD                      = pd.NamedAgg(column = 'Krd',                               aggfunc = 'sum')
                                                                                                                                                      )
            
        return self._fact_unitary_indices_with_mra
    
    def fact_portfolios_private_markets(self):
        if self._fact_portfolios_private_markets is None:
            self._fact_portfolios_private_markets = self.fact_positions_private_markets()[[  'PositionDate'
                                                                                           , 'Portfolio_PSPPortfolioCode'
                                                                                           , 'Position_NetAssetValue_CAD']
                                                                                           ].groupby(  ['PositionDate','Portfolio_PSPPortfolioCode']
                                                                                                     , dropna = False
                                                                                                     , as_index = False
                                                                                                     ).sum(numeric_only = True)

            self._fact_portfolios_private_markets['Portfolio_Type'] = 'Private Market'

        return self._fact_portfolios_private_markets

    def fact_portfolios_pooled_funds_with_constituents(self):
        if self._fact_portfolios_pooled_funds_with_constituents is None:
            self._fact_portfolios_pooled_funds_with_constituents = pd.concat([  self.fact_positions_pooled_funds_with_constituents()[['PositionDate', 'Portfolio_PSPPortfolioCode', 'Position_NetAssetValue_CAD']]
                                                                              , self.fact_positions_mra_ghost()[['PositionDate', 'Portfolio_PSPPortfolioCode', 'Position_NetAssetValue_CAD']]
                                                                             ])
                                                                                                                         
                                                                                                                         
            self._fact_portfolios_pooled_funds_with_constituents = self._fact_portfolios_pooled_funds_with_constituents.groupby( ['PositionDate','Portfolio_PSPPortfolioCode']
                                                                                                                                , dropna = False
                                                                                                                                , as_index = False
                                                                                                                                ).sum(numeric_only = True)

            self._fact_portfolios_pooled_funds_with_constituents['Portfolio_Type'] = 'Pooled Fund with Constituents'

        return self._fact_portfolios_pooled_funds_with_constituents

    #def fact_portfolios_pooled_funds_without_constituents(self):
    #    if self._fact_portfolios_pooled_funds_without_constituents is None:
    #        self._fact_portfolios_pooled_funds_without_constituents = self.fact_positions_pooled_funds_without_constituents()[[  'PositionDate'
    #                                                                                                                           , 'Portfolio_PSPPortfolioCode'
    #                                                                                                                           , 'Position_NetAssetValue_CAD']
    #                                                                                                                           ].groupby(  ['PositionDate','Portfolio_PSPPortfolioCode']
    #                                                                                                                                     , dropna = False
    #                                                                                                                                     , as_index = False
    #                                                                                                                                     ).sum(numeric_only = True)
    #
    #        self._fact_portfolios_private_markets['Portfolio_Type'] = 'Pooled Fund without Constituents'
    #
    #    return self._fact_portfolios_pooled_funds_without_constituents

    def fact_portfolios_internal(self):
        if self._fact_portfolios_internal is None:
            
            self._fact_portfolios_internal = self.fact_positions_internal()[self.fact_positions_internal()['Object_Type']=='Portfolio'][[  'PositionDate'
                                                                                                                                         , 'Portfolio_PSPPortfolioCode'
                                                                                                                                         , 'Position_NetAssetValue_CAD']
                                                                                                                                         ].groupby(  ['PositionDate','Portfolio_PSPPortfolioCode']
                                                                                                                                                     , dropna = False
                                                                                                                                                     , as_index = False
                                                                                                                                                     ).sum(numeric_only = True)

            self._fact_portfolios_internal['Portfolio_Type'] = 'Internal'

        return self._fact_portfolios_internal

    def fact_portfolios_V2(self):
        if self._fact_portfolios_V2 is None:
            self._fact_portfolios_V2 = pd.concat([  self.fact_portfolios_private_markets()
                                                  , self.fact_portfolios_pooled_funds_with_constituents()
                                                  #, self.fact_portfolios_pooled_funds_without_constituents()
                                                  , self.fact_portfolios_internal()])

        return self._fact_portfolios_V2

    #@#track_execution
    def fact_positions_internal(self):
        if self._fact_positions_internal is None:
            
            key = ['PositionDate','Portfolio_PSPPortfolioCode']

            non_internal_portfolios = pd.concat([ self.fact_portfolios_private_markets()[key]
                                                , self.fact_portfolios_pooled_funds_with_constituents()[key]])

            non_internal_portfolios['is_internal'] = 0.0

            self._fact_positions_internal = self.fact_positions().merge(  non_internal_portfolios
                                                                        , on = key
                                                                        , how = 'left'
                                                                        , validate = 'many_to_one'
                                                                        )
                                                                        
            self._fact_positions_internal['is_internal'] = self._fact_positions_internal['is_internal'].fillna(1.0)

            #Separate private markets, pooled funds and standard positions
            self._fact_positions_internal = self._fact_positions_internal[self._fact_positions_internal['is_internal'] == 1.0].copy(deep = True)
                  
            self._fact_positions_internal['Position_Source'] = 'Position Per Leg'
            self._fact_positions_internal['Position_Type']   = self._fact_positions_internal['Position_Type'].replace('Normal','Internal').replace('Pooled Fund','Pooled Fund/Private Membership without Data')
            self._fact_positions_internal['Object_Type']     = 'Portfolio'
            
            self._fact_positions_internal = pd.concat([self._fact_positions_internal, self.fact_positions_benchmark()])
            self._fact_positions_internal['SourceDate'] = pd.to_datetime(self._fact_positions_internal['PositionDate'], format = '%Y-%m-%d')
            
        return self._fact_positions_internal
    
    #@#track_execution
    def fact_positions_internal_with_mra(self):
        if self._fact_positions_internal_with_mra is None:
            
            self._fact_positions_internal_with_mra = self.fact_positions_internal().copy(deep = True)
            
            self._fact_positions_internal_with_mra['Instrument_ReportingCurrencyCode'] = self._fact_positions_internal_with_mra['Instrument_CurrencyCode']

            ##Merge for internal positions
            ##PA FIX: ADjusted for addition of 'Instrument_CurrencyCode_mra' in fact_mra_data
            self._fact_positions_internal_with_mra = self._fact_positions_internal_with_mra.merge(  self.fact_mra_data()
                                                                                                  , on = [  'PositionDate'
                                                                                                          , 'Portfolio_PSPPortfolioCode'
                                                                                                          , 'Instrument_PSPInstrumentID'
                                                                                                          , 'Object_Type'
                                                                                                         ]
                                                                                                  , how = 'left'
                                                                                                  , suffixes = ['','_mra']
                                                                                                  , validate = 'many_to_many'
                                                                                                 ).drop(columns = ['Instrument_CurrencyCode_mra'])

            self._fact_positions_internal_with_mra = self._fact_positions_internal_with_mra.merge(  self.fact_mra_data_currency(keep_zero = False)
                                                                                                  , on = [  'PositionDate'
                                                                                                          , 'Portfolio_PSPPortfolioCode'
                                                                                                          , 'Instrument_PSPInstrumentID'
                                                                                                          , 'Object_Type'
                                                                                                         ]
                                                                                                  , how = 'left'
                                                                                                  , suffixes = ['','_mra_currency']
                                                                                                  , validate = 'many_to_many'
                                                                                                 ).reset_index(drop=True)
            self._fact_positions_internal_with_mra['to_delete'] = 0
            self._fact_positions_internal_with_mra['adjusted'] = ''
            self._fact_positions_internal_with_mra['adjusted_variant'] = ''
            self._fact_positions_internal_with_mra['Instrument_ReportingCurrencyCode'] = self._fact_positions_internal_with_mra['Instrument_CurrencyCode']
            self._fact_positions_internal_with_mra['entry_type'] = 'primary'
            self._fact_positions_internal_with_mra['to_delete'] = 0

            self._fact_positions_internal_with_mra = self._fact_positions_internal_with_mra.copy(deep = True).sort_values(by = [  'Instrument_PSPInstrumentCategorizationID'
                                                                                                                                , 'PositionDate'
                                                                                                                                , 'Portfolio_PSPPortfolioCode'
                                                                                                                                , 'Instrument_PSPInstrumentID'
                                                                                                                                , 'Leg_PSPInstrumentLegID'
                                                                                                                                , 'Instrument_CurrencyCode'
                                                                                                                               ])
            
            positions_agg = self._fact_positions_internal_with_mra.groupby(  by = [  'Instrument_PSPInstrumentCategorizationID'
                                                                                   , 'PositionDate'
                                                                                   , 'Portfolio_PSPPortfolioCode'
                                                                                   , 'Instrument_PSPInstrumentID'
                                                                                   , 'Leg_PSPInstrumentLegID'
                                                                                   , 'Instrument_CurrencyCode'
                                                                                   , 'Object_Type'
                                                                                  ]
                                                                           , dropna = False
                                                                          ).agg( position_count = pd.NamedAgg(column = 'entry_type', aggfunc = 'count')
                                                                               ).reset_index()
            
            self._fact_positions_internal_with_mra = self._fact_positions_internal_with_mra.merge(  positions_agg
                                                                                                  , on = [  'Instrument_PSPInstrumentCategorizationID'
                                                                                                         , 'PositionDate'
                                                                                                         , 'Portfolio_PSPPortfolioCode'
                                                                                                         , 'Instrument_PSPInstrumentID'
                                                                                                         , 'Leg_PSPInstrumentLegID'
                                                                                                         , 'Instrument_CurrencyCode'
                                                                                                         , 'Object_Type'
                                                                                                        ]
                                                                                                 , how = 'left')
            
            #We only adjust if there is a match with MRA and if there is actually more than one line per unique position combination
            condition_rule_prime = (~self._fact_positions_internal_with_mra['BatchKey'].isnull())&(self._fact_positions_internal_with_mra['position_count'] > 1)
            
            # Rule 0
            # kill clause for position without notional, quantity or net asset value
            condition_rule_0_1 = (self._fact_positions_internal_with_mra['Position_Quantity']==0)
            condition_rule_0_2 = (self._fact_positions_internal_with_mra['Position_NominalAmount']==0)
            condition_rule_0_3 = (self._fact_positions_internal_with_mra['Position_MarketValue_CAD']==0)
            condition_rule_0_4 = (self._fact_positions_internal_with_mra['Position_AccruedInterestValue_CAD']==0)
            condition_rule_0_5 = (self._fact_positions_internal_with_mra['Position_TaxReclaimValue_CAD']==0)
            condition_rule_0_6 = (self._fact_positions_internal_with_mra['Position_NetAssetValue_CAD']==0)

            condition_rule_0 = condition_rule_prime & condition_rule_0_1 & condition_rule_0_2 & condition_rule_0_3 & condition_rule_0_4 & condition_rule_0_5 & condition_rule_0_6

            self._fact_positions_internal_with_mra.loc[condition_rule_0, 'to_delete'] = 1
            
            self._fact_positions_internal_with_mra.loc[condition_rule_0, 'adjusted'] = self._fact_positions_internal_with_mra.loc[condition_rule_0, 'adjusted'] + '/ Rule 0'
            self._fact_positions_internal_with_mra.loc[condition_rule_0,].to_excel('rule_0.xlsx')
            
            # Rule 1
            # Delete non-matching row to eliminate duplication on merge
            rule_1_id_list = [ 1048 #Currency Option
                             , 1050 #FX Non-Deliverable Forward
                             , 1051 #FX Forward
                             , 1052 #FX Spot
                             , 1107 #Cross Currency Swap
                             ]

            condition_rule_1_1 = (self._fact_positions_internal_with_mra['Instrument_PSPInstrumentCategorizationID'].isin(rule_1_id_list))
            condition_rule_1_2 = (self._fact_positions_internal_with_mra['Instrument_CurrencyCode'] != self._fact_positions_internal_with_mra['Instrument_CurrencyCode_mra_currency'])

            condition_rule_1 = condition_rule_prime & (~condition_rule_0) & condition_rule_1_1 & condition_rule_1_2

            self._fact_positions_internal_with_mra.loc[condition_rule_1, ['to_delete']] = 1
            
            self._fact_positions_internal_with_mra.loc[condition_rule_1_1, 'adjusted'] = self._fact_positions_internal_with_mra.loc[condition_rule_1_1, 'adjusted']  + '/ Rule 1'

            # Rule 2
            # Neutralise nav for product in following list when currency esb is not currency mra and adjust currency to mra currency
            rule_2_id_list = [
                             # 1009 #Short-Term Note
                              #, 1017 #MAV
                              #, 1020 #Bond
                              #, 1031 #Commodity Futures
                              #, 1040 #Option on Equity Index - OTC
                              #, 1066 #Futures On Currency
                             # , 1159 #Volatility Swap on Currency
                             1011 #common shares
                             ]

            condition_rule_2_0 = (~self._fact_positions_internal_with_mra['Instrument_PSPInstrumentCategorizationID'].isin(rule_2_id_list))
            condition_rule_2_1 = (self._fact_positions_internal_with_mra['Instrument_CurrencyCode'] != self._fact_positions_internal_with_mra['Instrument_CurrencyCode_mra_currency'])
            condition_rule_2_2 = (self._fact_positions_internal_with_mra['Instrument_CurrencyCode_mra_currency'].isnull())

            condition_rule_2 = condition_rule_prime & (~condition_rule_0) & condition_rule_2_0 & condition_rule_2_1 & (~condition_rule_2_2)

            self._fact_positions_internal_with_mra.loc[condition_rule_2, 'Position_NetAssetValue_CAD'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_2, 'Position_MarketValue_CAD'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_2, 'Position_AccruedInterestValue_CAD'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_2, 'Position_TaxReclaimValue_CAD'] = 0
            
            self._fact_positions_internal_with_mra.loc[condition_rule_2, 'Position_CommodityDollarDelta'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_2, 'Position_EquityDollarDelta'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_2, 'Position_NotionalInBaseCurrency'] = 0
            
            self._fact_positions_internal_with_mra.loc[condition_rule_2, 'Instrument_ReportingCurrencyCode'] = self._fact_positions_internal_with_mra.loc[condition_rule_2, 'Instrument_CurrencyCode_mra_currency']
            self._fact_positions_internal_with_mra.loc[condition_rule_2, 'entry_type'] = 'secondary'

            self._fact_positions_internal_with_mra.loc[condition_rule_2_1, 'adjusted'] = self._fact_positions_internal_with_mra.loc[condition_rule_2_1, 'adjusted'] + '/ Rule 2'
            
            # Rule 3
            # Neutralise KRD for IR swap legs that are not fixed
            rule_3_id_list = [  1058 #Interest Rate Swap
                              , 1109 #Overnight Index Swap
                             ]

            condition_rule_3_1 = (self._fact_positions_internal_with_mra['Instrument_PSPInstrumentCategorizationID'].isin(rule_3_id_list))
            condition_rule_3_2 = (~self._fact_positions_internal_with_mra['Leg_Type'].isin(['Fixed']))

            condition_rule_3 = condition_rule_prime & (~condition_rule_0) & condition_rule_3_1 & condition_rule_3_2

            self._fact_positions_internal_with_mra.loc[condition_rule_3, 'Position_KRD'] = 0

            self._fact_positions_internal_with_mra.loc[condition_rule_3_1, 'adjusted'] = self._fact_positions_internal_with_mra.loc[condition_rule_3_1, 'adjusted'] + '/ Rule 3'

            # Rule 4
            # Neutralise KRD for Inflation and swap legs that are inflation
            rule_4_id_list = [  1059 #Inflation Swap
                             ]

            condition_rule_4_1 = (self._fact_positions_internal_with_mra['Instrument_PSPInstrumentCategorizationID'].isin(rule_4_id_list))
            condition_rule_4_2 = (self._fact_positions_internal_with_mra['Leg_Type'].isin(['Inflation']))

            condition_rule_4 = condition_rule_prime & (~condition_rule_0) & condition_rule_4_1 & condition_rule_4_2

            self._fact_positions_internal_with_mra.loc[condition_rule_4, 'Position_KRD'] = 0

            self._fact_positions_internal_with_mra.loc[condition_rule_4_1, 'adjusted'] = self._fact_positions_internal_with_mra.loc[condition_rule_4_1, 'adjusted'] + '/ Rule 4'

            # Rule 5
            # Neutralise KRD for InflationBond swap legs that are total return
            rule_5_id_list = [  1162 #Total Return Swap on Inflation Bond
                             ]

            condition_rule_5_1 = (self._fact_positions_internal_with_mra['Instrument_PSPInstrumentCategorizationID'].isin(rule_5_id_list))
            condition_rule_5_2 = (self._fact_positions_internal_with_mra['Leg_Type'].isin(['TotalReturn']))

            condition_rule_5 = condition_rule_prime & (~condition_rule_0) & condition_rule_5_1 & condition_rule_5_2

            self._fact_positions_internal_with_mra.loc[condition_rule_5, 'Position_KRD'] = 0

            self._fact_positions_internal_with_mra.loc[condition_rule_5_1, 'adjusted']     = self._fact_positions_internal_with_mra.loc[condition_rule_5_1, 'adjusted'] + '/ Rule 5'
            
            # Rule 6
            # Neutralise KRD for Credit Default swap legs that are not creditfee
            rule_6_id_list = [  1032 #Credit Default Swap
                              , 1108 #Credit Default Swap on Index
                             ]

            condition_rule_6_1 = (self._fact_positions_internal_with_mra['Instrument_PSPInstrumentCategorizationID'].isin(rule_6_id_list))
            condition_rule_6_2 = (~self._fact_positions_internal_with_mra['Leg_Type'].isin(['CreditFee']))

            condition_rule_6 = condition_rule_prime & (~condition_rule_0) & condition_rule_6_1 & condition_rule_6_2

            self._fact_positions_internal_with_mra.loc[condition_rule_6, 'Position_KRD'] = 0

            self._fact_positions_internal_with_mra.loc[condition_rule_6_1, 'adjusted']     = self._fact_positions_internal_with_mra.loc[condition_rule_6_1, 'adjusted'] + '/ Rule 6'

            # Rule 7
            # A Neutralise KRD for Equity swap legs that are TotalReturn
            # B Neutralise EquityDollarDelta and CommodityDollarDelta for Equity and Commodity swap legs that are not TotalReturn
            # C Delete non-currency matching rows for TRS legs that are not total return
            # D Neutralise nav for non-currency matching rows for TRS legs that are not total return

            rule_7_id_list = [  1043 #Total Return Swap on Equity Index
                              , 1044 #Total Return Swap on Single Equity / Equity Basket
                             ]

            condition_rule_7_1 = (self._fact_positions_internal_with_mra['Instrument_PSPInstrumentCategorizationID'].isin(rule_7_id_list))
            condition_rule_7_2 = (self._fact_positions_internal_with_mra['Leg_Type'].isin(['TotalReturn']))
            condition_rule_7_3 = (self._fact_positions_internal_with_mra['Instrument_CurrencyCode'] != self._fact_positions_internal_with_mra['Instrument_CurrencyCode_mra_currency'])

            condition_rule_7_A = condition_rule_prime & (~condition_rule_0) & condition_rule_7_1 & condition_rule_7_2 & ~condition_rule_7_3
            condition_rule_7_B = condition_rule_prime & (~condition_rule_0) & condition_rule_7_1 & ~condition_rule_7_2 & ~condition_rule_7_3
            condition_rule_7_C = condition_rule_prime & (~condition_rule_0) & condition_rule_7_1 & condition_rule_7_2 & condition_rule_7_3
            condition_rule_7_D = condition_rule_prime & (~condition_rule_0) & condition_rule_7_1 & ~condition_rule_7_2 & condition_rule_7_3

            self._fact_positions_internal_with_mra.loc[condition_rule_7_A, 'Position_KRD'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_7_A, 'adjusted_variant'] = 'A'

            self._fact_positions_internal_with_mra.loc[condition_rule_7_B, 'Position_EquityDollarDelta'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_7_B, 'Position_CommodityDollarDelta'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_7_B, 'adjusted_variant'] = 'B'

            self._fact_positions_internal_with_mra.loc[condition_rule_7_C, 'to_delete'] = 1
            self._fact_positions_internal_with_mra.loc[condition_rule_7_C, 'adjusted_variant'] = 'C'

            self._fact_positions_internal_with_mra.loc[condition_rule_7_D, 'Position_NetAssetValue_CAD'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_7_D, 'Position_MarketValue_CAD'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_7_D, 'Position_AccruedInterestValue_CAD'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_7_D, 'Position_TaxReclaimValue_CAD'] = 0
            self._fact_positions_internal_with_mra.loc[condition_rule_7_D, 'Instrument_ReportingCurrencyCode'] = self._fact_positions_internal_with_mra.loc[condition_rule_7_D, 'Instrument_CurrencyCode_mra_currency']
            self._fact_positions_internal_with_mra.loc[condition_rule_7_D, 'entry_type'] = 'secondary'
            self._fact_positions_internal_with_mra.loc[condition_rule_7_D, 'adjusted_variant'] = 'D'

            self._fact_positions_internal_with_mra.loc[condition_rule_7_1, 'adjusted']     = self._fact_positions_internal_with_mra.loc[condition_rule_7_1, 'adjusted'] + '/ Rule 7'
            
            self._fact_positions_internal_with_mra = self._fact_positions_internal_with_mra[self._fact_positions_internal_with_mra['to_delete']==0]
            
        return self._fact_positions_internal_with_mra
    
    #@#track_execution
    def fact_positions_all(self):
        if self._fact_positions_all is None:
            
            internal_columns                          = [row for row in PAC.final_positions_columns if row in self.fact_positions_internal().columns]
            pooled_funds_with_constituents_columns    = [row for row in PAC.final_positions_columns if row in self.fact_positions_pooled_funds_with_constituents().columns]
            #pooled_funds_without_constituents_columns = [row for row in PAC.final_positions_columns if row in self.fact_positions_pooled_funds_without_constituents().columns]
            private_markets_columns                   = [row for row in PAC.final_positions_columns if row in self.fact_positions_private_markets().columns]
                
            self._fact_positions_all = pd.concat([ self.fact_positions_internal()[internal_columns].reset_index()
                                                 , self.fact_positions_pooled_funds_with_constituents()[pooled_funds_with_constituents_columns].reset_index()
                                                 #, self.fact_positions_pooled_funds_without_constituents()[pooled_funds_without_constituents_columns].reset_index()
                                                 , self.fact_positions_private_markets()[private_markets_columns].reset_index()
                                                 ]
                                                )
            
            #self._fact_positions_all['Instrument_ReportingCurrencyCode'] = self._fact_positions_all['Instrument_ReportingCurrencyCode'].fillna(self._fact_positions_all['Instrument_CurrencyCode'])
        
        return self._fact_positions_all
    
    #@#track_execution
    def fact_positions_all_with_mra(self):
        if self._fact_positions_all_with_mra is None:
            if self.run_standard:

                if self.run_private:
                    positions_private_markets = self.fact_positions_private_markets()
                    private_markets_columns= [col for col in PAC.final_positions_columns if col != 'Final_Ratio_NAV_PresentValue']
                    self._fact_positions_all_with_mra = positions_private_markets.reindex(columns=positions_private_markets.columns.union(private_markets_columns))
                    self._fact_positions_all_with_mra['RiskMetricsPositionType'] = 'Not applicable'
                else:
                
                    internal_columns                          = [row for row in PAC.final_positions_columns if row in self.fact_positions_internal_with_mra().columns]
                    pooled_funds_with_constituents_columns    = [row for row in PAC.final_positions_columns if row in self.fact_positions_pooled_funds_with_constituents_with_mra().columns]
                    private_markets_columns                   = [row for row in PAC.final_positions_columns if row in self.fact_positions_private_markets().columns]
                    mra_ghost_local_columns                   = [row for row in PAC.final_positions_columns if row in self.fact_positions_mra_ghost().columns]

                    if self._fact_positions_all_with_mra is None:
                        self._fact_positions_all_with_mra = pd.concat([ self.fact_positions_internal_with_mra()[internal_columns].reset_index(drop=True)
                                                                    , self.fact_positions_pooled_funds_with_constituents_with_mra()[pooled_funds_with_constituents_columns].reset_index(drop=True)
                                                                    , self.fact_positions_private_markets()[private_markets_columns].reset_index(drop=True)
                                                                    , self.fact_positions_mra_ghost()[mra_ghost_local_columns].reset_index(drop=True)
                                                                    ]).reset_index(drop=True)
                    else:
                        self._fact_positions_all_with_mra = pd.concat([ self._fact_positions_all_with_mra
                                                                    , self.fact_positions_internal_with_mra()[internal_columns].reset_index(drop=True)
                                                                    , self.fact_positions_pooled_funds_with_constituents_with_mra()[pooled_funds_with_constituents_columns].reset_index(drop=True)
                                                                    , self.fact_positions_private_markets()[private_markets_columns].reset_index(drop=True)
                                                                    , self.fact_positions_mra_ghost()[mra_ghost_local_columns].reset_index(drop=True)
                                                                    ]).reset_index(drop=True)

                #Fix: Delete all 
                #Get Position Price
                self._fact_positions_all_with_mra = self._fact_positions_all_with_mra.merge(  self.prices()
                                                                                                , left_on = ['PositionDate','Instrument_PSPInstrumentID']
                                                                                                , right_on = ['PositionDate','Instrument_PSPInstrumentID']
                                                                                                , how = 'left'
                                                                                                , validate = 'many_to_one'
                                                                                            ).rename(columns = { 'Price_CurrencyCode' : 'Instrument_PriceCurrencyCode'
                                                                                                                , 'Price_Local'        : 'Instrument_PriceLocal'
                                                                                                                , 'Price_CAD'          : 'Instrument_PriceCAD'})
                
                #Get Future Underlying PSPInstrumentID
                self._fact_positions_all_with_mra = self._fact_positions_all_with_mra.merge(  self.prices()
                                                                                            , left_on = ['PositionDate','Future_UnderlyingPSPInstrumentID']
                                                                                            , right_on = ['PositionDate','Instrument_PSPInstrumentID']
                                                                                            , how = 'left'
                                                                                            , suffixes = ['','_fut_und']
                                                                                            , validate = 'many_to_one'
                                                                                        ).drop(columns = ['Instrument_PSPInstrumentID_fut_und']).rename(columns = {  'Price_CurrencyCode' : 'FutureUnderlying_PriceCurrencyCode'
                                                                                                                                                                    , 'Price_Local'        : 'FutureUnderlying_PriceLocal'
                                                                                                                                                                    , 'Price_CAD'          : 'FutureUnderlying_PriceCAD'})
                
                #Get Option Underlying Price
                self._fact_positions_all_with_mra = self._fact_positions_all_with_mra.merge(  self.prices()
                                                                                            , left_on = ['PositionDate','Option_UnderlyingPSPInstrumentID']
                                                                                            , right_on = ['PositionDate','Instrument_PSPInstrumentID']
                                                                                            , how = 'left'
                                                                                            , suffixes = ['','_opt_und']
                                                                                            , validate = 'many_to_one'
                                                                                        ).drop(columns = ['Instrument_PSPInstrumentID_opt_und']).rename(columns = {  'Price_CurrencyCode' : 'OptionUnderlying_PriceCurrencyCode'
                                                                                                                                                                    , 'Price_Local'        : 'OptionUnderlying_PriceLocal'
                                                                                                                                                                    , 'Price_CAD'          : 'OptionUnderlying_PriceCAD'})
                
                #Get Ultimate Underlying Price
                self._fact_positions_all_with_mra = self._fact_positions_all_with_mra.merge(  self.prices()
                                                                                            , left_on = ['PositionDate','UltimateUnderlying_PSPInstrumentID']
                                                                                            , right_on = ['PositionDate','Instrument_PSPInstrumentID']
                                                                                            , how = 'left'
                                                                                            , suffixes = ['','_ult_und']
                                                                                            , validate = 'many_to_one'
                                                                                        ).drop(columns = ['Instrument_PSPInstrumentID_ult_und']).rename(columns = {  'Price_CurrencyCode' : 'UltimateUnderlying_PriceCurrencyCode'
                                                                                                                                                                    , 'Price_Local'        : 'UltimateUnderlying_PriceLocal'
                                                                                                                                                                    , 'Price_CAD'          : 'UltimateUnderlying_PriceCAD'})

                #Get Fx rates
                self._fact_positions_all_with_mra = self._fact_positions_all_with_mra.merge(  self.fx_rates()
                                                                                            , on = ['PositionDate', 'Instrument_CurrencyCode']
                                                                                            , how = 'left'
                                                                                            , validate = 'many_to_one'
                                                                                        )

            if self.run_unitary_benchmarks:
                unitary_benchmark_columns                 = [row for row in PAC.final_positions_columns if row in self.fact_unitary_benchmark_with_mra().columns]
            
                if self._fact_positions_all_with_mra is None:
                    self._fact_positions_all_with_mra = self.fact_unitary_benchmark_with_mra()[unitary_benchmark_columns].reset_index(drop=True)
                else:
                    self._fact_positions_all_with_mra = pd.concat([ self._fact_positions_all_with_mra.reset_index()
                                                                  , self.fact_unitary_benchmark_with_mra()[unitary_benchmark_columns].reset_index(drop=True)
                                                                  ]).reset_index(drop=True)
            
            if self.run_unitary_indices:
                unitary_indices_columns                 = [row for row in PAC.final_positions_columns if row in self.fact_unitary_indices_with_mra().columns]
            
                if self._fact_positions_all_with_mra is None:
                    self._fact_positions_all_with_mra = self.fact_unitary_indices_with_mra()[unitary_indices_columns].reset_index(drop=True)
                else:
                    self._fact_positions_all_with_mra = pd.concat([ self._fact_positions_all_with_mra.reset_index(drop=True)
                                                                  , self.fact_unitary_indices_with_mra()[unitary_indices_columns].reset_index(drop=True)
                                                                  ]).reset_index(drop=True)

        return self._fact_positions_all_with_mra
    
    #@#track_execution
    def fact_private_markets_sector_country(self):
        if self._fact_private_markets_sector_country is None:
            self.fact_positions_private_markets()
        return self._fact_private_markets_sector_country
    
    def fact_all_benchmarks(self):
        if self._fact_all_benchmarks is None:
            self._fact_all_benchmarks = 1
        return self._fact_all_benchmarks

    def fact_mra_ghost_instruments(self):
        if self._fact_mra_ghost_instruments is None:
            if len(self.pooled_fund_ghost_psp_portfolio_ids())>0:
                self._fact_mra_ghost_instruments = self.mra_ghost_instruments().drop_duplicates()
    
        return self._fact_mra_ghost_instruments

    def fact_mra_ghost_instruments_sector_country(self):
        if self._fact_mra_ghost_instruments_sector_country is None:
            self.fact_positions_mra_ghost()
        return self._fact_mra_ghost_instruments_sector_country
    
    #@#track_execution
    def fact_mra_data(self):
        
        if self._fact_mra_data is None:
        
            portfolio_mra_batch_mapping = self.fact_portfolios().merge(  self.mra_batch_mapping()
                                                                       , left_on = ['PositionDate','Portfolio_PSPPortfolioID']
                                                                       , right_on = ['CalendarDate','PortfolioID']
                                                                       , how = 'inner'
                                                                       , validate = 'one_to_one'
                                                                      )[[  'PositionDate'
                                                                         , 'Portfolio_PSPPortfolioCode'
                                                                         , 'Portfolio_Key'
                                                                         , 'MostRecent_CalendarKey'
                                                                       ]]
            
            self._fact_mra_data = portfolio_mra_batch_mapping.merge(  self.mra_batch_data()
                                                                    , left_on = ['MostRecent_CalendarKey','Portfolio_Key']
                                                                    , right_on = ['CalendarKey','Portfolio_Key']
                                                                    , how = 'left'
                                                                    , validate = 'many_to_many'
                                                                   )[[  'PositionDate'
                                                                      , 'Portfolio_PSPPortfolioCode'
                                                                      , 'Portfolio_Key'
                                                                      , 'PortfolioID'
                                                                      , 'MostRecent_CalendarKey'
                                                                      , 'Instrument_Key'
                                                                      , 'InstrumentID'
                                                                      , 'Instrument_CurrencyCode'
                                                                      , 'RiskMetricsPositionType'
                                                                      , 'BatchKey'
                                                                      , 'Delta'
                                                                      , 'Portfolio_NotionalInBaseCurrency'
                                                                      , 'Portfolio_CommodityDollarDelta'
                                                                      , 'Portfolio_EquityDollarDelta'
                                                                      , 'Benchmark_NotionalInBaseCurrency'
                                                                      , 'Benchmark_CommodityDollarDelta'
                                                                      , 'Benchmark_EquityDollarDelta'
                                                                     ]]
            
            self._fact_mra_data['has_MRA_data'] = 1
            
            self._fact_mra_data = self._fact_mra_data.rename(columns = {'InstrumentID':'Instrument_PSPInstrumentID'})
            
            #self._fact_mra_data = self._fact_mra_data[self._fact_mra_data['Instrument_PSPInstrumentID'] > 0]
            
            self._fact_mra_data = self._fact_mra_data.groupby([   'PositionDate'
                                                                , 'Portfolio_PSPPortfolioCode'
                                                                , 'Portfolio_Key'
                                                                , 'PortfolioID'
                                                                , 'MostRecent_CalendarKey'
                                                                , 'Instrument_Key'
                                                                , 'Instrument_PSPInstrumentID'
                                                                , 'Instrument_CurrencyCode'
                                                                , 'RiskMetricsPositionType'
                                                                , 'BatchKey'
                                                              ]
                                                              , dropna = False
                                                             ).agg(  Delta                             = pd.NamedAgg(column = 'Delta'                           , aggfunc = 'mean') 
                                                                   , Portfolio_NotionalInBaseCurrency  = pd.NamedAgg(column = 'Portfolio_NotionalInBaseCurrency', aggfunc = 'sum')
                                                                   , Portfolio_CommodityDollarDelta    = pd.NamedAgg(column = 'Portfolio_CommodityDollarDelta'  , aggfunc = 'sum')
                                                                   , Portfolio_EquityDollarDelta       = pd.NamedAgg(column = 'Portfolio_EquityDollarDelta'     , aggfunc = 'sum') 
                                                                   , Benchmark_NotionalInBaseCurrency  = pd.NamedAgg(column = 'Benchmark_NotionalInBaseCurrency', aggfunc = 'sum')
                                                                   , Benchmark_CommodityDollarDelta    = pd.NamedAgg(column = 'Benchmark_CommodityDollarDelta'  , aggfunc = 'sum')
                                                                   , Benchmark_EquityDollarDelta       = pd.NamedAgg(column = 'Benchmark_EquityDollarDelta'     , aggfunc = 'sum')
                                                                  ).reset_index()

            portfolio_fact_mra_data = self._fact_mra_data[[ 'PositionDate'
                                                          , 'Portfolio_PSPPortfolioCode'
                                                          , 'Portfolio_Key'
                                                          , 'PortfolioID'
                                                          , 'MostRecent_CalendarKey'
                                                          , 'Instrument_Key'
                                                          , 'Instrument_PSPInstrumentID'
                                                          , 'Instrument_CurrencyCode'
                                                          , 'RiskMetricsPositionType'
                                                          , 'BatchKey'
                                                          , 'Delta'
                                                          , 'Portfolio_NotionalInBaseCurrency'
                                                          , 'Portfolio_CommodityDollarDelta'
                                                          , 'Portfolio_EquityDollarDelta'
                                                         ]].rename(columns = { 'Delta'                           :'Position_Delta'
                                                                             , 'Portfolio_NotionalInBaseCurrency':'Position_NotionalInBaseCurrency'
                                                                             , 'Portfolio_CommodityDollarDelta'  :'Position_CommodityDollarDelta'
                                                                             , 'Portfolio_EquityDollarDelta'     :'Position_EquityDollarDelta'})
            portfolio_fact_mra_data['Object_Type'] = 'Portfolio'
            
            benchmark_fact_mra_data = self._fact_mra_data[[ 'PositionDate'
                                                          , 'Portfolio_PSPPortfolioCode'
                                                          , 'Portfolio_Key'
                                                          , 'PortfolioID'
                                                          , 'MostRecent_CalendarKey'
                                                          , 'Instrument_Key'
                                                          , 'Instrument_PSPInstrumentID'
                                                          , 'Instrument_CurrencyCode'
                                                          , 'RiskMetricsPositionType'
                                                          , 'BatchKey'
                                                          , 'Delta'
                                                          , 'Benchmark_NotionalInBaseCurrency'
                                                          , 'Benchmark_CommodityDollarDelta'
                                                          , 'Benchmark_EquityDollarDelta'
                                                         ]].rename(columns = { 'Delta'                           :'Position_Delta'
                                                                             , 'Benchmark_NotionalInBaseCurrency':'Position_NotionalInBaseCurrency'
                                                                             , 'Benchmark_CommodityDollarDelta'  :'Position_CommodityDollarDelta'
                                                                             , 'Benchmark_EquityDollarDelta'     :'Position_EquityDollarDelta'})
            benchmark_fact_mra_data['Object_Type'] = 'Benchmark'
            
            self._fact_mra_data = pd.concat([portfolio_fact_mra_data,benchmark_fact_mra_data])
            
            self._fact_mra_data['Position_NotionalInBaseCurrency'] = self._fact_mra_data['Position_NotionalInBaseCurrency'].apply(lambda x: round(x, 0))
            self._fact_mra_data['Position_CommodityDollarDelta']   = self._fact_mra_data['Position_CommodityDollarDelta'].apply(lambda x: round(x, 0))
            self._fact_mra_data['Position_EquityDollarDelta']      = self._fact_mra_data['Position_EquityDollarDelta'].apply(lambda x: round(x, 0))     

            self._fact_mra_data = self._fact_mra_data[ (self._fact_mra_data['Position_NotionalInBaseCurrency']!=0)
                                                      |(self._fact_mra_data['Position_CommodityDollarDelta']!=0)
                                                      |(self._fact_mra_data['Position_EquityDollarDelta']!=0)]
            
        return self._fact_mra_data

    #@#track_execution    
    def fact_mra_data_currency(self, keep_zero = False):
        
        if self._fact_mra_data_currency is None:
        
            portfolio_mra_batch_mapping = self.fact_portfolios().merge(  self.mra_batch_mapping()
                                                                       , left_on = ['PositionDate','Portfolio_PSPPortfolioID']
                                                                       , right_on = ['CalendarDate','PortfolioID']
                                                                       , how = 'inner'
                                                                       , validate = 'one_to_one'
                                                                      )[[  'PositionDate'
                                                                         , 'Portfolio_PSPPortfolioCode'
                                                                         , 'Portfolio_Key'
                                                                         , 'MostRecent_CalendarKey'
                                                                        ]]
            
            self._fact_mra_data_currency = portfolio_mra_batch_mapping.merge(  self.mra_batch_data_currency()
                                                                             , left_on = ['MostRecent_CalendarKey','Portfolio_Key']
                                                                             , right_on = ['CalendarKey','Portfolio_Key']
                                                                             , how = 'left'
                                                                             , validate = 'many_to_many'
                                                                            )[[  'PositionDate'
                                                                               , 'Portfolio_PSPPortfolioCode'
                                                                               , 'Portfolio_Key'
                                                                               , 'PortfolioID'
                                                                               , 'MostRecent_CalendarKey'
                                                                               , 'Instrument_Key'
                                                                               , 'InstrumentID'
                                                                               , 'CurrencyCode'
                                                                               , 'RiskMetricsPositionType'
                                                                               , 'BatchKey'
                                                                               , 'Portfolio_PresentValue'
                                                                               , 'Portfolio_KRD'
                                                                               , 'Portfolio_CurrencyDollarDelta'
                                                                               , 'Benchmark_PresentValue'
                                                                               , 'Benchmark_KRD'
                                                                               , 'Benchmark_CurrencyDollarDelta'
                                                                              ]]
            
            self._fact_mra_data_currency['has_MRA_data'] = 1
            self._fact_mra_data_currency = self._fact_mra_data_currency.rename(columns = {  'InstrumentID':'Instrument_PSPInstrumentID'
                                                                                          , 'CurrencyCode':'Instrument_CurrencyCode'
                                                                                         }
                                                                              )
            
            #self._fact_mra_data_currency = self._fact_mra_data_currency[self._fact_mra_data_currency['Instrument_PSPInstrumentID'] > 0]
            
            self._fact_mra_data_currency = self._fact_mra_data_currency.groupby([  'PositionDate'
                                                                                 , 'Portfolio_PSPPortfolioCode'
                                                                                 , 'Portfolio_Key'
                                                                                 , 'PortfolioID'
                                                                                 , 'MostRecent_CalendarKey'
                                                                                 , 'Instrument_Key'
                                                                                 , 'Instrument_PSPInstrumentID'
                                                                                 , 'Instrument_CurrencyCode'
                                                                                 , 'RiskMetricsPositionType'
                                                                                 , 'BatchKey'
                                                                                ]
                                                                               , dropna = False
                                                                               ).agg(    Portfolio_PresentValue        = pd.NamedAgg(column = 'Portfolio_PresentValue'        , aggfunc = 'sum') 
                                                                                       , Portfolio_KRD                 = pd.NamedAgg(column = 'Portfolio_KRD'                 , aggfunc = 'sum')
                                                                                       , Portfolio_CurrencyDollarDelta = pd.NamedAgg(column = 'Portfolio_CurrencyDollarDelta' , aggfunc = 'sum') 
                                                                                       , Benchmark_PresentValue        = pd.NamedAgg(column = 'Benchmark_PresentValue'        , aggfunc = 'sum')
                                                                                       , Benchmark_KRD                 = pd.NamedAgg(column = 'Benchmark_KRD'                 , aggfunc = 'sum')
                                                                                       , Benchmark_CurrencyDollarDelta = pd.NamedAgg(column = 'Benchmark_CurrencyDollarDelta' , aggfunc = 'sum')
                                                                                      ).reset_index()
            
            portfolio_fact_mra_data_currency = self._fact_mra_data_currency[[ 'PositionDate'
                                                                            , 'Portfolio_PSPPortfolioCode'
                                                                            , 'Portfolio_Key'
                                                                            , 'PortfolioID'
                                                                            , 'MostRecent_CalendarKey'
                                                                            , 'Instrument_Key'
                                                                            , 'Instrument_PSPInstrumentID'
                                                                            , 'Instrument_CurrencyCode'
                                                                            , 'RiskMetricsPositionType'
                                                                            , 'BatchKey'
                                                                            , 'Portfolio_PresentValue'
                                                                            , 'Portfolio_KRD'
                                                                            , 'Portfolio_CurrencyDollarDelta'
                                                                           ]].rename(columns = { 'Portfolio_PresentValue'       :'Position_PresentValue'
                                                                                               , 'Portfolio_KRD'                :'Position_KRD'
                                                                                               , 'Portfolio_CurrencyDollarDelta':'Position_CurrencyDollarDelta'})
            portfolio_fact_mra_data_currency['Object_Type'] = 'Portfolio'
            benchmark_fact_mra_data_currency = self._fact_mra_data_currency[[ 'PositionDate'
                                                                            , 'Portfolio_PSPPortfolioCode'
                                                                            , 'Portfolio_Key'
                                                                            , 'PortfolioID'
                                                                            , 'MostRecent_CalendarKey'
                                                                            , 'Instrument_Key'
                                                                            , 'Instrument_PSPInstrumentID'
                                                                            , 'Instrument_CurrencyCode'
                                                                            , 'RiskMetricsPositionType'
                                                                            , 'BatchKey'
                                                                            , 'Benchmark_PresentValue'
                                                                            , 'Benchmark_KRD'
                                                                            , 'Benchmark_CurrencyDollarDelta'
                                                                           ]].rename(columns = { 'Benchmark_PresentValue'       :'Position_PresentValue'
                                                                                               , 'Benchmark_KRD'                :'Position_KRD'
                                                                                               , 'Benchmark_CurrencyDollarDelta':'Position_CurrencyDollarDelta'})
            benchmark_fact_mra_data_currency['Object_Type'] = 'Benchmark'
            
            self._fact_mra_data_currency = pd.concat([portfolio_fact_mra_data_currency,benchmark_fact_mra_data_currency])
            
            self._fact_mra_data_currency['Position_PresentValue']        = self._fact_mra_data_currency['Position_PresentValue'].apply(lambda x: round(x, 0))
            self._fact_mra_data_currency['Position_KRD']                 = self._fact_mra_data_currency['Position_KRD'].apply(lambda x: round(x, 0))
            self._fact_mra_data_currency['Position_CurrencyDollarDelta'] = self._fact_mra_data_currency['Position_CurrencyDollarDelta'].apply(lambda x: round(x, 0))   
            
            sum_fact_mra_data_currency = self._fact_mra_data_currency.groupby([ 'Object_Type'
                                                                              , 'PositionDate'
                                                                              , 'Portfolio_PSPPortfolioCode'
                                                                              , 'Portfolio_Key'
                                                                              , 'PortfolioID'
                                                                              , 'MostRecent_CalendarKey'
                                                                              , 'Instrument_Key'
                                                                              , 'Instrument_PSPInstrumentID'
                                                                              , 'RiskMetricsPositionType'
                                                                              , 'BatchKey'
                                                                              ], dropna = False
                                                                             ).agg(  Position_Total_PresentValue        = pd.NamedAgg(column = 'Position_PresentValue'        , aggfunc = 'sum') 
                                                                                   , Position_Total_KRD                 = pd.NamedAgg(column = 'Position_KRD'                 , aggfunc = 'sum')
                                                                                   , Position_Total_CurrencyDollarDelta = pd.NamedAgg(column = 'Position_CurrencyDollarDelta' , aggfunc = 'sum') 
                                                                                  )
            
            self._fact_mra_data_currency = self._fact_mra_data_currency.merge(  sum_fact_mra_data_currency
                                                                              , on = [  'Object_Type'
                                                                                      , 'PositionDate'
                                                                                      , 'Portfolio_PSPPortfolioCode'
                                                                                      , 'Portfolio_Key'
                                                                                      , 'PortfolioID'
                                                                                      , 'MostRecent_CalendarKey'
                                                                                      , 'Instrument_Key'
                                                                                      , 'Instrument_PSPInstrumentID'
                                                                                      , 'RiskMetricsPositionType'
                                                                                      , 'BatchKey'
                                                                                     ]
                                                                             , how = 'left'
                                                                             )
            
        if keep_zero:
            return self._fact_mra_data_currency
        else:
            return self._fact_mra_data_currency[ (self._fact_mra_data_currency['Position_PresentValue']!=0)
                                                |(self._fact_mra_data_currency['Position_KRD']!=0)
                                                |(self._fact_mra_data_currency['Position_CurrencyDollarDelta']!=0)
                                               ]

    #@#track_execution    
    def fact_exposure_non_extended(self):
        if self._fact_exposure_non_extended is None:
            self.calculate_exposure()
            self._fact_exposure_non_extended = self.fact_positions_all_with_mra()
            
            if self.run_standard:
                # apply scaling for pooled funds
                self._fact_exposure_non_extended = self._fact_exposure_non_extended.merge(self.fact_portfolios_scaling()[['PositionDate','Portfolio_PSPPortfolioCode', 'Final_Ratio_NAV_PresentValue']]
                                                                                            , on = ['PositionDate','Portfolio_PSPPortfolioCode']
                                                                                            , how = 'left'
                                                                                            , validate = 'many_to_one')
            
                self._fact_exposure_non_extended['Final_Ratio_NAV_PresentValue'] = self._fact_exposure_non_extended['Final_Ratio_NAV_PresentValue'].fillna(1)

                filter_benchmark = self._fact_exposure_non_extended['Object_Type']=='Benchmark'
                self._fact_exposure_non_extended.loc[filter_benchmark, 'Final_Ratio_NAV_PresentValue'] = 1.0

                self._fact_exposure_non_extended[PAC.pooled_funds_scaling_columns] = self._fact_exposure_non_extended[PAC.pooled_funds_scaling_columns].mul(self._fact_exposure_non_extended['Final_Ratio_NAV_PresentValue'],axis = 0)
            
            data_to_fill = [  'Position_NetAssetValue_CAD'
                            , 'Exposure_FI'
                            , 'Exposure_CR'
                            , 'Exposure_Issuer'
                            , 'Exposure_Equity'
                            , 'Exposure_FX'
                            , 'Exposure_Commodity']

            self.fact_exposure_non_extended()[data_to_fill] = self.fact_exposure_non_extended()[data_to_fill].fillna(0)

        return self._fact_exposure_non_extended
    
    #@#track_execution    
    def fact_exposure_extended(self):
        if self._fact_exposure_extended is None:
            self.fact_exposure_non_extended()
            
            fact_exposure_extended_A = self.fact_exposure_non_extended()[self.fact_exposure_non_extended()['Instrument_CurrencyCode'] == self.fact_exposure_non_extended()['Instrument_ReportingCurrencyCode']].copy(deep = True)
            fact_exposure_extended_B = self.fact_exposure_non_extended()[self.fact_exposure_non_extended()['Instrument_CurrencyCode'] != self.fact_exposure_non_extended()['Instrument_ReportingCurrencyCode']].copy(deep = True)
            #fact_exposure_extended_B_columns = [column for column in fact_exposure_extended_B.columns if column in PAC.extended_columns]
            #fact_exposure_extended_B = fact_exposure_extended_B[fact_exposure_extended_B_columns].copy(deep = True)
            
            fact_exposure_extended_A = fact_exposure_extended_A.merge(  self.fact_all_constituents()
                                                                      , left_on = ['PositionDate','UltimateUnderlying_IndexProxyPSPInstrumentID']
                                                                      , right_on = ['PositionDate','Constituee_PSPInstrumentID']
                                                                      , how = 'left'
                                                                     )
            
            self._fact_exposure_extended = pd.concat([fact_exposure_extended_A, fact_exposure_extended_B])
        
            self._fact_exposure_extended['Constituee_Type']                             = self._fact_exposure_extended['Constituee_Type'].fillna('Direct')                     
            self._fact_exposure_extended['Constituent_Weight']                          = self._fact_exposure_extended['Constituent_Weight'].fillna(1.0)                                       
            self._fact_exposure_extended['Constituent_IssuerExposureFactor']            = self._fact_exposure_extended['Constituent_IssuerExposureFactor'].fillna(1.0)                            
            self._fact_exposure_extended['Constituent_EquityExposureFactor']            = self._fact_exposure_extended['Constituent_EquityExposureFactor'].fillna(1.0)                             
            self._fact_exposure_extended['Constituent_CommodityExposureFactor']         = 1.0                        
            self._fact_exposure_extended['Constituent_FxExposureFactor']                = 1.0                                                     

            self._fact_exposure_extended['Constituee_PSPInstrumentID']                  = self._fact_exposure_extended['Constituee_PSPInstrumentID'].fillna(                 self._fact_exposure_extended['UltimateUnderlying_PSPInstrumentID'])                   
            self._fact_exposure_extended['Constituent_PSPInstrumentID']                 = self._fact_exposure_extended['Constituent_PSPInstrumentID'].fillna(                self._fact_exposure_extended['UltimateUnderlying_PSPInstrumentID'])   
            self._fact_exposure_extended['Constituent_Family']                          = self._fact_exposure_extended['Constituent_Family'].fillna(                         self._fact_exposure_extended['UltimateUnderlying_Family'])                          
            self._fact_exposure_extended['Constituent_PSPInstrumentCategorizationID']   = self._fact_exposure_extended['Constituent_PSPInstrumentCategorizationID'].fillna(  self._fact_exposure_extended['UltimateUnderlying_PSPInstrumentCategorizationID'])   
            self._fact_exposure_extended['Constituent_PSPInstrumentCategorizationCode'] = self._fact_exposure_extended['Constituent_PSPInstrumentCategorizationCode'].fillna(self._fact_exposure_extended['UltimateUnderlying_PSPInstrumentCategorizationCode'])
            self._fact_exposure_extended['Constituent_Description']                     = self._fact_exposure_extended['Constituent_Description'].fillna(                    self._fact_exposure_extended['UltimateUnderlying_Description'])                          
            self._fact_exposure_extended['Constituent_Market']                          = self._fact_exposure_extended['Constituent_Market'].fillna(                         self._fact_exposure_extended['UltimateUnderlying_Market'])                                 
            self._fact_exposure_extended['Constituent_Type']                            = self._fact_exposure_extended['Constituent_Type'].fillna(                           self._fact_exposure_extended['UltimateUnderlying_Type'])                                
            self._fact_exposure_extended['Constituent_IssuerCode']                      = self._fact_exposure_extended['Constituent_IssuerCode'].fillna(                     self._fact_exposure_extended['UltimateUnderlying_IssuerCode'])                                
            self._fact_exposure_extended['Constituent_CurrencyCode']                    = self._fact_exposure_extended['Constituent_CurrencyCode'].fillna(                   self._fact_exposure_extended['Instrument_ReportingCurrencyCode'])  

            self._fact_exposure_extended['Constituent_Exposure_Issuer']                 = self._fact_exposure_extended['Exposure_Issuer']    * self._fact_exposure_extended['Constituent_IssuerExposureFactor']    * self._fact_exposure_extended['Constituent_Weight']
            self._fact_exposure_extended['Constituent_Exposure_Equity']                 = self._fact_exposure_extended['Exposure_Equity']    * self._fact_exposure_extended['Constituent_EquityExposureFactor']    * self._fact_exposure_extended['Constituent_Weight']
            self._fact_exposure_extended['Constituent_Exposure_FX']                     = self._fact_exposure_extended['Exposure_FX']        * self._fact_exposure_extended['Constituent_FxExposureFactor']        * self._fact_exposure_extended['Constituent_Weight']
            self._fact_exposure_extended['Constituent_Exposure_Commodity']              = self._fact_exposure_extended['Exposure_Commodity'] * self._fact_exposure_extended['Constituent_CommodityExposureFactor'] * self._fact_exposure_extended['Constituent_Weight']
            self._fact_exposure_extended['Constituent_Exposure_Commodity']              = self._fact_exposure_extended['Exposure_Commodity'] * self._fact_exposure_extended['Constituent_CommodityExposureFactor'] * self._fact_exposure_extended['Constituent_Weight']
            
            self._fact_exposure_extended['Constituent_MarketValue_CAD']                 = self._fact_exposure_extended['Position_MarketValue_CAD']   * self._fact_exposure_extended['Constituent_Weight']
            self._fact_exposure_extended['Constituent_NetAssetValue_CAD']               = self._fact_exposure_extended['Position_NetAssetValue_CAD'] * self._fact_exposure_extended['Constituent_Weight']

            self._fact_exposure_extended = self._fact_exposure_extended.merge(  self.dim_issuers()
                                                                              , left_on = ['Constituent_IssuerCode']
                                                                              , right_on = ['Issuer_Code']
                                                                              , how = 'left'
                                                                              , validate = 'many_to_one'
                                                                             )
            
            self._fact_exposure_extended['Issuer_EquityExposureFactor']    = self._fact_exposure_extended['Issuer_EquityExposureFactor'].fillna(1.0)    
            self._fact_exposure_extended['Issuer_IssuerExposureFactor']    = self._fact_exposure_extended['Issuer_IssuerExposureFactor'] .fillna(1.0)   
            self._fact_exposure_extended['Issuer_FxExposureFactor']        = self._fact_exposure_extended['Issuer_FxExposureFactor'].fillna(1.0)
            self._fact_exposure_extended['Issuer_CommodityExposureFactor'] = self._fact_exposure_extended['Issuer_CommodityExposureFactor'].fillna(1.0)

            self._fact_exposure_extended['Exposure_Issuer']                = self._fact_exposure_extended['Constituent_Exposure_Issuer']    * self._fact_exposure_extended['Issuer_EquityExposureFactor']           
            self._fact_exposure_extended['Exposure_Equity']                = self._fact_exposure_extended['Constituent_Exposure_Equity']    * self._fact_exposure_extended['Issuer_IssuerExposureFactor']           
            self._fact_exposure_extended['Exposure_FX']                    = self._fact_exposure_extended['Constituent_Exposure_FX']        * self._fact_exposure_extended['Issuer_FxExposureFactor']       
            self._fact_exposure_extended['Exposure_Commodity']             = self._fact_exposure_extended['Constituent_Exposure_Commodity'] * self._fact_exposure_extended['Issuer_CommodityExposureFactor']            
            
            self._fact_exposure_extended['Issuer_RiskLocationCountryCode']   = self._fact_exposure_extended['Issuer_RiskLocationCountryCode']  .fillna(self._fact_exposure_extended['Instrument_RiskLocationCountryCode']  )      
            self._fact_exposure_extended['Issuer_NormalizedCountryCode']     = self._fact_exposure_extended['Issuer_NormalizedCountryCode']    .fillna(self._fact_exposure_extended['Instrument_NormalizedCountryCode']    )   
            self._fact_exposure_extended['Issuer_BICSBETAClassificationID']  = self._fact_exposure_extended['Issuer_BICSBETAClassificationID'] .fillna(self._fact_exposure_extended['Instrument_BICSBETAClassificationID'] )      
            self._fact_exposure_extended['Issuer_BICSBETASectorCode']        = self._fact_exposure_extended['Issuer_BICSBETASectorCode']       .fillna(self._fact_exposure_extended['Instrument_BICSBETASectorCode']       )
            self._fact_exposure_extended['Issuer_BICSBETASectorName']        = self._fact_exposure_extended['Issuer_BICSBETASectorName']       .fillna(self._fact_exposure_extended['Instrument_BICSBETASectorName']       )
            self._fact_exposure_extended['Issuer_BICSBETAIndustryGroupCode'] = self._fact_exposure_extended['Issuer_BICSBETAIndustryGroupCode'].fillna(self._fact_exposure_extended['Instrument_BICSBETAIndustryGroupCode'])       
            self._fact_exposure_extended['Issuer_BICSBETAIndustryGroupName'] = self._fact_exposure_extended['Issuer_BICSBETAIndustryGroupName'].fillna(self._fact_exposure_extended['Instrument_BICSBETAIndustryGroupName']) 
            self._fact_exposure_extended['Issuer_BICSBETAIndustryCode']      = self._fact_exposure_extended['Issuer_BICSBETAIndustryCode']     .fillna(self._fact_exposure_extended['Instrument_BICSBETAIndustryCode'])       
            self._fact_exposure_extended['Issuer_BICSBETAIndustryName']      = self._fact_exposure_extended['Issuer_BICSBETAIndustryName']     .fillna(self._fact_exposure_extended['Instrument_BICSBETAIndustryName'])     
            self._fact_exposure_extended['Issuer_BICSBETAActivityCode']      = self._fact_exposure_extended['Issuer_BICSBETAActivityCode']     .fillna(self._fact_exposure_extended['Instrument_BICSBETAActivityCode'])       
            self._fact_exposure_extended['Issuer_BICSBETAActivityName']      = self._fact_exposure_extended['Issuer_BICSBETAActivityName']     .fillna(self._fact_exposure_extended['Instrument_BICSBETAActivityName'])   
            self._fact_exposure_extended['Issuer_BICSBETASubActivityCode']   = self._fact_exposure_extended['Issuer_BICSBETASubActivityCode']  .fillna(self._fact_exposure_extended['Instrument_BICSBETASubActivityCode'])       
            self._fact_exposure_extended['Issuer_BICSBETASubActivityName']   = self._fact_exposure_extended['Issuer_BICSBETASubActivityName']  .fillna(self._fact_exposure_extended['Instrument_BICSBETASubActivityName'])       
            self._fact_exposure_extended['Issuer_BICSBETASegmentCode']       = self._fact_exposure_extended['Issuer_BICSBETASegmentCode']      .fillna(self._fact_exposure_extended['Instrument_BICSBETASegmentCode'])       
            self._fact_exposure_extended['Issuer_BICSBETASegmentName']       = self._fact_exposure_extended['Issuer_BICSBETASegmentName']      .fillna(self._fact_exposure_extended['Instrument_BICSBETASegmentName'])       
            
            self._fact_exposure_extended = self._fact_exposure_extended.merge(  self.dim_gics()
                                                                              , left_on = ['Constituent_PSPInstrumentID']
                                                                              , right_on = ['PSPInstrumentID']
                                                                              , how = 'left'
                                                                              , validate = 'many_to_one'
                                                                             )
            
            self._fact_exposure_extended['Constituent_GICSSectorCode']        = self._fact_exposure_extended['SectorCode'].fillna(self._fact_exposure_extended['Instrument_GICSSectorCode'])
            self._fact_exposure_extended['Constituent_GICSSectorName']        = self._fact_exposure_extended['SectorName'].fillna(self._fact_exposure_extended['Instrument_GICSSectorName'])
            self._fact_exposure_extended['Constituent_GICSIndustryGroupCode'] = self._fact_exposure_extended['IndustryGroupCode']
            self._fact_exposure_extended['Constituent_GICSIndustryGroupName'] = self._fact_exposure_extended['IndustryGroupName'].fillna(self._fact_exposure_extended['Instrument_GICSIndustryGroupName'])
            self._fact_exposure_extended['Constituent_GICSIndustryCode']      = self._fact_exposure_extended['IndustryCode'].fillna(self._fact_exposure_extended['Instrument_GICSIndustryCode'])
            self._fact_exposure_extended['Constituent_GICSIndustryName']      = self._fact_exposure_extended['IndustryName'].fillna(self._fact_exposure_extended['Instrument_GICSIndustryName'])
            self._fact_exposure_extended['Constituent_GICSSubIndustryCode']   = self._fact_exposure_extended['SubIndustryCode']
            self._fact_exposure_extended['Constituent_GICSSubIndustryName']   = self._fact_exposure_extended['SubIndustryName'].fillna(self._fact_exposure_extended['Instrument_GICSSubIndustryName'])
            
            self._fact_exposure_extended = self._fact_exposure_extended.merge( self.dim_countries()
                                                                             , left_on = ['Issuer_RiskLocationCountryCode']
                                                                             , right_on = ['Country_ISOCode']
                                                                             , how = 'left'
                                                                             , validate = 'm:1'
                                                                             )
            self._fact_exposure_extended = self._fact_exposure_extended.rename(columns = { 'Country_Name'              : 'Issuer_RiskLocationCountryName'
                                                                                         , 'Country_CurrencyCode'      : 'Issuer_RiskLocationCountryCurrencyCode'
                                                                                         , 'Country_IntermediateRegion': 'Issuer_RiskLocationCountryIntermediateRegion'
                                                                                         , 'Country_SubRegion'         : 'Issuer_RiskLocationCountrySubRegion'
                                                                                         , 'Country_Region'            : 'Issuer_RiskLocationCountryRegion'}
                                                                              )
            

            self._fact_exposure_extended = self._fact_exposure_extended.merge( self.dim_countries()
                                                                             , left_on = ['Issuer_NormalizedCountryCode']
                                                                             , right_on = ['Country_ISOCode']
                                                                             , how = 'left'
                                                                             , validate = 'm:1'
                                                                             )
            self._fact_exposure_extended = self._fact_exposure_extended.rename(columns = { 'Country_Name'              : 'Issuer_NormalizedCountryName'
                                                                                         , 'Country_CurrencyCode'      : 'Issuer_NormalizedCountryCurrencyCode'
                                                                                         , 'Country_IntermediateRegion': 'Issuer_NormalizedCountryIntermediateRegion'
                                                                                         , 'Country_SubRegion'         : 'Issuer_NormalizedCountrySubRegion'
                                                                                         , 'Country_Region'            : 'Issuer_NormalizedCountryRegion'}
                                                                              )
                
            self._fact_exposure_extended = self._fact_exposure_extended.merge(  self.fact_portfolios()
                                                                              , on = ['PositionDate','Portfolio_PSPPortfolioCode']
                                                                              , how = 'left'
                                                                              , suffixes = ['','_portfolio']
                                                                              , validate = 'many_to_one'
                                                                             ).drop(columns = ['Portfolio_PSPPortfolioID_portfolio'])
            
            self._fact_exposure_extended = self._fact_exposure_extended.merge( self.dim_portfolios()
                                                                             , left_on = ['Portfolio_PSPPortfolioCode']
                                                                             , right_on = ['L4_PSPPortfolioCode']
                                                                             , how = 'left'
                                                                             , validate = 'm:1'
                                                                             )

        return self._fact_exposure_extended
    

    ####################################################################################################
    ### 5 Exposure Calculations Logic ##################################################################
    ####################################################################################################

    #@#track_execution    
    def calculate_exposure(self):    
        
        self.fact_positions_all_with_mra()
        
        is_unitary_benchmark_filter = (self._fact_positions_all_with_mra['Object_Type'] == 'Unitary Benchmark')|(self._fact_positions_all_with_mra['Object_Type'] == 'Unitary Index')
        is_pooled_fund_filter       = (self._fact_positions_all_with_mra['Position_Type'] == 'Pooled Fund/Private Membership with Data') & (self._fact_positions_all_with_mra['Object_Type'] == 'Portfolio')
        no_pooled_fund_filter       = ~is_pooled_fund_filter & ~is_unitary_benchmark_filter

        self.exposure_columns = [  'PositionDate'
                                 , 'Portfolio_PSPPortfolioCode'
                                 , 'Instrument_PSPInstrumentID'
                                 , 'Instrument_PSPInstrumentCategorizationID'
                                 , 'Instrument_PSPInstrumentCategorizationCode'
                                 , 'RiskMetricsPositionType'
                                 , 'Instrument_CurrencyCode'
                                 , 'Instrument_ReportingCurrencyCode'
                                ]
        
        self.exposure_values_columns = [  'Exposure_Issuer'
                                        , 'Exposure_Equity'
                                        , 'Exposure_FX'
                                        , 'Exposure_Commodity'
                                        , 'Exposure_FI'
                                        , 'Exposure_CR'
                                       ]
        
        self._fact_positions_all_with_mra['calc_formula'] = ''

        if len(self._fact_positions_all_with_mra[is_unitary_benchmark_filter].index)>0:
            self._fact_positions_all_with_mra.loc[is_unitary_benchmark_filter, 'calc_type']                    = 'unitary'
            self._fact_positions_all_with_mra.loc[is_unitary_benchmark_filter, 'use_pooled_fund_calculations'] = 0
            self.calculate_exposure_unitary_benchmark()
            self._fact_positions_all_with_mra.loc[is_unitary_benchmark_filter, 'calc_formula']                 = self._fact_positions_all_with_mra.loc[is_unitary_benchmark_filter, 'unitary_benchmark_calculation_family']

        if self.run_standard:
            self._fact_positions_all_with_mra.loc[is_pooled_fund_filter, 'calc_type']                          = 'pooled fund'
            self._fact_positions_all_with_mra.loc[is_pooled_fund_filter, 'use_pooled_fund_calculations']       = 1
            self.calculate_exposure_exotic()
            self._fact_positions_all_with_mra.loc[is_pooled_fund_filter, 'calc_formula']                       = self._fact_positions_all_with_mra.loc[is_pooled_fund_filter, 'exotic_calculation_family']

            self._fact_positions_all_with_mra.loc[no_pooled_fund_filter, 'calc_type']                          = 'normal'
            self._fact_positions_all_with_mra.loc[no_pooled_fund_filter, 'use_pooled_fund_calculations']       = 0
            self.calculate_exposure_normal()
            self._fact_positions_all_with_mra.loc[no_pooled_fund_filter, 'calc_formula']                       = self._fact_positions_all_with_mra.loc[no_pooled_fund_filter, 'normal_calculation_family']
        
    #@#track_execution
    def calculate_exposure_unitary_benchmark(self):
        
        unitary_benchmark_mapping_df = pd.DataFrame(PAC.unitary_benchmark_mapping, columns = ['Instrument_PSPInstrumentCategorizationID', 'unitary_benchmark_calculation_family'])
        self._fact_positions_all_with_mra = self.fact_positions_all_with_mra().merge(  unitary_benchmark_mapping_df
                                                                                     , on = ['Instrument_PSPInstrumentCategorizationID']
                                                                                     , how = 'left'
                                                                                     , validate = 'm:1'
                                                                                    )
        
        self.calculate_exposure_unitary_benchmark_IssuerMV_FxFMV_EquityMV()
        self.calculate_exposure_unitary_benchmark_IssuerMV_AI_FxFMV()
        self.calculate_exposure_unitary_benchmark_FxFMV_CommodityMV()

    #@#track_execution
    def calculate_exposure_normal(self):
        
        normal_mapping_df = pd.DataFrame(PAC.normal_mapping, columns = ['Instrument_PSPInstrumentCategorizationID', 'normal_calculation_family'])
        
        self._fact_positions_all_with_mra = self.fact_positions_all_with_mra().merge(  normal_mapping_df
                                                                                     , on = ['Instrument_PSPInstrumentCategorizationID']
                                                                                     , how = 'left'
                                                                                     , validate = 'm:1'
                                                                                    )

        self.calculate_exposure_normal_FxCcyDelta()
        self.calculate_exposure_normal_FxFMV()
        self.calculate_exposure_normal_FxFMV_CommodityCmdtyDDelta()
        self.calculate_exposure_normal_FxFMV_CommodityNot()
        self.calculate_exposure_normal_IssNotDe_FxFMV_EqtNotD()
        self.calculate_exposure_normal_IssuerMV_FxFMV_EquityMV()
        self.calculate_exposure_normal_IssuerMV_AI_FxFMV()
        self.calculate_exposure_normal_IssuerNot_FxFMV_Swap()
        self.calculate_exposure_normal_IssuerNot_FxFMV_CDO()
        self.calculate_exposure_normal_IssuerNot_FxFMV_Fut()
        self.calculate_exposure_normal_IssuerNot_FxFMV_Fwd()
        self.calculate_exposure_normal_IssuerNot_FxFMV_EquityNot_2Legs()
        self.calculate_exposure_normal_IssuerNot_FxFMV_EquityNot_1_Fut()
        self.calculate_exposure_normal_IssuerNot_FxFMV_EquityNot_1_Fwd()
        self.calculate_exposure_normal_IssuerNotDelta_FxFMV_CDS()
        self.calculate_exposure_normal_IssuerNotDelta_FxFMV_Bond()
        self.calculate_exposure_normal_IssuerNotDelta_FxFMV_Fut()
        self.calculate_exposure_normal_private_IssuerNAV_FxMV()

    #@#track_execution
    def calculate_exposure_exotic(self):
        
        exotic_mapping_df = pd.DataFrame(PAC.exotic_mapping, columns = ['RiskMetricsPositionType', 'exotic_calculation_family'])
                                                             
        self._fact_positions_all_with_mra = self.fact_positions_all_with_mra().merge(  exotic_mapping_df
                                                                                     , on = ['RiskMetricsPositionType']
                                                                                     , how = 'left'
                                                                                     , validate = 'm:1'
                                                                                    )
        
        self.calculate_exposure_exotic_FxCcyDDelta()
        self.calculate_exposure_exotic_FxPV()
        self.calculate_exposure_exotic_FxPV_CommoCmdtyDDelta()
        self.calculate_exposure_exotic_IssEqtyDelta_FxPV_EqEqtDe()
        self.calculate_exposure_exotic_IssuerNot_FxPV()
        self.calculate_exposure_exotic_IssuerNotDelta_FxPV()
        self.calculate_exposure_exotic_IssuerPV_FxPV()
        self.calculate_exposure_exotic_IssuerNotDelta_FxPV_EqtyEqtDDe()
        self.calculate_exposure_exotic_IssuerPV_FxPV_EqtyEqtDDe()


    #UB1 IssuerMV_FxFMV_EquityMV
    #@#track_execution
    def calculate_exposure_unitary_benchmark_IssuerMV_FxFMV_EquityMV(self, debug = False):
        
        columns_IssuerMV_FxFMV_EquityMV = [  'Position_NetAssetValue_CAD'
                                            , 'Position_KRD'
                                           ]
        IssuerMV_FxFMV_EquityMV = (self._fact_positions_all_with_mra['unitary_benchmark_calculation_family'] == 'IssuerMV_FxFMV_EquityMV')&(self._fact_positions_all_with_mra['calc_type'] == 'unitary')

        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_Equity']    = self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerMV_FxFMV_EquityMV][self.exposure_columns + columns_IssuerMV_FxFMV_EquityMV + self.exposure_values_columns].sort_values(by = self.exposure_columns)

    #UB2 IssuerMV_AI_FxFMV
    #@#track_execution
    def calculate_exposure_unitary_benchmark_IssuerMV_AI_FxFMV(self, debug = False):
        
        columns_IssuerMV_AI_FxFMV = [  'Position_NetAssetValue_CAD'
                                     , 'Position_KRD'
                                    ]
        IssuerMV_AI_FxFMV = (self._fact_positions_all_with_mra['unitary_benchmark_calculation_family'] == 'IssuerMV_AI_FxFMV')&(self._fact_positions_all_with_mra['calc_type'] == 'unitary')

        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerMV_AI_FxFMV][self.exposure_columns + columns_IssuerMV_AI_FxFMV + self.exposure_values_columns].sort_values(by = self.exposure_columns)

    #UB3 FxCcyDelta  
    #@#track_execution 
    def calculate_exposure_unitary_benchmark_FxFMV_CommodityMV(self, debug = False):
        
        columns_FxFMV_CommodityMV = [  'Position_NetAssetValue_CAD'
                                     , 'Position_KRD'
                                    ]

        FxFMV_CommodityMV = (self._fact_positions_all_with_mra['unitary_benchmark_calculation_family'] == 'FxFMV_CommodityMV')&(self._fact_positions_all_with_mra['calc_type'] == 'unitary')

        self._fact_positions_all_with_mra.loc[FxFMV_CommodityMV, 'Exposure_Issuer']    = 0
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityMV, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityMV, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[FxFMV_CommodityMV, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityMV, 'Exposure_Commodity'] = self._fact_positions_all_with_mra.loc[FxFMV_CommodityMV, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityMV, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[FxFMV_CommodityMV, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityMV, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[FxFMV_CommodityMV][self.exposure_columns + columns_FxFMV_CommodityMV + self.exposure_values_columns].sort_values(by = self.exposure_columns)
        
    #A1 FxCcyDelta  
    #@#track_execution 
    def calculate_exposure_normal_FxCcyDelta(self, debug = False):
        
        columns_FxCcyDelta = [  'Position_NetAssetValue_CAD'
                              , 'Position_CurrencyDollarDelta'
                              , 'Position_Total_PresentValue'
                              , 'Position_Total_CurrencyDollarDelta'
                             ]

        FxCcyDDelta = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'FxCcyDDelta')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        FxCcyDDelta_1 = (self._fact_positions_all_with_mra['Position_CurrencyDollarDelta'].isnull())
        FxCcyDDelta_2 = ~(FxCcyDDelta_1) & (self._fact_positions_all_with_mra['Instrument_ReportingCurrencyCode'] == 'CAD')
        FxCcyDDelta_3 = ~(FxCcyDDelta_1) & (self._fact_positions_all_with_mra['Instrument_ReportingCurrencyCode'] != 'CAD')

        self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Exposure_Issuer'] = 0
        self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Exposure_Equity'] = 0

        self._fact_positions_all_with_mra.loc[FxCcyDDelta & FxCcyDDelta_1, 'Exposure_FX'] = self._fact_positions_all_with_mra.loc[FxCcyDDelta & FxCcyDDelta_1, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[FxCcyDDelta & FxCcyDDelta_2, 'Exposure_FX'] =   self._fact_positions_all_with_mra.loc[FxCcyDDelta & FxCcyDDelta_2, 'Position_Total_PresentValue'] \
                                                                                            - self._fact_positions_all_with_mra.loc[FxCcyDDelta & FxCcyDDelta_2, 'Position_Total_CurrencyDollarDelta']
        self._fact_positions_all_with_mra.loc[FxCcyDDelta & FxCcyDDelta_3, 'Exposure_FX'] = self._fact_positions_all_with_mra.loc[FxCcyDDelta & FxCcyDDelta_3, 'Position_CurrencyDollarDelta']

        self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Exposure_FI'] = self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Exposure_CR'] = 0
        
        if debug:
            return self._fact_positions_all_with_mra[FxCcyDDelta][self.exposure_columns + columns_FxCcyDelta + self.exposure_values_columns].sort_values(by = self.exposure_columns)
        
    #A2 FxFMV
    #@#track_execution
    def calculate_exposure_normal_FxFMV(self, debug = False):
        
        columns_FxFMV = [  'Position_NetAssetValue_CAD'
                         , 'Position_KRD'
                        ]
        FxFMV = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'FxFMV')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        self._fact_positions_all_with_mra.loc[FxFMV, 'Exposure_Issuer']    = 0
        self._fact_positions_all_with_mra.loc[FxFMV, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[FxFMV, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[FxFMV, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[FxFMV, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[FxFMV, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[FxFMV, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[FxFMV, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[FxFMV][self.exposure_columns + columns_FxFMV + self.exposure_values_columns].sort_values(by = self.exposure_columns)
        
    #A3 FxFMV_CommodityCmdtyDDelta
    #@#track_execution
    def calculate_exposure_normal_FxFMV_CommodityCmdtyDDelta(self, debug = False):
        #exposure calculations filter definition
        columns_FxFMV_CommodityCmdtyDDelta = [  'Position_NominalAmount'
                                              , 'Option_ContractSize'
                                              , 'OptionUnderlying_PriceCAD'
                                              , 'Notional_CAD'
                                              , 'Position_Delta'
                                              , 'Position_CommodityDollarDelta'
                                              , 'Position_NetAssetValue_CAD'
                                              , 'Position_KRD'
                                             ]

        FxFMV_CommodityCmdtyDDelta = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'FxFMV_CommodityCmdtyDDelta')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Notional_CAD'] =  self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Position_NominalAmount'] \
                                                                                             * self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Option_ContractSize'].fillna(1) \
                                                                                             * self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'OptionUnderlying_PriceCAD']

        self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Delta_Notional_CAD'] =   abs(self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Notional_CAD']) \
                                                                                                    * self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Position_Delta']

        self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Exposure_Issuer']    = 0
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Exposure_Commodity'] = self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Delta_Notional_CAD']\
                                                                                                  .fillna(self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Position_CommodityDollarDelta'])
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityCmdtyDDelta, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[FxFMV_CommodityCmdtyDDelta][self.exposure_columns + columns_FxFMV_CommodityCmdtyDDelta + self.exposure_values_columns].sort_values(by = self.exposure_columns)        
    
    #A4 FxFMV_CommodityNot
    #@#track_execution
    def calculate_exposure_normal_FxFMV_CommodityNot(self, debug = False):
        #exposure calculations filter definition
        columns_FxFMV_CommodityNot = [  'Position_NominalAmount'
                                      , 'Future_ContractSize'
                                      , 'FutureUnderlying_PriceCAD'
                                      , 'Instrument_PriceCAD'
                                      , 'Future_TickSize'
                                      , 'Future_TickValue'
                                      , 'Notional_CAD'
                                      , 'Position_CommodityDollarDelta'
                                      , 'Position_NetAssetValue_CAD'
                                      , 'Position_KRD'
                                     ]

        FxFMV_CommodityNot = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'FxFMV_CommodityNot')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Notional_CAD'] =   self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Position_NominalAmount'] \
                                                                                      * self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'FutureUnderlying_PriceCAD'].fillna(self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Instrument_PriceCAD']) \
                                                                                      / self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Future_TickSize'].fillna(1) \
                                                                                      * self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Future_TickValue'].fillna(1)

        self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Exposure_Issuer']    = 0
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Exposure_Commodity'] = self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Notional_CAD']
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[FxFMV_CommodityNot, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[FxFMV_CommodityNot][self.exposure_columns + columns_FxFMV_CommodityNot + self.exposure_values_columns].sort_values(by = self.exposure_columns)
        
    #@#track_execution
    def calculate_exposure_normal_IssNotDe_FxFMV_EqtNotD(self, debug = False): 
        #exposure calculations filter definition
        columns_IssNotDe_FxFMV_EqtNotD = [  'Position_NominalAmount'
                                          , 'Option_ContractSize'
                                          , 'Option_ConversionRatio'
                                          , 'OptionUnderlying_PriceCAD'
                                          , 'Notional_CAD'
                                          , 'Position_Delta'
                                          , 'Delta_Notional_CAD'
                                          , 'Position_EquityDollarDelta'
                                          , 'Position_NetAssetValue_CAD'
                                          , 'Position_KRD'
                                         ]

        IssNotDe_FxFMV_EqtNotD = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssNotDe_FxFMV_EqtNotD')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        #Standard Positions
        self._fact_positions_all_with_mra.loc[(IssNotDe_FxFMV_EqtNotD), 'Notional_CAD'] =   self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Position_NominalAmount'] \
                                                                                          * self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Option_ContractSize'].fillna(1) \
                                                                                          * self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Option_ConversionRatio'].fillna(1) \
                                                                                          * self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'OptionUnderlying_PriceCAD']

        self._fact_positions_all_with_mra.loc[(IssNotDe_FxFMV_EqtNotD), 'Delta_Notional_CAD'] =   abs(self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Notional_CAD']) \
                                                                                                * self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Position_Delta']

        self._fact_positions_all_with_mra.loc[(IssNotDe_FxFMV_EqtNotD), 'Exposure_Issuer']    =   self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Delta_Notional_CAD']\
                                                                                                 .fillna(self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Position_EquityDollarDelta'])

        self._fact_positions_all_with_mra.loc[(IssNotDe_FxFMV_EqtNotD), 'Exposure_Equity']    =   self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Delta_Notional_CAD']\
                                                                                                 .fillna(self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Position_EquityDollarDelta'])

        self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssNotDe_FxFMV_EqtNotD, 'Exposure_CR']        = 0
        
        if debug:
            return self._fact_positions_all_with_mra[IssNotDe_FxFMV_EqtNotD][self.exposure_columns + columns_IssNotDe_FxFMV_EqtNotD + self.exposure_values_columns].sort_values(by = self.exposure_columns)

    #@#track_execution
    def calculate_exposure_normal_IssuerMV_FxFMV_EquityMV(self, debug = False):         
        #exposure calculations filter definition
        columns_IssuerMV_FxFMV_EquityMV = [  'Position_MarketValue_CAD'
                                           , 'Position_NetAssetValue_CAD'
                                           , 'Position_KRD'
                                          ]

        IssuerMV_FxFMV_EquityMV = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerMV_FxFMV_EquityMV')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Position_MarketValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_Equity']    = self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Position_MarketValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerMV_FxFMV_EquityMV, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerMV_FxFMV_EquityMV][self.exposure_columns + columns_IssuerMV_FxFMV_EquityMV + self.exposure_values_columns].sort_values(by = self.exposure_columns)        

    #@#track_execution
    def calculate_exposure_normal_IssuerMV_AI_FxFMV(self, debug = False):         
        #exposure calculations filter definition
        columns_IssuerMV_AI_FxFMV = [  'Position_MarketValue_CAD'
                                     , 'Position_NetAssetValue_CAD'
                                     , 'Position_KRD'
                                    ]

        IssuerMV_AI_FxFMV = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerMV_AI_FxFMV')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_Issuer']    =  self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Position_MarketValue_CAD']\
                                                                                          + self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Position_AccruedInterestValue_CAD']

        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Exposure_CR']        = self._fact_positions_all_with_mra.loc[IssuerMV_AI_FxFMV, 'Position_KRD'].fillna(0)

        if debug:
            return self._fact_positions_all_with_mra[IssuerMV_AI_FxFMV][self.exposure_columns + columns_IssuerMV_AI_FxFMV + self.exposure_values_columns].sort_values(by = self.exposure_columns)      

    #@#track_execution
    def calculate_exposure_normal_IssuerNot_FxFMV_Swap(self, debug = False):   
        #exposure calculations filter definition
        columns_IssuerNot_FxFMV_Swap = [  'Leg_Type'
                                        , 'Position_NominalAmount'
                                        , 'Position_FXRates_CurrencyCode_to_CAD'
                                        , 'Leg_Factor'
                                        , 'Notional_CAD'
                                        , 'Position_NetAssetValue_CAD'
                                        , 'Position_KRD'
                                       ]

        IssuerNot_FxFMV_Swap = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerNot_FxFMV_Swap')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Leg_Factor'] = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Leg_Type'].map(lambda x: 1 if x == 'TotalReturn' else -1 if x == 'CreditProtection' else 0).astype(int)
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Notional_CAD']   =   self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Position_NominalAmount']\
                                                                                        * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Position_FXRates_CurrencyCode_to_CAD']

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Exposure_Issuer']    =   self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Notional_CAD']\
                                                                                                   * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Leg_Factor']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Exposure_CR']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Swap, 'Position_KRD'].fillna(0)

        if debug:
            return self._fact_positions_all_with_mra[IssuerNot_FxFMV_Swap][self.exposure_columns + columns_IssuerNot_FxFMV_Swap + self.exposure_values_columns].sort_values(by = self.exposure_columns)    

    #@#track_execution
    def calculate_exposure_normal_IssuerNot_FxFMV_CDO(self, debug = False): 
        #exposure calculations filter definition
        columns_IssuerNot_FxFMV_CDO = [  'Leg_Type'
                                       , 'Position_NominalAmount'
                                       , 'Position_FXRates_CurrencyCode_to_CAD'
                                       , 'Leg_Factor'
                                       , 'Notional_CAD'
                                       , 'Position_NetAssetValue_CAD'
                                       , 'Position_KRD'
                                      ]

        IssuerNot_FxFMV_CDO = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerNot_FxFMV_CDO')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Leg_Factor'] = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Leg_Type'].map(lambda x: 1 if x == 'TotalReturn' else -1 if x == 'CreditProtection' else 0).astype(int)
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Notional_CAD']   =  self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Position_NominalAmount'] \
                                                                                        * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Position_FXRates_CurrencyCode_to_CAD']

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Exposure_Issuer']    =  self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Notional_CAD']\
                                                                                            * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Leg_Factor']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Exposure_CR']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_CDO, 'Position_KRD'].fillna(0)

        if debug:
            return self._fact_positions_all_with_mra[IssuerNot_FxFMV_CDO][self.exposure_columns + columns_IssuerNot_FxFMV_CDO + self.exposure_values_columns].sort_values(by = self.exposure_columns)

    #@#track_execution
    def calculate_exposure_normal_IssuerNot_FxFMV_Fut(self, debug = False): 
        #exposure calculations filter definition
        columns_IssuerNot_FxFMV_Fut = [  'Position_NominalAmount'
                                       , 'Future_ContractSymbol'
                                       , 'Instrument_PriceCAD'
                                       , 'Future_ContractSize'
                                       , 'Position_FXRates_CurrencyCode_to_CAD'
                                       , 'Notional_CAD'
                                       , 'Position_NetAssetValue_CAD'
                                       , 'Position_KRD'
                                      ]

        IssuerNot_FxFMV_Fut = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerNot_FxFMV_Fut')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'ContractValue_CAD'] = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, [  'Future_ContractSymbol'
                                                                                                                                                          , 'Instrument_PriceLocal'
                                                                                                                                                          , 'Instrument_PriceCAD'
                                                                                                                                                          , 'Future_ContractSize'
                                                                                                                                                          , 'Position_FXRates_CurrencyCode_to_CAD']].apply(lambda x: function_bond_future_price(x), axis = 1) 
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'Notional_CAD']      = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'Position_NominalAmount'] * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'ContractValue_CAD'] 

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'Notional_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fut, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerNot_FxFMV_Fut][self.exposure_columns + columns_IssuerNot_FxFMV_Fut + self.exposure_values_columns].sort_values(by = self.exposure_columns)        

    #@#track_execution        
    def calculate_exposure_normal_IssuerNot_FxFMV_Fwd(self, debug = False): 
        #exposure calculations filter definition
        columns_IssuerNot_FxFMV_Fwd = [  'Position_NominalAmount'
                                       , 'Forward_Price'
                                       , 'Position_FXRates_CurrencyCode_to_CAD'
                                       , 'Position_NetAssetValue_CAD'
                                       , 'Notional_CAD'
                                       , 'Position_KRD'
                                      ]

        IssuerNot_FxFMV_Fwd = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerNot_FxFMV_Fwd')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Notional_CAD'] = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Position_NominalAmount'] \
                                                                                     * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Forward_Price'] / 100.0 \
                                                                                     * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Position_FXRates_CurrencyCode_to_CAD']\
                                                                                     + self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Position_NetAssetValue_CAD']

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Notional_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_Fwd, 'Exposure_CR']        = 0
        
        if debug:
            return self._fact_positions_all_with_mra[IssuerNot_FxFMV_Fwd][self.exposure_columns + columns_IssuerNot_FxFMV_Fwd + self.exposure_values_columns].sort_values(by = self.exposure_columns)

    #@#track_execution
    def calculate_exposure_normal_IssuerNot_FxFMV_EquityNot_2Legs(self, debug = False): 
        #exposure calculations filter definition
        columns_IssuerNot_FxFMV_EquityNot_2Legs = [  'Leg_Type'
                                                   , 'Leg_Factor'
                                                   , 'Leg_FirstResetDate'
                                                   , 'First_Reset_Factor'
                                                   , 'Leg_LastResetDate'
                                                   , 'Last_Reset_Factor'
                                                   , 'Position_Quantity'
                                                   , 'Position_NetAssetValue_CAD'
                                                   , 'Notional_CAD'
                                                   , 'Position_KRD'
                                                  ]

        IssuerNot_FxFMV_EquityNot_2Legs = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerNot_FxFMV_EquityNot_2Legs')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Leg_Factor']         = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Leg_Type'].map(lambda x: 1 if x == 'TotalReturn' else -1 if x == 'CreditProtection' else 0).astype(int)
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'First_Reset_Factor'] = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, ['PositionDate','Leg_FirstResetDate']].apply(lambda x: function_check_first_reset_date(x), axis = 1)
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Last_Reset_Factor']  = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, ['PositionDate','Leg_LastResetDate']].apply(lambda x: function_check_last_reset_date(x), axis = 1)


        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Notional_CAD'] =  self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Position_Quantity'] \
                                                                                                  * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'UltimateUnderlying_PriceCAD']

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Exposure_Issuer']    =   self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Notional_CAD'] \
                                                                                                              * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'First_Reset_Factor']\
                                                                                                              * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Last_Reset_Factor']\
                                                                                                              * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Leg_Factor']

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Exposure_Equity']    =   self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Notional_CAD'] \
                                                                                                              * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'First_Reset_Factor']\
                                                                                                              * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Last_Reset_Factor']\
                                                                                                              * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Leg_Factor']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_2Legs, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerNot_FxFMV_EquityNot_2Legs][self.exposure_columns + columns_IssuerNot_FxFMV_EquityNot_2Legs + self.exposure_values_columns].sort_values(by = self.exposure_columns) 

    #@#track_execution        
    def calculate_exposure_normal_IssuerNot_FxFMV_EquityNot_1_Fut(self, debug = False): 
        #exposure calculations filter definition
        columns_IssuerNot_FxFMV_EquityNot_1_Fut = [  'Position_NominalAmount'
                                                   , 'Future_ContractSize'
                                                   , 'Instrument_PriceCAD'
                                                   , 'Notional_CAD'
                                                   , 'Position_NetAssetValue_CAD'
                                                   , 'Position_KRD'
                                                  ]

        IssuerNot_FxFMV_EquityNot_1_Fut = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerNot_FxFMV_EquityNot_1_Fut')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')
        
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Notional_CAD'] =  self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Position_NominalAmount']\
                                                                                                  * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Future_ContractSize']\
                                                                                                  * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Instrument_PriceCAD']

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Notional_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Exposure_Equity']    = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Notional_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fut, 'Exposure_CR']        = 0
        
        if debug:
            return self._fact_positions_all_with_mra[IssuerNot_FxFMV_EquityNot_1_Fut][self.exposure_columns + columns_IssuerNot_FxFMV_EquityNot_1_Fut + self.exposure_values_columns].sort_values(by = self.exposure_columns)       
 
    #@#track_execution       
    def calculate_exposure_normal_IssuerNot_FxFMV_EquityNot_1_Fwd(self, debug = False): 
        #exposure calculations filter definition
        columns_IssuerNot_FxFMV_EquityNot_1_Fwd = [  'Position_NominalAmount'
                                                   , 'UltimateUnderlying_PriceCAD'
                                                   , 'Notional_CAD'
                                                   , 'Position_NetAssetValue_CAD'
                                                   , 'Position_KRD'
                                                  ]

        IssuerNot_FxFMV_EquityNot_1_Fwd = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerNot_FxFMV_EquityNot_1_Fwd')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')
        
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Notional_CAD'] =  self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Position_NominalAmount']\
                                                                                                  * self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'UltimateUnderlying_PriceCAD']

        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Notional_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Exposure_Equity']    = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Notional_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerNot_FxFMV_EquityNot_1_Fwd, 'Exposure_CR']        = 0
        
        if debug:
            return self._fact_positions_all_with_mra[IssuerNot_FxFMV_EquityNot_1_Fwd][self.exposure_columns + columns_IssuerNot_FxFMV_EquityNot_1_Fwd + self.exposure_values_columns].sort_values(by = self.exposure_columns)       

    #@#track_execution        
    def calculate_exposure_normal_IssuerNotDelta_FxFMV_CDS(self, debug = False): 
        #exposure calculations filter definition
        columns_IssuerNotDelta_FxFMV_CDS = [  'Position_NominalAmount'
                                            , 'Position_FXRates_CurrencyCode_to_CAD'
                                            , 'Notional_CAD'
                                            , 'Position_Delta'
                                            , 'Delta_Notional_CAD'
                                            , 'Position_NetAssetValue_CAD'
                                            , 'Position_KRD'
                                           ]

        IssuerNotDelta_FxFMV_CDS = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerNotDelta_FxFMV_CDS')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')
        
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Notional_CAD'] =   self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Position_NominalAmount']  \
                                                                                            * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Position_FXRates_CurrencyCode_to_CAD']

        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Delta_Notional_CAD'] =   abs(self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Notional_CAD'])  \
                                                                                                  * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Position_Delta']

        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Delta_Notional_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_CDS, 'Exposure_CR']        = 0
        
        if debug:
            return self._fact_positions_all_with_mra[IssuerNotDelta_FxFMV_CDS][self.exposure_columns + columns_IssuerNotDelta_FxFMV_CDS + self.exposure_values_columns].sort_values(by = self.exposure_columns)      

    #@#track_execution        
    def calculate_exposure_normal_IssuerNotDelta_FxFMV_Bond(self, debug = False): 
        #exposure calculations filter definition
        columns_IssuerNotDelta_FxFMV_Bond = [  'Position_NominalAmount'
                                             , 'UltimateUnderlying_PriceCAD'
                                             , 'Notional_CAD'
                                             , 'Position_Delta'
                                             , 'Delta_Notional_CAD'
                                             , 'Position_NetAssetValue_CAD'
                                             , 'Position_KRD'
                                            ]

        IssuerNotDelta_FxFMV_Bond = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerNotDelta_FxFMV_Bond')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')
        
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Notional_CAD'] =  self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Position_NominalAmount']\
                                                                                            * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'UltimateUnderlying_PriceCAD']

        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Delta_Notional_CAD'] =  abs(self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Notional_CAD']) \
                                                                                                  * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Position_Delta']

        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Exposure_Issuer']    =  self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Delta_Notional_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Bond, 'Exposure_CR']        = 0
        
        if debug:
            return self._fact_positions_all_with_mra[IssuerNotDelta_FxFMV_Bond][self.exposure_columns + columns_IssuerNotDelta_FxFMV_Bond + self.exposure_values_columns].sort_values(by = self.exposure_columns)     

    #@#track_execution        
    def calculate_exposure_normal_IssuerNotDelta_FxFMV_Fut(self, debug = False):         
        #exposure calculations filter definition
        columns_IssuerNotDelta_FxFMV_Fut = [  'OptionFuture_ContractSymbol'
                                            , 'Position_NominalAmount'
                                            , 'OptionUnderlying_PriceLocal'
                                            , 'OptionUnderlying_PriceCAD'
                                            , 'Option_ContractSize'
                                            , 'Position_FXRates_CurrencyCode_to_CAD'
                                            , 'Notional_CAD'
                                            , 'Delta_Notional_CAD'
                                            , 'Position_Delta'
                                            , 'Position_NetAssetValue_CAD'
                                            , 'Position_KRD'
                                           ]

        IssuerNotDelta_FxFMV_Fut = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerNotDelta_FxFMV_Fut')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        IssuerNotDelta_FxFMV_Fut_1 = (self._fact_positions_all_with_mra['OptionFuture_ContractSymbol'].isnull())
        IssuerNotDelta_FxFMV_Fut_2 = (~self._fact_positions_all_with_mra['OptionFuture_ContractSymbol'].isnull())

        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut & IssuerNotDelta_FxFMV_Fut_1, 'Notional_CAD'] =  self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut & IssuerNotDelta_FxFMV_Fut_1, 'Position_NominalAmount']  \
                                                                                                                        * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut & IssuerNotDelta_FxFMV_Fut_1, 'OptionUnderlying_PriceCAD']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut & IssuerNotDelta_FxFMV_Fut_2, 'Notional_CAD'] =  self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut & IssuerNotDelta_FxFMV_Fut_2, 'Position_NominalAmount']\
                                                                                                                        * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut & IssuerNotDelta_FxFMV_Fut_2, [   'OptionFuture_ContractSymbol'
                                                                                                                                                                                                                       , 'OptionUnderlying_PriceLocal'
                                                                                                                                                                                                                       , 'OptionUnderlying_PriceCAD'
                                                                                                                                                                                                                       , 'Option_ContractSize'
                                                                                                                                                                                                                       , 'Position_FXRates_CurrencyCode_to_CAD']
                                                                                                                                                                                                                       ].apply(lambda x: function_bond_future_price(x), axis = 1)

        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Delta_Notional_CAD'] =  abs(self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Notional_CAD']) \
                                                                                                 * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Position_Delta'] 

        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Delta_Notional_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Position_NetAssetValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Position_KRD'].fillna(0)
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxFMV_Fut, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerNotDelta_FxFMV_Fut][self.exposure_columns + columns_IssuerNotDelta_FxFMV_Fut + self.exposure_values_columns].sort_values(by = self.exposure_columns)
    
    #function to apply private investment exposure rule inside public market portfolio type (Instrument_Categorzation_ID = 0)
    def calculate_exposure_normal_private_IssuerNAV_FxMV(self,debug = False):
        columns_IssuerNAV_FxMV = [  'Position_MarketValue_CAD'
                                  , 'Position_NetAssetValue_CAD'
                                 ]

        IssuerNAV_FxMV = (self._fact_positions_all_with_mra['normal_calculation_family'] == 'IssuerNAV_FxMV')&(self._fact_positions_all_with_mra['calc_type'] == 'normal')

        self._fact_positions_all_with_mra.loc[IssuerNAV_FxMV, 'Exposure_Issuer']    =  self._fact_positions_all_with_mra.loc[IssuerNAV_FxMV, 'Position_NetAssetValue_CAD']
                                                                                          
        self._fact_positions_all_with_mra.loc[IssuerNAV_FxMV, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerNAV_FxMV, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNAV_FxMV, 'Position_MarketValue_CAD']
        self._fact_positions_all_with_mra.loc[IssuerNAV_FxMV, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNAV_FxMV, 'Exposure_FI']        = 0
        self._fact_positions_all_with_mra.loc[IssuerNAV_FxMV, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerNAV_FxMV][self.exposure_columns + columns_IssuerNAV_FxMV + self.exposure_values_columns].sort_values(by = self.exposure_columns)      


    #@#track_execution
    def calculate_exposure_exotic_FxCcyDDelta(self, debug = False):    
        columns_FxCcyDDelta = [ 'Position_CurrencyDollarDelta'
                              , 'Position_KRD']
        
        FxCcyDDelta = (self._fact_positions_all_with_mra['exotic_calculation_family'] == 'FxCcyDDelta')&(self._fact_positions_all_with_mra['calc_type'] == 'pooled fund')
        
        self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Exposure_Issuer']    = 0
        self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Position_CurrencyDollarDelta']
        self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Position_KRD']
        self._fact_positions_all_with_mra.loc[FxCcyDDelta, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[FxCcyDDelta][self.exposure_columns + columns_FxCcyDDelta + self.exposure_values_columns].sort_values(by = self.exposure_columns)

    #@#track_execution        
    def calculate_exposure_exotic_FxPV(self, debug = False):  
        columns_FxPV = [ 'Position_PresentValue'
                       , 'Position_KRD']
        
        FxPV = (self._fact_positions_all_with_mra['exotic_calculation_family'] == 'FxPV')&(self._fact_positions_all_with_mra['calc_type'] == 'pooled fund')
        
        self._fact_positions_all_with_mra.loc[FxPV, 'Exposure_Issuer']    = 0
        self._fact_positions_all_with_mra.loc[FxPV, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[FxPV, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[FxPV, 'Position_PresentValue']
        self._fact_positions_all_with_mra.loc[FxPV, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[FxPV, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[FxPV, 'Position_KRD']
        self._fact_positions_all_with_mra.loc[FxPV, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[FxPV][self.exposure_columns + columns_FxPV + self.exposure_values_columns].sort_values(by = self.exposure_columns)   

    #@#track_execution        
    def calculate_exposure_exotic_FxPV_CommoCmdtyDDelta(self, debug = False): 
        columns_FxPV_CommoCmdtyDDelta = [ 'Position_PresentValue'
                                        , 'Position_CommodityDollarDelta'
                                        , 'Position_KRD']
        
        FxPV_CommoCmdtyDDelta = (self._fact_positions_all_with_mra['exotic_calculation_family'] == 'FxPV_CommoCmdtyDDelta')&(self._fact_positions_all_with_mra['calc_type'] == 'pooled fund')
        
        self._fact_positions_all_with_mra.loc[FxPV_CommoCmdtyDDelta, 'Exposure_Issuer']    = 0
        self._fact_positions_all_with_mra.loc[FxPV_CommoCmdtyDDelta, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[FxPV_CommoCmdtyDDelta, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[FxPV_CommoCmdtyDDelta, 'Position_PresentValue']
        self._fact_positions_all_with_mra.loc[FxPV_CommoCmdtyDDelta, 'Exposure_Commodity'] = self._fact_positions_all_with_mra.loc[FxPV_CommoCmdtyDDelta, 'Position_CommodityDollarDelta']
        self._fact_positions_all_with_mra.loc[FxPV_CommoCmdtyDDelta, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[FxPV_CommoCmdtyDDelta, 'Position_KRD']
        self._fact_positions_all_with_mra.loc[FxPV_CommoCmdtyDDelta, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[FxPV_CommoCmdtyDDelta][self.exposure_columns + columns_FxPV_CommoCmdtyDDelta + self.exposure_values_columns].sort_values(by = self.exposure_columns)    
 
    #@#track_execution       
    def calculate_exposure_exotic_IssEqtyDelta_FxPV_EqEqtDe(self, debug = False): 
        columns_IssEqtyDelta_FxPV_EqEqtDe = [ 'Position_EquityDollarDelta'
                                            , 'Position_PresentValue'
                                            , 'Position_KRD']
        
        IssEqtyDelta_FxPV_EqEqtDe = (self._fact_positions_all_with_mra['exotic_calculation_family'] == 'IssEqtyDelta_FxPV_EqEqtDe')&(self._fact_positions_all_with_mra['calc_type'] == 'pooled fund')
        
        #IssEqtyDelta_FxPV_EqEqtDe_1 = (self._fact_positions_all_with_mra['exotic_calculation_family'] == 'IssEqtyDelta_FxPV_EqEqtDe')
        
        self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'MRA_neutralization_factor'] = self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'Instrument_PSPInstrumentCategorizationID'].map(lambda x: 0 if x == -1 else 1)
        self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'Position_EquityDollarDelta'] * self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'MRA_neutralization_factor']
        self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'Exposure_Equity']    = self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'Position_EquityDollarDelta'] * self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'MRA_neutralization_factor']
        self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'Position_PresentValue']
        self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'Position_KRD']
        self._fact_positions_all_with_mra.loc[IssEqtyDelta_FxPV_EqEqtDe, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssEqtyDelta_FxPV_EqEqtDe][self.exposure_columns + columns_IssEqtyDelta_FxPV_EqEqtDe + self.exposure_values_columns].sort_values(by = self.exposure_columns)    

    #@#track_execution        
    def calculate_exposure_exotic_IssuerNot_FxPV(self, debug = False):    
        columns_IssuerNot_FxPV = [ 'Position_NotionalInBaseCurrency'
                                 , 'Position_PresentValue'
                                 , 'Position_KRD']
        
        IssuerNot_FxPV = (self._fact_positions_all_with_mra['exotic_calculation_family'] == 'IssuerNot_FxPV')&(self._fact_positions_all_with_mra['calc_type'] == 'pooled fund')
        
        self._fact_positions_all_with_mra.loc[IssuerNot_FxPV, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerNot_FxPV, 'Position_NotionalInBaseCurrency']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxPV, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxPV, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxPV, 'Position_PresentValue']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxPV, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNot_FxPV, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNot_FxPV, 'Position_KRD']
        self._fact_positions_all_with_mra.loc[IssuerNot_FxPV, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerNot_FxPV][self.exposure_columns + columns_IssuerNot_FxPV + self.exposure_values_columns].sort_values(by = self.exposure_columns) 

    #@#track_execution        
    def calculate_exposure_exotic_IssuerNotDelta_FxPV(self, debug = False): 
        columns_IssuerNotDelta_FxPV = [ 'Position_NotionalInBaseCurrency'
                                      , 'Position_Delta'
                                      , 'Position_PresentValue'
                                      , 'Position_KRD']
        
        IssuerNotDelta_FxPV = (self._fact_positions_all_with_mra['exotic_calculation_family'] == 'IssuerNotDelta_FxPV')&(self._fact_positions_all_with_mra['calc_type'] == 'pooled fund')
        
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV, 'Exposure_Issuer']    = abs(self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV, 'Position_NotionalInBaseCurrency']) * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV, 'Position_Delta']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV, 'Position_PresentValue']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV, 'Position_KRD']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerNotDelta_FxPV][self.exposure_columns + columns_IssuerNotDelta_FxPV + self.exposure_values_columns].sort_values(by = self.exposure_columns)   

    #@#track_execution        
    def calculate_exposure_exotic_IssuerPV_FxPV(self, debug = False): 
        columns_IssuerPV_FxPV = [ 'Position_PresentValue'
                                , 'Position_KRD']
        
        IssuerPV_FxPV = (self._fact_positions_all_with_mra['exotic_calculation_family'] == 'IssuerPV_FxPV')&(self._fact_positions_all_with_mra['calc_type'] == 'pooled fund')
        
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerPV_FxPV, 'Position_PresentValue']
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV, 'Exposure_Equity']    = 0
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerPV_FxPV, 'Position_PresentValue']
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerPV_FxPV, 'Position_KRD']
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerPV_FxPV][self.exposure_columns + columns_IssuerPV_FxPV + self.exposure_values_columns].sort_values(by = self.exposure_columns)    

    #@#track_execution        
    def calculate_exposure_exotic_IssuerNotDelta_FxPV_EqtyEqtDDe(self, debug = False):   
        columns_IssuerNotDelta_FxPV_EqtyEqtDDe = [ 'Position_NotionalInBaseCurrency'
                                                 , 'Position_Delta'
                                                 , 'Position_KRD']
        
        IssuerNotDelta_FxPV_EqtyEqtDDe = (self._fact_positions_all_with_mra['exotic_calculation_family'] == 'IssuerNotDelta_FxPV_EqtyEqtDDe')&(self._fact_positions_all_with_mra['calc_type'] == 'pooled fund')
        
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'MRA_neutralization_factor'] = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Instrument_PSPInstrumentCategorizationID'].map(lambda x: 0 if x == -1 else 1)
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Position_NotionalInBaseCurrency'] * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Position_Delta'] * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'MRA_neutralization_factor']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Exposure_Equity']    = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Position_NotionalInBaseCurrency'] * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Position_Delta'] * self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'MRA_neutralization_factor']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Position_PresentValue']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Position_KRD']
        self._fact_positions_all_with_mra.loc[IssuerNotDelta_FxPV_EqtyEqtDDe, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerNotDelta_FxPV_EqtyEqtDDe][self.exposure_columns + columns_IssuerNotDelta_FxPV_EqtyEqtDDe + self.exposure_values_columns].sort_values(by = self.exposure_columns)  
 
    #@#track_execution       
    def calculate_exposure_exotic_IssuerPV_FxPV_EqtyEqtDDe(self, debug = False): 
        columns_IssuerPV_FxPV_EqtyEqtDDe = [ 'Position_PresentValue'
                                           , 'Position_EquityDollarDelta'
                                           , 'Position_PresentValue'
                                           , 'Position_KRD']
        
        IssuerPV_FxPV_EqtyEqtDDe = (self._fact_positions_all_with_mra['exotic_calculation_family'] == 'IssuerPV_FxPV_EqtyEqtDDe')&(self._fact_positions_all_with_mra['calc_type'] == 'pooled fund')
        
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'MRA_neutralization_factor'] = self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'Instrument_PSPInstrumentCategorizationID'].map(lambda x: 0 if x == -1 else 1)
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'Exposure_Issuer']    = self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'Position_PresentValue'] * self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'MRA_neutralization_factor']
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'Exposure_Equity']    = self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'Position_EquityDollarDelta'] * self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'MRA_neutralization_factor']
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'Exposure_FX']        = self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'Position_PresentValue']
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'Exposure_Commodity'] = 0
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'Exposure_FI']        = self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'Position_KRD']
        self._fact_positions_all_with_mra.loc[IssuerPV_FxPV_EqtyEqtDDe, 'Exposure_CR']        = 0

        if debug:
            return self._fact_positions_all_with_mra[IssuerPV_FxPV_EqtyEqtDDe][self.exposure_columns + columns_IssuerPV_FxPV_EqtyEqtDDe + self.exposure_values_columns].sort_values(by = self.exposure_columns)
    
    ####################################################################################################
    ### 6 Exposure Structure Output ####################################################################
    ####################################################################################################
    
    def generate_exposure_non_extended(self):
        if not self.run_standard:
            logging.exception("The argument 'run_standard' is not set to True")
        else:
            Position_NetAssetValue_CAD_filter = (self.fact_exposure_non_extended()['Position_NetAssetValue_CAD'] != 0) 
            Exposure_FI_filter                = (self.fact_exposure_non_extended()['Exposure_FI'] != 0)                
            Exposure_CR_filter                = (self.fact_exposure_non_extended()['Exposure_CR'] != 0)                
            Exposure_Issuer_filter            = (self.fact_exposure_non_extended()['Exposure_Issuer'] != 0)            
            Exposure_Equity_filter            = (self.fact_exposure_non_extended()['Exposure_Equity'] != 0)            
            Exposure_FX_filter                = (self.fact_exposure_non_extended()['Exposure_FX'] != 0)                
            Exposure_Commodity_filter         = (self.fact_exposure_non_extended()['Exposure_Commodity'] != 0)          
            Standard_filter                   = (self.fact_exposure_non_extended()['Object_Type'] != 'Unitary Benchmark')&(self.fact_exposure_non_extended()['Object_Type'] != 'Unitary Index')
            if self.batch_key is not None:
                Batch_filter                  = (self.fact_exposure_non_extended()['Portfolio_PSPPortfolioID'].isin(self.mra_batch_portfolios()))
                full_filter = (Position_NetAssetValue_CAD_filter | Exposure_FI_filter | Exposure_CR_filter | Exposure_Issuer_filter | Exposure_Equity_filter | Exposure_FX_filter | Exposure_Commodity_filter) & Standard_filter & Batch_filter
            else:
                full_filter = (Position_NetAssetValue_CAD_filter | Exposure_FI_filter | Exposure_CR_filter | Exposure_Issuer_filter | Exposure_Equity_filter | Exposure_FX_filter | Exposure_Commodity_filter) & Standard_filter
            
            return self.fact_exposure_non_extended()[full_filter][PAC.fact_exposure_columns]
    
    def generate_unitary_benchmarks(self):
        if not self.run_unitary_benchmarks:
            logging.exception("The argument 'run_unitary_benchmarks' is not set to True")
        else:
            Position_NetAssetValue_CAD_filter = (self.fact_exposure_non_extended()['Position_NetAssetValue_CAD'] != 0) 
            Exposure_FI_filter                = (self.fact_exposure_non_extended()['Exposure_FI'] != 0)                
            Exposure_CR_filter                = (self.fact_exposure_non_extended()['Exposure_CR'] != 0)                
            Exposure_Issuer_filter            = (self.fact_exposure_non_extended()['Exposure_Issuer'] != 0)            
            Exposure_Equity_filter            = (self.fact_exposure_non_extended()['Exposure_Equity'] != 0)            
            Exposure_FX_filter                = (self.fact_exposure_non_extended()['Exposure_FX'] != 0)                
            Exposure_Commodity_filter         = (self.fact_exposure_non_extended()['Exposure_Commodity'] != 0)          
            Unitary_Benchmark_filter          = (self.fact_exposure_non_extended()['Object_Type'] == 'Unitary Benchmark')
            
            full_filter = (Position_NetAssetValue_CAD_filter | Exposure_FI_filter | Exposure_CR_filter | Exposure_Issuer_filter | Exposure_Equity_filter | Exposure_FX_filter | Exposure_Commodity_filter) & Unitary_Benchmark_filter

            return self.fact_exposure_non_extended()[full_filter][PAC.fact_unitary_benchmarks_columns]

    def generate_unitary_indices(self):
        if not self.run_unitary_indices:
            logging.exception("The argument 'run_unitary_indices' is not set to True")
        else:
            Position_NetAssetValue_CAD_filter = (self.fact_exposure_non_extended()['Position_NetAssetValue_CAD'] != 0) 
            Exposure_FI_filter                = (self.fact_exposure_non_extended()['Exposure_FI'] != 0)                
            Exposure_CR_filter                = (self.fact_exposure_non_extended()['Exposure_CR'] != 0)                
            Exposure_Issuer_filter            = (self.fact_exposure_non_extended()['Exposure_Issuer'] != 0)            
            Exposure_Equity_filter            = (self.fact_exposure_non_extended()['Exposure_Equity'] != 0)            
            Exposure_FX_filter                = (self.fact_exposure_non_extended()['Exposure_FX'] != 0)                
            Exposure_Commodity_filter         = (self.fact_exposure_non_extended()['Exposure_Commodity'] != 0)          
            Unitary_Index_filter              = (self.fact_exposure_non_extended()['Object_Type'] == 'Unitary Index')
            
            full_filter = (Position_NetAssetValue_CAD_filter | Exposure_FI_filter | Exposure_CR_filter | Exposure_Issuer_filter | Exposure_Equity_filter | Exposure_FX_filter | Exposure_Commodity_filter) & Unitary_Index_filter

            return self.fact_exposure_non_extended()[full_filter][PAC.fact_unitary_indices_columns]
    
    def generate_exposure_extended(self):
        return self.fact_exposure_extended()[PAC.exposure_extended_mapping.keys()]

    def agg_by_categorization_id(self):
        if self._agg_by_categorization_id is None:
            self._agg_by_categorization_id = self.generate_exposure_non_extended()[[  'PositionDate'
                                                                                    , 'Object_Type'
                                                                                    , 'Position_Type'
                                                                                    , 'Position_Source'
                                                                                    , 'Portfolio_PSPPortfolioCode'
                                                                                    , 'Instrument_PSPInstrumentCategorizationID'
                                                                                    , "Instrument_PSPInstrumentCategorizationCode"
                                                                                    , 'use_pooled_fund_calculations'
                                                                                    , 'Position_NetAssetValue_CAD'
                                                                                    , 'Exposure_Equity'
                                                                                    , 'Exposure_Issuer'
                                                                                    , 'Exposure_Commodity'
                                                                                    , 'Exposure_FX'
                                                                                    , 'Exposure_FI'
                                                                                    , 'Exposure_CR']
                                                                                  ].groupby(by = [  'PositionDate'
                                                                                                  , 'Object_Type'
                                                                                                  , 'Position_Type'
                                                                                                  , 'Position_Source'
                                                                                                  , 'Portfolio_PSPPortfolioCode'
                                                                                                  , 'Instrument_PSPInstrumentCategorizationID'
                                                                                                  , "Instrument_PSPInstrumentCategorizationCode"
                                                                                                 ]
                                                                                           ).agg(  count              = pd.NamedAgg(column = 'use_pooled_fund_calculations', aggfunc = 'count')
                                                                                                 , NetAssetValue_CAD  = pd.NamedAgg(column = 'Position_NetAssetValue_CAD',   aggfunc = 'sum')
                                                                                                 , Exposure_Equity    = pd.NamedAgg(column = 'Exposure_Equity',              aggfunc = 'sum')
                                                                                                 , Exposure_Issuer    = pd.NamedAgg(column = 'Exposure_Issuer',              aggfunc = 'sum')
                                                                                                 , Exposure_Commodity = pd.NamedAgg(column = 'Exposure_Commodity',           aggfunc = 'sum')
                                                                                                 , Exposure_FX        = pd.NamedAgg(column = 'Exposure_FX',                  aggfunc = 'sum')
                                                                                                 , Exposure_FI        = pd.NamedAgg(column = 'Exposure_FI',                  aggfunc = 'sum')
                                                                                                 , Exposure_CR        = pd.NamedAgg(column = 'Exposure_CR',                  aggfunc = 'sum')
                                                                                                )
        return self._agg_by_categorization_id
    
    def agg_by_portfolio(self):
        if self._agg_by_portfolio is None:
            self._agg_by_portfolio = self.generate_exposure_non_extended()[[   'PositionDate'
                                                                             , 'Object_Type'
                                                                             , 'Position_Type'
                                                                             , 'Position_Source'
                                                                             , 'Portfolio_PSPPortfolioCode'
                                                                             , 'use_pooled_fund_calculations'
                                                                             , 'Position_NetAssetValue_CAD'
                                                                             , 'Exposure_Equity'
                                                                             , 'Exposure_Issuer'
                                                                             , 'Exposure_Commodity'
                                                                             , 'Exposure_FX'
                                                                             , 'Exposure_FI'
                                                                             , 'Exposure_CR']
                                                                           ].groupby(by = [  'PositionDate'
                                                                                           , 'Object_Type'
                                                                                           , 'Position_Type'
                                                                                           , 'Position_Source'
                                                                                           , 'Portfolio_PSPPortfolioCode'
                                                                                          ]
                                                                                    ).agg(  count              = pd.NamedAgg(column = 'use_pooled_fund_calculations', aggfunc = 'count')
                                                                                          , NetAssetValue_CAD  = pd.NamedAgg(column = 'Position_NetAssetValue_CAD',   aggfunc = 'sum')
                                                                                          , Exposure_Equity    = pd.NamedAgg(column = 'Exposure_Equity',              aggfunc = 'sum')
                                                                                          , Exposure_Issuer    = pd.NamedAgg(column = 'Exposure_Issuer',              aggfunc = 'sum')
                                                                                          , Exposure_Commodity = pd.NamedAgg(column = 'Exposure_Commodity',           aggfunc = 'sum')
                                                                                          , Exposure_FX        = pd.NamedAgg(column = 'Exposure_FX',                  aggfunc = 'sum')
                                                                                          , Exposure_FI        = pd.NamedAgg(column = 'Exposure_FI',                  aggfunc = 'sum')
                                                                                          , Exposure_CR        = pd.NamedAgg(column = 'Exposure_CR',                  aggfunc = 'sum')
                                                                                         )
        return self._agg_by_portfolio
    
    def generate_output_dict(self):
        
        if self.output_dictionary is None:
            
            self.output_dictionary = {}

            if self.run_standard:

                self.output_dictionary['fact_exposure']            = {  'name': 'fact_exposure'
                                                                    , 'file_format':'csv'
                                                                    , 'dataframe': self.generate_exposure_non_extended()[PAC.csv_columns['fact_exposure']]
                                                                    }
                
                self.output_dictionary['fact_all_constituents']    = {  'name': 'fact_all_constituents'
                                                                      , 'file_format':'csv'
                                                                      , 'dataframe': self.fact_all_constituents()[PAC.csv_columns['fact_all_constituents']]
                                                                     }
                
                self.output_dictionary['fact_portfolios']          = {  'name': 'fact_portfolios'
                                                                      , 'file_format':'csv'
                                                                      , 'dataframe': self.fact_portfolios()[PAC.csv_columns['fact_portfolios']]
                                                                     }
    
                self.output_dictionary['dim_issuers']              = {  'name': 'dim_issuers'
                                                                      , 'file_format':'csv'
                                                                      , 'dataframe': self.dim_issuers()[PAC.csv_columns['dim_issuers']]
                                                                      }
        
                self.output_dictionary['dim_gics']                 = {  'name': 'dim_gics'
                                                                      , 'file_format':'csv'
                                                                      , 'dataframe': self.dim_gics()[PAC.csv_columns['dim_gics']]
                                                                      }
            
                self.output_dictionary['dim_countries']            = {  'name': 'dim_countries'
                                                                      , 'file_format':'csv'
                                                                      , 'dataframe': self.dim_countries()[PAC.csv_columns['dim_countries']]
                                                                      }
                
                self.output_dictionary['dim_portfolios']           = {  'name': 'dim_portfolios'
                                                                      , 'file_format':'csv'
                                                                      , 'dataframe': self.dim_portfolios()[PAC.csv_columns['dim_portfolios']]
                                                                     }
                
            if self.run_unitary_benchmarks:
            
                self.output_dictionary['fact_unitary_benchmarks']  = {  'name': 'fact_unitary_benchmarks'
                                                                      , 'file_format':'csv'
                                                                      , 'dataframe': self.generate_unitary_benchmarks()[PAC.csv_columns['fact_unitary_benchmarks']]
                                                                     }
                
            if self.run_unitary_indices:
            
                self.output_dictionary['fact_unitary_indices']     = {  'name': 'fact_unitary_indices'
                                                                      , 'file_format':'csv'
                                                                      , 'dataframe': self.generate_unitary_indices()[PAC.csv_columns['fact_unitary_indices']]
                                                                     }

        return self.output_dictionary

    def generate_pipeline_outputs(self):
        signature_evaluation_date = self.parameters['evaluation_date']
        signature_position_dates   = data_acquisition.function_sql_list_formatter(parameter_list = self.parameters['position_dates'], is_string = True).replace("'", "").replace(",", "_")
        signature = '__' + signature_evaluation_date + '__' + signature_position_dates
        
        folder_path = self.file_path + '/' + self.execution_timestamp + signature
        
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        for current_dataset_name in self.generate_output_dict():
            current_file_format = self.output_dictionary[current_dataset_name]['file_format']
            
            if current_file_format == 'csv':
                
                current_file_name   = current_dataset_name + '.csv'
                current_file_path = folder_path + '/' + current_file_name
                
                current_file_df   = self.output_dictionary[current_dataset_name]['dataframe']
                
                current_file_df.astype(str).to_csv(  current_file_path
                                                   , index = False
                                                   , float_format = str
                                                   , quoting = csv.QUOTE_NONNUMERIC
                                                   , sep=';'
                                                  )
                
            elif current_file_format == 'excel':
                
                current_file_name   = current_dataset_name + '.xlsx'
                current_file_path = folder_path + '/' + current_file_name
                
                current_file_df   = self.output_dictionary[current_dataset_name]['dataframe']
                
                current_file_df.to_excel(  folder_path + '/' + current_file_name
                                         , index = False
                                         , float_format = str
                                         , quoting = csv.QUOTE_NONNUMERIC
                                         , sep=';'
                                        )
                
            elif current_file_format == 'multi_tab_excel':
                
                current_file_name     = current_dataset_name + '.xlsx'
                current_file_path     = folder_path + '/' + current_file_name
                
                current_files_dict = self.output_dictionary[current_dataset_name]['dataframes']
                
                with pd.ExcelWriter(current_file_path, engine='xlsxwriter') as writer:
                    for element in current_files_dict:
                        current_files_dict[element].to_excel(writer, sheet_name = element)
                          
        return self.file_path
    
        
    def generate_csv_files(self, d_store:DataSource = None):
        logging.info(f">>>>> Generating dataframes / csv files. <<<<<")
        signature_evaluation_date = self.parameters['evaluation_date']
        signature_position_dates   = data_acquisition.function_sql_list_formatter(parameter_list = self.parameters['position_dates'], is_string = True).replace("'", "").replace(",", "_")
        signature = '__' + signature_evaluation_date + '__' + signature_position_dates
        
        if self.output_path is None:
            folder_path = self.file_path + '/' + self.execution_timestamp + signature
        else:
            folder_path = self.file_path + '/' + self.output_path
        
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        for current_dataset_name in self.generate_output_dict():
            current_file_name    = current_dataset_name + '.csv'
            current_file_path    = folder_path + '/' + current_file_name
            current_file_format  = self.output_dictionary[current_dataset_name]['file_format']
            current_file_df      = self.output_dictionary[current_dataset_name]['dataframe']

            
            if current_file_format == 'csv':
                if d_store is not None:
                    published = d_store.load_dataframe(current_dataset_name,
                                                    self.output_dictionary[current_dataset_name].get('dataframe', None))
                else:
                    published = False
                
                if not published:
                    current_file_df.astype(str).replace(['nan','NaN','None','NaT','nat'],''
                                                        ).to_csv(  current_file_path
                                                                 , index = False
                                                                 , float_format = str
                                                                 , quoting = csv.QUOTE_NONNUMERIC
                                                                 , sep=';'
                                                                 )
                    with open(current_file_path, 'r', encoding="utf8") as file:
                        data = file.read().replace(';""', ';').replace('"";',';')

                    with open(current_file_path, 'w', encoding="utf8") as file:
                        file.write(data)

                
            elif current_file_format == 'excel':
                current_file_df.to_excel(  folder_path + '/' + current_file_name
                                 , index = False
                                 , float_format = str
                                 , quoting = csv.QUOTE_NONNUMERIC
                                 , sep=';'
                                )
        
        return self.file_path
    
    def generate_exposure_v1(self):
        if self._fact_exposure_extended_v1 is None:
            fact_filt = self.fact_exposure_extended().copy()
            #remove position without Issuer exposure
            fact_filt = fact_filt[(fact_filt['Constituent_Exposure_Issuer'] != 0)
                                 &(fact_filt['Object_Type'] == 'Portfolio')
                                 &(~fact_filt['Instrument_IssuerCode'].isin([-4,-14]))
                                 &(fact_filt['Portfolio_PSPPortfolioCode'] != 'TR01CAP')
                                 ]
            #set Instrument_IDs for pooled fund to -1 (to presere confidentiality)
            col_no_id = ['Instrument_PSPInstrumentID','Issuer_PSPLegalEntityID','Constituent_PSPInstrumentID','Leg_PSPInstrumentLegID']
            fact_filt.loc[fact_filt['Position_Type'].isin(['Pooled Fund/Private Membership with Data','Pooled Fund/Private Membership without Data']),col_no_id] = -1

            #use issuer level ID/Code if Intrument level is unavailable
            fact_filt['Instrument_BICSBETAClassificationID'] = fact_filt['Instrument_BICSBETAClassificationID'].fillna(fact_filt['Issuer_BICSBETAClassificationID'])
            fact_filt['Instrument_RiskLocationCountryCode'] = fact_filt['Instrument_RiskLocationCountryCode'].fillna(fact_filt['Issuer_RiskLocationCountryCode'])
            fact_filt = fact_filt[list(PAC.col_maping_v2_to_v1.keys())].rename(columns = PAC.col_maping_v2_to_v1)

            #sum exposure for rows with identitical attributes
            list_col_to_grouby = list(set(PAC.col_maping_v2_to_v1.values()) - set('CalculatedIssuerExposureinCAD'))
            fact_grouped = fact_filt.groupby(list_col_to_grouby, dropna=False,sort=False, as_index = False)\
                .agg({'CalculatedIssuerExposureinCAD': 'sum'})
            self._fact_exposure_extended_v1 = fact_grouped[list(PAC.col_maping_v2_to_v1.values())]
            self._fact_exposure_extended_v1['CalculatedIssuerExposureinCAD'] = pd.to_numeric(self._fact_exposure_extended_v1['CalculatedIssuerExposureinCAD'])
            self._fact_exposure_extended_v1['ValuationDate'] = self._fact_exposure_extended_v1['ValuationDate'].dt.strftime('%Y-%m-%d')
            
        return self._fact_exposure_extended_v1
    
    
    def generate_csv_file_exposure_v1(self, verify_end_of_month_date = True):
        
        #if verify_end_of_month_date is True:
        for date in self.parameters['position_dates']:
            date = datetime.strptime(date, "%Y-%m-%d")
            if (datetime.date(date + timedelta(days=1)).day != 1):
                logging.warn('One of the dates is not an end of month date')
                break
            else:
                #the function is called at the beginning, so we are sure we are able to generate the exposure before erasing old exposure
                self.generate_exposure_v1()
                try:
                    username = os.getlogin()
                    folder_path = PAC.exposure_v1_root_folder + username + PAC.exposure_v1_folder_path
                    #step to verify we dont upload two different files for the same date
                    #there is one big file for dates from 2021-08-31 to 2022-10-31 with data from V1 code
                    original_file_path = folder_path + PAC.exposure_v1_file_name
                    original_exposure_file = pd.read_csv(original_file_path,sep = '|')
                    dates_to_replace = set(original_exposure_file['ValuationDate']) & set(self.parameters['position_dates'])
                    if len(dates_to_replace) != 0:
                        original_exposure_file[~original_exposure_file['ValuationDate'].isin(dates_to_replace)].to_csv(original_file_path, sep = '|', index=False)

                    for date in self.parameters['position_dates']:
                        #create a new folder for a date when it does not already exists
                        if date not in next(os.walk(folder_path))[1] :
                            folder_path_new_date = folder_path + date
                            os.mkdir(folder_path_new_date)
                        #if the file for a sprecific EOM date already exist, we simply write over it
                        full_path = folder_path + date + '//' + PAC.exposure_v1_file_name
                        self.generate_exposure_v1()[self.generate_exposure_v1()['ValuationDate'] == date].to_csv(full_path, sep = '|', index=False)

                except Exception:
                    logging.exception('You must first sync SharePoint folder: "D&A Collaboration - Exposure files" to your machine')


    
    ####################################################################################################
    # 7 Data Validation  ###############################################################################
    #################################################################################################### 
    
    def mra_exposure_with_calendardate(self):
        if self._mra_exposure_with_calendardate is None:
            self._mra_exposure_with_calendardate = self.mra_exposure().merge(self.mra_batch_mapping()\
                         [['PortfolioID','CalendarDate','MostRecent_Batch_key']]
                        , left_on = ['PortfolioID', 'BatchKey']
                        , right_on = ['PortfolioID','MostRecent_Batch_key'] , how = 'left'
                        ).drop(columns=['MostRecent_Batch_key','CalendarKey'])
        return self._mra_exposure_with_calendardate


    def _compare_tfe_vs_mra_merge(self, granularity_level, object_type, port_to_ignore, use_snowflake=False):
        '''
        Auxiliary function to merge exposure dataset
        '''
       
        #filter out cat id and portfolios that are problematic
        cat_id_to_ignore = []
                           #[ 1162 # mra not considering this cat (TRS on inflation bond)
                           #,1108 # CDS constituent merge on MRA not working
                           #,1055 # delta of 0 from risk metrics
                           #]

        if use_snowflake:
            tfe_exposure = self.exposure_extended_snowflake().copy(deep = True)
        else:
            tfe_exposure = self.fact_exposure_extended().copy(deep = True)
        mra_exposure = self.mra_exposure_with_calendardate()

        #no comparison on public market portfolios holding private positions
        # private_port_id = tfe_exposure[(tfe_exposure['Position_Type'] == 'Private Market')
        #                               &(tfe_exposure['Portfolio_MarketType'] == 'Public Market')]['Portfolio_PSPPortfolioID'].unique()
        
        #remove port with small NAV, as they are usually not modelled by MRA
        if use_snowflake is False:
            small_nav_port_id = tfe_exposure[(tfe_exposure['Portfolio_Position_NetAssetValue_CAD'] < 50000000)
                                        &(tfe_exposure['Portfolio_MarketType'] == 'Public Market')]['Portfolio_PSPPortfolioID'].unique()
        else:
            small_nav_port_id =[]

        port_to_ignore += list(small_nav_port_id)
        
        tfe_exposure = tfe_exposure[(~tfe_exposure['Instrument_PSPInstrumentCategorizationID'].isin(cat_id_to_ignore))
                                     &(~tfe_exposure['Portfolio_PSPPortfolioID'].isin(port_to_ignore))]

        mra_exposure = mra_exposure[(~mra_exposure['Instrument_PSPInstrumentCategorizationID'].isin(cat_id_to_ignore))
                                    &(~mra_exposure['PortfolioID'].isin(port_to_ignore))]
        
        #we could add other dimensions to compare the exposures on
        granularity_list = ['PortfolioID', 'Instrument_PSPInstrumentCategorizationID','Constituent_PSPInstrumentCategorizationID']
        granularity_list_code = ['PortfolioCode', 'Instrument_PSPInstrumentCategorizationCode','Constituent_PSPInstrumentCategorizationCode']
        
        #create list for granularity levels chosen
        for idx, el in enumerate(granularity_list):
            if granularity_level == el:
                granularity_levels = granularity_list[:idx+1]
                index = idx
        
        #modify dict to only include relevant col
        exclusion_col = (set(granularity_list) - set(granularity_levels) ) | set(granularity_list_code[index+1:])
        columns_mapping_TFE_MRA = {key:val for key, val in PAC.col_mapping_tfe_mra.items() if val not in exclusion_col}
        
        #calculated exposure from TFE tool
        tfe_exposure = tfe_exposure[(tfe_exposure['Object_Type'] == object_type)]
        
        tfe_exposure = tfe_exposure[columns_mapping_TFE_MRA.keys()].rename(columns = (columns_mapping_TFE_MRA)) #ok
        cols_to_groupby = list(columns_mapping_TFE_MRA.values())[:-3]
        #col_merged = ['CalendarDate', 'PortfolioCode'] +  granularity_levels + list(PAC.col_mapping_tfe_mra.values())[-3:]
        
        tfe_exposure = tfe_exposure.fillna(0).groupby(cols_to_groupby , dropna = False, as_index = False).sum(numeric_only=True)

        #calculated exposure from risk team
        mra_exposure = mra_exposure[mra_exposure['Object_Type'] == object_type]
        cols_mra = list(columns_mapping_TFE_MRA.values())
        cols_mra.remove('PortfolioCode')
        cols_to_groupby_mra = cols_mra[:-3]
        mra_exposure = mra_exposure[cols_mra].fillna(0).groupby(cols_to_groupby_mra, dropna = False, as_index = False).sum(numeric_only=True)

        #left join on mra
        df_merged = pd.merge(tfe_exposure, mra_exposure
                             , on = cols_to_groupby_mra
                             , how = 'outer'
                             , suffixes = ['_fact','_mra'])
        
        #df_merged  = df_merged[[columns_mapping_TFE_MRA.values()]]
        return df_merged
    
    
    def compare_tfe_vs_mra_df(self
                              ,granularity_level = 'PortfolioID'
                              ,object_type = 'Portfolio'
                              ,exposure_to_compare = 'Issuer'
                              ,tolerance_level= 0.05
                              ,port_to_ignore = []
                              ,df_merged = None
                              ,excel_export = False
                              ,use_snowflake = False):
        
        '''
        Function to output a dataframe with divergent porfolios

        granularity_level: 'PortfolioID' or 'Instrument_PSPInstrumentCategorizationID'
        exposure_to_compare: issuer, equity or commodity
        object_type: 'Portfolio' or 'Benchmark'
        tolerance_level: % of difference to consider
        port_to_ignore: portfolio ID to ignore for the comparison
        excel_export: export output dataframe to excel file
        '''
        if df_merged is None:
            df_merged = self._compare_tfe_vs_mra_merge(granularity_level, object_type, port_to_ignore, use_snowflake)

        if object_type == 'Portfolio':
            diff_pct = abs((df_merged[f'Exposure_{exposure_to_compare}_fact'] / df_merged[f'Exposure_{exposure_to_compare}_mra'] )- 1 )
            diff_ind = diff_pct.loc[lambda x : x > tolerance_level]
            df_merged_tol = df_merged.iloc[diff_ind.index].copy()
            df_merged_tol['Difference_%'] = diff_ind
            df_merged_tol['Difference_absolute'] = abs(df_merged_tol[f'Exposure_{exposure_to_compare}_fact'] - df_merged_tol[f'Exposure_{exposure_to_compare}_mra'])
        else: #Benchmark
            diff_pct = abs((df_merged[f'Exposure_{exposure_to_compare}_fact']) / df_merged[f'Exposure_{exposure_to_compare}_mra'] )- 1 
            diff_ind = diff_pct.loc[lambda x : x > tolerance_level]
            df_merged_tol = df_merged.iloc[diff_ind.index].copy()
            df_merged_tol['Difference_%'] = diff_ind
            df_merged_tol['Difference_absolute'] = abs(df_merged_tol[f'Exposure_{exposure_to_compare}_fact'] + df_merged_tol[f'Exposure_{exposure_to_compare}_mra'])
        #remove inconsequential difference
        df_merged_tol = df_merged_tol[(df_merged_tol['Difference_absolute'] > 1000000)]\
                                    .sort_values(['CalendarDate','PortfolioID','Difference_absolute'], ascending = [True,True,False])
                                                
        if excel_export is True:
            df_merged_tol.to_excel(f'difference_{object_type}_level_eval_{self.original_evaluation_date}_position_{self.parameters["position_dates"]}.xlsx')

        return df_merged_tol
    
    def compare_tfe_vs_mra_summary(self
                                   ,port_to_ignore = []
                                   ,granularity_level = 'PortfolioID'
                                   ,object_type = 'Portfolio'
                                   ,tolerance_levels = [0.01,0.05]
                                   ,exposures_to_compare = ['Issuer', 'Equity']
                                   ):
        
        '''
        Function to generate summary comparison of public market exposure generated from MRA vs TFE
        Output: DF with number of portfolio for which exposure if different (tolerance level of 1% and 5%)
        '''

        df_merged = self._compare_tfe_vs_mra_merge(granularity_level, object_type, port_to_ignore)
        mra_exposure = self.mra_exposure_with_calendardate()

        data = []
        for exposure_to_compare in exposures_to_compare:
            for tolerance_level in tolerance_levels:
                df = self.compare_tfe_vs_mra_df(granularity_level = granularity_level
                                                ,object_type = object_type
                                                ,exposure_to_compare = exposure_to_compare
                                                ,tolerance_level = tolerance_level
                                                ,port_to_ignore = port_to_ignore
                                                ,df_merged = df_merged)
                for date in self.parameters['position_dates']:
                    insert_row = {
                                'Date': date
                                ,'Tolerance_Level' : tolerance_level
                                ,'Exposure': exposure_to_compare
                                ,'Number of portfolios (MRA)': mra_exposure[mra_exposure['CalendarDate'] == date]['PortfolioID'].nunique()
                                ,'Number of differences': df[df['CalendarDate'] == date]['PortfolioID'].nunique()
                                ,'Sum of dollar difference': df['Difference_absolute'].sum(numeric_only = True)
                                ,'Granularity_level': granularity_level
                                ,'Object_Type':object_type
                                 }
                    data.append(insert_row)

        df_summary = pd.DataFrame(data).sort_values('Date')
        return df_summary
    
    def compare_tfe_private_df(self, tolerance_level = 0.05, excel_export = False, use_snowflake = False):
        '''
        Function to compare exposure calculated from TFE vs Private Markets
        Only Issuer exposure is considered
        tolerance_level: % of difference to consider
        excel_export: export output dataframe to xlsx file
        '''

        private_exposure =  self.private_markets()
        col_to_groupby = ['PositionDate','Portfolio_PSPPortfolioID']
        
        #calculated exposure from TFE tool
        if use_snowflake:
            tfe_exposure = self.exposure_extended_snowflake()
        else:
            tfe_exposure = self.fact_exposure_extended()
        tfe_exposure= tfe_exposure[tfe_exposure['Portfolio_MarketType'] != 'Public Market']\
            [col_to_groupby + ['Constituent_Exposure_Issuer']].rename(columns={'Constituent_Exposure_Issuer':'Exposure_Issuer_TFE'})

        tfe_exposure = tfe_exposure.fillna(0).groupby(col_to_groupby, dropna = False,as_index = False).sum(numeric_only=True)

        #calculated exposure from private market team
        private_exposure = private_exposure.rename(columns={'Position_ExposureValue_CAD':'Exposure_Issuer_Private'})
        private_exposure = private_exposure[col_to_groupby + ['Exposure_Issuer_Private']]\
            .fillna(0).groupby(col_to_groupby, dropna = False).sum(numeric_only=True).reset_index()

        #left join on mra
        df_merged = pd.merge(private_exposure, tfe_exposure
                             , on = col_to_groupby
                             , how = 'left'
                             , suffixes = ['_private','_TFE'])
        
        diff_pct = abs((df_merged['Exposure_Issuer_Private'].astype('float64') / df_merged['Exposure_Issuer_TFE'].astype('float64') ) - 1)
        diff_ind = diff_pct.loc[lambda x : x > tolerance_level]
        df_merged = df_merged.iloc[diff_ind.index]
        df_merged['Difference_%'] = diff_ind

        df_merged['Difference_absolute'] = abs(df_merged['Exposure_Issuer_Private'] - df_merged['Exposure_Issuer_TFE'])
        #remove inconsequential difference
        df_merged = df_merged [df_merged['Difference_absolute'] > 100000].sort_values('Difference_%', ascending = False)

        if excel_export is True:
            df_merged.to_excel(f'difference_private_eval_{self.original_evaluation_date}_position_{self.parameters["position_dates"]}.xlsx')
        
        return df_merged

    def generate_automated_validation(self
                                     , min_absolute_error = 1000000
                                     , min_relative_error = 0.01
                                     , use_snowflake = False
                                     , exposure_to_test = ['Equity','Issuer','Commodity']
                                     ):
        
        #Benchmark by cat id
        comparison_mra_constituent_benchmark = self._compare_tfe_vs_mra_merge(  granularity_level   = 'Constituent_PSPInstrumentCategorizationID'
                                                                             , object_type         = 'Benchmark'
                                                                             , port_to_ignore      = []
                                                                             , use_snowflake = use_snowflake
                                                                            )
        comparison_mra_constituent_benchmark['Object_Type'] = 'Benchmark'
        comparison_mra_constituent_benchmark['Granularity_Level'] = 'Constituent_PSPInstrumentCategorizationID'
        comparison_mra_constituent_benchmark['Instrument_PSPInstrumentCategorizationID']  = comparison_mra_constituent_benchmark['Instrument_PSPInstrumentCategorizationID'].fillna(-999)
        comparison_mra_constituent_benchmark['Constituent_PSPInstrumentCategorizationID'] = comparison_mra_constituent_benchmark['Constituent_PSPInstrumentCategorizationID'].fillna(-999)
        comparison_mra_constituent_benchmark['Instrument_PSPInstrumentCategorizationCode']  = comparison_mra_constituent_benchmark['Instrument_PSPInstrumentCategorizationCode'].fillna('Not Available')
        comparison_mra_constituent_benchmark['Constituent_PSPInstrumentCategorizationCode'] = comparison_mra_constituent_benchmark['Constituent_PSPInstrumentCategorizationCode'].fillna('Not Available')
        
        #Portfolio by cat id
        comparison_mra_constituent_portfolio = self._compare_tfe_vs_mra_merge(  granularity_level   = 'Constituent_PSPInstrumentCategorizationID'
                                                                             , object_type         = 'Portfolio'
                                                                             , port_to_ignore      = []
                                                                             , use_snowflake = use_snowflake
                                                                            )
        comparison_mra_constituent_portfolio['Object_Type'] = 'Portfolio'
        comparison_mra_constituent_portfolio['Granularity_Level'] = 'Constituent_PSPInstrumentCategorizationID'
        comparison_mra_constituent_portfolio['Instrument_PSPInstrumentCategorizationID']  = comparison_mra_constituent_portfolio['Instrument_PSPInstrumentCategorizationID'].fillna(-999)
        comparison_mra_constituent_portfolio['Constituent_PSPInstrumentCategorizationID'] = comparison_mra_constituent_portfolio['Constituent_PSPInstrumentCategorizationID'].fillna(-999)
        comparison_mra_constituent_portfolio['Instrument_PSPInstrumentCategorizationCode']  = comparison_mra_constituent_portfolio['Instrument_PSPInstrumentCategorizationCode'].fillna('Not Available')
        comparison_mra_constituent_portfolio['Constituent_PSPInstrumentCategorizationCode'] = comparison_mra_constituent_portfolio['Constituent_PSPInstrumentCategorizationCode'].fillna('Not Available')
        

        #Benchmark by cat id
        comparison_mra_instrument_benchmark = self._compare_tfe_vs_mra_merge(  granularity_level   = 'Instrument_PSPInstrumentCategorizationID'
                                                                             , object_type         = 'Benchmark'
                                                                             , port_to_ignore      = []
                                                                             , use_snowflake = use_snowflake
                                                                            )
        comparison_mra_instrument_benchmark['Object_Type'] = 'Benchmark'
        comparison_mra_instrument_benchmark['Granularity_Level'] = 'Instrument_PSPInstrumentCategorizationID'
        comparison_mra_instrument_benchmark['Instrument_PSPInstrumentCategorizationID']  = comparison_mra_instrument_benchmark['Instrument_PSPInstrumentCategorizationID'].fillna(-999)
        comparison_mra_instrument_benchmark['Constituent_PSPInstrumentCategorizationID'] = -1
        comparison_mra_instrument_benchmark['Instrument_PSPInstrumentCategorizationCode']  = comparison_mra_instrument_benchmark['Instrument_PSPInstrumentCategorizationCode'].fillna('Not Available')
        comparison_mra_instrument_benchmark['Constituent_PSPInstrumentCategorizationCode'] = 'Total'
        
        #Portfolio by cat id
        comparison_mra_instrument_portfolio = self._compare_tfe_vs_mra_merge(  granularity_level   = 'Instrument_PSPInstrumentCategorizationID'
                                                                             , object_type         = 'Portfolio'
                                                                             , port_to_ignore      = []
                                                                             , use_snowflake = use_snowflake
                                                                            )
        comparison_mra_instrument_portfolio['Object_Type'] = 'Portfolio'
        comparison_mra_instrument_portfolio['Granularity_Level'] = 'Instrument_PSPInstrumentCategorizationID'
        comparison_mra_instrument_portfolio['Instrument_PSPInstrumentCategorizationID']  = comparison_mra_instrument_portfolio['Instrument_PSPInstrumentCategorizationID'].fillna(-999)
        comparison_mra_instrument_portfolio['Constituent_PSPInstrumentCategorizationID'] = -1
        comparison_mra_instrument_portfolio['Instrument_PSPInstrumentCategorizationCode']  = comparison_mra_instrument_portfolio['Instrument_PSPInstrumentCategorizationCode'].fillna('Not Available')
        comparison_mra_instrument_portfolio['Constituent_PSPInstrumentCategorizationCode'] = 'Total'
        
        #Benchmark total
        comparison_mra_portfolio_benchmark = self._compare_tfe_vs_mra_merge(  granularity_level   = 'PortfolioID'
                                                                            , object_type         = 'Benchmark'
                                                                            , port_to_ignore      = []
                                                                            , use_snowflake = use_snowflake
                                                                           )
        comparison_mra_portfolio_benchmark['Object_Type'] = 'Benchmark'
        comparison_mra_portfolio_benchmark['Granularity_Level'] = 'PortfolioID'
        comparison_mra_portfolio_benchmark['Instrument_PSPInstrumentCategorizationID']  = -1
        comparison_mra_portfolio_benchmark['Constituent_PSPInstrumentCategorizationID'] = -1
        comparison_mra_portfolio_benchmark['Instrument_PSPInstrumentCategorizationCode']  = 'Total'
        comparison_mra_portfolio_benchmark['Constituent_PSPInstrumentCategorizationCode'] = 'Total'
        
        #Portfolio total
        comparison_mra_portfolio_portfolio = self._compare_tfe_vs_mra_merge(  granularity_level   = 'PortfolioID'
                                                                            , object_type         = 'Portfolio'
                                                                            , port_to_ignore      = []
                                                                            , use_snowflake = use_snowflake
                                                                           )
        comparison_mra_portfolio_portfolio['Object_Type'] = 'Portfolio'
        comparison_mra_portfolio_portfolio['Granularity_Level'] = 'PortfolioID'
        comparison_mra_portfolio_portfolio['Instrument_PSPInstrumentCategorizationID']  = -1
        comparison_mra_portfolio_portfolio['Constituent_PSPInstrumentCategorizationID'] = -1
        comparison_mra_portfolio_portfolio['Instrument_PSPInstrumentCategorizationCode']  = 'Total'
        comparison_mra_portfolio_portfolio['Constituent_PSPInstrumentCategorizationCode'] = 'Total'
        
        #Relative difference calculations
        full_comparison_benchmark = pd.concat([comparison_mra_constituent_benchmark, comparison_mra_instrument_benchmark, comparison_mra_portfolio_benchmark])
        full_comparison_portfolio = pd.concat([comparison_mra_constituent_portfolio, comparison_mra_instrument_portfolio, comparison_mra_portfolio_portfolio])
        display_columns = []

        #Benchmark mra exposure must be multiplied by -1 to be aligned with TFE
        for exposure in exposure_to_test:
            mra_exposure_name = 'Exposure_' + exposure + '_mra'
            full_comparison_benchmark[mra_exposure_name] = -1.0 * full_comparison_benchmark[mra_exposure_name]
        
        full_comparison = pd.concat([full_comparison_benchmark, full_comparison_portfolio])
        full_comparison['exposure is not significantly different'] = 1
        
        for exposure in exposure_to_test:
            tfe_exposure_name = 'Exposure_' + exposure + '_fact'
            mra_exposure_name = 'Exposure_' + exposure + '_mra'
            absolute_error_name = exposure + ' absolute difference'
            relative_error_name = exposure + ' relative difference'
            non_significant_error_name = exposure + ' is not significantly different'

            display_columns = display_columns + [tfe_exposure_name, mra_exposure_name, absolute_error_name, relative_error_name, non_significant_error_name ]

            full_comparison[absolute_error_name]        = full_comparison[[tfe_exposure_name, mra_exposure_name]].apply(lambda x: adjusted_absolute_error(x[0], x[1]), axis = 1)
            full_comparison[relative_error_name]        = full_comparison[[tfe_exposure_name, mra_exposure_name]].apply(lambda x: adjusted_relative_error(x[0], x[1]), axis = 1)
            full_comparison[non_significant_error_name] = full_comparison[[absolute_error_name, relative_error_name]].apply(lambda x: flag_non_significant_error(x[0], x[1], min_absolute_error, min_relative_error), axis = 1)
            
            full_comparison['exposure is not significantly different'] = full_comparison['exposure is not significantly different'] * full_comparison[non_significant_error_name]
        

        other_columns = [row for row in full_comparison.columns if row not in display_columns]

        full_comparison = full_comparison[full_comparison['exposure is not significantly different'] == 0]
        
        return full_comparison[other_columns + display_columns]
    
    def compare_nav_before_after(self):
        nav_before = self.fact_portfolios().copy()
        nav_before = nav_before[['PositionDate','Portfolio_PSPPortfolioID','Portfolio_Position_NetAssetValue_CAD']]
        nav_after = self.fact_exposure_non_extended().copy()
        nav_after = nav_after[nav_after['Object_Type'] == 'Portfolio']
        nav_after = nav_after[['PositionDate','Portfolio_PSPPortfolioID','Portfolio_PSPPortfolioCode','Position_NetAssetValue_CAD']]\
            .groupby(['PositionDate','Portfolio_PSPPortfolioCode','Portfolio_PSPPortfolioID'], dropna = False, as_index = False).sum(numeric_only = True)

        nav_before_after = pd.merge(nav_before, nav_after, on = ['PositionDate','Portfolio_PSPPortfolioID'], how = 'outer')\
            .rename(columns={'Portfolio_Position_NetAssetValue_CAD':'Portfolio_NetAssetValue_before'
                            ,'Position_NetAssetValue_CAD'          :'Portfolio_NetAssetValue_after'})
        nav_before_after['Difference (absolute)'] = abs(nav_before_after['Portfolio_NetAssetValue_before'] - nav_before_after['Portfolio_NetAssetValue_after'])

        nav_before_after = nav_before_after.sort_values(['PositionDate','Difference (absolute)']
                                                        , ascending =[True, False])[['PositionDate'
                                                                                    ,'Portfolio_PSPPortfolioID'
                                                                                    ,'Portfolio_PSPPortfolioCode'
                                                                                    ,'Portfolio_NetAssetValue_before'
                                                                                    ,'Portfolio_NetAssetValue_after'
                                                                                    ,'Difference (absolute)'
                                                                                    ]]
        return nav_before_after
    
    def validation_creditriskdm_portfolio( self
                                         , min_absolute_error = 1000000
                                         , min_relative_error = 0.05
                                         ):
        '''
        This function compares the exposure produced by creditriskdm to the exposure produced by TFE on three levels: portfolio, instrument and constituent.
        The function tries to "bring" the exposure produced by creditriskdm to the same level as TFE, thefore a few rules are applied
        '''

        col_tfe = list(PAC.col_mapping_creditriskdm_to_tfe.values())
        cols_to_merge = list(PAC.col_mapping_creditriskdm_to_tfe.values())[:-1]
        exposure_tfe = self.exposure_tfe_snowflake().copy()[col_tfe]

        #clean creditriskdm data
        exposure_credit = self.exposure_creditrisk_dm().copy()

        #remove positions where that dont have a issuer exposure only for public market
        cond_1_1 = (exposure_credit['AssetClassName_Grouping'] == 'Public')
        cond_1_2 = (exposure_credit['Coverage'] == 'No Issuer')
        cond_1 =  cond_1_1 & (cond_1_2)

        #Exposure should be 0 for instrument that have asset grouping = public and coverage = private and not ALT
        cond_2_1 = (exposure_credit['Coverage'] == 'Private Market')
        cond_2_2 = (exposure_credit['PSPPortfolioCode'].str.startswith('ALT'))

        cond_2 = cond_1_1 & cond_2_1 & (~cond_2_2)

        cond_all = ~cond_1 & ~cond_2
        exposure_credit = exposure_credit[cond_all]
        #exposure_credit = exposure_credit[~cond_2]
        exposure_credit['Source'] = exposure_credit['Source'].apply(lambda x: 'Portfolio' if x == 'PSP' else 'Benchmark')

        exposure_credit = exposure_credit.rename(columns = (PAC.col_mapping_creditriskdm_to_tfe))[PAC.col_mapping_creditriskdm_to_tfe.values()]
        exposure_credit = exposure_credit.groupby(cols_to_merge, dropna = False, as_index=False).sum() # groupby to ignore country

        exposure_merged = pd.merge(   exposure_tfe
                                    , exposure_credit
                                    , on = cols_to_merge
                                    , how = 'outer'
                                    , suffixes = ['_tfe','_credit'])

        cols_port = col_tfe[:3]
        exposure_port = exposure_merged.groupby(cols_port, as_index= False, dropna=False).sum(numeric_only=True)
        exposure_port['instrument_psp_instrument_categorization_code'] = 'Not Avalaible'
        exposure_port['constituent_psp_instrument_categorization_code'] = 'Not Avalaible'
        exposure_port['granularity_level'] = 'Portfolio'

        cols_inst = col_tfe[:4]
        exposure_inst = exposure_merged.groupby(cols_inst, as_index= False, dropna=False).sum(numeric_only=True)
        exposure_inst['constituent_psp_instrument_categorization_code'] = 'Not Avalaible'
        exposure_inst['granularity_level'] = 'Instrument'

        cols_const = cols_to_merge
        exposure_const = exposure_merged.groupby(cols_const, as_index= False, dropna=False).sum(numeric_only=True)
        exposure_const['granularity_level'] = 'Constituent'

        exposure_all = pd.concat([exposure_port,exposure_inst,exposure_const])

        exposure_all['exposure is not significantly different'] = 1
        exposure_all['absolute_error'] = exposure_all[['constituent_issuer_exposure_tfe', 'constituent_issuer_exposure_credit']].apply(lambda x: adjusted_absolute_error(x[0], x[1]), axis = 1)
        exposure_all['relative_error'] = exposure_all[['constituent_issuer_exposure_tfe', 'constituent_issuer_exposure_credit']].apply(lambda x: adjusted_relative_error(x[0], x[1]), axis = 1)
        exposure_all['non_significant_error'] = exposure_all[['absolute_error', 'relative_error']].apply(lambda x: flag_non_significant_error(x[0], x[1], min_absolute_error, min_relative_error), axis = 1)

        exposure_all['exposure is not significantly different'] = exposure_all['exposure is not significantly different'] * exposure_all['non_significant_error']
        exposure_all = exposure_all[exposure_all['exposure is not significantly different'] == 0]

        #order columns
        exposure_all = exposure_all[['valuation_date', 'benchmark_assignation', 'granularity_level', 'l4_psp_portfolio_code',
                'instrument_psp_instrument_categorization_code',
                'constituent_psp_instrument_categorization_code', 
                'constituent_issuer_exposure_tfe', 'constituent_issuer_exposure_credit',
                'exposure is not significantly different', 'absolute_error',
                'relative_error', 'non_significant_error']]
        
        return exposure_all
    
    def validation_creditriskdm_emr(self
                                  , fields_to_compare = ['sector_name','region_name','l5_asset_class_name']
                                  , keep_significant_only = False
                                  , min_absolute_error = 1000000
                                  , min_relative_error = 0.05
        ):
        '''
        This functions compares the exposure produced by creditriskdm to the exposure produced by TFE based on the EMR report rules
        '''
        exposure_df = pd.DataFrame()

        for field in fields_to_compare:
            tfe_emr = self.exposure_tfe_snowflake_emr().copy()
            credit_emr = self.exposure_creditrisk_dm_emr().copy()

            if field != 'sector_name':
                tfe_emr = tfe_emr[~tfe_emr['country_name'].isnull()]
                credit_emr = credit_emr[~credit_emr['country_name'].isnull()]
            else:
                tfe_emr = tfe_emr[~tfe_emr[field].isnull()]
                credit_emr = credit_emr[~credit_emr[field].isnull()]
            
            cols_to_keep = ['valuation_date','issuer_exposure'] + [field]
            cols_to_groupby = ['valuation_date'] + [field]

            tfe_emr = tfe_emr[cols_to_keep].groupby(cols_to_groupby, dropna=False).sum().reset_index()
            tfe_emr['issuer_exposure_percentage'] = tfe_emr['issuer_exposure'] / tfe_emr['issuer_exposure'].sum()

            credit_emr = credit_emr[cols_to_keep].groupby(cols_to_groupby, dropna=False).sum().reset_index()
            credit_emr['issuer_exposure_percentage'] = credit_emr['issuer_exposure'] / credit_emr['issuer_exposure'].sum()
            
            exposure_all = pd.merge(tfe_emr, credit_emr
                                ,on = cols_to_groupby
                                ,how = 'outer'
                                ,suffixes= ('_tfe', '_credit'))
            
            exposure_all['metric_name'] = field
            exposure_all['metric_value'] = exposure_all[field]
            exposure_all['difference_dollar'] = exposure_all['issuer_exposure_tfe'] - exposure_all['issuer_exposure_credit']
            exposure_all['difference_bps'] = (exposure_all['issuer_exposure_tfe'] / exposure_all['issuer_exposure_credit'] - 1) * 10000

            exposure_df = pd.concat([exposure_df, exposure_all], axis = 0)    

        if not keep_significant_only:
            exposure_df = exposure_df[['valuation_date', 'metric_name', 'metric_value','issuer_exposure_tfe', 'issuer_exposure_credit',
                    'difference_dollar', 'difference_bps']]
            return exposure_df
        else:
            exposure_df['exposure is not significantly different'] = 1
            exposure_df['absolute_error'] = exposure_df[['issuer_exposure_tfe', 'issuer_exposure_credit']].apply(lambda x: adjusted_absolute_error(x[0], x[1]), axis = 1)
            exposure_df['relative_error'] = exposure_df[['issuer_exposure_tfe', 'issuer_exposure_credit']].apply(lambda x: adjusted_relative_error(x[0], x[1]), axis = 1)
            exposure_df['non_significant_error'] = exposure_df[['absolute_error', 'relative_error']].apply(lambda x: flag_non_significant_error(x[0], x[1], min_absolute_error, min_relative_error), axis = 1)

            exposure_df['exposure is not significantly different'] = exposure_df['exposure is not significantly different'] * exposure_df['non_significant_error']
            exposure_df = exposure_df[exposure_df['exposure is not significantly different'] == 0]

            exposure_df = exposure_df[['valuation_date', 'metric_name', 'metric_value','issuer_exposure_tfe', 'issuer_exposure_credit',
                    'exposure is not significantly different', 'absolute_error',
                    'relative_error', 'non_significant_error']]
            return exposure_df

    