Write-Host "---------> Invoking Retro-Exposure Compute tasks <---------" -ForegroundColor Green
$root_dir = Get-Location
$venv_dir = $root_dir.ToString() + "\.venv"
$activate_path = $venv_dir + "\Scripts\Activate.ps1"
 
& $activate_path
python -m retro_execution