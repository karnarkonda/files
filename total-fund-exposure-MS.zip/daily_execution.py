"""Daily Task Module."""
import logging

from app.process_triggers import (trigger_adhoc_executions,
                                  trigger_data_migration,
                                  trigger_exposure_compute,
                                  trigger_quality_validation)
from app.services.messaging.msteams import MSTeams

if __name__ == "__main__":
    # Core Stages
    try:
        # Step 1
        trigger_exposure_compute()
        # Step 2
        trigger_data_migration()

        MSTeams().post_info('Daily Exposure Processor',
                            'Daily Execution Completed!')
    except Exception:
        logging.exception("**** Exception thrown during daily benchmarking **")

    # Auxilliary stages
    try:
        # Run MRA Business Validation rules.
        trigger_quality_validation()

        # Run Adhoc stored procs
        trigger_adhoc_executions()
  
    except Exception:
        logging.exception("**** Exception thrown during Post-daily \
                          benchmarking executions**")
