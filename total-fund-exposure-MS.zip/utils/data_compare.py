from difflib import SequenceMatcher

import pandas as pd


def diff_value(OLD, NEW):
    numeric_class = [
        "int",
        "float",
        "<class 'numpy.float64'>",
        "<class 'numpy.int32'>",
    ]
    if str(type(OLD)) == "<class 'str'>":
        if str(type(NEW)) == "<class 'str'>":
            return float("nan")
        else:
            return ["type issue", float("nan")]
    elif str(type(OLD)) in numeric_class:
        if str(type(NEW)) in numeric_class:
            return 1.0 if OLD == NEW else NEW / OLD
        else:
            return float("nan")
    else:
        return float("nan")


def compare_value(OLD, NEW, tolerance=5):
    if OLD != OLD:
        if NEW != NEW:
            return ["Ok", "00", float("nan")]
        else:
            return ["Issue", "01", NEW]
    else:
        if NEW != NEW:
            return ["Issue", "10", OLD]
        else:
            diff = diff_value(OLD, NEW)
            if round(diff, tolerance) == 1.0:
                return ["Ok", "11", 1.0]
            else:
                return ["Issue", "11", diff]


def compare_dataset(
    dataset_OLD,
    dataset_NEW,
    unique_key_columns
    # , groupby_columns
    ,
    analysis_columns,
):
    master_df = pd.concat(
        [dataset_OLD[unique_key_columns], dataset_NEW[unique_key_columns]]
    ).drop_duplicates()

    dataset_OLD["exists"] = 1
    dataset_NEW["exists"] = 1
    analysis_columns = ["exists"] + analysis_columns

    OLD_analysis_columns = {}
    NEW_analysis_columns = {}

    display_columns = unique_key_columns

    for column in analysis_columns:
        OLD_analysis_columns[column] = column + "_OLD"
        NEW_analysis_columns[column] = column + "_NEW"
        display_columns = display_columns + [
            column + "_OLD",
            column + "_NEW",
            column + "_Diff_Status",
            column + "_Diff_Result",
            column + "_Diff_Value",
        ]

    master_df = master_df.merge(
        dataset_OLD, on=unique_key_columns, how="left", validate="one_to_one"
    )

    master_df = master_df.rename(columns=OLD_analysis_columns)

    master_df = master_df.merge(
        dataset_NEW, on=unique_key_columns, how="left", validate="one_to_one"
    )

    master_df = master_df.rename(columns=NEW_analysis_columns)

    master_df["exists_OLD"] = master_df["exists_OLD"].fillna(0).astype(int)
    master_df["exists_NEW"] = master_df["exists_NEW"].fillna(0).astype(int)

    for column in analysis_columns:
        print(column)
        master_df[
            [
                column + "_Diff_Status",
                column + "_Diff_Result",
                column + "_Diff_Value",
            ]
        ] = master_df[[column + "_OLD", column + "_NEW"]].apply(
            lambda x: compare_value(x[0], x[1]), axis=1, result_type="expand"
        )

    display(master_df)

    return master_df[display_columns]
