"""Data acquisition module."""
import pandas as pd
import os
import json
import datetime
import logging

s_l_folder_path: str = os.path.join(os.getcwd(), "cached_queries")
s_l_file_path: str = os.path.join(s_l_folder_path, "cached_query_results.json")


# Function to try and acquire a key from a dictionnary, returning default value if it does not exist
def try_dictionnary_acquisition(parameter, dictionary, default=None):
    try:
        parameter_value = dictionary[parameter]
    except:
        parameter_value = default

    return parameter_value


# Function to acquire a query file based on a provided sql_dictionnary
def function_get_sql_data(
    query_name: str,
    sql_dictionary,
    initialized_adaconnect,
    parameters,
    force_refresh=False,
):
    # Extract sql query from file and associated query dictionay
    sql_query_str, sql_query_dictionary = function_get_sql_query(
        query_name, sql_dictionary
    )

    target_service_name = sql_query_dictionary["query_target_service_name"]

    query_force_refresh = try_dictionnary_acquisition(
        "query_force_refresh", sql_query_dictionary, False
    )
    query_file_path = try_dictionnary_acquisition(
        "query_file_path", sql_query_dictionary, None
    )

    # format associated sql query with query dictionary and get query signature
    formated_sql_query, query_parameter_signature = function_format_sql_query(
        sql_query_str, sql_query_dictionary, parameters
    )
    # print(formated_sql_query)
    if query_file_path is not None:
        full_local_path = (
            query_file_path + "_" + query_parameter_signature + ".pkl"
        )

    if force_refresh or query_force_refresh:
        refresh_flag = True
    else:
        refresh_flag = False

    if not refresh_flag:
        try:
            final_sql_result_df = pd.read_pickle(full_local_path)
            # refresh_flag = False
            file_loaded = True
            # print('Local dataset available for ' + query_name + ' with signature ' + query_parameter_signature + ', acquiring from local')
        except:
            # print('Local dataset unavailable for ' + query_name + ' with signature ' + query_parameter_signature + ' acquiring from source')
            refresh_flag = True
            file_loaded = False

    if refresh_flag:
        # print('Refreshing data...')
        # print(sql_query_str)
        # print(formated_sql_query)

        # execute query and store as df
        sql_result_df = function_retrieve_sql_query_results(
            formated_sql_query, target_service_name, initialized_adaconnect
        )
        # display(sql_result_df)
        if sql_result_df is None:
            logging.info("None results from SQL")
            logging.info(formated_sql_query)

        # Try and extract formating metadata and process accordingly.  If none, return original dataframe
        format_parameter_data = try_dictionnary_acquisition(
            "query_format_dict", sql_query_dictionary, None
        )
        rename_parameter_data = try_dictionnary_acquisition(
            "query_rename_dict", sql_query_dictionary, None
        )

        # print(sql_query_dictionary)
        # print(rename_parameter_data)

        # display(sql_result_df)
        # print('Formating data...')
        if format_parameter_data is not None:
            format_function = format_parameter_data["format_function"]
            format_parameters = format_parameter_data["format_parameters"]

            formated_sql_result_df = format_function(
                sql_result_df, format_parameters
            )

        else:
            formated_sql_result_df = sql_result_df

        if rename_parameter_data is not None:
            rename_function = rename_parameter_data["rename_function"]
            rename_parameters = rename_parameter_data["rename_parameters"]

            final_sql_result_df = rename_function(
                formated_sql_result_df, rename_parameters
            )

        else:
            final_sql_result_df = formated_sql_result_df

        # If full local path exists, we need to store query for next execution
        if full_local_path is not None:
            logging.info(
                "Saving local dataset at for "
                + query_name
                + " with signature "
                + query_parameter_signature
                + " at "
                + full_local_path
            )
            final_sql_result_df.to_pickle(full_local_path)

    return final_sql_result_df


# Function to acquire a query file based on a provided sql_dictionnary
def function_get_sql_query(query_name: str, sql_dictionary):
    try:
        query_dictionnary = sql_dictionary[query_name]
        query_path = query_dictionnary["query_sql_path"]
        query_file = open(query_path, "r")
        query_string = query_file.read()

    except Exception as error:
        print("get_sql_query", str(error))
        query_string = None

    return query_string, query_dictionnary


# Function to format a query string based on parameters to format and their corresponding parameters value
def function_format_sql_query(query_str: str, query_dictionary, parameters):
    formated_query_str = query_str

    query_parameters = try_dictionnary_acquisition(
        "query_parameters", query_dictionary
    )

    # today = dt.datetime.now().strftime ("%Y%m%d")

    parameter_signature = ""

    try:
        if query_parameters is not None:
            for query_parameter in query_parameters:
                # print(query_parameter)
                # print(formated_query_str)
                parameter_dictionary = query_parameters[query_parameter]
                # print(parameter_dictionary)
                # print(parameter_dictionary)

                parameter_name = "__{}__".format(query_parameter)

                # Try and extract parameter qualifier to build query.  Qualifier do not need to be provided as they default if required
                query_parameter_is_optionnal = try_dictionnary_acquisition(
                    "is_optional", parameter_dictionary, False
                )
                query_parameter_is_list = try_dictionnary_acquisition(
                    "is_list", parameter_dictionary, False
                )
                query_parameter_is_string = try_dictionnary_acquisition(
                    "is_string", parameter_dictionary, False
                )
                query_parameter_prefix = try_dictionnary_acquisition(
                    "prefix", parameter_dictionary, None
                )
                query_parameter_suffix = try_dictionnary_acquisition(
                    "suffix", parameter_dictionary, None
                )
                query_parameter_is_signature = try_dictionnary_acquisition(
                    "is_signature", parameter_dictionary, False
                )

                parameter_raw_value = try_dictionnary_acquisition(
                    query_parameter, parameters, None
                )
                if (query_parameter_is_optionnal and parameter_raw_value is None):
                    formated_query_str = formated_query_str.replace(parameter_name, "")

                    # if query_parameter_is_signature:
                    #     parameter_signature = (parameter_signature + parameter_name+ "_None")

                else:
                    # Initiate parameter value as empty string
                    parameter_value = ""

                    # Insert parameter prefix if specified
                    if query_parameter_prefix is not None:
                        parameter_value = (parameter_value + query_parameter_prefix)

                    # Check if parameter is a list and process accordingly while providing is_string qualifier
                    if query_parameter_is_list:
                        parameter_value = (parameter_value + function_sql_list_formatter(parameter_raw_value, query_parameter_is_string))

                    # If parameter is not a list, process accordingly while managing is_string qualifier
                    else:
                        if query_parameter_is_string:
                            parameter_value = (parameter_value+ "'"+ str(parameter_raw_value)+ "'")
                        else:
                            parameter_value = parameter_value + str(parameter_raw_value)

                    # Insert parameter suffix at end if specified
                    if query_parameter_suffix is not None:
                        parameter_value = (parameter_value + query_parameter_suffix)

                    formated_query_str = formated_query_str.replace(parameter_name, parameter_value)

                    if query_parameter_is_signature:
                        parameter_signature = (parameter_signature + parameter_name+ "_" + parameter_value.replace("'", "").replace(",", "_"))

    except Exception:
        logging.exception("Exception: format_sql_query")
        logging.info(query_parameters)
        logging.info(parameters)
        logging.info(formated_query_str)
        formated_query_str = None

    return formated_query_str, parameter_signature


# Function to format a list of variables to a SQL compatible list, taking account the fact that variables are string or not
def function_sql_list_formatter(parameter_list, is_string=False):
    formated_parameter = ""

    if is_string:
        formated_parameter = "'" + parameter_list[0]
        for item in range(len(parameter_list) - 1):
            formated_parameter = (
                formated_parameter + "','" + parameter_list[item + 1]
            )
        formated_parameter = formated_parameter + "'"

    else:
        formated_parameter = ",".join(map(str, parameter_list))

    return formated_parameter


# Function to execute a sql query and retrieve the resulting dataframe
def function_retrieve_sql_query_results(
    query_str: str,
    target_service_name,
    initialized_adaconnect,
    local_load_save=False,
    mode: str = "r",
):
    """Execute sql query on datastores and fetch results"""
    result = None
    conn = None
    if target_service_name == "sqlserver" and initialized_adaconnect:
        conn = initialized_adaconnect.get("sqlserver")
    elif target_service_name == "snowflake" and initialized_adaconnect:
        conn = initialized_adaconnect.get("snowflake")

    try:
        if not conn.connection:
            conn.connect()
            
        if mode == "r" and local_load_save:
            _creat_save_file_folder()
            _delete_old_saved_queries()
            if not _load_from_pickle(query_str):
                result = pd.read_sql(query_str, conn.connection)
                _save_to_pickle(query_str)

        elif mode == "r" and not local_load_save:
            result = pd.read_sql(query_str, conn.connection)

    except Exception:
        logging.exception("Exception thrown while retrieving Sql query")

    return result


def _creat_save_file_folder(self):
    # if save location for dataframes doesn't exist create it
    # if json file for saving dataframes doesn't exist create it

    if not os.path.exists(self.s_l_folder_path):
        os.makedirs(self.s_l_folder_path)

    if not os.path.exists(self.s_l_file_path):
        with open(self.s_l_file_path, "w") as f:
            json.dump({"0_null": ""}, f)


def _delete_old_saved_queries(self):
    # check if the queries in the json file are the old saved dataframes and
    # queries in json and delete both
    # no # delete them
    # check if the associated pickle files exist
    # no , # yes
    # delete the associated pickle files as well
    with open(self.s_l_file_path, "r") as f:
        data = json.load(f)
    current_date = datetime.datetime.now().strftime("%Y%m%d")
    to_delete = [
        key for key in data.keys() if key.split("_")[-1] < current_date
    ]
    for key in to_delete:
        del data[key]
    with open(self.s_l_file_path, "w") as f:
        json.dump(data, f)


def _save_to_pickle(self, query_string, save_days: int = 10):
    # json file names will be like (#serielnumber_deletetiondate)
    # check if queries exist in the json file
    # No, add to json file and save pickle file
    # yes, add to json file and save pickle file AND delete the old json
    # file entry and pickle file
    with open(self.s_l_file_path, "r") as f:
        data = json.load(f)

    key = int(max(data.keys(), default=0).split("_")[0]) + 1
    current_date = datetime.datetime.now().date()
    deletion_date = current_date + datetime.timedelta(days=save_days)
    deletion_date = deletion_date.strftime("%Y%m%d")

    save_key = str(key) + "_" + deletion_date

    data[save_key] = query_string
    with open(self.s_l_file_path, "w") as f:
        json.dump(data, f)

    self.output.to_pickle(self.s_l_folder_path + "/" + save_key + ".pkl")


def _load_from_pickle(self, query_string: str):
    # check if dataframe matching the found query still exist
    # (user didn't manualy delete it)
    # no , # if query doesn't exist anymore remove it from the json file
    # yes, load dataframe
    pickle_loaded = False
    try:
        with open(self.s_l_file_path, "r") as f:
            data = json.load(f)
        for key, value in data.items():
            if value == query_string:
                self.output = pd.read_pickle(
                    self.s_l_folder_path + "/" + str(key) + ".pkl"
                )
                pickle_loaded = True
                break
    except FileNotFoundError:
        pickle_loaded = False

    return pickle_loaded

