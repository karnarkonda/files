import datetime as dt
import time
import logging
import os
from typing import List
from datetime import datetime, timedelta

import pandas as pd

def function_reset_folder(  directory_path: str
                          , exceptions: List[str] = []
                          , display_only: bool = False):
    deleted_list = []
    try:
        for root, dirs, files in os.walk(directory_path):
            for file in files:
                if file in exceptions:
                    continue
                else:
                    file_path = os.path.join(root, file)
                    deleted_list.append(file_path)
                    if display_only is False:
                        os.remove(file_path)
        print("All files and subdirectories in " + directory_path + " deleted successfully.")
    except OSError:
        print("Error occurred while deleting files and subdirectories in " + directory_path + ".")
                
    return deleted_list

def timeit(method):
    def timed(*args, **kw):
        ts = time.time()
        result = method(*args, **kw)
        te = time.time()
        if 'log_time' in kw:
            name = kw.get('log_name', method.__name__.upper())
            kw['log_time'][name] = int((te - ts) * 1000)
        else:
            t = te - ts
            if t < 1:
                logger.info('%r  %2.2f ms' % (method.__name__, (te - ts) * 1000))
                logger.info('###########################################################################################################')
            else:
                logger.info(f'The function {method.__name__} took {format_seconds_to_hhmmss(t)} to execute')
                logger.info('###########################################################################################################')

        return result
    return timed

def function_extract_dataset(  dataset_name
                             , parameters_dictionnary
                             , sql_dictionnary
                             , refresh
                            ):
    
    full_dataset_path = parameters_dictionnary['execution_path'] + '/' + dataset_name + '_' + parameters_dictionnary['today']
    
    if dataset_name == 'dates':
        if refresh is False:
            try:
                dataset_df = pd.read_csv(full_dataset_path)
                dataset_df = function_format_dates(dataset_df)
            
            except Exception as error:
                logging.info('Data unavailable for ', dataset_name, str(error), ', refreshing data.')
                refresh = True
        else:
            dataset_df = function_extract_dates(parameters_dictionnary)
            dataset_df = function_format_dates(dataset_df)
            dataset_df.to_csv(full_dataset_path, index = False)
            
        
            
def function_extract_dates(parameters_dictionnary):
    
    columns_name = ['date']
    
    query_file = open(parameters_dictionnary['execution_path'] , 'r')
    query_str = query_file.read()

    dataset_df = pd.read_sql(query_str, parameters_dictionnary['warehouse_connection'])
    
    return dataset_df

def function_format_dates( dataset_df
                         , parameters_dictionnary
                         ):
    
    dataset_df['date'] = pd.to_datetime(dataset_df['date'], parameters_dictionnary['date_format'])
    
    return dataset_df 



def function_date_range(  start_date: str
                        , end_date = None
                        , span = 0
                        , as_string = True
                        , date_format = '%Y-%m-%d'
                       ):
    
    start_date_dt = dt.datetime.strptime(start_date, '%Y-%m-%d')
    
    date_range = []
    
    if as_string:
        date_range.append(start_date)
    else:
        date_range.append(start_date_dt)
    
    if end_date is None:
        for delta in range(span + 1):
            new_date = start_date_dt + dt.timedelta(days = -1)
            if as_string:
                date_range.append(new_date.strftime(date_format))
            else:
                date_range.append(new_date)
                              
    return date_range
                

def get_last_businessday(today=datetime.now()):

    backdate = (today.weekday() % 4) if today.weekday() > 4 else 1

    # Calculate the date of the previous working day
    interim_date = (today - timedelta(days=backdate))
    previous_workday = get_last_businessday(interim_date) if interim_date.weekday() > 4 else interim_date

    return previous_workday
