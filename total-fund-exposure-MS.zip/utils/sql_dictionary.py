import pandas as pd


# Function to format a dataframe based on a dictionnary of format parameters
def function_format_df(df: pd.DataFrame, format_parameters):
    for format_parameter in format_parameters:
        format_columns = format_parameters[format_parameter]
        # print(format_parameter)
        if format_parameter == "date":
            for format_column in format_columns:
                df[format_column] = pd.to_datetime(df[format_column], format="%Y-%m-%d")
        elif format_parameter == "integer":
            for format_column in format_columns:
                df[format_column] = df[format_column].astype(int)

    return df


# Function to format a dataframe based on a dictionnary of format parameters
def function_rename_df(df: pd.DataFrame, rename_parameters):
    df = df.rename(columns=rename_parameters)

    return df


issuer_ratings_query_dict = {
    "query_sql_path": "sql/IssuerQueries/QueryIssuerRatings.sql",
    "query_file_path": "dataset/IssuerQueries/QueryIssuerRatings",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "issuer_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "psp_all_issuer_codes": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Issuer_Code"]},
    },
}

gics_query_dict = {
    "query_sql_path": "sql/InstrumentQueries/QueryGICS.sql",
    "query_file_path": "dataset/InstrumentQueries/QueryGICS",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["PSPInstrumentID"]},
    },
}

portfolio_query_dict = {
    "query_sql_path": "sql/PortfolioQueries/QueryPortfolios.sql",
    "query_file_path": "dataset/PortfolioQueries/QueryPortfolios",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "integer": [
                "L1_PSPPortfolioID",
                "L2_PSPPortfolioID",
                "L3_PSPPortfolioID",
                "L4_PSPPortfolioID",
            ]
        },
    },
}

positions_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryPositions.sql",
    "query_file_path": "dataset/queries_L0/QueryPositions",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "exclusions_psp_instrument_ids": {
            "is_optional": True,
            "is_list": True,
            "is_string": False,
            "prefix": "AND PSPInstrumentID NOT IN (",
            "suffix": ")",
            "is_signature": False,
        },
        "psp_portfolio_ids": {
            "is_optional": True,
            "is_list": True,
            "is_string": False,
            "is_string": True,
            "prefix": "AND P.PSPPortfolioCode IN (",
            "suffix": ")",
            "is_signature": False,
        },
        "exclusions_psp_fund_codes": {
            "is_optional": True,
            "is_list": True,
            "is_string": False,
            "is_string": True,
            "prefix": "AND ISNULL(Pf.PSPFundCode,'None') NOT IN (",
            "suffix": ")",
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["PositionDate"],
            "integer": [
                "Portfolio_PSPPortfolioID",
                "Instrument_PSPInstrumentID",
            ],
        },
    },
}

instruments_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryInstruments.sql",
    "query_file_path": "dataset/queries_L0/QueryInstruments",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Instrument_PSPInstrumentID"]},
    },
}

instruments_query_dict_snowflake = {
  "query_sql_path": "sql/Queries_Snowflake/QueryInstruments.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryInstruments",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["instrument_pspinstrumentid"]},
        },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "instrument_pspinstrumentid": "Instrument_PSPInstrumentID",
            "instrument_family": "Instrument_Family",
            "instrument_pspinstrumentcategorizationid": "Instrument_PSPInstrumentCategorizationID",
            "instrument_pspinstrumentcategorizationcode": "Instrument_PSPInstrumentCategorizationCode",
            "instrument_description": "Instrument_Description",
            "instrument_market": "Instrument_Market",
            "instrument_type": "Instrument_Type",
            "instrument_issuercode": "Instrument_IssuerCode",
            "instrument_penultimatepaymentdate": "Instrument_PenultimatePaymentDate",
            "instrument_currencycode": "Instrument_CurrencyCode",
            "underlying_pspinstrumentid": "Underlying_PSPInstrumentID",
            "coal_underlying_pspinstrumentid":"Coal_Underlying_PSPInstrumentID",
            "option_style": "Option_Style",
            "contractsize": "ContractSize",
            "future_contractsymbol": "Future_ContractSymbol",
            "optionfuture_contractsymbol":"OptionFuture_ContractSymbol",
            "option_conversionratio": "Option_ConversionRatio",
            "forward_price": "Forward_Price",
            "future_ticksize": "Future_TickSize",
            "future_tickvalue": "Future_TickValue",
            "instrument_indexproxypspinstrumentid":"Instrument_IndexProxyPSPInstrumentID"
            }
        },
    
}



options_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryOptions.sql",
    "query_file_path": "dataset/queries_L0/QueryOptions",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Instrument_PSPInstrumentID"]},
    },
}

futures_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryFutures.sql",
    "query_file_path": "dataset/queries_L0/QueryFutures",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Instrument_PSPInstrumentID"]},
    },
}

forwards_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryForwards.sql",
    "query_file_path": "dataset/queries_L0/QueryForwards",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Instrument_PSPInstrumentID"]},
    },
}

swap_legs_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryLegs.sql",
    "query_file_path": "dataset/queries_L0/QueryLegs",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Instrument_PSPInstrumentID"]},
    },
}

swap_legs_query_dict_snowflake = {
    "query_sql_path": "sql/Queries_Snowflake/QueryLegs.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryLegs",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
     "query_format_dict": {
         "format_function": function_format_df,
         "format_parameters": {"integer": ["instrument_pspinstrumentid"]},
     },
     "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "instrument_pspinstrumentid": "Instrument_PSPInstrumentID",
            "leg_pspinstrumentlegid":"Leg_PSPInstrumentLegID",
            "leg_firstresetdate":"Leg_FirstResetDate",
            "leg_lastresetdate":"Leg_LastResetDate",
            "leg_type": "Leg_Type",
            "leg_direction": "Leg_Direction",
            "underlying_pspinstrumentid": "Underlying_PSPInstrumentID"
        },
    },
}

security_financing_query_dict = {
    "query_sql_path": "sql/queries_L0/QuerySecurityFinancing.sql",
    "query_file_path": "dataset/queries_L0/QuerySecurityFinancing",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Instrument_PSPInstrumentID"]},
    },
}

index_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryIndex.sql",
    "query_file_path": "dataset/queries_L0/QueryIndex",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "index_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "integer": [
                "Instrument_PSPInstrumentID",
                "Instrument_IndexProxyPSPInstrumentID",
            ]
        },
    },
}

index_constituents_query_dict = {
    "query_sql_path": "sql/ConstituentsQueries/QueryIndexConstituents.sql",
    "query_file_path": "dataset/ConstituentsQueries/QueryIndexConstituents",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["PositionDate", "SourceDate"],
            "integer": [
                "Constituent_PSPInstrumentID",
                "Index_PSPInstrumentID",
            ],
        },
    },
}

etf_constituents_query_dict = {
    "query_sql_path": "sql/ConstituentsQueries/QueryETFConstituents.sql",
    "query_file_path": "dataset/ConstituentsQueries/QueryETFConstituents",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "etf_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["PositionDate", "SourceDate"],
            "integer": ["Constituent_PSPInstrumentID", "ETF_PSPInstrumentID"],
        },
    },
}

basket_constituents_query_dict = {
    "query_sql_path": "sql/ConstituentsQueries/QueryBasketConstituents.sql",
    "query_file_path": "dataset/ConstituentsQueries/QueryBasketConstituents",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["PositionDate", "SourceDate"],
            "integer": [
                "Constituent_PSPInstrumentID",
                "Basket_PSPInstrumentID",
            ],
        },
    },
}

credit_constituents_query_dict = {
    "query_sql_path": "sql/ConstituentsQueries/QueryCreditConstituents.sql",
    "query_file_path": "dataset/ConstituentsQueries/QueryCreditConstituents",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        # "credit_index_instrument_ids": {
        #    "is_optional": False,
        #    "is_list": True,
        #    "is_string": False,
        #    "is_signature": False,
        #},
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["PositionDate", "SourceDate"],
            "integer": [
                "Constituent_IssuerCode",
                "CreditIndex_PSPInstrumentID",
            ],
        },
    },
}

credit_constituents_snowflake_query_dict = {
    "query_sql_path": "sql/Queries_Snowflake/QueryCreditConstituents.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryCreditConstituents",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
         "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["positiondate", "sourcedate"],
            "integer": [
                "constituent_issuercode",
                "creditindex_pspinstrumentid",
            ],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            'positiondate': 'PositionDate',
            'sourcedate' : 'SourceDate',
            'creditindex_pspinstrumentid': 'CreditIndex_PSPInstrumentID',
            'constituent_issuername': 'Constituent_IssuerName',
            'constituent_debttierdescription': 'Constituent_DebtTierDescription',
            'constituent_issuercode' : 'Constituent_IssuerCode',
            'constituent_currencycode' : 'Constituent_CurrencyCode',
            'constituent_weight' : 'Constituent_Weight'
        },
    },
}

constituents_query_dict = {
    "query_sql_path": "sql/Queries_Snowflake/QueryETFIndexBasketConstituents.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryETFIndexBasketConstituents",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
         "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["positiondate", "sourcedate"],
            "integer": [
                "constituee_pspinstrumentid",
                "constituent_pspinstrumentid",
            ],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            'positiondate': 'PositionDate',
            'sourcedate' : 'SourceDate',
            'constituee_type' : 'Constituee_Type',
            'constituee_pspinstrumentid': 'Constituee_PSPInstrumentID',
            'constituent_pspinstrumentid': 'Constituent_PSPInstrumentID',
            'constituent_currencycode': 'Constituent_CurrencyCode',
            'constituent_weight' : 'Constituent_Weight'
        },
    },
}

shares_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryShares.sql",
    "query_file_path": "dataset/queries_L0/QueryShares",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Instrument_PSPInstrumentID"]},
    },
}

pooled_funds_options_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryPooledFundOptions.sql",
    "query_file_path": "dataset/queries_L0/QueryPooledFundOptions",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Instrument_PSPInstrumentID"]},
    },
}

pooled_funds_forwards_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryPooledFundForwards.sql",
    "query_file_path": "dataset/queries_L0/QueryPooledFundForwards",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Instrument_PSPInstrumentID"]},
    },
}

pooled_funds_credit_derivatives_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryPooledFundCreditDerivatives.sql",
    "query_file_path": "dataset/queries_L0/QueryPooledFundCreditDerivatives",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Instrument_PSPInstrumentID"]},
    },
}

pooled_funds_swaps_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryPooledFundSwaps.sql",
    "query_file_path": "dataset/queries_L0/QueryPooledFundSwaps",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        }
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"integer": ["Instrument_PSPInstrumentID"]},
    },
}

pooled_funds_query_dict = {
    "query_sql_path": "sql/queries_L1/QueryPooledFund.sql",
    "query_file_path": "dataset/queries_L1/QueryPooledFund",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "pooled_fund_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "pooled_fund_psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "prefix": "AND PSPPortfolioID in (",
            "suffix": ")",
            "is_signature": False,
        },
        "pooled_fund_psp_instrument_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "prefix": "AND P.PSPInstrumentID in (",
            "suffix": ")",
            "is_signature": False,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["PositionDate", "PooledFundDate"],
            "integer": [
                "Instrument_PSPInstrumentID",
                "PooledFund_PSPInstrumentID",
            ],
        },
    },
}

pooled_funds_ratio_query_dict = {
    "query_sql_path": "sql/queries_L1/QueryPooledFundRatio.sql",
    "query_file_path": "dataset/queries_L1/QueryPooledFundRatio",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "pooled_fund_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "pooled_fund_psp_instrument_ids": {
            "is_optional": True,
            "is_list": True,
            "is_string": False,
            "prefix": "AND FundPSPInstrumentID in (",
            "suffix": ")",
            "is_signature": False,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["PositionDate", "PooledFundDate"],
            "integer": [
                "Portfolio_PSPPortfolioID",
                "Instrument_PSPInstrumentID",
            ],
        },
    },
}

fx_rates_query_dict = {
    "query_sql_path": "sql/queries_L2/QueryFxRates.sql",
    "query_file_path": "dataset/queries_L2/QueryFxRates",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"date": ["PositionDate"]},
    },
}

fx_rates_query_dict_snowflake = {
    "query_sql_path": "sql/Queries_Snowflake/QueryFxRates.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryFxRates",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {"date": ["positiondate"]},
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "positiondate": "PositionDate",
            "instrument_currencycode": "Instrument_CurrencyCode",
            "position_fxrates_currencycode_to_cad":"Position_FXRates_CurrencyCode_to_CAD",
        },
    },
}

prices_query_dict = {
    "query_sql_path": "sql/queries_L3/QueryPricesForAllInstruments.sql",
    "query_file_path": "dataset/queries_L3/QueryPricesForAllInstruments",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "price_psp_instrument_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["PositionDate"],
            "integer": ["Instrument_PSPInstrumentID"],
        },
    },
}

prices_query_dict_snowflake = {
    "query_sql_path": "sql/Queries_Snowflake/QueryPricesForAllInstruments.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryPricesForAllInstruments",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "price_psp_instrument_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },	
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["positiondate"],
            "integer": ["instrument_pspinstrumentid"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "positiondate": "PositionDate",
            "instrument_pspinstrumentid": "Instrument_PSPInstrumentID",
            "price_currencycode":"Price_CurrencyCode",
            "price_local":"Price_Local",
            "price_cad":"Price_CAD",
        },
    },
}


private_markets_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryPrivateMarkets.sql",
    "query_file_path": "dataset/queries_L0/QueryPrivateMarkets",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "issuer_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["PositionDate", "SourceDate"],
            "integer": ["Portfolio_PSPPortfolioID"],
        },
    },
}


benchmarks_query_dict = {
    "query_sql_path": "sql/queries_L0/QueryBenchmarks.sql",
    "query_file_path": "dataset/queries_L0/QueryBenchmarks",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_asset_class_names": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["PositionDate"],
            "integer": [
                "Benchmark_PSPInstrumentID",
                "Benchmark_FinalPSPInstrumentID",
            ],
        },
    },
}

benchmarks_query_dict_snowflake = {
    "query_sql_path": "sql/Queries_Snowflake/QueryBenchmarks.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryBenchmarks",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_asset_class_names": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": False,
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["positiondate"],
            "integer": [
                "benchmark_pspinstrumentid",
                "benchmark_finalpspinstrumentid",
            ],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            'positiondate': 'PositionDate',
            'assetclass_name' : 'AssetClass_Name',
            'assetclass_pspbenchmarkcode': 'AssetClass_PSPBenchmarkCode',
            'assetclass_benchmarkassignationdescription': 'AssetClass_BenchmarkAssignationDescription',
            'benchmark_name': 'Benchmark_Name',
            'benchmark_currencycode':'Benchmark_CurrencyCode',
            'benchmark_pspinstrumentid' : 'Benchmark_PSPInstrumentID',
            'benchmark_weight' : 'Benchmark_Weight',
            'benchmark_finalpspinstrumentid' : 'Benchmark_FinalPSPInstrumentID',
        },
    },
}

issuers_query_dict = {
    "query_sql_path": "sql/IssuerQueries/QueryIssuers.sql",
    "query_file_path": "dataset/IssuerQueries/QueryIssuers",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "issuer_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "psp_issuer_codes": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
    },
}

issuer_sectors_query_dict = {
    "query_sql_path": "sql/IssuerQueries/QueryIssuerSectors.sql",
    "query_file_path": "dataset/IssuerQueries/QueryIssuerSectors",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "issuer_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "psp_all_issuer_codes": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
    },
}

mra_ghost_instruments_query_dict = {
    "query_sql_path": "sql/MRAQueries/QueryMRABatchData_GhostData.sql",
    "query_file_path": "dataset/MRAQueries/QueryMRABatchData_GhostData",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "pooled_fund_ghost_psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["CalendarKey"],
            "integer": ["PortfolioKey", "PortfolioID", "BatchKey"],
        },
    },
}

mra_exposure_query_dict = {
    "query_sql_path": "sql/MRAQueries/QueryMRABatchDataExposure.sql",
    "query_file_path": "dataset/MRAQueries/QueryMRABatchDataExposure",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["CalendarKey"],
            "integer": ["PortfolioKey", "PortfolioID", "BatchKey"],
        },
    },
}

mra_exposure_fx_query_dict = {
    "query_sql_path": "sql/MRAQueries/QueryMRABatchDataExposureFX.sql",
    "query_file_path": "dataset/MRAQueries/QueryMRABatchDataExposureFX",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["CalendarKey"],
            "integer": ["PortfolioKey", "PortfolioID", "BatchKey"],
        },
    },
}


mra_batch_mapping_query_dict = {
    "query_sql_path": "sql/MRAQueries/QueryMRABatchMapping.sql",
    "query_file_path": "dataset/MRAQueries/QueryMRABatchMapping",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["CalendarDate", "MostRecent_CalendarKey"],
            "integer": ["PortfolioKey", "PortfolioID"],
        },
    },
}

mra_batch_data_query_dict = {
    "query_sql_path": "sql/MRAQueries/QueryMRABatchData.sql",
    "query_file_path": "dataset/MRAQueries/QueryMRABatchData",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["CalendarKey"],
            "integer": ["PortfolioKey", "PortfolioID", "BatchKey"],
        },
    },
}

mra_batch_data_currency_query_dict = {
    "query_sql_path": "sql/MRAQueries/QueryMRABatchDataCurrency.sql",
    "query_file_path": "dataset/MRAQueries/QueryMRABatchDataCurrency",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["CalendarKey"],
            "integer": ["PortfolioKey", "PortfolioID", "BatchKey"],
        },
    },
}

###Snowflake MRA QUeries
mra_ghost_instruments_query_dict_snowflake = {
    "query_sql_path": "sql/MRAQueries_Snowflake/QueryMRABatchData_GhostData.sql",
    "query_file_path": "dataset/MRAQueries_Snowflake/QueryMRABatchData_GhostData",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "pooled_fund_ghost_psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
        "database_mra": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
        "batch_key": {
            "is_optional": True,
            "is_list": True,
            "is_string": False,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["calendar_key"],
            "integer": ["portfolio_key", "portfolio_id", "batch_key"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "portfolio_key": "Portfolio_Key",
            "portfolio_id": "PortfolioID",
            "instrumentkey": "Instrument_Key",
            "instrumentid": "Instrument_PSPInstrumentID",
            "riskmetricspositiontype": "RiskMetricsPositionType",
            "calendar_key": "CalendarKey",
            "batch_key": "BatchKey",
            "instrumentfamily": "Instrument_Family",
            "instrumentcategorizationid": "Instrument_PSPInstrumentCategorizationID",
            "instrumentcategorizationcode": "Instrument_PSPInstrumentCategorizationCode",
            "instrumentdescription": "Instrument_Description",
            "instrumentmarket": "Instrument_Market",
            "instrumenttype": "Instrument_Type",
            "issuercode": "Instrument_IssuerCode",
            "ultimateunderlyinginstrumentid": "UltimateUnderlying_PSPInstrumentID",
            "uui_instrumentfamily": "UltimateUnderlying_Family",
            "uui_instrumentcategorizationid": "UltimateUnderlying_PSPInstrumentCategorizationID",
            "uui_instrumentcategorizationcode": "UltimateUnderlying_PSPInstrumentCategorizationCode",
            "uui_instrumentdescription": "UltimateUnderlying_Description",
            "uui_instrumentmarket": "UltimateUnderlying_Market",
            "uui_instrumenttype": "UltimateUnderlying_Type",
            "uui_issuercode": "UltimateUnderlying_IssuerCode",
            "uui_indexproxyid": "UltimateUnderlying_IndexProxyPSPInstrumentID",
            "gicssectorcode": "UltimateUnderlying_GICSSectorCode",
            "gicssectorname": "UltimateUnderlying_GICSSectorName",
            "gicsindustrygroupname": "UltimateUnderlying_GICSIndustryGroupName",
            "gicsindustrycode": "UltimateUnderlying_GICSIndustryCode",
            "gicsindustryname": "UltimateUnderlying_GICSIndustryName",
            "gicssubindustryname": "UltimateUnderlying_GICSSubIndustryName",
            "bloombergsectordescription": "Instrument_BICSBETASectorName",
            "bloombergindustrydescription": "Instrument_BICSBETAIndustryName",
            "bloombergsubindustrydescription": "Instrument_BICSBETASubIndustryDescription",
            "issuer_code": "IssuerCode",
            "issuer_name": "IssuerName",
            "issuer_legal_name": "IssuerLegalName",
            "risk_location_country_code": "RiskLocationCountryCode",
            "risk_location_country_name": "RiskLocationCountryName",
            "psp_legal_entity_id": "LegalEntityID",
            "legal_name": "LegalName",
        },
    },
}

mra_exposure_query_dict_snowflake = {
    "query_sql_path": "sql/MRAQueries_Snowflake/QueryMRABatchDataExposure.sql",
    "query_file_path": "dataset/MRAQueries_Snowflake/QueryMRABatchDataExposure",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
        "database_mra": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["calendar_key"],
            "integer": ["portfolio_key", "portfolio_id", "batch_key"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "portfolio_key": "Portfolio_Key",
            "portfolio_id": "PortfolioID",
            "object_type": "Object_Type",
            "benchmark_key": "BenchmarkKey",
            "benchmark_code": "BenchmarkCode",
            "instrument_key": "Instrument_Key",
            "instrument_id": "Instrument_PSPInstrumentID",
            "risk_metrics_position_type": "Instrument_RiskMetricsPositionType",
            "instrument_categorization_id": "Instrument_PSPInstrumentCategorizationID",
            "instrument_categorization_code": "Instrument_PSPInstrumentCategorizationCode",
            "i2_instrumentkey": "Constituent_Key",
            "i2_instrumentid": "Constituent_PSPInstrumentID",
            "i2_riskmetricspositiontype": "Constituent_RiskMetricsPositionType",
            "i2_instrumentcategorizationid": "Constituent_PSPInstrumentCategorizationID",
            "i2_instrumentcategorizationcode": "Constituent_PSPInstrumentCategorizationCode",
            "calendar_key": "CalendarKey",
            "batch_key": "BatchKey",
            "exposure_commodity": "Exposure_Commodity",
            "exposure_equity": "Exposure_Equity",
            "exposure_issuer": "Exposure_Issuer",
        },
    },
}


mra_exposure_fx_query_dict_snowflake = {
    "query_sql_path": "sql/MRAQueries_Snowflake/QueryMRABatchDataExposureFX.sql",
    "query_file_path": "dataset/MRAQueries_Snowflake/QueryMRABatchDataExposureFX",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
        "database_mra": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["calendar_key"],
            "integer": ["portfolio_key", "portfolio_id", "batch_key"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "portfolio_key": "Portfolio_Key",
            "portfolio_id": "PortfolioID",
            "object_type": "Object_Type",
            "benchmark_key": "BenchmarkKey",
            "benchmark_code": "BenchmarkCode",
            "instrument_key": "Instrument_Key",
            "instrument_id": "Instrument_PSPInstrumentID",
            "risk_metrics_position_type": "Instrument_RiskMetricsPositionType",
            "instrument_categorization_id": "Instrument_PSPInstrumentCategorizationID",
            "instrument_categorization_code": "Instrument_PSPInstrumentCategorizationCode",
            "currency_code": "Instrument_CurrencyCode",
            "i2_instrumentkey": "Constituent_Key",
            "i2_instrumentid": "Constituent_PSPInstrumentID",
            "i2_riskmetricspositiontype": "Constituent_RiskMetricsPositionType",
            "i2_instrumentcategorizationid": "Constituent_PSPInstrumentCategorizationID",
            "i2_instrumentcategorizationcode": "Constituent_PSPInstrumentCategorizationCode",
            "c2_currency_code": "Constituent_CurrencyCode",
            "calendar_key": "CalendarKey",
            "batch_key": "BatchKey",
            "exposure_fx": "Exposure_FX",
        },
    },
}


mra_batch_mapping_query_dict_snowflake = {
    "query_sql_path": "sql/MRAQueries_Snowflake/QueryMRABatchMapping.sql",
    "query_file_path": "dataset/MRAQueries_Snowflake/QueryMRABatchMapping",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
        "database_mra": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
        "batch_key": {
            "is_optional": True,
            "is_list": True,
            "is_string": False,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["calendar_date", "mostrecent_calendarkey"],
            "integer": [
                "portfolio_key",
                "portfolio_id",
                "mostrecent_batch_key",
            ],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "portfolio_key": "Portfolio_Key",
            "portfolio_id": "PortfolioID",
            "calendar_date": "CalendarDate",
            "mostrecent_calendarkey": "MostRecent_CalendarKey",
            "mostrecent_batch_key": "MostRecent_Batch_key",
        },
    },
}

mra_batch_data_query_dict_snowflake = {
    "query_sql_path": "sql/MRAQueries_Snowflake/QueryMRABatchData.sql",
    "query_file_path": "dataset/MRAQueries_Snowflake/QueryMRABatchData",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
        "database_mra": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
        "batch_key": {
            "is_optional": True,
            "is_list": True,
            "is_string": False,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["calendar_key"],
            "integer": ["portfolio_key", "portfolio_id", "batch_key"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "portfolio_key": "PortfolioKey",
            "portfolio_id": "PortfolioID",
            "benchmark_key": "BenchmarkKey",
            "benchmark_code": "BenchmarkCode",
            "instrument_key": "InstrumentKey",
            "instrument_id": "InstrumentID",
            "risk_metrics_position_type": "RiskMetricsPositionType",
            "calendar_key": "CalendarKey",
            "batch_key": "BatchKey",
            "delta": "Delta",
            "portfolio_notional_in_base_currency": "Portfolio_NotionalInBaseCurrency",
            "portfolio_commodity_dollar_delta": "Portfolio_CommodityDollarDelta",
            "portfolio_equity_dollar_delta": "Portfolio_EquityDollarDelta",
            "benchmark_notional_in_base_currency": "Benchmark_NotionalInBaseCurrency",
            "benchmark_commodity_dollar_delta": "Benchmark_CommodityDollarDelta",
            "benchmark_equity_dollar_delta": "Benchmark_EquityDollarDelta",
        },
    },
}

mra_batch_data_currency_query_dict_snowflake = {
    "query_sql_path": "sql/MRAQueries_Snowflake/QueryMRABatchDataCurrency.sql",
    "query_file_path": "dataset/MRAQueries_Snowflake/QueryMRABatchDataCurrency",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
        "database_mra": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
        "batch_key": {
            "is_optional": True,
            "is_list": True,
            "is_string": False,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["calendar_key"],
            "integer": ["portfolio_key", "portfolio_id", "batch_key"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "portfolio_key": "PortfolioKey",
            "portfolio_id": "PortfolioID",
            "benchmark_key": "BenchmarkKey",
            "benchmark_code": "BenchmarkCode",
            "instrument_key": "InstrumentKey",
            "instrument_id": "InstrumentID",
            "risk_metrics_position_type": "RiskMetricsPositionType",
            "calendar_key": "CalendarKey",
            "batch_key": "BatchKey",
            "currency_key": "CurrencyKey",
            "currency_code": "CurrencyCode",
            "portfolio_present_value": "Portfolio_PresentValue",
            "portfolio_krd": "Portfolio_KRD",
            "portfolio_currency_dollar_delta": "Portfolio_CurrencyDollarDelta",
            "benchmark_present_value": "Benchmark_PresentValue",
            "benchmark_krd": "Benchmark_KRD",
            "benchmark_currency_dollar_delta": "Benchmark_CurrencyDollarDelta",
        },
    },
}

mra_index_data_query_dict_snowflake = {
    "query_sql_path": "sql/MRAQueries_Snowflake/QueryMRAIndexData.sql",
    "query_file_path": "dataset/MRAQueries_Snowflake/QueryMRAIndexData",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "benchmark_index_psp_instrument_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
        "krd_statistic_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
        "delta_statistic_id": {
            "is_optional": False,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
        },
        "pv_statistic_id": {
            "is_optional": False,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
        },
        "index_total_nav": {
            "is_optional": False,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
        },
        "database_mra": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": "."
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": "."
        },
        "database_tfe": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": "."
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["mostrecent_calendar_key"],
            "integer": ["index_id", "mostrecent_index_key", "mostrecent_batch_key", "instrument_key", "instrument_id"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "index_id": "Index_PSPInstrumentID",
            "mostrecent_index_key": "Index_Key",
            "mostrecent_calendar_key": "MostRecent_CalendarKey",
            "mostrecent_batch_key": "BatchKey",
            "instrument_key": "Instrument_Key",
            "instrument_id": "Instrument_PSPInstrumentID",
            "currency_code": "Instrument_CurrencyCode",
            "present_value_u": "PresentValue",
            "delta": "Delta",
            "krdt_u": "Krd",
        },
    },
}


mra_index_mapping_query_dict_snowflake = {
    "query_sql_path": "sql/MRAQueries_Snowflake/QueryMRAIndexMapping.sql",
    "query_file_path": "dataset/MRAQueries_Snowflake/QueryMRAIndexMapping",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "benchmark_index_psp_instrument_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": False,
        },
        "database_mra": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": "."
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": "."
        },
        "database_tfe": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": "."
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["calendar_date", "mostrecent_calendar_key"],
            "integer": ["index_id", "mostrecent_index_key", "mostrecent_batch_key"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "calendar_date": "PositionDate",
            "index_id": "Index_PSPInstrumentID",
            "mostrecent_index_key": "Index_Key",
            "mostrecent_calendar_key": "MostRecent_CalendarKey",
            "mostrecent_batch_key": "BatchKey",
        },
    },
}

mra_batch_portfolios_query_dict_snowflake = {
    "query_sql_path": "sql/MRAQueries_Snowflake/QueryMRABatchPortfolios.sql",
    "query_file_path": "dataset/MRAQueries_Snowflake/QueryMRABatchPortfolios",
    "query_target_service_name": "snowflake",
    "query_force_refresh": True,
    "query_parameters": {
        "batch_key": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
            "is_signature": True,
        },
        "database_mra": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "portfolio_id": "PortfolioID",
        },
    },
}

maturity_dates_query_dict_snowflake = {
    "query_sql_path": "sql/Queries_Snowflake/QueryMaturityDates.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryMaturityDates",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": [
                "maturity_date",
                "termination_date",
                "first_delivery_date",
                "expiration_date",
            ],
            "integer": ["psp_instrument_id"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "psp_instrument_id": "Instrument_PSPInstrumentID",
            "maturity_date": "Instrument_MaturityDate",
            "termination_date": "Instrument_TerminationDate",
            "first_delivery_date": "Instrument_FirstDeliveryDate",
            "expiration_date": "Instrument_ExpirationDate",
        },
    },
}

exposure_extended_query_dict_snowflake = {
    "query_sql_path": "sql/Exposure_Snowflake/QueryVWExposureExtended.sql",
    "query_file_path": "dataset/Exposure_Snowflake/QueryVWExposureExtended",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "database_tfe": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["positiondate"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "positiondate": "PositionDate",
            "object_type": "Object_Type",
            "l4_pspportfolioid": "Portfolio_PSPPortfolioID",
            "l4_pspportfoliocode": "Portfolio_PSPPortfolioCode",
            "position_type": "Position_Type",
            "portfolio_markettype": "Portfolio_MarketType",
            "instrument_pspinstrumentcategorizationid": "Instrument_PSPInstrumentCategorizationID",
            "instrument_pspinstrumentcategorizationcode": "Instrument_PSPInstrumentCategorizationCode",
            "constituent_pspinstrumentcategorizationid": "Constituent_PSPInstrumentCategorizationID",
            "constituent_pspinstrumentcategorizationcode": "Constituent_PSPInstrumentCategorizationCode",
            "constituent_exposure_issuer": "Exposure_Issuer",
            "constituent_exposure_equity": "Exposure_Equity",
            "constituent_exposure_commodity": "Exposure_Commodity",
        },
    },
}

exposure_non_extended_query_dict_snowflake = {
    "query_sql_path": "sql/Exposure_Snowflake/QueryVWExposureNonExtended.sql",
    "query_file_path": "dataset/Exposure_Snowflake/QueryVWExposureNonExtended",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "database_tfe": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["positiondate"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "positiondate": "PositionDate",
            "object_type": "Object_Type",
            "l4_pspportfolioid": "Portfolio_PSPPortfolioID",
            "l4_pspportfoliocode": "Portfolio_PSPPortfolioCode",
            "position_type": "Position_Type",
            "portfolio_markettype": "Portfolio_MarketType",
            "instrument_pspinstrumentcategorizationid": "Instrument_PSPInstrumentCategorizationID",
            "instrument_pspinstrumentcategorizationcode": "Instrument_PSPInstrumentCategorizationCode",
            "exposure_issuer": "Exposure_Issuer",
            "exposure_equity": "Exposure_Equity",
            "exposure_commodity": "Exposure_Commodity",
        },
    },
}

exposure_tfe_query_dict_snowflake = {
    "query_sql_path": "sql/Exposure_Snowflake/QueryVWExposureTFE.sql",
    "query_file_path": "dataset/Exposure_Snowflake/QueryVWExposureTFE",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "database_tfe": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["valuation_date"],
        },
    }
}


exposure_tfe_query_emr_dict_snowflake = {
    "query_sql_path": "sql/Exposure_Snowflake/QueryVWExposureTFE_EMR.sql",
    "query_file_path": "dataset/Exposure_Snowflake/QueryVWExposureTFE_EMR",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "database_tfe": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["valuation_date"],
        },
    },    
}


exposure_creditrisk_dm_query_dict = {
    "query_sql_path": "sql\Exposure_CreditRiskDM\QueryCreditRiskDM.sql", 
    "query_file_path": "dataset/Exposure_CreditRiskDM/exposure_creditrisk_dm",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["ValuationDate"],
        },
    }
}

exposure_creditrisk_dm_emr_query_dict = {
    "query_sql_path": "sql\Exposure_CreditRiskDM\QueryCreditRiskDM_EMR.sql", 
    "query_file_path": "dataset/Exposure_CreditRiskDM/exposure_creditrisk_dm_emr",
    "query_target_service_name": "sqlserver",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["valuation_date"],
        },
    }
}

position_dates_production_query_dict_snowflake = {
    "query_sql_path": "sql/Queries_Snowflake/QueryDates.sql",
    "query_file_path": "dataset/Dates/QueryDates_Snowflake",
    "query_target_service_name": "snowflake",
    "query_force_refresh": True,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "database_mra": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": False,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["calendar_date"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
              "calendar_date": "PositionDate"
        },
    },
}

portfolio_query_dict_snowflake = {
    "query_sql_path": "sql/Queries_Snowflake/QueryPortfolios.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryPortfolios",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "psp_portfolio_ids": {
            "is_optional": False,
            "is_list": True,
            "is_string": False,
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": True,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "integer": [
                "l1_pspportfolioid",
                "l2_pspportfolioid",
                "l3_pspportfolioid",
                "l4_pspportfolioid",
            ]
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "l1_pspportfoliocode": "L1_PSPPortfolioCode",
            "l1_pspportfolioid": "L1_PSPPortfolioID",
            "l1_portfolioname": "L1_PortfolioName",
            "l1_portfoliotype": "L1_PortfolioType",
            "l1_managingdepartment": "L1_ManagingDepartment",
            "l1_managertype": "L1_ManagerType",
            "l1_managingstyle": "L1_ManagingStyle",
            "l1_pspassetclassallocationcode": "L1_PSPAssetClassAllocationCode",
            "l1_assetclassallocationdescription": "L1_AssetClassAllocationDescription",
            "l1_portfoliostyle": "L1_PortfolioStyle",
            "l1_ownerdepartment": "L1_OwnerDepartment",
            "l1_pspinvestmentteamcode": "L1_PSPInvestmentTeamCode",
            "l1_investmentteamname": "L1_InvestmentTeamName",
            "l2_pspportfoliocode": "L2_PSPPortfolioCode",
            "l2_pspportfolioid": "L2_PSPPortfolioID",
            "l2_portfolioname": "L2_PortfolioName",
            "l2_portfoliotype": "L2_PortfolioType",
            "l2_managingdepartment": "L2_ManagingDepartment",
            "l2_managertype": "L2_ManagerType",
            "l2_managingstyle": "L2_ManagingStyle",
            "l2_pspassetclassallocationcode": "L2_PSPAssetClassAllocationCode",
            "l2_assetclassallocationdescription": "L2_AssetClassAllocationDescription",
            "l2_portfoliostyle": "L2_PortfolioStyle",
            "l2_ownerdepartment": "L2_OwnerDepartment",
            "l2_pspinvestmentteamcode": "L2_PSPInvestmentTeamCode",
            "l2_investmentteamname": "L2_InvestmentTeamName",
            "l3_pspportfoliocode": "L3_PSPPortfolioCode",
            "l3_pspportfolioid": "L3_PSPPortfolioID",
            "l3_portfolioname": "L3_PortfolioName",
            "l3_portfoliotype": "L3_PortfolioType",
            "l3_managingdepartment": "L3_ManagingDepartment",
            "l3_managertype": "L3_ManagerType",
            "l3_managingstyle": "L3_ManagingStyle",
            "l3_pspassetclassallocationcode": "L3_PSPAssetClassAllocationCode",
            "l3_assetclassallocationdescription": "L3_AssetClassAllocationDescription",
            "l3_portfoliostyle": "L3_PortfolioStyle",
            "l3_ownerdepartment": "L3_OwnerDepartment",
            "l3_pspinvestmentteamcode": "L3_PSPInvestmentTeamCode",
            "l3_investmentteamname": "L3_InvestmentTeamName",
            "l4_pspportfoliocode": "L4_PSPPortfolioCode",
            "l4_pspportfolioid": "L4_PSPPortfolioID",
            "l4_portfolioname": "L4_PortfolioName",
            "l4_portfoliotype": "L4_PortfolioType",
            "l4_managingdepartment": "L4_ManagingDepartment",
            "l4_managertype": "L4_ManagerType",
            "l4_managingstyle": "L4_ManagingStyle",
            "l4_pspassetclassallocationcode": "L4_PSPAssetClassAllocationCode",
            "l4_assetclassallocationdescription": "L4_AssetClassAllocationDescription",
            "l4_portfoliostyle": "L4_PortfolioStyle",
            "l4_ownerdepartment": "L4_OwnerDepartment",
            "l4_pspinvestmentteamcode": "L4_PSPInvestmentTeamCode",
            "l4_investmentteamname": "L4_InvestmentTeamName",
            "investmentstrategycalc": "InvestmentStrategyCalc",
        },
    },
}

private_markets_query_dict_snowflake = {
    "query_sql_path": "sql/Queries_Snowflake/QueryPrivateMarkets.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryPrivateMarkets",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "final_position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": True,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["positiondate", "sourcedate"],
            "integer": ["portfolio_pspportfolioid"],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "positiondate": "PositionDate",
            "sourcedate": "SourceDate",
            "portfolio_pspportfoliocode": "Portfolio_PSPPortfolioCode",
            "portfolio_pspportfolioid": "Portfolio_PSPPortfolioID",
            "portfolio_name": "Portfolio_Name",
            "portfolio_markettype": "Portfolio_MarketType",
            "portfolio_assetclass": "Portfolio_AssetClass",
            "portfolio_investmentteam": "Portfolio_InvestmentTeam",
            "portfolio_managertype": "Portfolio_ManagerType",
            "portfolio_managingstyle": "Portfolio_ManagingStyle",
            "portfolio_managingdepartment": "Portfolio_ManagingDepartment",
            "portfolio_ownerdepartment": "Portfolio_OwnerDepartment",
            "instrument_pspinstrumentid": "Instrument_PSPInstrumentID",
            "instrument_currencycode": "Instrument_CurrencyCode",
            "leg_pspinstrumentlegid": "Leg_PSPInstrumentLegID",
            "position_quantity": "Position_Quantity",
            "position_nominalamount": "Position_NominalAmount",
            "position_marketvalue_cad": "Position_MarketValue_CAD",
            "position_accruedinterestvalue_cad": "Position_AccruedInterestValue_CAD",
            "position_taxreclaimvalue_cad": "Position_TaxReclaimValue_CAD",
            "position_netassetvalue_cad": "Position_NetAssetValue_CAD",
            "position_exposurevalue_cad": "Position_ExposureValue_CAD",
            "instrument_risklocationcountrycode": "Instrument_RiskLocationCountryCode",
            "instrument_normalizedcountrycode": "Instrument_NormalizedCountryCode",
            "instrument_geographyname": "Instrument_GeographyName",
            "instrument_bicsbetaclassificationid": "Instrument_BICSBETAClassificationID",
            "instrument_bicsbetasectorcode": "Instrument_BICSBETASectorCode",
            "instrument_bicsbetasectorname": "Instrument_BICSBETASectorName",
            "instrument_bicsbetaindustrygroupcode": "Instrument_BICSBETAIndustryGroupCode",
            "instrument_bicsbetaindustrygroupname": "Instrument_BICSBETAIndustryGroupName",
            "instrument_bicsbetaindustrycode": "Instrument_BICSBETAIndustryCode",
            "instrument_bicsbetaindustryname": "Instrument_BICSBETAIndustryName",
            "instrument_bicsbetasubindustrycode": "Instrument_BICSBETASubIndustryCode",
            "instrument_bicsbetasubindustryname": "Instrument_BICSBETASubIndustryName",
            "instrument_bicsbetaactivitycode": "Instrument_BICSBETAActivityCode",
            "instrument_bicsbetaactivityname": "Instrument_BICSBETAActivityName",
            "instrument_bicsbetasubactivitycode": "Instrument_BICSBETASubActivityCode",
            "instrument_bicsbetasubactivityname": "Instrument_BICSBETASubActivityName",
            "instrument_bicsbetasegmentcode": "Instrument_BICSBETASegmentCode",
            "instrument_bicsbetasegmentname": "Instrument_BICSBETASegmentName",
        },
    },
}

positions_query_dict_snowflake = {
    "query_sql_path": "sql/Queries_Snowflake/QueryPositions.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryPositions",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "exclusions_psp_instrument_ids": {
            "is_optional": True,
            "is_list": True,
            "is_string": False,
            "prefix": "AND PPL.PSP_INSTRUMENT_ID NOT IN (",
            "suffix": ")",
            "is_signature": False,
        },
        "psp_portfolio_ids": {
            "is_optional": True,
            "is_list": True,
            "is_string": False,
            "prefix": "AND PPL.PSP_PORTFOLIO_ID IN (",
            "suffix": ")",
            "is_signature": False,
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": True,
            "suffix": ".",
        },
        "exclusions_psp_fund_codes": {
            "is_optional": True,
            "is_list": True,
            "is_string": False,
            "is_string": True,
            "prefix": "AND IFNULL(PF.PSP_FUND_CODE,'None') NOT IN (",
            "suffix": ")",
            "is_signature": False,
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["positiondate"],
            "integer": [
                "portfolio_pspportfolioid",
                "instrument_pspinstrumentid",
            ],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {
            "positiondate": "PositionDate",
            "portfolio_pspportfoliocode": "Portfolio_PSPPortfolioCode",
            "portfolio_pspportfolioid": "Portfolio_PSPPortfolioID",
            "portfolio_name": "Portfolio_Name",
            "portfolio_markettype": "Portfolio_MarketType",
            "portfolio_assetclass": "Portfolio_AssetClass",
            "portfolio_investmentteam": "Portfolio_InvestmentTeam",
            "portfolio_managertype": "Portfolio_ManagerType",
            "portfolio_managingstyle": "Portfolio_ManagingStyle",
            "portfolio_managingdepartment": "Portfolio_ManagingDepartment",
            "portfolio_ownerdepartment": "Portfolio_OwnerDepartment",
            "instrument_pspinstrumentid": "Instrument_PSPInstrumentID",
            "instrument_currencycode": "Instrument_CurrencyCode",
            "leg_pspinstrumentlegid": "Leg_PSPInstrumentLegID",
            "leg_positionlevel": "Leg_PositionLevel",
            "leg_type": "Leg_Type",
            "position_quantity": "Position_Quantity",
            "position_nominalamount": "Position_NominalAmount",
            "position_marketvalue_cad": "Position_MarketValue_CAD",
            "position_accruedinterestvalue_cad": "Position_AccruedInterestValue_CAD",
            "position_taxreclaimvalue_cad": "Position_TaxReclaimValue_CAD",
            "position_netassetvalue_cad": "Position_NetAssetValue_CAD",
        },
    },
}

unique_benchmarks_query_dict_snowflake = {
    "query_sql_path": "sql/Queries_Snowflake/QueryUniqueBenchmarks.sql",
    "query_file_path": "dataset/Queries_Snowflake/QueryUniqueBenchmarks",
    "query_target_service_name": "snowflake",
    "query_force_refresh": False,
    "query_parameters": {
        "evaluation_date": {
            "is_optional": False,
            "is_list": False,
            "is_string": True,
            "is_signature": True,
        },
        "position_dates": {
            "is_optional": False,
            "is_list": True,
            "is_string": True,
            "is_signature": True,
        },
        "database_warehouse": {
            "is_optional": True,
            "is_list": False,
            "is_string": False,
            "is_signature": True,
            "suffix": ".",
        },
    },
    "query_format_dict": {
        "format_function": function_format_df,
        "format_parameters": {
            "date": ["effective_date"],
            "integer": [
                "psp_instrument_id",'psp_benchmark_id'
            ],
        },
    },
    "query_rename_dict": {
        "rename_function": function_rename_df,
        "rename_parameters": {  'psp_benchmark_code':'Benchmark_PSPBenchmarkCode'
                              , 'psp_benchmark_id':'Benchmark_PSPBenchmarkID'
                              , 'benchmark_name':'Benchmark_PSPBenchmarkName'
                              , 'effective_date':'PositionDate'
                              , 'psp_instrument_id':'Index_PSPInstrumentID'
                              , 'weight':'Index_Weight'
                             }
    },
}


sql_dictionary = {
    "portfolios": portfolio_query_dict,
    "positions": positions_query_dict,
    "gics": gics_query_dict,
    "instruments": instruments_query_dict,
    "instruments_snowflake": instruments_query_dict_snowflake,
    "options": options_query_dict,
    "futures": futures_query_dict,
    "forwards": forwards_query_dict,
    "swap_legs": swap_legs_query_dict,
    "swap_legs_snowflake":swap_legs_query_dict_snowflake,
    "security_financing": security_financing_query_dict,
    "index": index_query_dict,
    "index_constituents": index_constituents_query_dict,
    "etf_constituents": etf_constituents_query_dict,
    "basket_constituents": basket_constituents_query_dict,
    "credit_constituents": credit_constituents_query_dict,
    "credit_constituents_snowflake":credit_constituents_snowflake_query_dict,
    "constituents": constituents_query_dict,
    "shares": shares_query_dict,
    "pooled_funds_options": pooled_funds_options_query_dict,
    "pooled_funds_forwards": pooled_funds_forwards_query_dict,
    "pooled_funds_credit_derivatives": pooled_funds_credit_derivatives_query_dict,
    "pooled_funds_swaps": pooled_funds_swaps_query_dict,
    "pooled_funds": pooled_funds_query_dict,
    "pooled_funds_ratio": pooled_funds_ratio_query_dict,
    "fx_rates": fx_rates_query_dict,
    "fx_rates_snowflake": fx_rates_query_dict_snowflake,
    "prices": prices_query_dict,
    "prices_snowflake": prices_query_dict_snowflake,
    "private_markets": private_markets_query_dict,
    "benchmarks": benchmarks_query_dict,
    "benchmarks_snowflake":benchmarks_query_dict_snowflake,
    "index_constituents": index_constituents_query_dict,
    "issuers": issuers_query_dict,
    "issuer_sectors": issuer_sectors_query_dict,
    "issuer_ratings": issuer_ratings_query_dict,
    "mra_batch_mapping": mra_batch_mapping_query_dict,
    "mra_batch_data": mra_batch_data_query_dict,
    "mra_batch_data_currency": mra_batch_data_currency_query_dict,
    "mra_ghost_instruments": mra_ghost_instruments_query_dict,
    "mra_exposure": mra_exposure_query_dict,
    "mra_exposure_fx": mra_exposure_fx_query_dict,
    "mra_batch_mapping_snowflake": mra_batch_mapping_query_dict_snowflake,
    "mra_batch_data_snowflake": mra_batch_data_query_dict_snowflake,
    "mra_batch_data_currency_snowflake": mra_batch_data_currency_query_dict_snowflake,
    "mra_ghost_instruments_snowflake": mra_ghost_instruments_query_dict_snowflake,
    "mra_exposure_snowflake": mra_exposure_query_dict_snowflake,
    "mra_exposure_fx_snowflake": mra_exposure_fx_query_dict_snowflake,
    "mra_batch_portfolios_snowflake": mra_batch_portfolios_query_dict_snowflake,
    "maturity_dates_snowflake": maturity_dates_query_dict_snowflake,
    "exposure_extended_snowflake": exposure_extended_query_dict_snowflake,
    "exposure_non_extended_snowflake": exposure_non_extended_query_dict_snowflake,
    "exposure_tfe_snowflake": exposure_tfe_query_dict_snowflake,
    "exposure_tfe_snowflake_emr": exposure_tfe_query_emr_dict_snowflake,
    "exposure_creditrisk_dm": exposure_creditrisk_dm_query_dict,
    "exposure_creditrisk_dm_emr":exposure_creditrisk_dm_emr_query_dict,
    "position_dates_production": position_dates_production_query_dict_snowflake,
    "portfolios_snowflake":portfolio_query_dict_snowflake,
    "positions_snowflake":positions_query_dict_snowflake,
    "private_markets_snowflake":private_markets_query_dict_snowflake,
    "unique_benchmarks_snowflake":unique_benchmarks_query_dict_snowflake,
    "mra_index_data":mra_index_data_query_dict_snowflake,
    "mra_index_mapping":mra_index_mapping_query_dict_snowflake,
}
