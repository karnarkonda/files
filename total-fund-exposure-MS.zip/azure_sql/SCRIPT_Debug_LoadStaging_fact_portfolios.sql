/****** Script for SelectTopNRows command from SSMS  ******/
SELECT 
		 *
FROM [dbo].[ST_fact_portfolios]

SELECT 
		  CAST(PositionDate	AS DATE)
		, Portfolio_PSPPortfolioCode				
		, CAST(Portfolio_PSPPortfolioID AS INT)					
		, Portfolio_Name							
		, Portfolio_Type							
		, Portfolio_MarketType						
		, Portfolio_AssetClass						
		, Portfolio_InvestmentTeam					
		, Portfolio_ManagerType						
		, Portfolio_ManagingStyle					
		, Portfolio_ManagingDepartment				
		, Portfolio_OwnerDepartment					
		, CONVERT(INT,            Portfolio_Position_Count)		
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_Position_MarketValue_CAD))
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_Position_NetAssetValue_CAD))
		, CONVERT(INT,            Portfolio_Internal_Count)	
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_Internal_MarketValue_CAD))	
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_Internal_NetAssetValue_CAD))	
		, CONVERT(INT,            Portfolio_PooledFund_Count)	
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_PooledFund_MarketValue_CAD))	
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_PooledFund_NetAssetValue_CAD))		
FROM [dbo].[ST_fact_portfolios]