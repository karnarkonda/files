SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      PA Ratelle
-- Create Date: 2023-02-16
-- Description: 
-- =============================================
ALTER PROCEDURE dbo.UP_LoadStaging_fact_exposure
(
      @temporary_table_exposure_data VARCHAR(MAX) = 'ST_fact_exposure'
)
AS
BEGIN

	/*AAA**************************************************************************************************/
	/** Create Temporary Tables ***************************************************************************/
	/******************************************************************************************************/
    SET NOCOUNT ON;
	IF OBJECT_ID('tempdb..#TB_temporary_fact_exposure','u')  IS NOT NULL DROP TABLE #TB_temporary_fact_exposure
	CREATE TABLE #TB_temporary_fact_exposure
	(
		  PositionDate											DATE			NOT NULL
		, Object_Type											VARCHAR(50)		NOT NULL
		, Position_Type											VARCHAR(50)		NOT NULL
		, Position_Source										VARCHAR(50)		NOT NULL
		, Portfolio_PSPPortfolioCode							VARCHAR(50)		NOT NULL
		, Portfolio_PSPPortfolioID								INT				NOT NULL
		, Instrument_CurrencyCode								VARCHAR(3)		NOT NULL
		, Instrument_ReportingCurrencyCode						VARCHAR(3)		NOT NULL
		, Instrument_PSPInstrumentID							INT				NOT NULL
		, Instrument_PSPInstrumentCategorizationID				INT				NULL
		, Instrument_PSPInstrumentCategorizationCode			VARCHAR(200)	NULL
		, Instrument_Description								VARCHAR(200)	NULL
		, UltimateUnderlying_PSPInstrumentID					INT				NOT NULL
		, UltimateUnderlying_PSPInstrumentCategorizationID		INT				NULL
		, UltimateUnderlying_PSPInstrumentCategorizationCode	VARCHAR(200)	NULL
		, UltimateUnderlying_Description						VARCHAR(200)	NULL
		, UltimateUnderlying_IssuerCode							INT				NULL
		, UltimateUnderlying_IndexProxyPSPInstrumentID			INT				NULL
		, Leg_PSPInstrumentLegID								INT				NOT NULL
		, Leg_Type												VARCHAR(50)		NULL
		, Leg_Direction											VARCHAR(50)		NULL
		, Leg_PositionLevel										VARCHAR(50)		NULL
		, Option_Style											VARCHAR(50)		NULL
		, Position_NetAssetValue_CAD							NUMERIC(28,10)	NULL
		, Exposure_FX											NUMERIC(28,10)	NULL
		, Exposure_FI											NUMERIC(28,10)	NULL
		, Exposure_CR											NUMERIC(28,10)	NULL
		, Exposure_Issuer										NUMERIC(28,10)	NULL
		, Exposure_Equity										NUMERIC(28,10)	NULL
		, Exposure_Commodity									NUMERIC(28,10)	NULL
		, MostRecent_CalendarKey								DATE			NULL
		, BatchKey												INT				NULL
		, Portfolio_Key											INT				NULL
		, Instrument_Key										INT				NOT NULL
		, RiskMetricsPositionType								VARCHAR(50)		NULL
		, normal_calculation_family								VARCHAR(50)		NULL
		, exotic_calculation_family								VARCHAR(50)		NULL
		, use_pooled_fund_calculations							INT				NULL
		, row_count												INT             NULL
		, PRIMARY KEY CLUSTERED(PositionDate, Portfolio_PSPPortfolioCode, Instrument_PSPInstrumentID, Object_Type, Instrument_CurrencyCode, Instrument_ReportingCurrencyCode, Leg_PSPInstrumentLegID, Instrument_Key)
	)

	IF OBJECT_ID('tempdb..#TB_temporary_fact_exposure_keys','u')  IS NOT NULL DROP TABLE #TB_temporary_fact_exposure_keys
	CREATE TABLE #TB_temporary_fact_exposure_keys
	(
		  PositionDate										DATE			NOT NULL
		, Portfolio_PSPPortfolioCode						VARCHAR(50)		NOT NULL
		, PRIMARY KEY CLUSTERED(PositionDate, Portfolio_PSPPortfolioCode)
	)
	
	/*BBB**************************************************************************************************/
	/** Insert Into Temporary Table ***********************************************************************/
	/******************************************************************************************************/
	DECLARE @insertion_query_exposure_data VARCHAR(MAX);
	SET @insertion_query_exposure_data = '
	INSERT INTO #TB_temporary_fact_exposure
	(
		  PositionDate											
		, Object_Type											
		, Position_Type											
		, Position_Source										
		, Portfolio_PSPPortfolioCode							
		, Portfolio_PSPPortfolioID								
		, Instrument_CurrencyCode								
		, Instrument_ReportingCurrencyCode						
		, Instrument_PSPInstrumentID							
		, Instrument_PSPInstrumentCategorizationID				
		, Instrument_PSPInstrumentCategorizationCode			
		, Instrument_Description								
		, UltimateUnderlying_PSPInstrumentID					
		, UltimateUnderlying_PSPInstrumentCategorizationID		
		, UltimateUnderlying_PSPInstrumentCategorizationCode	
		, UltimateUnderlying_Description						
		, UltimateUnderlying_IssuerCode							
		, UltimateUnderlying_IndexProxyPSPInstrumentID			
		, Leg_PSPInstrumentLegID								
		, Leg_Type												
		, Leg_Direction											
		, Leg_PositionLevel										
		, Option_Style											
		, Position_NetAssetValue_CAD							
		, Exposure_FX											
		, Exposure_FI											
		, Exposure_CR											
		, Exposure_Issuer										
		, Exposure_Equity										
		, Exposure_Commodity									
		, MostRecent_CalendarKey								
		, BatchKey												
		, Portfolio_Key											
		, Instrument_Key										
		, RiskMetricsPositionType								
		, normal_calculation_family								
		, exotic_calculation_family								
		, use_pooled_fund_calculations	
	)
	SELECT 
		  PositionDate											
		, Object_Type											
		, Position_Type											
		, Position_Source										
		, Portfolio_PSPPortfolioCode							
		, CAST(CAST(Portfolio_PSPPortfolioID				   			AS FLOAT) AS INT)
		, Instrument_CurrencyCode								
		, ISNULL(Instrument_ReportingCurrencyCode, Instrument_CurrencyCode)						
		, CAST(CAST(Instrument_PSPInstrumentID							AS FLOAT) AS INT)						
		, CAST(CAST(Instrument_PSPInstrumentCategorizationID			AS FLOAT) AS INT)				
		, Instrument_PSPInstrumentCategorizationCode			
		, Instrument_Description								
		, CAST(CAST(UltimateUnderlying_PSPInstrumentID					AS FLOAT) AS INT)				
		, CAST(CAST(UltimateUnderlying_PSPInstrumentCategorizationID	AS FLOAT) AS INT)				
		, UltimateUnderlying_PSPInstrumentCategorizationCode	
		, UltimateUnderlying_Description						
		, CAST(CAST(UltimateUnderlying_IssuerCode						AS FLOAT) AS INT)		
		, CAST(CAST(UltimateUnderlying_IndexProxyPSPInstrumentID		AS FLOAT) AS INT)	
		, CAST(CAST(ISNULL(Leg_PSPInstrumentLegID,0)					AS FLOAT) AS INT)							
		, Leg_Type												
		, Leg_Direction											
		, Leg_PositionLevel										
		, Option_Style											
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Position_NetAssetValue_CAD	))						
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Exposure_FX	))										
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Exposure_FI	))										
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Exposure_CR	))										
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Exposure_Issuer))										
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Exposure_Equity))									
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Exposure_Commodity))									
		, MostRecent_CalendarKey								
		, ISNULL(CAST(CAST(BatchKey	      AS FLOAT) AS INT),0)
		, ISNULL(CAST(CAST(Portfolio_Key  AS FLOAT) AS INT),0)
		, ISNULL(CAST(CAST(Instrument_Key AS FLOAT) AS INT), ROW_NUMBER () OVER(PARTITION BY PositionDate, Portfolio_PSPPortfolioCode, Instrument_PSPInstrumentID, Instrument_CurrencyCode, Instrument_ReportingCurrencyCode, Leg_PSPInstrumentLegID, CAST(CAST(Instrument_Key AS FLOAT) AS INT) ORDER BY Position_NetAssetValue_CAD DESC))
		, RiskMetricsPositionType								
		, normal_calculation_family								
		, exotic_calculation_family								
		, CAST(CAST(use_pooled_fund_calculations						AS FLOAT) AS INT)	
	FROM ' + @temporary_table_exposure_data + ' 
	WHERE Instrument_CurrencyCode IS NOT NULL'
	
	print(@insertion_query_exposure_data)
	EXEC(@insertion_query_exposure_data);
	--You are here
	WITH data_count (
					  PositionDate
					, Portfolio_PSPPortfolioCode
					, Object_Type
					, Instrument_PSPInstrumentID
					, Instrument_CurrencyCode
					, Instrument_ReportingCurrencyCode
					, Leg_PSPInstrumentLegID
					, Instrument_Key
					, row_count
					)
	AS	(
		 SELECT 
			  PositionDate
			, Portfolio_PSPPortfolioCode
			, Object_Type
			, Instrument_PSPInstrumentID
			, Instrument_CurrencyCode
			, Instrument_ReportingCurrencyCode
			, Leg_PSPInstrumentLegID
			, Instrument_Key
			, COUNT(*)
		 FROM #TB_temporary_fact_exposure
		 GROUP BY
			  PositionDate
			, Portfolio_PSPPortfolioCode
			, Object_Type
			, Instrument_PSPInstrumentID
			, Instrument_CurrencyCode
			, Instrument_ReportingCurrencyCode
			, Leg_PSPInstrumentLegID
			, Instrument_Key
		)
	UPDATE P SET
		  P.row_count            = R.row_count
	FROM #TB_temporary_fact_exposure P
	INNER JOIN data_count R ON		R.PositionDate                      = P.PositionDate 
								AND R.Portfolio_PSPPortfolioCode		= P.Portfolio_PSPPortfolioCode 
								AND R.Object_Type						= P.Object_Type
								AND R.Instrument_PSPInstrumentID		= P.Instrument_PSPInstrumentID 
								AND R.Instrument_CurrencyCode			= P.Instrument_CurrencyCode 
								AND R.Instrument_ReportingCurrencyCode	= P.Instrument_ReportingCurrencyCode 
								AND R.Leg_PSPInstrumentLegID			= P.Leg_PSPInstrumentLegID
								AND R.Instrument_Key					= P.Instrument_Key

	PRINT('Inserted ' + CAST(@@rowcount AS VARCHAR) + ' rows into temporary staging table')
	
	/*CCC**************************************************************************************************/
	/** Generate Data Atomicity ***************************************************************************/
	/******************************************************************************************************/
	INSERT INTO #TB_temporary_fact_exposure_keys
	(
		  PositionDate						
		, Portfolio_PSPPortfolioCode			
	)
	SELECT
		  PositionDate						
		, Portfolio_PSPPortfolioCode			
	FROM #TB_temporary_fact_exposure
	GROUP BY 
		  PositionDate						
		, Portfolio_PSPPortfolioCode			
	
	/*DDD**************************************************************************************************/
	/** Delete original data based on atomicity ***********************************************************/
	/******************************************************************************************************/
	DELETE FROM P
	FROM #TB_temporary_fact_exposure_keys PK
	INNER JOIN dbo.TB_fact_exposure P ON P.PositionDate = PK.PositionDate AND P.Portfolio_PSPPortfolioCode = PK.Portfolio_PSPPortfolioCode
	--TRUNCATE TABLE dbo.TB_fact_exposure
	PRINT('Deleted ' + CAST(@@rowcount AS VARCHAR) + ' rows into dbo.TB_fact_exposure')

	SELECT TOP 100 
		  PositionDate													
		, Object_Type													
		, Position_Type													
		, Position_Source												
		, Portfolio_PSPPortfolioCode									
		, Portfolio_PSPPortfolioID										
		, Instrument_CurrencyCode										
		, Instrument_ReportingCurrencyCode								
		, Instrument_PSPInstrumentID									
		, Instrument_PSPInstrumentCategorizationID						
		, Instrument_PSPInstrumentCategorizationCode					
		, Instrument_Description										
		, UltimateUnderlying_PSPInstrumentID							
		, UltimateUnderlying_PSPInstrumentCategorizationID				
		, UltimateUnderlying_PSPInstrumentCategorizationCode			
		, UltimateUnderlying_Description								
		, UltimateUnderlying_IssuerCode									
		, UltimateUnderlying_IndexProxyPSPInstrumentID					
		, Leg_PSPInstrumentLegID										
		, Leg_Type														
		, Leg_Direction													
		, Leg_PositionLevel												
		, Option_Style													
		, Position_NetAssetValue_CAD									
		, Exposure_FX													
		, Exposure_FI													
		, Exposure_CR													
		, Exposure_Issuer												
		, Exposure_Equity												
		, Exposure_Commodity											
		, MostRecent_CalendarKey										
		, BatchKey														
		, Portfolio_Key													
		, Instrument_Key												
		, RiskMetricsPositionType										
		, normal_calculation_family										
		, exotic_calculation_family										
		, use_pooled_fund_calculations		
		, row_count
	FROM #TB_temporary_fact_exposure
	WHERE row_count>1
	ORDER BY 
			  PositionDate
			, Portfolio_PSPPortfolioCode
			, Instrument_PSPInstrumentID
			, Instrument_CurrencyCode
			, Instrument_ReportingCurrencyCode
			, Leg_PSPInstrumentLegID

	
	/*EEE**************************************************************************************************/
	/** Insert Into Portfolios ****************************************************************************/
	/******************************************************************************************************/
	INSERT INTO dbo.TB_fact_exposure
	(
		  PositionDate											
		, Object_Type											
		, Position_Type											
		, Position_Source										
		, Portfolio_PSPPortfolioCode							
		, Portfolio_PSPPortfolioID								
		, Instrument_CurrencyCode								
		, Instrument_ReportingCurrencyCode						
		, Instrument_PSPInstrumentID							
		, Instrument_PSPInstrumentCategorizationID				
		, Instrument_PSPInstrumentCategorizationCode			
		, Instrument_Description								
		, UltimateUnderlying_PSPInstrumentID					
		, UltimateUnderlying_PSPInstrumentCategorizationID		
		, UltimateUnderlying_PSPInstrumentCategorizationCode	
		, UltimateUnderlying_Description						
		, UltimateUnderlying_IssuerCode							
		, UltimateUnderlying_IndexProxyPSPInstrumentID			
		, Leg_PSPInstrumentLegID								
		, Leg_Type												
		, Leg_Direction											
		, Leg_PositionLevel										
		, Option_Style											
		, Position_NetAssetValue_CAD							
		, Exposure_FX											
		, Exposure_FI											
		, Exposure_CR											
		, Exposure_Issuer										
		, Exposure_Equity										
		, Exposure_Commodity									
		, MostRecent_CalendarKey								
		, BatchKey												
		, Portfolio_Key											
		, Instrument_Key										
		, RiskMetricsPositionType								
		, normal_calculation_family								
		, exotic_calculation_family								
		, use_pooled_fund_calculations							
	)
	SELECT
		  PositionDate													--  PositionDate											
		, Object_Type													--, Object_Type											
		, Position_Type													--, Position_Type											
		, Position_Source												--, Position_Source										
		, Portfolio_PSPPortfolioCode									--, Portfolio_PSPPortfolioCode							
		, Portfolio_PSPPortfolioID										--, Portfolio_PSPPortfolioID								
		, Instrument_CurrencyCode										--, Instrument_CurrencyCode								
		, Instrument_ReportingCurrencyCode								--, Instrument_ReportingCurrencyCode						
		, Instrument_PSPInstrumentID									--, Instrument_PSPInstrumentID							
		, Instrument_PSPInstrumentCategorizationID						--, Instrument_PSPInstrumentCategorizationID				
		, Instrument_PSPInstrumentCategorizationCode					--, Instrument_PSPInstrumentCategorizationCode			
		, Instrument_Description										--, Instrument_Description								
		, UltimateUnderlying_PSPInstrumentID							--, UltimateUnderlying_PSPInstrumentID					
		, UltimateUnderlying_PSPInstrumentCategorizationID				--, UltimateUnderlying_PSPInstrumentCategorizationID		
		, UltimateUnderlying_PSPInstrumentCategorizationCode			--, UltimateUnderlying_PSPInstrumentCategorizationCode	
		, UltimateUnderlying_Description								--, UltimateUnderlying_Description						
		, UltimateUnderlying_IssuerCode									--, UltimateUnderlying_IssuerCode							
		, UltimateUnderlying_IndexProxyPSPInstrumentID					--, UltimateUnderlying_IndexProxyPSPInstrumentID			
		, Leg_PSPInstrumentLegID										--, Leg_PSPInstrumentLegID								
		, Leg_Type														--, Leg_Type												
		, Leg_Direction													--, Leg_Direction											
		, Leg_PositionLevel												--, Leg_PositionLevel										
		, Option_Style													--, Option_Style											
		, Position_NetAssetValue_CAD									--, Position_NetAssetValue_CAD							
		, Exposure_FX													--, Exposure_FX											
		, Exposure_FI													--, Exposure_FI											
		, Exposure_CR													--, Exposure_CR											
		, Exposure_Issuer												--, Exposure_Issuer										
		, Exposure_Equity												--, Exposure_Equity										
		, Exposure_Commodity											--, Exposure_Commodity									
		, MostRecent_CalendarKey										--, MostRecent_CalendarKey								
		, BatchKey														--, BatchKey												
		, Portfolio_Key													--, Portfolio_Key											
		, Instrument_Key												--, Instrument_Key										
		, RiskMetricsPositionType										--, RiskMetricsPositionType								
		, normal_calculation_family										--, normal_calculation_family								
		, exotic_calculation_family										--, exotic_calculation_family								
		, use_pooled_fund_calculations									--, use_pooled_fund_calculations							
	FROM #TB_temporary_fact_exposure
	WHERE row_count=1
	
	SELECT 
		  *
	FROM #TB_temporary_fact_exposure
	WHERE row_count>1
	ORDER BY 
			  PositionDate
			, Portfolio_PSPPortfolioCode
			, Instrument_PSPInstrumentID
			, Instrument_CurrencyCode
			, Instrument_ReportingCurrencyCode
			, Leg_PSPInstrumentLegID

	PRINT('Inserted ' + CAST(@@rowcount AS VARCHAR)  + ' rows into dbo.TB_fact_exposure')

END
GO
