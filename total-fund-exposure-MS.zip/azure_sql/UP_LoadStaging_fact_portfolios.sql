SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      PA Ratelle
-- Create Date: 2023-02-16
-- Description: 
-- =============================================
ALTER PROCEDURE dbo.UP_LoadStaging_fact_portfolios
(
      @temporary_table_portfolios_data VARCHAR(MAX) = 'ST_fact_portfolios'
)
AS
BEGIN

	/*AAA**************************************************************************************************/
	/** Insert Portfolios Data ****************************************************************************/
	/******************************************************************************************************/
    SET NOCOUNT ON;
	CREATE TABLE #TB_temporary_fact_portfolios
	(
		  [DataKey]											INT IDENTITY(1,1) 
		, PositionDate										DATE			NOT NULL
		, Portfolio_PSPPortfolioCode						VARCHAR(50)		NOT NULL
		, Portfolio_PSPPortfolioID							INT				NULL
		, Portfolio_Name									VARCHAR(200)	NULL
		, Portfolio_Type									VARCHAR(50)		NULL
		, Portfolio_MarketType								VARCHAR(50)		NULL
		, Portfolio_AssetClass								VARCHAR(50)		NULL
		, Portfolio_InvestmentTeam							VARCHAR(50)		NULL
		, Portfolio_ManagerType								VARCHAR(50)		NULL
		, Portfolio_ManagingStyle							VARCHAR(50)		NULL
		, Portfolio_ManagingDepartment						VARCHAR(50)		NULL
		, Portfolio_OwnerDepartment							VARCHAR(50)		NULL
		, Portfolio_Position_Count							INT				NULL
		, Portfolio_Position_MarketValue_CAD				NUMERIC(28,10)	NULL
		, Portfolio_Position_NetAssetValue_CAD				NUMERIC(28,10)	NULL
		, Portfolio_Internal_Count							INT				NULL
		, Portfolio_Internal_MarketValue_CAD				NUMERIC(28,10)	NULL
		, Portfolio_Internal_NetAssetValue_CAD				NUMERIC(28,10)	NULL
		, Portfolio_PooledFund_Count						INT				NULL
		, Portfolio_PooledFund_MarketValue_CAD				NUMERIC(28,10)	NULL
		, Portfolio_PooledFund_NetAssetValue_CAD			NUMERIC(28,10)	NULL
		, PRIMARY KEY CLUSTERED(PositionDate, Portfolio_PSPPortfolioCode)
	)

	CREATE TABLE #TB_temporary_fact_portfolios_keys
	(
		  PositionDate										DATE			NOT NULL
		, Portfolio_PSPPortfolioCode						VARCHAR(50)		NOT NULL
	)
	
	/*BBB**************************************************************************************************/
	/** Insert Into Temporary Table ***********************************************************************/
	/******************************************************************************************************/
	DECLARE @insertion_query_portfolios_data VARCHAR(MAX);
	SET @insertion_query_portfolios_data = '
	INSERT INTO #TB_temporary_fact_portfolios
	(
		  PositionDate								
		, Portfolio_PSPPortfolioCode				
		, Portfolio_PSPPortfolioID					
		, Portfolio_Name							
		, Portfolio_Type							
		, Portfolio_MarketType						
		, Portfolio_AssetClass						
		, Portfolio_InvestmentTeam					
		, Portfolio_ManagerType						
		, Portfolio_ManagingStyle					
		, Portfolio_ManagingDepartment				
		, Portfolio_OwnerDepartment					
		, Portfolio_Position_Count					
		, Portfolio_Position_MarketValue_CAD		
		, Portfolio_Position_NetAssetValue_CAD		
		, Portfolio_Internal_Count					
		, Portfolio_Internal_MarketValue_CAD		
		, Portfolio_Internal_NetAssetValue_CAD		
		, Portfolio_PooledFund_Count				
		, Portfolio_PooledFund_MarketValue_CAD		
		, Portfolio_PooledFund_NetAssetValue_CAD	
	)
	SELECT 
		  CAST(PositionDate	AS DATE)
		, Portfolio_PSPPortfolioCode				
		, CAST(Portfolio_PSPPortfolioID AS INT)					
		, Portfolio_Name							
		, Portfolio_Type							
		, Portfolio_MarketType						
		, Portfolio_AssetClass						
		, Portfolio_InvestmentTeam					
		, Portfolio_ManagerType						
		, Portfolio_ManagingStyle					
		, Portfolio_ManagingDepartment				
		, Portfolio_OwnerDepartment					
		, CONVERT(INT,            Portfolio_Position_Count)		
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_Position_MarketValue_CAD))
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_Position_NetAssetValue_CAD))
		, CONVERT(INT,            Portfolio_Internal_Count)	
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_Internal_MarketValue_CAD))	
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_Internal_NetAssetValue_CAD))	
		, CONVERT(INT,            Portfolio_PooledFund_Count)	
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_PooledFund_MarketValue_CAD))	
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Portfolio_PooledFund_NetAssetValue_CAD))
	FROM ' + @temporary_table_portfolios_data

	EXEC(@insertion_query_portfolios_data)
	PRINT('Inserted ' + CAST(@@rowcount AS VARCHAR) + ' rows into temporary staging table')
	
	/*CCC**************************************************************************************************/
	/** Generate Data Atomicity ***************************************************************************/
	/******************************************************************************************************/
	INSERT INTO #TB_temporary_fact_portfolios_keys
	(
		  PositionDate				
		, Portfolio_PSPPortfolioCode
	)
	SELECT
		  PositionDate				
		, Portfolio_PSPPortfolioCode
	FROM #TB_temporary_fact_portfolios
	GROUP BY 
		  PositionDate				
		, Portfolio_PSPPortfolioCode
	
	/*DDD**************************************************************************************************/
	/** Delete original data based on atomicity ***********************************************************/
	/******************************************************************************************************/
	DELETE FROM P
	FROM #TB_temporary_fact_portfolios_keys PK
	INNER JOIN dbo.TB_fact_portfolios P ON P.PositionDate = PK.PositionDate AND P.Portfolio_PSPPortfolioCode = PK.Portfolio_PSPPortfolioCode

	PRINT('Deleted ' + CAST(@@rowcount AS VARCHAR) + ' rows into dbo.TB_fact_portfolios')
	
	/*EEE**************************************************************************************************/
	/** Insert Into Portfolios ****************************************************************************/
	/******************************************************************************************************/
	INSERT INTO dbo.TB_fact_portfolios
	(
		  PositionDate										
		, Portfolio_PSPPortfolioCode						
		, Portfolio_PSPPortfolioID							
		, Portfolio_Name									
		, Portfolio_Type									
		, Portfolio_MarketType								
		, Portfolio_AssetClass								
		, Portfolio_InvestmentTeam							
		, Portfolio_ManagerType								
		, Portfolio_ManagingStyle							
		, Portfolio_ManagingDepartment						
		, Portfolio_OwnerDepartment							
		, Portfolio_Position_Count							
		, Portfolio_Position_MarketValue_CAD				
		, Portfolio_Position_NetAssetValue_CAD				
		, Portfolio_Internal_Count							
		, Portfolio_Internal_MarketValue_CAD				
		, Portfolio_Internal_NetAssetValue_CAD				
		, Portfolio_PooledFund_Count						
		, Portfolio_PooledFund_MarketValue_CAD				
		, Portfolio_PooledFund_NetAssetValue_CAD			
	)
	SELECT
		  PositionDate										
		, Portfolio_PSPPortfolioCode						
		, Portfolio_PSPPortfolioID							
		, Portfolio_Name									
		, Portfolio_Type									
		, Portfolio_MarketType								
		, Portfolio_AssetClass								
		, Portfolio_InvestmentTeam							
		, Portfolio_ManagerType								
		, Portfolio_ManagingStyle							
		, Portfolio_ManagingDepartment						
		, Portfolio_OwnerDepartment							
		, Portfolio_Position_Count							
		, Portfolio_Position_MarketValue_CAD				
		, Portfolio_Position_NetAssetValue_CAD				
		, Portfolio_Internal_Count							
		, Portfolio_Internal_MarketValue_CAD				
		, Portfolio_Internal_NetAssetValue_CAD				
		, Portfolio_PooledFund_Count						
		, Portfolio_PooledFund_MarketValue_CAD				
		, Portfolio_PooledFund_NetAssetValue_CAD		
	FROM #TB_temporary_fact_portfolios

	PRINT('Inserted ' + CAST(@@rowcount AS VARCHAR)  + ' rows into dbo.TB_fact_portfolios')

END
GO
