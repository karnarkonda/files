SELECT *			
FROM dbo.ST_fact_constituents

SELECT 
	  CAST(PositionDate	AS DATE)
	, CAST(Constituee_PSPInstrumentID					AS INT)				
	, Constituee_Type								
	, CAST(Constituent_PSPInstrumentID					AS INT)					
	, Constituent_Family							
	, CONVERT(INT, CONVERT(FLOAT, Constituent_PSPInstrumentCategorizationID))
	, Constituent_PSPInstrumentCategorizationCode	
	, Constituent_Description						
	, Constituent_Market							
	, Constituent_Type								
	, Constituent_IssuerCode						
	, Constituent_CurrencyCode						
	, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Constituent_Weight))							
	, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Constituent_IssuerExposureFactor))				
	, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Constituent_EquityExposureFactor))				
FROM dbo.ST_fact_constituents
WHERE PositionDate = '2022-11-11'
 AND Constituee_PSPInstrumentID = 10907
 AND Constituent_PSPInstrumentID = 2274572

