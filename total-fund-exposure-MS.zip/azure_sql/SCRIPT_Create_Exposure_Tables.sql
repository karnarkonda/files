/****** Object:  Table dbo.TB_constituents_data    Script Date: 2023-02-16 11:59:21 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.TB_fact_constituents','U') IS NOT NULL DROP TABLE dbo.TB_fact_constituents
CREATE TABLE dbo.TB_fact_constituents
(
	  PositionDate									DATE			NOT NULL
	, Constituee_PSPInstrumentID					INT				NOT NULL
	, Constituee_Type								VARCHAR(50)		NULL
	, Constituent_PSPInstrumentID					INT				NOT NULL
	, Constituent_Family							VARCHAR(50)		NULL
	, Constituent_PSPInstrumentCategorizationID		NUMERIC(28,10)	NULL
	, Constituent_PSPInstrumentCategorizationCode	VARCHAR(200)	NULL
	, Constituent_Description						VARCHAR(200)	NULL
	, Constituent_Market							VARCHAR(200)	NULL
	, Constituent_Type								VARCHAR(200)	NULL
	, Constituent_IssuerCode						NUMERIC(28,10)	NULL
	, Constituent_CurrencyCode						VARCHAR(3)		NOT NULL
	, Constituent_Weight							NUMERIC(28,10)	NOT NULL
	, Constituent_IssuerExposureFactor				NUMERIC(28,10)	NULL
	, Constituent_EquityExposureFactor				NUMERIC(28,10)	NULL
	, PRIMARY KEY CLUSTERED(PositionDate, Constituee_PSPInstrumentID, Constituent_PSPInstrumentID)
)

IF OBJECT_ID('dbo.TB_fact_exposure','U') IS NOT NULL DROP TABLE dbo.TB_fact_exposure
CREATE TABLE dbo.TB_fact_exposure
(
	  PositionDate											DATE			NOT NULL
	, Object_Type											VARCHAR(50)		NOT NULL
	, Position_Type											VARCHAR(50)		NOT NULL
	, Position_Source										VARCHAR(50)		NOT NULL
	, Portfolio_PSPPortfolioCode							VARCHAR(50)		NOT NULL
	, Portfolio_PSPPortfolioID								INT				NOT NULL
	, Instrument_CurrencyCode								VARCHAR(3)		NOT NULL
	, Instrument_ReportingCurrencyCode						VARCHAR(3)		NOT NULL
	, Instrument_PSPInstrumentID							INT				NOT NULL
	, Instrument_PSPInstrumentCategorizationID				INT				NULL
	, Instrument_PSPInstrumentCategorizationCode			VARCHAR(200)	NULL
	, Instrument_Description								VARCHAR(200)	NULL
	, UltimateUnderlying_PSPInstrumentID					INT				NOT NULL
	, UltimateUnderlying_PSPInstrumentCategorizationID		INT				NULL
	, UltimateUnderlying_PSPInstrumentCategorizationCode	VARCHAR(200)	NULL
	, UltimateUnderlying_Description						VARCHAR(200)	NULL
	, UltimateUnderlying_IssuerCode							INT				NULL
	, UltimateUnderlying_IndexProxyPSPInstrumentID			INT				NULL
	, Leg_PSPInstrumentLegID								INT				NOT NULL
	, Leg_Type												VARCHAR(50)		NULL
	, Leg_Direction											VARCHAR(50)		NULL
	, Leg_PositionLevel										VARCHAR(50)		NULL
	, Option_Style											VARCHAR(50)		NULL
	, Position_NetAssetValue_CAD							NUMERIC(28,10)	NULL
	, Exposure_FX											NUMERIC(28,10)	NULL
	, Exposure_FI											NUMERIC(28,10)	NULL
	, Exposure_CR											NUMERIC(28,10)	NULL
	, Exposure_Issuer										NUMERIC(28,10)	NULL
	, Exposure_Equity										NUMERIC(28,10)	NULL
	, Exposure_Commodity									NUMERIC(28,10)	NULL
	, MostRecent_CalendarKey								DATE			NULL
	, BatchKey												INT				NULL
	, Portfolio_Key											INT				NULL
	, Instrument_Key										INT				NOT NULL
	, RiskMetricsPositionType								VARCHAR(50)		NULL
	, normal_calculation_family								VARCHAR(50)		NULL
	, exotic_calculation_family								VARCHAR(50)		NULL
	, use_pooled_fund_calculations							INT				NULL
	
)

IF OBJECT_ID('dbo.TB_dimension_issuers','U') IS NOT NULL DROP TABLE dbo.TB_dimension_issuers
CREATE TABLE dbo.TB_dimension_issuers
(
	  Issuer_Code										INT				NOT NULL
	, Issuer_Name										VARCHAR(200)	NULL
	, Issuer_PSPLegalEntityID							INT				NULL
	, Issuer_UltimateParentCode							INT				NULL
	, Issuer_UltimateParentName							VARCHAR(200)	NULL
	, Issuer_RiskLocationCountryCode					VARCHAR(4)		NULL
	, Issuer_NormalizedCountryCode						VARCHAR(4)		NULL
	, Issuer_BICSBETAClassificationID					INT				NULL
	, Issuer_BICSBETASectorCode							VARCHAR(50)		NULL
	, Issuer_BICSBETASectorName							VARCHAR(200)	NULL
	, Issuer_BICSBETAIndustryGroupCode					VARCHAR(50)		NULL
	, Issuer_BICSBETAIndustryGroupName					VARCHAR(200)	NULL
	, Issuer_UltimateParentPSPLegalEntityID				NUMERIC(28,10)	NULL
	, Issuer_UltimateParentRiskLocationCountryCode		VARCHAR(4)		NULL
	, Issuer_UltimateParentNormalizedCountryCode		VARCHAR(4)		NULL
	, Issuer_UltimateParentBICSBETAClassificationID		NUMERIC(28,10)	NULL
	, Issuer_UltimateParentBICSBETASectorCode			VARCHAR(50)		NULL
	, Issuer_UltimateParentBICSBETASectorName			VARCHAR(200)	NULL
	, Issuer_UltimateParentBICSBETAIndustryGroupCode	VARCHAR(50)		NULL
	, Issuer_UltimateParentBICSBETAIndustryGroupName	VARCHAR(200)	NULL
	, Issuer_EquityExposureFactor						NUMERIC(28,10)	NULL
	, Issuer_IssuerExposureFactor						NUMERIC(28,10)	NULL
	, Issuer_FxExposureFactor							NUMERIC(28,10)	NULL
	, Issuer_CommodityExposureFactor					NUMERIC(28,10)	NULL
	, Issuer_FIExposureFactor							NUMERIC(28,10)	NULL
	, Issuer_CRExposureFactor							NUMERIC(28,10)	NULL
	, PRIMARY KEY CLUSTERED(Issuer_Code)
)

IF OBJECT_ID('dbo.TB_fact_portfolios','U') IS NOT NULL DROP TABLE dbo.TB_fact_portfolios
CREATE TABLE dbo.TB_fact_portfolios
(
	  PositionDate								DATE			NOT NULL
	, Portfolio_PSPPortfolioCode				VARCHAR(50)		NOT NULL
	, Portfolio_PSPPortfolioID					INT				NULL
	, Portfolio_Name							VARCHAR(200)	NULL
	, Portfolio_Type							VARCHAR(50)		NULL
	, Portfolio_MarketType						VARCHAR(50)		NULL
	, Portfolio_AssetClass						VARCHAR(50)		NULL
	, Portfolio_InvestmentTeam					VARCHAR(50)		NULL
	, Portfolio_ManagerType						VARCHAR(50)		NULL
	, Portfolio_ManagingStyle					VARCHAR(50)		NULL
	, Portfolio_ManagingDepartment				VARCHAR(50)		NULL
	, Portfolio_OwnerDepartment					VARCHAR(50)		NULL
	, Portfolio_Position_Count					INT				NULL
	, Portfolio_Position_MarketValue_CAD		NUMERIC(28,10)	NULL
	, Portfolio_Position_NetAssetValue_CAD		NUMERIC(28,10)	NULL
	, Portfolio_Internal_Count					INT				NULL
	, Portfolio_Internal_MarketValue_CAD		NUMERIC(28,10)	NULL
	, Portfolio_Internal_NetAssetValue_CAD		NUMERIC(28,10)	NULL
	, Portfolio_PooledFund_Count				INT				NULL
	, Portfolio_PooledFund_MarketValue_CAD		NUMERIC(28,10)	NULL
	, Portfolio_PooledFund_NetAssetValue_CAD	NUMERIC(28,10)	NULL
	, PRIMARY KEY CLUSTERED(PositionDate, Portfolio_PSPPortfolioCode)
)