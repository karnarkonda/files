SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      PA Ratelle
-- Create Date: 2023-02-16
-- Description: 
-- =============================================
ALTER PROCEDURE dbo.UP_LoadStaging_fact_constituents
(
      @temporary_table_constituents_data VARCHAR(MAX) = 'ST_fact_constituents'
)
AS
BEGIN

	/*AAA**************************************************************************************************/
	/** Create Temporary Tables ***************************************************************************/
	/******************************************************************************************************/
    SET NOCOUNT ON;
	CREATE TABLE #TB_temporary_fact_constituents
	(
		  [DataKey]										INT IDENTITY(1,1) 
		, PositionDate									DATE			NOT NULL
		, Constituee_PSPInstrumentID					INT				NOT NULL
		, Constituee_Type								VARCHAR(50)		NULL
		, Constituent_PSPInstrumentID					INT				NOT NULL
		, Constituent_Family							VARCHAR(50)		NULL
		, Constituent_PSPInstrumentCategorizationID		NUMERIC(28,10)	NULL
		, Constituent_PSPInstrumentCategorizationCode	VARCHAR(200)	NULL
		, Constituent_Description						VARCHAR(200)	NULL
		, Constituent_Market							VARCHAR(200)	NULL
		, Constituent_Type								VARCHAR(200)	NULL
		, Constituent_IssuerCode						NUMERIC(28,10)	NULL
		, Constituent_CurrencyCode						VARCHAR(3)		NOT NULL
		, Constituent_Weight							NUMERIC(28,10)	NOT NULL
		, Constituent_IssuerExposureFactor				NUMERIC(28,10)	NULL
		, Constituent_EquityExposureFactor				NUMERIC(28,10)	NULL
		, PRIMARY KEY CLUSTERED(PositionDate, Constituee_PSPInstrumentID, Constituent_PSPInstrumentID)
	)

	CREATE TABLE #TB_temporary_fact_constituents_keys
	(
		  PositionDate										DATE			NOT NULL
		, Constituee_PSPInstrumentID						VARCHAR(50)		NOT NULL
	)
	
	/*BBB**************************************************************************************************/
	/** Insert Into Temporary Table ***********************************************************************/
	/******************************************************************************************************/
	DECLARE @insertion_query_portfolios_data VARCHAR(MAX);
	SET @insertion_query_portfolios_data = '
	INSERT INTO #TB_temporary_fact_constituents
	(
		  PositionDate									
		, Constituee_PSPInstrumentID					
		, Constituee_Type								
		, Constituent_PSPInstrumentID					
		, Constituent_Family							
		, Constituent_PSPInstrumentCategorizationID		
		, Constituent_PSPInstrumentCategorizationCode	
		, Constituent_Description						
		, Constituent_Market							
		, Constituent_Type								
		, Constituent_IssuerCode						
		, Constituent_CurrencyCode						
		, Constituent_Weight							
		, Constituent_IssuerExposureFactor				
		, Constituent_EquityExposureFactor					
	)
	SELECT 
		  CAST(PositionDate	AS DATE)
		, CAST(Constituee_PSPInstrumentID					AS INT)				
		, Constituee_Type								
		, CAST(Constituent_PSPInstrumentID					AS INT)					
		, Constituent_Family							
		, CONVERT(INT, CONVERT(FLOAT, Constituent_PSPInstrumentCategorizationID))
		, Constituent_PSPInstrumentCategorizationCode	
		, Constituent_Description						
		, Constituent_Market							
		, Constituent_Type								
		, Constituent_IssuerCode						
		, Constituent_CurrencyCode						
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Constituent_Weight))							
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Constituent_IssuerExposureFactor))				
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Constituent_EquityExposureFactor))				
	FROM ' + @temporary_table_constituents_data

	EXEC(@insertion_query_portfolios_data)
	PRINT('Inserted ' + CAST(@@rowcount AS VARCHAR) + ' rows into temporary staging table')
	
	/*CCC**************************************************************************************************/
	/** Generate Data Atomicity ***************************************************************************/
	/******************************************************************************************************/
	INSERT INTO #TB_temporary_fact_constituents_keys
	(
		  PositionDate				
		, Constituee_PSPInstrumentID
	)
	SELECT
		  PositionDate				
		, Constituee_PSPInstrumentID
	FROM #TB_temporary_fact_constituents
	GROUP BY 
		  PositionDate				
		, Constituee_PSPInstrumentID
	
	/*DDD**************************************************************************************************/
	/** Delete original data based on atomicity ***********************************************************/
	/******************************************************************************************************/
	DELETE FROM P
	FROM #TB_temporary_fact_constituents_keys PK
	INNER JOIN dbo.TB_fact_constituents P ON P.PositionDate = PK.PositionDate AND P.Constituee_PSPInstrumentID = PK.Constituee_PSPInstrumentID

	PRINT('Deleted ' + CAST(@@rowcount AS VARCHAR) + ' rows into dbo.TB_fact_constituents')
	
	/*EEE**************************************************************************************************/
	/** Insert Into Portfolios ****************************************************************************/
	/******************************************************************************************************/
	INSERT INTO dbo.TB_fact_constituents
	(
		  PositionDate									
		, Constituee_PSPInstrumentID					
		, Constituee_Type								
		, Constituent_PSPInstrumentID					
		, Constituent_Family							
		, Constituent_PSPInstrumentCategorizationID		
		, Constituent_PSPInstrumentCategorizationCode	
		, Constituent_Description						
		, Constituent_Market							
		, Constituent_Type								
		, Constituent_IssuerCode						
		, Constituent_CurrencyCode						
		, Constituent_Weight							
		, Constituent_IssuerExposureFactor				
		, Constituent_EquityExposureFactor							
	)
	SELECT
		  PositionDate									
		, Constituee_PSPInstrumentID					
		, Constituee_Type								
		, Constituent_PSPInstrumentID					
		, Constituent_Family							
		, Constituent_PSPInstrumentCategorizationID		
		, Constituent_PSPInstrumentCategorizationCode	
		, Constituent_Description						
		, Constituent_Market							
		, Constituent_Type								
		, Constituent_IssuerCode						
		, Constituent_CurrencyCode						
		, Constituent_Weight							
		, Constituent_IssuerExposureFactor				
		, Constituent_EquityExposureFactor				
	FROM #TB_temporary_fact_constituents

	PRINT('Inserted ' + CAST(@@rowcount AS VARCHAR)  + ' rows into dbo.TB_fact_constituents')

END
GO
