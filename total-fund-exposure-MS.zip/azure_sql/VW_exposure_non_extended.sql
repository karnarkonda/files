SELECT 
	  P.PositionDate
	, P.Portfolio_PSPPortfolioCode
	, P.Portfolio_PSPPortfolioID
	, P.Portfolio_Name
	, P.Portfolio_Type
	, P.Portfolio_MarketType
	, P.Portfolio_AssetClass
	, P.Portfolio_InvestmentTeam
	, P.Portfolio_ManagerType
	, P.Portfolio_ManagingStyle
	, P.Portfolio_ManagingDepartment
	, P.Portfolio_OwnerDepartment

	, TFE.Object_Type
	, TFE.Position_Type
	, TFE.Position_Source

	, TFE.Instrument_CurrencyCode
	, TFE.Instrument_ReportingCurrencyCode
	
	, TFE.Instrument_PSPInstrumentID
	, TFE.Instrument_PSPInstrumentCategorizationID
	, TFE.Instrument_PSPInstrumentCategorizationCode
	, TFE.Instrument_Description

	, TFE.UltimateUnderlying_PSPInstrumentID
	, TFE.UltimateUnderlying_PSPInstrumentCategorizationID
	, TFE.UltimateUnderlying_PSPInstrumentCategorizationCode
	, TFE.UltimateUnderlying_Description
	
	, TFE.Leg_PSPInstrumentLegID
	, TFE.Leg_Type
	, TFE.Leg_Direction
	, TFE.Leg_PositionLevel

	, TFE.Option_Style

	--Issuer Data
	, I.Issuer_Code
	, I.Issuer_Name
	, I.Issuer_PSPLegalEntityID
	, I.Issuer_RiskLocationCountryCode
	, I.Issuer_NormalizedCountryCode
	,I.Issuer_BICSBETAClassificationID
	, I.Issuer_BICSBETASectorCode
	, I.Issuer_BICSBETASectorName
	, I.Issuer_BICSBETAIndustryGroupCode
	, I.Issuer_BICSBETAIndustryGroupName

	, ISNULL(I.Issuer_UltimateParentCode					 , I.Issuer_Code)						AS 'Issuer_UltimateParentCode'
	, ISNULL(I.Issuer_UltimateParentName					 , I.Issuer_Name)						AS 'Issuer_UltimateParentName'
	, ISNULL(I.Issuer_UltimateParentPSPLegalEntityID		 , I.Issuer_PSPLegalEntityID)			AS 'Issuer_UltimateParentPSPLegalEntityID'
	, ISNULL(I.Issuer_UltimateParentRiskLocationCountryCode	 , I.Issuer_RiskLocationCountryCode)	AS 'Issuer_UltimateParentRiskLocationCountryCode'
	, ISNULL(I.Issuer_UltimateParentNormalizedCountryCode	 , I.Issuer_NormalizedCountryCode)		AS 'Issuer_UltimateParentNormalizedCountryCode'
	, ISNULL(I.Issuer_UltimateParentBICSBETAClassificationID , I.Issuer_BICSBETAClassificationID)   AS 'Issuer_UltimateParentBICSBETAClassificationID'
	, ISNULL(I.Issuer_UltimateParentBICSBETASectorCode		 , I.Issuer_BICSBETASectorCode)			AS 'Issuer_UltimateParentBICSBETASectorCode'
	, ISNULL(I.Issuer_UltimateParentBICSBETASectorName		 , I.Issuer_BICSBETASectorName)			AS 'Issuer_UltimateParentBICSBETASectorName'
	, ISNULL(I.Issuer_UltimateParentBICSBETAIndustryGroupCode, I.Issuer_BICSBETAIndustryGroupCode)	AS 'Issuer_UltimateParentBICSBETAIndustryGroupCode'
	, ISNULL(I.Issuer_UltimateParentBICSBETAIndustryGroupName, I.Issuer_BICSBETAIndustryGroupName)	AS 'Issuer_UltimateParentBICSBETAIndustryGroupName'

	--Exposure Data
	, ISNULL(TFE.Position_NetAssetValue_CAD ,0) AS NetAssetValue_CAD
	, ISNULL(TFE.Exposure_CR			   , 0) AS Exposure_CR		
	, ISNULL(TFE.Exposure_FI			   , 0) AS Exposure_FI		
	, ISNULL(TFE.Exposure_FX			   , 0) AS Exposure_FX			    
	, ISNULL(TFE.Exposure_Issuer		   , 0) AS Exposure_Issuer		    
	, ISNULL(TFE.Exposure_Equity		   , 0) AS Exposure_Equity		    
	, ISNULL(TFE.Exposure_Commodity		   , 0) AS Exposure_Commodity	    
	
	--Risk Data
	, TFE.MostRecent_CalendarKey
	, TFE.BatchKey
	, TFE.Portfolio_Key 
	, TFE.Instrument_Key 
	, TFE.RiskMetricsPositionType
	, CASE WHEN TFE.use_pooled_fund_calculations=0 THEN TFE.normal_calculation_family ELSE TFE.exotic_calculation_family END AS 'calc_formula'
	, CASE WHEN TFE.use_pooled_fund_calculations=0 THEN 'Normal' ELSE 'Exotic' END AS 'calc_type'
FROM dbo.TB_fact_portfolios P
INNER JOIN dbo.TB_fact_exposure TFE ON P.Portfolio_PSPPortfolioID = TFE.Portfolio_PSPPortfolioID AND P.PositionDate = TFE.PositionDate
LEFT JOIN dbo.TB_dimension_issuers I ON I.Issuer_Code = TFE.UltimateUnderlying_IssuerCode
WHERE
		P.PositionDate = '2022-11-11' 
	AND P.Portfolio_PSPPortfolioCode = 'CEA513'