EXEC dbo.UP_LoadStaging_fact_portfolios
	  @temporary_table_portfolios_data = 'ST_fact_portfolios'

EXEC dbo.UP_LoadStaging_fact_constituents
	  @temporary_table_constituents_data = 'ST_fact_constituents'

EXEC dbo.UP_LoadStaging_fact_exposure
	  @temporary_table_exposure_data = 'ST_fact_exposure'



	  	INSERT INTO #TB_temporary_fact_exposure
	(
		  PositionDate											
		, Object_Type											
		, Position_Type											
		, Position_Source										
		, Portfolio_PSPPortfolioCode							
		, Portfolio_PSPPortfolioID								
		, Instrument_CurrencyCode								
		, Instrument_ReportingCurrencyCode						
		, Instrument_PSPInstrumentID							
		, Instrument_PSPInstrumentCategorizationID				
		, Instrument_PSPInstrumentCategorizationCode			
		, Instrument_Description								
		, UltimateUnderlying_PSPInstrumentID					
		, UltimateUnderlying_PSPInstrumentCategorizationID		
		, UltimateUnderlying_PSPInstrumentCategorizationCode	
		, UltimateUnderlying_Description						
		, UltimateUnderlying_IssuerCode							
		, UltimateUnderlying_IndexProxyPSPInstrumentID			
		, Leg_PSPInstrumentLegID								
		, Leg_Type												
		, Leg_Direction											
		, Leg_PositionLevel										
		, Option_Style											
		, Position_NetAssetValue_CAD							
		, Exposure_FX											
		, Exposure_FI											
		, Exposure_CR											
		, Exposure_Issuer										
		, Exposure_Equity										
		, Exposure_FX2											
		, Exposure_Commodity									
		, MostRecent_CalendarKey								
		, BatchKey												
		, Portfolio_Key											
		, Instrument_Key										
		, RiskMetricsPositionType								
		, normal_calculation_family								
		, exotic_calculation_family								
		, use_pooled_fund_calculations											
	)
	SELECT 
		  PositionDate											
		, Object_Type											
		, Position_Type											
		, Position_Source										
		, Portfolio_PSPPortfolioCode							
		, CAST(Portfolio_PSPPortfolioID				   			AS INT)	
		, Instrument_CurrencyCode								
		, Instrument_ReportingCurrencyCode						
		, CAST(Instrument_PSPInstrumentID						AS INT)						
		, CAST(Instrument_PSPInstrumentCategorizationID			AS INT)				
		, Instrument_PSPInstrumentCategorizationCode			
		, Instrument_Description								
		, CAST(UltimateUnderlying_PSPInstrumentID				AS INT)					
		, UltimateUnderlying_PSPInstrumentCategorizationID		
		, UltimateUnderlying_PSPInstrumentCategorizationCode	
		, UltimateUnderlying_Description						
		, UltimateUnderlying_IssuerCode							
		, CAST(UltimateUnderlying_IndexProxyPSPInstrumentID			
		, CAST(Leg_PSPInstrumentLegID					   		AS INT)								
		, Leg_Type												
		, Leg_Direction											
		, Leg_PositionLevel										
		, Option_Style											
		, Position_NetAssetValue_CAD							
		, Exposure_FX											
		, Exposure_FI											
		, Exposure_CR											
		, Exposure_Issuer										
		, Exposure_Equity										
		, Exposure_FX2											
		, Exposure_Commodity									
		, MostRecent_CalendarKey								
		, CAST(BatchKey						   					AS INT)											
		, CAST(Portfolio_Key					   				AS INT)											
		, CAST(Instrument_Key					   				AS INT)										
		, RiskMetricsPositionType								
		, normal_calculation_family								
		, exotic_calculation_family								
		, use_pooled_fund_calculations								
	FROM ST_fact_exposure