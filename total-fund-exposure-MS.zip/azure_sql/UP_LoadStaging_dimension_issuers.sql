SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      PA Ratelle
-- Create Date: 2023-02-16
-- Description: 
-- =============================================
ALTER PROCEDURE dbo.UP_LoadStaging_dimension_issuers
(
      @temporary_table_issuers_data VARCHAR(MAX) = 'ST_dimension_issuers'
)
AS
BEGIN

	/*AAA**************************************************************************************************/
	/** Create Temporary Tables ***************************************************************************/
	/******************************************************************************************************/
    SET NOCOUNT ON;
	CREATE TABLE #TB_temporary_dimension_issuers
	(
		  Issuer_Code										INT				NOT NULL
		, Issuer_Name										VARCHAR(200)	NULL
		, Issuer_PSPLegalEntityID							INT				NULL
		, Issuer_UltimateParentCode							INT				NULL
		, Issuer_UltimateParentName							VARCHAR(200)	NULL
		, Issuer_RiskLocationCountryCode					VARCHAR(4)		NULL
		, Issuer_NormalizedCountryCode						VARCHAR(4)		NULL
		, Issuer_BICSBETAClassificationID					INT				NULL
		, Issuer_BICSBETASectorCode							INT				NULL
		, Issuer_BICSBETASectorName							VARCHAR(200)	NULL
		, Issuer_BICSBETAIndustryGroupCode					INT				NULL
		, Issuer_BICSBETAIndustryGroupName					VARCHAR(200)	NULL
		, Issuer_UltimateParentPSPLegalEntityID				NUMERIC(28,10)	NULL
		, Issuer_UltimateParentRiskLocationCountryCode		VARCHAR(4)		NULL
		, Issuer_UltimateParentNormalizedCountryCode		VARCHAR(4)		NULL
		, Issuer_UltimateParentBICSBETAClassificationID		INT				NULL
		, Issuer_UltimateParentBICSBETASectorCode			INT				NULL
		, Issuer_UltimateParentBICSBETASectorName			VARCHAR(200)	NULL
		, Issuer_UltimateParentBICSBETAIndustryGroupCode	INT				NULL
		, Issuer_UltimateParentBICSBETAIndustryGroupName	VARCHAR(200)	NULL
		, Issuer_EquityExposureFactor						NUMERIC(28,10)	NULL
		, Issuer_IssuerExposureFactor						NUMERIC(28,10)	NULL
		, Issuer_FxExposureFactor							NUMERIC(28,10)	NULL
		, Issuer_CommodityExposureFactor					NUMERIC(28,10)	NULL
		, Issuer_FIExposureFactor							NUMERIC(28,10)	NULL
		, Issuer_CRExposureFactor							NUMERIC(28,10)	NULL
		, PRIMARY KEY CLUSTERED(Issuer_Code)
	)

	CREATE TABLE #TB_temporary_dimension_issuers_keys
	(
		  Issuer_Code										INT				NOT NULL
	)
	
	/*BBB**************************************************************************************************/
	/** Insert Into Temporary Table ***********************************************************************/
	/******************************************************************************************************/
	DECLARE @insertion_query_exposure_data VARCHAR(MAX);
	SET @insertion_query_exposure_data = '
	INSERT INTO #TB_temporary_dimension_issuers
	(
		  Issuer_Code									
		, Issuer_Name						
		, Issuer_PSPLegalEntityID			
		, Issuer_UltimateParentCode			
		, Issuer_UltimateParentName			
		, Issuer_RiskLocationCountryCode	
		, Issuer_NormalizedCountryCode		
		, Issuer_BICSBETAClassificationID	
		, Issuer_BICSBETASectorCode			
		, Issuer_BICSBETASectorName			
		, Issuer_BICSBETAIndustryGroupCode	
		, Issuer_BICSBETAIndustryGroupName					
		, Issuer_UltimateParentPSPLegalEntityID				
		, Issuer_UltimateParentRiskLocationCountryCode		
		, Issuer_UltimateParentNormalizedCountryCode		
		, Issuer_UltimateParentBICSBETAClassificationID	
		, Issuer_UltimateParentBICSBETASectorCode		
		, Issuer_UltimateParentBICSBETASectorName		
		, Issuer_UltimateParentBICSBETAIndustryGroupCode
		, Issuer_UltimateParentBICSBETAIndustryGroupName	
		, Issuer_EquityExposureFactor						
		, Issuer_IssuerExposureFactor						
		, Issuer_FxExposureFactor							
		, Issuer_CommodityExposureFactor					
		, Issuer_FIExposureFactor							
		, Issuer_CRExposureFactor																	
	)
	SELECT 
		  CAST(CAST(Issuer_Code							AS FLOAT) AS INT)						
		, Issuer_Name					
		, CAST(CAST(Issuer_PSPLegalEntityID				AS FLOAT) AS INT)				
		, CAST(CAST(Issuer_UltimateParentCode			AS FLOAT) AS INT)				
		, Issuer_UltimateParentName											
		, Issuer_RiskLocationCountryCode					
		, Issuer_NormalizedCountryCode			
		, CAST(CAST(Issuer_BICSBETAClassificationID		AS FLOAT) AS INT)				
		, CAST(CAST(Issuer_BICSBETASectorCode	        AS FLOAT) AS INT)											
		, Issuer_BICSBETASectorName			
		, CAST(CAST(Issuer_BICSBETAIndustryGroupCode	AS FLOAT) AS INT)				
		, Issuer_BICSBETAIndustryGroupName					
		,  CAST(CAST(Issuer_UltimateParentPSPLegalEntityID AS FLOAT) AS INT)			
		, Issuer_UltimateParentRiskLocationCountryCode		
		, Issuer_UltimateParentNormalizedCountryCode		
		, CAST(CAST(Issuer_UltimateParentBICSBETAClassificationID	AS FLOAT) AS INT)	
		, CAST(CAST(Issuer_UltimateParentBICSBETASectorCode			AS FLOAT) AS INT)
		, Issuer_UltimateParentBICSBETASectorName			
		, CAST(CAST(Issuer_UltimateParentBICSBETAIndustryGroupCode	AS FLOAT) AS INT)
		, Issuer_UltimateParentBICSBETAIndustryGroupName	
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Issuer_EquityExposureFactor	))						
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Issuer_IssuerExposureFactor	))					
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Issuer_FxExposureFactor		))					
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Issuer_CommodityExposureFactor	))				
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Issuer_FIExposureFactor		))						
		, CONVERT(NUMERIC(28,10), CONVERT(FLOAT, Issuer_CRExposureFactor		))							
	FROM ' + @temporary_table_issuers_data

	print(@insertion_query_exposure_data)
	EXEC(@insertion_query_exposure_data)
	PRINT('Inserted ' + CAST(@@rowcount AS VARCHAR) + ' rows into temporary staging table')
	
	/*CCC**************************************************************************************************/
	/** Generate Data Atomicity ***************************************************************************/
	/******************************************************************************************************/
	INSERT INTO #TB_temporary_dimension_issuers_keys
	(
		  Issuer_Code
	)
	SELECT
		  Issuer_Code		
	FROM #TB_temporary_dimension_issuers
	GROUP BY 
		  Issuer_Code		
	
	/*DDD**************************************************************************************************/
	/** Delete original data based on atomicity ***********************************************************/
	/******************************************************************************************************/
	DELETE FROM P
	FROM #TB_temporary_dimension_issuers_keys PK
	INNER JOIN dbo.TB_dimension_issuers P ON P.Issuer_Code = PK.Issuer_Code

	PRINT('Deleted ' + CAST(@@rowcount AS VARCHAR) + ' rows into dbo.TB_dimension_issuers')
	
	/*EEE**************************************************************************************************/
	/** Insert Into Portfolios ****************************************************************************/
	/******************************************************************************************************/
	INSERT INTO dbo.TB_dimension_issuers
	(
		  Issuer_Code									
		, Issuer_Name						
		, Issuer_PSPLegalEntityID			
		, Issuer_UltimateParentCode			
		, Issuer_UltimateParentName			
		, Issuer_RiskLocationCountryCode	
		, Issuer_NormalizedCountryCode		
		, Issuer_BICSBETAClassificationID	
		, Issuer_BICSBETASectorCode			
		, Issuer_BICSBETASectorName			
		, Issuer_BICSBETAIndustryGroupCode	
		, Issuer_BICSBETAIndustryGroupName					
		, Issuer_UltimateParentPSPLegalEntityID				
		, Issuer_UltimateParentRiskLocationCountryCode		
		, Issuer_UltimateParentNormalizedCountryCode		
		, Issuer_UltimateParentBICSBETAClassificationID	
		, Issuer_UltimateParentBICSBETASectorCode		
		, Issuer_UltimateParentBICSBETASectorName		
		, Issuer_UltimateParentBICSBETAIndustryGroupCode
		, Issuer_UltimateParentBICSBETAIndustryGroupName	
		, Issuer_EquityExposureFactor						
		, Issuer_IssuerExposureFactor						
		, Issuer_FxExposureFactor							
		, Issuer_CommodityExposureFactor					
		, Issuer_FIExposureFactor							
		, Issuer_CRExposureFactor							
	)
	SELECT
		  Issuer_Code									
		, Issuer_Name						
		, Issuer_PSPLegalEntityID			
		, Issuer_UltimateParentCode			
		, Issuer_UltimateParentName			
		, Issuer_RiskLocationCountryCode	
		, Issuer_NormalizedCountryCode		
		, Issuer_BICSBETAClassificationID	
		, Issuer_BICSBETASectorCode			
		, Issuer_BICSBETASectorName			
		, Issuer_BICSBETAIndustryGroupCode	
		, Issuer_BICSBETAIndustryGroupName					
		, Issuer_UltimateParentPSPLegalEntityID				
		, Issuer_UltimateParentRiskLocationCountryCode		
		, Issuer_UltimateParentNormalizedCountryCode		
		, Issuer_UltimateParentBICSBETAClassificationID	
		, Issuer_UltimateParentBICSBETASectorCode		
		, Issuer_UltimateParentBICSBETASectorName		
		, Issuer_UltimateParentBICSBETAIndustryGroupCode
		, Issuer_UltimateParentBICSBETAIndustryGroupName	
		, Issuer_EquityExposureFactor						
		, Issuer_IssuerExposureFactor						
		, Issuer_FxExposureFactor							
		, Issuer_CommodityExposureFactor					
		, Issuer_FIExposureFactor							
		, Issuer_CRExposureFactor					
	FROM #TB_temporary_dimension_issuers

	PRINT('Inserted ' + CAST(@@rowcount AS VARCHAR)  + ' rows into dbo.TB_dimension_issuers')

END
GO
