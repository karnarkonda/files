Write-Host ">>>> Initializing project dependencies & tooling <<<<<<<" -ForegroundColor Green

$root_dir = Get-Location
$venv_dir = $root_dir.ToString() + "\.venv"
$activate_path = $venv_dir + "\Scripts\Activate.ps1"
$status = 1

# Setup Python virtual env for project
if (Test-Path -Path  $venv_dir) {
    Write-Host ".... Found existing python virtual env: " $venv_dir -ForegroundColor Yellow
    & $activate_path
    python -m pip -q install --upgrade pip
    pip install -q -r .\requirements\psp_requirements.txt

} else {
     Write-Host ".... Creating python virtual Environment." -ForegroundColor Yellow
     python -m venv .venv
     & $activate_path
     python -m pip install --upgrade pip
     pip install -r .\requirements\psp_requirements.txt
}

# Enable chocolatey to install Make tool
if (Get-Command -Name choco -ErrorAction SilentlyContinue)
{
    Write-Host ".... Chocolatey exists." -ForegroundColor Yellow
}
else {
    Write-Host ".... Installing Chocolatey." -ForegroundColor Yellow
    $status = Set-ExecutionPolicy Bypass -Scope Process -Force; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
    if ($status -ne 1){
        Write-Host "===================================================================================" -ForegroundColor Red
        Write-Host " >>> Chocolatey installation FAILED! Please ensure you are running as Administrator" -ForegroundColor Red -NoNewline
        Write-Host -ForegroundColor Green ([System.Char]::ConvertFromUtf32(0x1F4A9))
        Write-Host ""
        return
    }
}


if (Get-Command -Name make -ErrorAction SilentlyContinue)
{
    Write-Host ".... Make tool exists." -ForegroundColor Yellow
    Write-Host "===================================================================================" -ForegroundColor Green
    Write-Host " >>>>>> Initialization Completed!.... " -ForegroundColor Green -NoNewline
    Write-Host -ForegroundColor Green ([System.Char]::ConvertFromUtf32(0x1F4A5))
    Write-Host ""
}
else {
    choco install make
    Write-Host ".... Installing Make tool." -ForegroundColor Yellow
    Write-Host "===================================================================================" -ForegroundColor Green
    Write-Host " >>>>>> Initialization Completed!.... " -ForegroundColor Green -NoNewline
    Write-Host -ForegroundColor Green ([System.Char]::ConvertFromUtf32(0x1F4A5))
    Write-Host ""
}

    
    