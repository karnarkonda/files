## Total Fund Exposure Microservice (TFE-MS)

The TFE microservice generates portfolio exposure benchmark data periodically (daily).


### Setup
To run the project on local/dev environment, certain tools and dependencies are required.

- **Required dependency**
  - Python 3.9 or later

First checkout this project repo to your local machine.
  - **Next, start a Powershell terminal (Run as Administrator). From within the project root directory, execute the powershell script.**

    `PS C:\path\to\project\total_fund_exposure_MS> .\init_project.ps1`

    __this sets up a python virtual environment for the project (if it doesn't exist), installs the python dependencies & command line tools__

  - **Start the application service with the command below.**

    `PS C:\path\to\project\total_fund_exposure_MS> make start-dev`


### Development
- TODO: Setting up VS-Code debugging for project development.
- TESTING:
  - **Run the command below to execute the tests defined for the project modules.**

    `PS C:\path\to\project\total_fund_exposure_MS> make test` - _runs all tests_

    `PS C:\path\to\project\total_fund_exposure_MS> make test path=.\path\to\file` -  _runs a specific test_

    _See screenshot of test run_

    ![make_test.png](/docs/make_test.png)



### Code Compliance
Contributing code to this project requires for it to be compliant with PEP8 standards.
Follow the process itemized below to ensure your code complies with the coding standard for the project.

1. **Run the command below to check if your newly authored code/changes are compliant.**

   `PS C:\path\to\project\total_fund_exposure_MS> make check path=.\path\to\file`

   _If there are any warnings with the format/syntax of the new or edited code, it will show up on your terminal with an erring report.(sample below)_

   ![make_check.png](/docs/make_check.png)

2. **Run the command below to fix any PEP8 standards issue with your code.**

   The command attempts to auto-fix errors/warnings, however some may require a manual fix.

   `PS C:\path\to\project\total_fund_exposure_MS> make check-fix path=.\path\to\file`

   _Output of the fix command displays as below._

   ![make_check_fix.png](/docs/make_check_fix.png)

3. **Finally, repeat Step 1. to check if there are any more unfixed errors/warnings.**

   You have to manually fix any outstanding errors/warnings that could not be automatically fixed.


